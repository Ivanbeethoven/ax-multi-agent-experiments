# 2026-10-28 重整后的实验计划

这是一份执行前协议。当前整理工作只在本机进行，不创建云实例、不启动实验。正式实验必须先通过能力资格检查，再按本文件的生命周期口径记录结果。

## 共同装置和版本合同

本机整理环境是 us-east-1 的 8 核、约 30 GiB 内存主机，数据盘有约 186 GiB 可用并挂载在 `/work`。它只用于文档、归档、构建和小型 smoke；正式四节点对象服务、worker、Redis 和监控资源沿用 `paper-design/design.json` 的规划，实际节点身份和资源在每批记录。ext4/XFS 只作系统调用和设备标定，并单独写明持久性和故障模型。

每批开始前冻结所有版本和输入：

1. 执行 `git ls-remote https://github.com/Ivanbeethoven/rustfs refs/heads/feat/dynamic-block-size-rebased`，把完整输出和解析时间写入本批 `backend-pin.json`。
2. `backend-pin.json` 至少写 `repository`、`branch`、`frozen_commit`、`image_reference`、`image_digest`、`built_from_commit`、`resolved_at`、`brewfs_client_sha` 和 `resolved_by`。BrewFS 客户端版本单独记录。
3. 从 `frozen_commit` 构建或验证 RustFS 镜像；`docker inspect -f '{{ index .Config.Labels "org.opencontainers.image.revision" }}' IMAGE` 必须等于 `frozen_commit`。固定 digest 但无法追溯来源的镜像不合格。
4. 生成部署 spec 时遇到 `REPLACE_WITH` 或 `REGISTRY/` 立即失败。分支不可读、构建失败或镜像来源不匹配时阻断整批，并在 `backend-pin.json` 写 `blocked_reason`，不换分支、不用官方 `latest`。
5. 运行后从服务端持久元数据、布局解码工具和请求日志记录实际生效的 block size 与布局。配置值没有造成实际布局变化时，对象粒度实验不具备资格。

四个明确配置名称如下：

| 配置 | 组成 | 用途 |
|---|---|---|
| BrewFS flat-v1 | BrewFS 基础路径、原生元数据 | 同系统基础参照 |
| BrewFS Overlay + 原生封存下层 | Overlay、原生 lower | 观察 Delta 和工作区路径；对应现有设计的第二项配置 |
| BrewFS Overlay + Packed 下层 | 与上项相同的 Overlay、固定 Packed lower | 隔离只读元数据表示；对应现有设计的第三项配置 |
| JuiceFS | JuiceFS、同一 Redis/RustFS 资源 | 外部成熟系统对照 |

Overlay 两组必须面对同一固定版本、相同 payload、缓存总预算和对象布局；合法的不可变缓存可以保留。JuiceFS 分支使用原生 clone，迁移允许重开已有远端目录；没有 fork 的系统必须真正物化等价隔离状态并计费。

每个批次保存 `batch-manifest.json`、`backend-pin.json`、配置和输入摘要、命令及返回码、阶段事件、资源采样、服务指标、对象/版本清单、内容断言、namespace digest、失败原因和最终 readback。阶段至少分开记录：准备、发令、首个正确操作、应用返回、远端确认、另一客户端可恢复读取、排空和独立终检。应用返回早于远端确认时，不能把前者当作完成。

独立样本是完整批次或配对区组；请求、兄弟状态、同一 trace 的复制和复用前缀都不是额外样本。先做三个独立 pilot，再依据方差和最小有意义效果冻结正式批次数。所有失败保留，修复后使用新批次。

## 基础能力和语义资格

**JuiceFS 对照位。** JuiceFS 在同一 Redis、同一 RustFS S3 后端和同一 payload 上执行创建、读取、覆盖、truncate、rename、unlink、sync 及重开 smoke；记录同样的独立 readback 和元数据确认。JuiceFS 没有 BrewFS Packed lower 和同一 fork 语义的地方，只作语义/连通性对照，不参加 Packed 或 BrewFS 专有能力排名。


目的：确认每个配置真的提供后续实验需要的操作，并把不支持能力从性能比较中排除。装置使用完整四节点资源；smoke 可用 `fixtures.json` 中 1 GiB 文件树的前 256 个小文件和两个 4 MiB 文件，但必须标明是子集。

负载按固定顺序执行：创建、读取、覆盖、truncate、rename、unlink、sync；先修改父状态再确认版本，从该版本创建两个子状态；父、子、兄弟分别修改；关闭一个 worker 后由另一个 worker 重开已确认版本；删除一半引用并观察回收；最后让新 writer 获得权威后使旧 writer 真正发出迟到写和发布。

记录字段：实际入口和源代码 revision、请求/响应、错误分类、输入与二进制摘要、每个动作的内容和属性断言、独立 readback、namespace digest、GC 可达性、旧 writer 是否被存储层拒绝、实际 B/q 和 Packed manifest。输出 `qualification.json`、操作绑定和证据清单。

准入标准：父修改能被子继承；父、子和兄弟隔离；rename/unlink 后句柄、hardlink、truncate 后 extend 正确；新客户端能重开；reader 或历史版本引用的对象不被 GC；新权威建立后迟到写和发布被拒绝。任何失败标记 `unsupported` 或 `blocked`，不进入正式性能比较。此协议只能证明能力和语义，不能证明吞吐、容量或故障可靠性。

## 属性缓存与重复打开

**JuiceFS 对照位。** JuiceFS 用相同文件大小、相同 4 KiB/64 KiB/1 MiB `open→read→close` 负载，显式记录 `--attr-cache`、`--entry-cache`、`--open-cache`、`--cache-dir` 和实际 FUSE/磁盘字节；与 BrewFS 共用 Redis、RustFS、payload 和缓存预算。JuiceFS 没有 `KEEP_CACHE` FOPEN 标志和 Packed lower，因此只比较重复打开的磁盘字节与 stat 延迟；KEEP_CACHE 机制归因、Packed 指标不排名。


目的：找到安全缓存复用条件，解释 Overlay 的元数据路径开销。

属性缓存使用一个固定文件执行 100,000 次 `stat`，再使用 1,000、10,000、100,000 inode 的轮转工作集。BrewFS flat-v1 与 BrewFS Overlay + 原生封存下层分别测试有效 TTL 0、100 ms、1 s；实现不支持的值写明缺失。记录实际回复 TTL 的分桶/采样、FUSE `getattr`/`lookup`、后端 RPC、CPU、墙钟、p50/p95/p99，以及 TTL 过期、lease 改变和修改边界的正确性。

重复打开对 4 KiB、64 KiB、1 MiB 文件各执行 100–1,000 次 `open → read → close`，只改变 `KEEP_CACHE`。加入单次打开连续读、每次不同 inode、超过缓存的工作集，以及修改、truncate、删除重建。记录 FUSE READ、实际字节、缓存命中、CPU 和墙钟，并逐次核对内容。generation、lease、deadline 约束必须保持；不能仅把 TTL 统一改成 1 秒。该实验不能回答跨节点迁移、Packed 构建偿本或大规模任务完成率。

## 同机四配置写入成本

**JuiceFS 对照位。** JuiceFS 按相同 ABBA/小文件/大文件/随机覆盖/删除负载运行，使用同一 Redis、RustFS、CPU/内存上限和缓存总预算；分别记应用返回、writeback 上传、远端确认、排空和终检。JuiceFS 没有 BrewFS Overlay/Packed lower，故只参加通用写入等待和生命周期列，不参加 Overlay 或 Packed 专属排名。


目的：在同一输入和资源下分解 Overlay、Packed 和外部对照的写入等待，避免把 close 重复计入总时间。

复用 `pytest-full-02` 和固定 ABBA 工作量，在同一机器、同一资源和同一输入下运行四个配置。顺序采用随机化配对区组；补充多小文件、单大文件、随机覆盖和写入中删除。每次 `flush`/`close` 入口记录 dirty 字节、未完成上传和队列长度。

记录准备、回放、排空、终检和完整生命周期；上传等待、元数据提交、锁等待、销毁和远端确认分别记账。每个写入动作报告应用返回、远端确认、另一客户端恢复读取三个时间。ABBA 报告中的累计 close 已包含多次文件周转，不能再作为额外阶段加到墙钟时间。单次重跑是描述性证据，不能给出统计显著性。

## Delta 分支、继承和历史保留

**JuiceFS 对照位。** JuiceFS 在相同父 payload、子数量、修改率、树形和历史保留窗口上使用其原生 clone/snapshot 能力，并记录 clone、首写、save、重开和回收的同层计量；Redis、RustFS、缓存预算和 payload 与 BrewFS 对齐。若本版本/单机后端无法提供可恢复 clone，记录确切错误并将 JuiceFS 该臂标为不参加排名，不用物化复制冒充 clone。


目的：证明成本优势来自隔离状态的创建、修改和长期保留，而不是只来自一次快速 fork。

使用约 1 GiB、32,896 文件的确定性输入。父工作区先完成数据修改、rename、创建、删除和属性变化，再确认版本。子状态数量为 1、16、64；每子初始修改 1 MiB，扩展修改率 0、0.1%、1%、10%、50%。树形固定 32 次 fork、33 个状态，比较星型、四叉树和四条深 8 链；所有形状都访问固定 4 个叶子，每叶 4,096 次 lookup 和 4 KiB 校验读。

记录父准备、fork 到首个正确操作、首次持久写、save、私有元数据、共享对象只计一次后的总存储、查询和小读成本。惰性工作若推迟到首读、首写或保存，必须跟随生命周期计入。BrewFS flat-v1 的物化隔离适配器必须把复制/构建成本列出；JuiceFS 用 clone；缺少能力的配置不排名。

历史保留先做 1,000 和 10,000 个已确认状态，100,000 为扩展。按预注册样本重开最早、最新和多代分支；删除半数引用，保护窗口 600 秒，再观察 3,600 秒。记录逻辑删除、可回收对象、回收排队、实际物理释放和仍被 reader/历史版本引用的对象。主要结果是每增加一个可恢复状态的资源斜率和回收对前台探针的干扰。只存在元数据、无法重开的状态不计入可恢复容量。

## Packed 访问、共享数据库干扰与偿本

**JuiceFS 对照位。** JuiceFS 对同一个 lookup/stat/readdir/read 查询序列、消费者数、缓存冷暖状态和共享数据库探针运行原生目录/对象路径，并记录元数据请求、对象请求、客户端解码和物理读字节；Redis、RustFS、payload、CPU/内存和 8192 MiB cache 预算保持一致。JuiceFS 没有 Packed lower、Packed manifest、索引页/descriptor 指标和打包构建偿本，因此这些列写“不适用”，该配置不参加 Packed 专属排名，只保留通用查询基线。


目的：同时回答“中心数据库少做了什么”“对象服务和客户端多做了什么”以及“首次构建何时回本”。

访问使用 32,768 和 1,048,576 个 1 KiB 文件，每个 session 固定 32,768 个查询，消费者为 1、16、64，访问重叠和不重叠分别记录。查询族包括随机正 lookup、固定正负比例 lookup、inode 属性、相邻名称、readdir 后取属性、lookup 后读取内容。Overlay + 原生封存下层与 Overlay + Packed 下层固定 lower 版本、payload、缓存预算、g/B/q、inline/压缩条件，并区分客户端冷、索引暖、元数据暖。

分层记录 lower/upper/控制数据库请求，索引页、元数据页、descriptor、payload 的对象请求和字节，以及客户端解码、校验、页命中、单飞等待和尾延迟。共享数据库干扰先用无背景探针标定：5 分钟内队列不持续增长，计划到达后 2 秒内完成率至少 99%；取两表示较低的可持续速率为共同基准，写探针固定为其 0.25 倍，背景只读为 0、1、4 倍。完全相同的到达表在达到在途上限后仍记排队、拒绝和截止违约，不能通过减慢发令隐藏拥塞。

Packed 生命周期把首次构建、上传、校验、发布和第一次使用全部计入；原生固定版本的必要准备也计入。每版本复用次数为 1、4、16、64、256，更新率 0.1%、1%、10%，连续 8 个版本，每版本使用 4 或 64 次，历史保留 0 或 600 秒。没有增量打包器时按实际全量构建计费，不假定成本与变化率成正比。CPU 秒、请求数、存储字节和墙钟分别核算，并行阶段不相加。结果必须保留少消费者、频繁更新、低局部性和缓存已热的原生参照不回本边界。

## 对象粒度和动态布局

**JuiceFS 对照位。** JuiceFS 在相同对象长度、读请求列表、缓存预算和 RustFS 后端上运行 whole/range/随机/顺序读，记录其 block-size、GET range、客户端字节、服务端/设备字节和尾延迟。JuiceFS 没有 BrewFS 的 `g`、Packed frame 和 RustFS B/q hint 接线；这些指标标记“不适用”，不把 JuiceFS 默认块大小与 BrewFS 动态布局放在同一排名。


目的：先证明处理变量确实改变了持久布局，再比较性能。

固定定义：`g` 是 BrewFS 客户端分块粒度，`L` 是最终编码后对象长度，`B` 是 RustFS EC 编码块大小，`q` 是 shard 内部校验/读取粒度。以研究分支的 2 data + 2 parity 拓扑为例，B=64 KiB、256 KiB、1 MiB、4 MiB 时应分别解码实际 shard 长度和 q；B=1 MiB 可能与旧布局相同，不能把“没有新 q 标记”当成失败。

资格门保存编译 feature、服务端门控、每个请求的 hint、有效 B、hint 被忽略的原因、数据片/校验片数量、inline/protected 状态和从持久 `xl.meta` 解码的 q。公共 S3 HEAD 没有 q 时，必须使用内部元数据解码工具。四个同设备目录只做功能验证；多盘/多节点性能必须有真实设备身份和资源隔离。

消融分三层：先固定后端布局和读取策略，只改变 g=1、4、8、16 MiB；再固定对象内容、长度和 S3 请求列表，只改变合法 B/q；最后固定持久布局，只改变 Range、whole-object、预取、请求合并和缓存准入。负载包含 4 KiB 随机索引读、64 KiB/1 MiB 读、跨 q/B 边界、尾部、顺序扫描和部分覆盖。报告网络读取放大、设备读取放大和上传放大；服务端 pread 不能代替设备字节。只有资格门确认布局真的改变的组才进入效应比较。该计划不能从单一 hint 推断所有缓存或物理磁盘行为。

## 迁移、恢复和 fencing

**JuiceFS 对照位。** JuiceFS 用相同保存点、冷/暖缓存、迁移数量、pending 修改和故障屏障测重挂/重开、首个正确读、所有权转移与迟到写拒绝；同一 Redis、RustFS、payload 和资源预算保持不变。JuiceFS 不提供 BrewFS Packed 构建、Entity lease/fencing 证据的地方，分别记“不适用/未资格”，不把简单重挂耗时解释为迁移安全能力。


目的：覆盖完整停顿，并验证真实写权威，而不是只测目标挂载耗时。

四个源 worker 承载 16 个工作区，四个目标 worker 预先可用；迁移数量为 0、1、4、8，状态分别带 0、1、16、128 MiB pending 修改，目标分冷和暖。计时从迁移请求开始，包含工具边界等待、drain、版本固定、必要打包、上传、校验、发布和目标取数。报告请求到首个正确文件操作、权威转移、工具完成、剩余任务完成，以及未迁移邻居的尾延迟和按时完成率。

故障由事件屏障控制，覆盖确认前、确认后、目标恢复中断、旧 reader 与 GC 并存、源失去协调连接但仍能访问存储。新 writer 获得权威后，旧 writer 必须真正发出迟到写和发布；检查存储层拒绝和独立 readback 未污染。主要故障点每点 20 次用于时序覆盖，但零失败不能解释为生产可靠性。该协议不能用杀进程替代 fencing，也不能把同宿主容器交接称为跨节点迁移。

## 固定任务完成能力和真实 Agent

**JuiceFS 对照位。** JuiceFS 使用相同冻结 trace、模型、工具权限、worker 并发、截止时间、共享 payload 和 8192 MiB cache 预算，记录准备、工具返回、远端确认、正确完成率和资源消耗。没有 BrewFS fork/Packed/迁移语义的 JuiceFS 任务臂保留原始失败原因并从对应专有排名剔除；只在共同可执行的读写路径上作外部基线。


固定任务主实验使用 7 条 trace、每条 8 份，共 56 个任务；worker 并发为 1、4、16；每任务 1,800 秒，共同观察截止 101,100 秒。只比较通过资格的四个配置；准备共享只计一次但纳入生命周期。报告正确完成曲线、共同截止完成率、合格任务吞吐、任务族延迟、全成功 makespan（仅全成功时）和多服务资源消耗。旧 `campaign.py` 的四 trace/64 任务输出不是本协议任务表。

真实 Agent 在第三个完整工具结果后触发继续、四子 fork 或迁移。固定模型、任务、工具权限、初态和评分器；保存历史、工具结果、环境、文件状态和剩余预算，并要求出现真实后续工具调用。四个子会话等分父任务剩余总模型预算，父任务停止消耗预算，30 分钟期限不因恢复重置，不事后重新分配未用预算。主结果按父任务统计“至少一子正确完成”，同时公布所有子结果和选择规则。合成 `state.json` 的保存/读回不能替代真实会话恢复。

## 与现有文件的一致性、冲突和停止条件

本计划保留 `paper-design/README.md` 的五个研究问题、七份 trace、56 任务、资源分层和“先资格、后性能”的顺序；保留 `design.json` 的三种 BrewFS 配置、Packed 构建成本、对象粒度分层、迁移和任务完成指标。为便于不熟悉历史的人阅读，本文件把设计文件中的作者标签展开为完整配置名称，实验人员不需要记忆历史编号。

现有 `plan.zh.md` 和 `reference/details.zh.md` 仍是参数和操作细节的权威备查资料；本文件补充讨论记录中最高优先级的属性 TTL、`KEEP_CACHE` 重复打开、四配置同机写入分解、共享数据库探针和 RustFS 布局资格门。若旧文档与本文件发生数值冲突，以 `design.json` 的冻结字段为准，并在本批 manifest 写明采用的协议版本；不把历史旧参数回填到旧结果。

任一阶段遇到语义失败、镜像 pin 失败、布局未改变、远端确认缺失、独立 readback 失败、队列持续增长或资源越界，都停止对应性能组并保留失败材料。完成本轮资格、缓存解释、实际 B/q 变化和同机差距归因之前，不开展大规模分支、Packed 偿本、迁移故障全矩阵或真实 Agent 主实验。

## 本批明确不能回答的问题

- 单机一次运行不能给出跨硬件、跨地域或生产级可靠性结论。
- 没有真实 RustFS `backend-pin.json`、镜像 revision 和运行时 B/q 的批次，不能声称动态布局生效。
- `valid=false`、操作数相等或最终树相等不能替代中途读语义、属性、目录视图和独立恢复验证。
- 输入 trace 的事件比例不能直接代表默认挂载的系统调用比例、运行时间占比或缓存命中率。
- 客户端 PUT/GET、服务端 pread 和页缓存计数不能直接等同于物理磁盘或网络 wire 字节。
- 一次 Packed 访问结果不能推出所有查询更快；它可能只证明数据库减压，并把工作转移给对象服务或客户端。
- 没有跨节点协调、真实写者迟到写和 fencing 证据，不能声称迁移安全或恢复可靠。
- 固定 56 任务的正确完成曲线不能推出随 worker 无限扩展的吞吐；扩展实验必须重新定义资源和任务模型。

