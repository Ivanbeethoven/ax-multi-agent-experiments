# This file is maintained automatically by "terraform init".
# Manual edits may be lost in future updates.

provider "registry.terraform.io/aliyun/alicloud" {
  version     = "1.274.0"
  constraints = "1.274.0"
  hashes = [
    "h1:scb4Qj9eFJuGmQYE7Sy7r7mfb+2PJKhtq5ITDcAIxyk=",
    "zh:158b951d83cb14772659c25ccb5ca16596da65ad4b2bf2d36692c9bc60756671",
    "zh:8ba67beca66b7f53dc485e9b809f89197e8b5e9df95fd6ff554d17d94d85533e",
    "zh:a15eac3ed1e9b54c6ebb1f0eade6317f946ac7be5fec083bc0c095c141dc0319",
    "zh:ab0fa081cc974eaa030917520d6a44ae8af3e2650fbf6d41c8e257cf29db79cf",
    "zh:b7ffe3cf957762de9af696d27810771155250077ccf539535b72843574cbb2bb",
    "zh:bb1b696c700a420c3ceadd1fdc15c141e8b88594a8f60042da819422ab3cb59d",
    "zh:e9edea4c4e2d8e93cfa06578a89839cbd20f390389886afa1976a7cf346b015f",
    "zh:eb23f5a8af70069437755c7b431c3a3daf77fc8faf94706389be7032fb41d962",
    "zh:ecda67ec41c14b08e1f83b7c0e06e09b2f6e7a3804357c3ac95e925cae98507c",
    "zh:ee91170b19777abffa75e161b22b4ee7581e688c259cbbd53aa33a367d195ca7",
    "zh:fd0507a5908391075adc1d1be0f1080cfc471181af560308c3951453a5608b04",
  ]
}
