#!/usr/bin/env bash
set -euo pipefail
root=/srv/ax-overlay-open-20261113
cd "$root"
exec >compare-launch-02.log 2>&1
trap 'echo $? > /srv/ax-overlay-open-20261113/compare-launch-02.exit' EXIT
while test ! -f checks.exit || test ! -f release.exit || test ! -f extra-checks.exit; do sleep 5; done
python3 - <<'PY'
import json,re
from pathlib import Path
r=Path('.')
known='workspace::meta_layer::tests::writable_acl_independent_sqlite_instances_keep_mode_acl_during_atime_writes'
assert (r/'release.exit').read_text().strip()=='0'
assert (r/'tdd-ready.exit').read_text().strip()=='101'
assert '1 failed' in (r/'tdd-ready.log').read_text()
assert 'warm permissions must retain one bounded payload' in (r/'tdd-cache.log').read_text()
assert (r/'tdd-cache.exit').read_text().strip()=='101'
log=(r/'checks.log').read_text()
assert 'ready_driver_finishes_in_caller_poll_with_scoped_authority ... ok' in log
assert 'cached_permission_read_shares_snapshot_and_invalidates_after_chmod ... ok' in log
assert 'cargo clippy' in log and 'test result:' in log
failed=re.findall(r'^test (\S+) \.\.\. FAILED$',log,re.M)
assert failed in ([],[known]),failed
assert (r/'checks.exit').read_text().strip()==('101' if failed else '0')
original_checks={p.stem: p.read_text().strip() for p in r.glob('check-*.exit')}
checks=dict(original_checks)
shell_labels=['syntax-'+s for s in ['run_perf_in_container.sh','run_redis_perf.sh','run_juicefs_perf_in_container.sh','run_juicefs_perf.sh']]+['test_perf_report_delta.sh','test_juicefs_direct_matrix.sh','test_juicefs_perf_report.sh']
for label in shell_labels:
    assert original_checks['check-'+label]=='2'
    assert (r/('retry-'+label+'.exit')).read_text().strip()=='0'
    checks['check-'+label]='0'
assert (r/'retry-shell-checks.exit').read_text().strip()=='0'
assert checks
assert all(v=='0' for v in checks.values()),checks
assert (r/'extra-checks.exit').read_text().strip()=='1'
receipt=dict(measured_feature_failures=failed,default_ci_checks=checks,
    original_ci_checks=original_checks,shell_retry_reason='Windows CRLF normalized to LF in remote checkout; no semantic changes',
    full_ci_passed=not failed,known_sqlite_failure_is_not_a_redis_measurement_block=bool(failed),
    source_base='03c8cc55d61473533c00a8afe13b4ef1fcd9b725')
(r/'checks-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
PY
cp candidate-formatted.patch artifacts/source.patch
(cd artifacts && sha256sum brewfs packed_snapshot_fixture source.patch >SHA256SUMS)
export GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=http.proxy GIT_CONFIG_VALUE_0=http://127.0.0.1:17901
sleep 10
{
  date -Is
  uptime
  free -b
  df -B1 /srv
  docker ps --format '{{.Names}} {{.Status}}'
} >compare-host-before.txt
bash harness-v3/experiments/overlay-open-a355-20261113/run-compare.sh \
  /srv/ax-overlay-tax-20261113/total/artifacts "$root/artifacts" "$root/compare-01"
echo 0 >compare-01.exit
python3 harness-v3/experiments/overlay-open-a355-20261113/run_detail.py \
  --binary "$root/artifacts/brewfs" --producer "$root/artifacts/packed_snapshot_fixture" \
  --source-commit 03c8cc55d61473533c00a8afe13b4ef1fcd9b725 --source-patch "$root/artifacts/source.patch" \
  --workspace-format workspace --build-profile optimized-release --comparison empty-cache --object-meter proxy \
  --cache-state on --metadata-sync remote --metadata-edits 8 --pairs 3 --passes 32 \
  --out "$root/mutation-check-01" >mutation-check-01.log 2>&1
echo 0 >mutation-check-01.exit
