#!/usr/bin/env bash
set -uo pipefail
root=/srv/ax-overlay-open-20261113
cd "$root/candidate-source"
failed=0
run_check() { local label="$1"; shift; "$@" >"$root/retry-$label.log" 2>&1; local status=$?; echo "$status" >"$root/retry-$label.exit"; test "$status" = 0 || failed=1; }
for script in run_perf_in_container.sh run_redis_perf.sh run_juicefs_perf_in_container.sh run_juicefs_perf.sh; do run_check "syntax-$script" bash -n "docker/compose-xfstests/$script"; done
for script in test_perf_report_delta.sh test_juicefs_direct_matrix.sh test_juicefs_perf_report.sh; do run_check "$script" bash "docker/compose-xfstests/$script"; done
echo "$failed" >"$root/retry-shell-checks.exit"
exit "$failed"
