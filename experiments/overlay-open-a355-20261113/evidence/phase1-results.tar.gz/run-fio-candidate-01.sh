#!/usr/bin/env bash
set -euo pipefail
cd /srv/ax-overlay-open-20261113
exec >fio-candidate-01.log 2>&1
trap 'echo $? > /srv/ax-overlay-open-20261113/fio-candidate-01.exit' EXIT
export GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=http.proxy GIT_CONFIG_VALUE_0=http://127.0.0.1:17901
python3 harness-v4/experiments/overlay-open-a355-20261113/run_fio_guard.py --binary "$PWD/artifacts/brewfs" --producer /srv/ax-overlay-tax-20261113/total/artifacts/packed_snapshot_fixture --source-commit 03c8cc55d61473533c00a8afe13b4ef1fcd9b725 --source-patch "$PWD/artifacts/source.patch" --workspace-format workspace --build-profile optimized-release --comparison empty-cache --object-meter proxy --cache-state on --metadata-sync remote --metadata-edits 8 --pairs 3 --passes 32 --out "$PWD/fio-candidate-01"
