#!/usr/bin/env bash
set -uo pipefail
root=/srv/ax-overlay-open-20261113
parent=/srv/ax-overlay-tax-20261113
cd "$root"
exec >build-check-02.log 2>&1
trap 'echo $? > /srv/ax-overlay-open-20261113/build-check-02.exit' EXIT
while test ! -f fair-baseline-01.exit; do sleep 5; done
test "$(cat fair-baseline-01.exit)" = 0 || exit 1
export PATH="$parent/toolchain/bin:$PATH" CARGO_HOME="$parent/cargo"
export CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_RELEASE_DEBUG=0
export CARGO_BUILD_JOBS=16 RUST_TEST_THREADS=2
export CARGO_TARGET_DIR="$parent/target"
features=fuse-io-uring-runtime,workspace,native-packed-base,frozen-base-metadata,rustfs-ec-block-size-hint,observability
mkdir tdd-source-02
tar -xzf "$parent/base-source.tar.gz" -C tdd-source-02 || exit 1
cd tdd-source-02
python3 - <<'PY'
from pathlib import Path
for path in Path('src').rglob('*.rs'):
    path.write_bytes(path.read_bytes().replace(b'\r\n', b'\n'))
PY
git apply ../tdd.patch || exit 1
cargo fmt --all || exit 1
cargo test --offline --locked --lib --no-default-features --features "$features" ready_driver -- --nocapture >../tdd-ready.log 2>&1
echo $? >../tdd-ready.exit
cargo test --offline --locked --lib --no-default-features --features "$features" cached_permission_read_shares_snapshot -- --nocapture >../tdd-cache.log 2>&1
echo $? >../tdd-cache.exit
cd "$root"
mkdir candidate-source
tar -xzf "$parent/base-source.tar.gz" -C candidate-source || exit 1
cd candidate-source
python3 - <<'PY'
from pathlib import Path
for path in Path('src').rglob('*.rs'):
    path.write_bytes(path.read_bytes().replace(b'\r\n', b'\n'))
PY
git apply ../candidate.patch || exit 1
cargo fmt --all || exit 1
(
  set -e
  set -x
  cargo fmt --all --check
  cargo test --offline --locked --lib --no-default-features --features "$features" ready_driver -- --nocapture
  cargo test --offline --locked --lib --no-default-features --features "$features" cached_permission_read_shares_snapshot -- --nocapture
  cargo clippy --offline --locked --workspace --all-targets --no-default-features --features "$features" -- -D warnings
  cargo test --offline --locked --workspace --lib --bins --no-default-features --features "$features"
) >../checks.log 2>&1 &
checks=$!
(
  set -e
  set -x
  export CARGO_TARGET_DIR="$parent/release-target"
  cargo --config profile.release.package.brewfs.opt-level=3 build --offline --locked --release --no-default-features --features "$features" --bin brewfs --bin packed_snapshot_fixture
  mkdir ../artifacts
  cp "$CARGO_TARGET_DIR/release/brewfs" "$CARGO_TARGET_DIR/release/packed_snapshot_fixture" ../artifacts/
  cp ../candidate.patch ../artifacts/source.patch
  cd ../artifacts
  sha256sum brewfs packed_snapshot_fixture source.patch >SHA256SUMS
) >../release.log 2>&1 &
release=$!
wait "$checks"; echo $? >../checks.exit
wait "$release"; echo $? >../release.exit
test "$(cat ../release.exit)" = 0
