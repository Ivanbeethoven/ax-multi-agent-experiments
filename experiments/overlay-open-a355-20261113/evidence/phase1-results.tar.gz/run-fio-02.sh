#!/usr/bin/env bash
set -euo pipefail
cd /srv/ax-overlay-open-20261113
exec >fio-guard-02.log 2>&1
trap 'echo $? > /srv/ax-overlay-open-20261113/fio-guard-02.exit' EXIT
export GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=http.proxy GIT_CONFIG_VALUE_0=http://127.0.0.1:17901
bash harness-v4/experiments/overlay-open-a355-20261113/run-regression.sh /srv/ax-overlay-tax-20261113/total/artifacts /srv/ax-overlay-open-20261113/artifacts /srv/ax-overlay-open-20261113/fio-guard-02
