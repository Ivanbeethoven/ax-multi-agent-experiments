#!/usr/bin/env bash
set -uo pipefail
root=/srv/ax-overlay-open-20261113
parent=/srv/ax-overlay-tax-20261113
cd "$root"
exec >extra-checks.log 2>&1
trap 'echo $? > /srv/ax-overlay-open-20261113/extra-checks.exit' EXIT
while test ! -f checks.exit; do sleep 5; done
cd candidate-source
export PATH="$parent/toolchain/bin:$PATH" CARGO_HOME="$parent/cargo"
export CARGO_TARGET_DIR="$parent/target" CARGO_BUILD_JOBS=16 CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 RUST_TEST_THREADS=2
failed=0
run_check() {
  local label="$1"; shift
  "$@" >"$root/check-$label.log" 2>&1
  local status=$?
  echo "$status" >"$root/check-$label.exit"
  test "$status" = 0 || failed=1
}
for script in run_perf_in_container.sh run_redis_perf.sh run_juicefs_perf_in_container.sh run_juicefs_perf.sh; do
  run_check "syntax-$script" bash -n "docker/compose-xfstests/$script"
done
for script in test_perf_report_delta.sh test_juicefs_direct_matrix.sh test_juicefs_perf_report.sh; do
  run_check "$script" bash "docker/compose-xfstests/$script"
done
run_check workspace-check cargo check --offline --locked --workspace
run_check workspace-build cargo build --offline --locked --workspace
if cargo metadata --offline --no-deps --format-version 1 | python3 -c 'import json,sys; d=json.load(sys.stdin); sys.exit(not any(p["name"]=="rfuse3" and p["id"] in d["workspace_members"] for p in d["packages"]))'; then
  for feature in tokio-runtime io-uring-runtime async-io-runtime; do
    run_check "rfuse3-$feature" cargo check --offline --locked -p rfuse3 --no-default-features --features "$feature"
  done
fi
for feature in fuse-tokio-runtime fuse-io-uring-runtime; do
  run_check "$feature" cargo check --offline --locked -p brewfs --no-default-features --features "$feature"
done
run_check workspace-test cargo test --offline --locked --workspace --lib --bins
run_check workspace-clippy cargo clippy --offline --locked --workspace --all-targets -- -D warnings
exit "$failed"
