# PR449 prefetch test synchronization qualification

GREEN commit: 53c725f36db5bcd060ec2483a0abecb943bed4ea.
GREEN complete default CI: https://github.com/brewfs/brewfs/actions/runs/43305771564 .
The workspace library test step passed1355/ignored265/failed0; build and all-targets Clippy with -D warnings passed. This workflow uses --lib, unlike the earlier7093 lib+bins count. Nine local lightweight gates passed; format was checked again after the fixture correction.

RED commit: 2a1ed7fae77b5b7ad47d25e4e541a2210fade57b.
RED exact regression: https://github.com/brewfs/brewfs/actions/runs/43305784066 .
Exactly one test ran and failed in0.06s with `settle returned before the gated backend completed`. Both branches contain the identical final regression. RED restores only the old waiting heuristic and limits its workflow test step to this regression.

The old helper watched an unchanged scheduling counter for20ms. The production background task uses an8-slot try-acquire limiter and may deliberately drop speculative work. The original PR failure reports28 of64 full GET starts, but has no terminal/dropped counter record: this evidence does not assign all missing starts to either unfinished work or dropped tasks.

The corrected traffic fixture explicitly serializes each distinct cold read through real full-response completion and worker semaphore release after cache publication. It preserves all original traffic/budget assertions, including64 GETs. A gated backend proves that waiting cannot finish while IO is blocked. No assertion threshold is increased; no production code changes.

The first qualification attempt used a64KiB object, exactly one page. The demand read legitimately promoted the whole page to block cache, so no background GET was scheduled; both arms failed waiting for its entry. Those logs are retained as an invalid fixture attempt, not as valid RED/GREEN. The second attempt uses a4MiB object/cache and asserts scheduling before waiting.

Only src/chunk/store/read_amplification_tests.rs, included under cfg(test), differs between7093 and GREEN. Measured Packed binary/source7093 and its performance records remain the performance identity. No new release or performance measurement was run for this test-only follow-up. PR449 itself is updated only by root after independent review; its automatically triggered CI is a separate run.

Archive allowlist contains only evidence, test source, workflows and patches. It excludes targets, executables, credentials and private keys. SHA256 entries below bind every member.
