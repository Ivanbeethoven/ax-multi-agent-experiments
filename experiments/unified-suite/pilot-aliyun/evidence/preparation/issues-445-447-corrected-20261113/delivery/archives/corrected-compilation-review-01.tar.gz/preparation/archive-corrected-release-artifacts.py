#!/usr/bin/env python3
"""Preserve frozen release artifacts before the actual runtime campaign."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path('/srv/perf-issues-corrected-20261112')
OUT = ROOT/'archive'
OUT.mkdir(exist_ok=True)
ARCHIVE = OUT/'release-artifacts-01.tar.gz'
assert not ARCHIVE.exists()
assert json.loads((ROOT/'evidence/release-controller-01/receipt.json').read_text())['passed'] is True
unit = 'ax447-corrected-release-archive-01'
raw = subprocess.check_output(['systemctl','show',unit,'-p','CPUQuotaPerSecUSec','-p','MemoryMax','-p','ControlGroup'],text=True)
props = dict(line.split('=',1) for line in raw.splitlines())
assert props['CPUQuotaPerSecUSec'] == '1s' and int(props['MemoryMax']) == 2*1024**3
assert props['ControlGroup'] in Path('/proc/self/cgroup').read_text()


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream,'sha256').hexdigest()


paths = []
for arm in ('baseline','candidate'):
    identity = json.loads((ROOT/'evidence'/(arm+'-release-01')/'artifact-identity.json').read_text())
    assert identity['passed'] is True
    binary = ROOT/'artifacts'/arm/'brewfs'
    assert sha(binary) == identity['binary']['sha256']
    paths.append(binary)
    paths.extend(p for p in (ROOT/'evidence'/(arm+'-release-01')).rglob('*') if p.is_file())
paths.extend(p for p in (ROOT/'evidence/release-controller-01').rglob('*') if p.is_file())
paths.extend(p for p in (ROOT/'source-freeze').rglob('*') if p.is_file())
paths = sorted(set(paths))
for p in paths:
    assert p.is_relative_to(ROOT) and not p.is_symlink()
    assert p.name not in ('ssh-key','cloud-key','known_hosts')
manifest = {'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'scope': 'Immutable source/build receipts and two release binaries only; no performance results or mutable test cache',
            'parallel_scope': 'Parent-authorized archive during non-timed baseline compilation; CPU1/2GiB separate from testCPU3/38GiB',
            'unit': props, 'files': {str(p.relative_to(ROOT)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in paths}}
manifest_path = OUT/'release-artifacts-01.manifest.json'
manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(ARCHIVE,'w:gz',compresslevel=1) as archive:
    for p in paths:
        archive.add(p,arcname=str(p.relative_to(ROOT)),recursive=False)
    archive.add(manifest_path,arcname='release-artifacts-01.manifest.json',recursive=False)
receipt = {'passed': True,'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'archive':str(ARCHIVE),'archive_bytes':ARCHIVE.stat().st_size,'archive_sha256':sha(ARCHIVE),
           'manifest_sha256':sha(manifest_path),'file_count':len(paths),
           'uncompressed_bytes':sum(p.stat().st_size for p in paths),'actual_unit':props,
           'script_sha256':sha(Path(__file__))}
(OUT/'release-artifacts-01.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
