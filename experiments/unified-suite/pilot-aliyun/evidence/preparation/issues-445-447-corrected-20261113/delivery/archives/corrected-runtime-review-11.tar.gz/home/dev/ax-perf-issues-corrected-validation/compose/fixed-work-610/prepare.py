#!/usr/bin/env python3
"""Derive a fixed-work guard from frozen 601/603 tooling; no workload here."""
import difflib
import hashlib
import json
import subprocess
from pathlib import Path

OUT = Path('/home/dev/ax-fixed-work-610')
RAW = Path('/home/dev/ax-perf-issues-validation/corrected-runtime-review-08/harness')
OLD_ROOT = '/home/dev/ax-perf-issues-corrected-validation/compose'
NEW_ROOT = OLD_ROOT + '/fixed-work-610'
OUT.mkdir(exist_ok=True)


def sha(body):
    return hashlib.sha256(body).hexdigest()


def replace_once(text, old, new):
    assert text.count(old) == 1, (old, text.count(old))
    return text.replace(old, new)


def write_delta(name, old, new):
    (OUT / name).write_text(new)
    (OUT / (name + '.patch')).write_text(''.join(difflib.unified_diff(
        old.splitlines(True), new.splitlines(True), fromfile='frozen', tofile='fixed-work-610')))


case = (RAW / 'run-compose-case.py').read_text()
assert sha(case.encode()) == 'a6621e4987ca488487ea45e455d7fd473ba3620ea518475c898e227941584085'
newcase = replace_once(case,
    "choices=['cached-smoke', 'cached', 'randwrite-gate', 'known-tail-oracle', 'regression']",
    "choices=['fixed-work-randwrite1']")
newcase = replace_once(newcase, "'PERF_FIO_RUNTIME': '20',", "'PERF_FIO_RUNTIME': '0',")
newcase = replace_once(newcase,
    "'PERF_FIO_DIRECT_MATRIX': '0' if args.case == 'randwrite-gate' else '0 1',",
    "'PERF_FIO_DIRECT_MATRIX': '',\n"
    "        'PERF_FIO_RANDWRITE_DIRECT': '1',\n"
    "        'PERF_FIO_RANDWRITE_RUNTIME': '0',\n"
    "        'PERF_FIO_RANDWRITE_SIZE': '512m',\n"
    "        'PERF_FIO_RANDWRITE_NUMJOBS': '4',\n"
    "        'PERF_FIO_RANDWRITE_BS': '4m',\n"
    "        'PERF_FIO_RANDWRITE_IOENGINE': 'io_uring',\n"
    "        'PERF_FIO_RANDWRITE_IODEPTH': '1',\n"
    "        'PERF_FIO_RANDWRITE_ARGS': '--io_size=1g',")
newcase = replace_once(newcase,
    "tools = 'fio-randwrite' if args.case == 'randwrite-gate' else 'fio-seqwrite fio-randwrite fio-randrw'",
    "tools = 'fio-randwrite'")
newcase = replace_once(newcase,
    "expected_count = 1 if args.case.startswith('cached') or args.case == 'randwrite-gate' else 6",
    'expected_count = 1')
newcase = newcase.replace("str(ROOT / 'compose.json')", "str(ROOT / 'fixed-work-610/compose.json')")
newcase = newcase.replace("(ROOT / 'compose.json').read_bytes()", "(ROOT / 'fixed-work-610/compose.json').read_bytes()")
newcase = newcase.replace("str(ROOT / 'run-isolated-redis-perf.sh')", "str(ROOT / 'fixed-work-610/run-fixed-host.sh')")
newcase = newcase.replace("(ROOT / 'run-isolated-redis-perf.sh').read_bytes()", "(ROOT / 'fixed-work-610/run-fixed-host.sh').read_bytes()")
newcase = newcase.replace("(ROOT / 'run-measured-perf-in-container.sh').read_bytes()", "(ROOT / 'fixed-work-610/run-fixed-container.sh').read_bytes()")
write_delta('run-fixed-case.py', case, newcase)

container = (RAW / 'run-measured-perf-in-container.sh').read_text()
assert sha(container.encode()) == '4d605c4848fa8a163d631d248a19e8019416b3b644501830749e746aa6799025'
start = container.index('            randwrite)\n', container.index('run_fio_profile()'))
end = container.index('            randrw)\n', start)
block = container[start:end]
newblock = replace_once(block, '                use_time_based=true\n',
    '                use_time_based=true\n'
    '                if [[ "$runtime" == 0 ]]; then\n'
    '                    use_time_based=false\n'
    '                fi\n')
newcontainer = container[:start] + newblock + container[end:]
write_delta('run-fixed-container.sh', container, newcontainer)

host = (RAW / 'run-isolated-redis-perf.sh').read_text()
newhost = replace_once(host, '== ' + OLD_ROOT + '/compose.json', '== ' + NEW_ROOT + '/compose.json')
write_delta('run-fixed-host.sh', host, newhost)

compose = Path('/home/dev/ax-issue447-profile-prefix-604/compose-original.json').read_text()
newcompose = replace_once(compose, OLD_ROOT + '/run-measured-perf-in-container.sh:', NEW_ROOT + '/run-fixed-container.sh:')
write_delta('compose.json', compose, newcompose)
assert json.loads(newcompose)['services']['perf']['volumes'] != json.loads(compose)['services']['perf']['volumes']

for name in ['run-fixed-container.sh', 'run-fixed-host.sh']:
    subprocess.run(['bash', '-n', str(OUT / name)], check=True)
compile(newcase, 'run-fixed-case.py', 'exec')
(OUT / 'source-derivation.json').write_text(json.dumps({
    'scope': 'Fixed-work foreground plus strict writeback drain; no claim of complete later maintenance or unchanged cumulative-history matrix',
    'frozen_inputs': {str(RAW / n): sha((RAW / n).read_bytes()) for n in ['run-compose-case.py', 'run-measured-perf-in-container.sh', 'run-isolated-redis-perf.sh']},
    'workload': {'name': 'fio-randwrite', 'direct': 1, 'ioengine': 'io_uring', 'iodepth': 1,
                 'jobs': 4, 'working_set_bytes_per_job': 512 << 20, 'io_bytes_per_job': 1 << 30,
                 'block_size_bytes': 4 << 20, 'total_write_bytes': 4 << 30, 'total_write_ios': 1024,
                 'randseed': 20261031, 'time_based': False, 'runtime_limit': False},
    'default_compaction_preserved': True, 'original_three_cpu_boundaries_preserved': True,
    'payload_scope': 'Original fio buffer generation and fixed seed retained; scramble timestamps mean payload is not asserted byte-identical across arms.',
    'pairs': [{'trial': 610, 'order': ['baseline', 'candidate']}, {'trial': 611, 'order': ['candidate', 'baseline']}, {'trial': 612, 'order': ['baseline', 'candidate']}],
    'old_601_603_results_replaced': False, 'performance_accepted': False,
}, indent=2) + '\n')
print('Derived fixed-work case/container/host/compose; no workload started.')
