#!/usr/bin/env python3
"""Run selected frozen arms with the exact release features under the host lock."""
import argparse
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import socket
import subprocess
import time
import traceback

parser = argparse.ArgumentParser()
parser.add_argument('--spec', required=True, type=Path)
parser.add_argument('--output', required=True, type=Path)
parser.add_argument('--unit', required=True)
parser.add_argument('--arms', choices=('baseline', 'candidate'), nargs='+', default=['baseline', 'candidate'])
parser.add_argument('--target', type=Path, default=Path('/home/dev/ax-issues-target'))
args = parser.parse_args()
spec = json.loads(args.spec.read_text())
assert spec['net_tree_proof_passed'] is True
assert re.fullmatch(r'ax447-corrected-[a-z0-9-]+', args.unit)
assert len(args.arms) == len(set(args.arms))
assert args.target in (Path('/home/dev/ax-issues-target'),
                       Path('/srv/perf-issues-corrected-20261112/target-exact-baseline'))
features = 'fuse-io-uring-runtime,workspace-overlay,observability,rustfs-ec-block-size-hint'
assert spec['features'] == features
args.output.mkdir(parents=True, exist_ok=False)
env = dict(os.environ)
env.update(PATH='/root/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin:/root/.cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',
           CARGO_HOME='/root/.cargo', CARGO_TARGET_DIR=str(args.target),
           CARGO_BUILD_JOBS='3', CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0',
           RUST_TEST_THREADS='3', CARGO_TERM_COLOR='never', GIT_OPTIONAL_LOCKS='0',
           GIT_CONFIG_COUNT='1', GIT_CONFIG_KEY_0='safe.directory')
for key in ('RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'RUSTC_WRAPPER'):
    assert not env.get(key), key
receipt = {'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'passed': False, 'arms': [], 'features': features, 'default_features': False,
           'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'spec_sha256': hashlib.sha256(args.spec.read_bytes()).hexdigest()}
receipt['test_host'] = {'hostname': socket.gethostname(), 'uname': list(os.uname())}
receipt['requested_arms'] = args.arms
receipt['source_scope'] = spec.get('source_scope', 'Original runtime source heads')
receipt['publication_projection'] = spec.get('publication_projection')


def save():
    (args.output/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')


with Path('/home/dev/.ax-rbm-heavy.lock').open('w') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX)
    active = subprocess.run(['pgrep', '-ax', 'cargo|rustc|fio'], text=True, capture_output=True)
    assert active.returncode == 1, active.stdout
    receipt['lock_acquired_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    receipt['rustc'] = subprocess.check_output(['rustc', '-Vv'], env=env, text=True)
    assert receipt['rustc'].startswith('rustc 1.99.1 ')
    receipt['actual_process_cgroup'] = Path('/proc/self/cgroup').read_text()
    properties = subprocess.check_output(['systemctl', 'show', args.unit,
        '-p', 'CPUQuotaPerSecUSec', '-p', 'MemoryMax', '-p', 'RuntimeMaxUSec',
        '-p', 'ControlGroup'], text=True)
    props = dict(line.split('=', 1) for line in properties.splitlines())
    assert props['CPUQuotaPerSecUSec'] == '3s', props
    assert int(props['MemoryMax']) == 38 * 1024 ** 3, props
    assert props['ControlGroup'] in receipt['actual_process_cgroup']
    receipt['actual_unit'] = props
    try:
        for arm in args.arms:
            entry = spec['arms'][arm]
            source = Path(entry['rbm_source'])
            allowed_sources = {Path('/home/dev/ax-issue447-corrected-'+arm)}
            if arm == 'candidate' and spec.get('publication_projection', {}).get('passed') is True:
                allowed_sources.add(Path('/home/dev/ax-issue447-publication-candidate'))
            assert source in allowed_sources
            assert re.fullmatch(r'[0-9a-f]{40}', entry['commit'])
            arm_env = dict(env, GIT_CONFIG_VALUE_0=str(source))

            def git(*parts):
                return subprocess.check_output(['git', '-C', str(source), *parts], env=arm_env, text=True).strip()

            assert git('rev-parse', 'HEAD') == entry['commit']
            assert git('rev-parse', 'HEAD^{tree}') == entry['tree']
            assert not git('status', '--porcelain')
            command = ['cargo', 'test', '--locked', '--workspace', '--lib', '--bins',
                       '--no-default-features', '--features', features]
            item = dict(arm=arm, commit=entry['commit'], tree=entry['tree'],
                        source=str(source), command=command,
                        started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                        environment={k: arm_env[k] for k in ('CARGO_HOME', 'CARGO_TARGET_DIR',
                            'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL', 'CARGO_PROFILE_DEV_DEBUG',
                            'RUST_TEST_THREADS', 'CARGO_TERM_COLOR', 'GIT_OPTIONAL_LOCKS',
                            'GIT_CONFIG_COUNT', 'GIT_CONFIG_KEY_0', 'GIT_CONFIG_VALUE_0')})
            receipt['arms'].append(item)
            save()
            start = time.monotonic()
            with (args.output/(arm+'.log')).open('wb') as log:
                result = subprocess.run(command, cwd=source, env=arm_env,
                                        stdout=log, stderr=subprocess.STDOUT, timeout=3600)
            item.update(exit_code=result.returncode, elapsed_seconds=time.monotonic()-start,
                        finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
            save()
            assert result.returncode == 0, arm+' exact feature tests failed'
            assert git('rev-parse', 'HEAD') == entry['commit']
            assert not git('status', '--porcelain')
            item['source_still_clean'] = True
            with (args.output/(arm+'.log')).open('rb') as stream:
                item['log_sha256'] = hashlib.file_digest(stream, 'sha256').hexdigest()
            log_text = (args.output/(arm+'.log')).read_text(errors='replace')
            executables = re.findall(r'^\s+Running unittests .* \(([^)]+)\)$', log_text, re.M)
            assert executables, 'missing executed unit-test binary identities'
            item['tested_executables'] = []
            for executable in dict.fromkeys(executables):
                path = Path(executable).resolve()
                assert path.is_relative_to(args.target.resolve())
                with path.open('rb') as stream:
                    binary_hash = hashlib.file_digest(stream, 'sha256').hexdigest()
                item['tested_executables'].append({'path': str(path), 'bytes': path.stat().st_size,
                                                   'sha256': binary_hash})
            save()
        receipt['passed'] = True
    except Exception:
        receipt['error'] = traceback.format_exc()
        raise
    finally:
        receipt['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save()
print(json.dumps({'passed': True, 'arms': [x['commit'] for x in receipt['arms']]}), flush=True)
