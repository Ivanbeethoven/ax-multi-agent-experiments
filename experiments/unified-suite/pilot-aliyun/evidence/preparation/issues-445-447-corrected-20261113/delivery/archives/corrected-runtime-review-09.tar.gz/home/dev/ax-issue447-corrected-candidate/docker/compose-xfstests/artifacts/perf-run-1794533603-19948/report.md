# BrewFS Perf Report

Meta backend: redis

## Summary

| Tool | Status | Seconds | Log |
| --- | --- | ---: | --- |
| fio-seqwrite-direct0 | pass | 22 | tools/fio-seqwrite-direct0.log |
| fio-seqwrite-direct1 | pass | 20 | tools/fio-seqwrite-direct1.log |
| fio-randwrite-direct0 | pass | 26 | tools/fio-randwrite-direct0.log |
| fio-randwrite-direct1 | pass | 21 | tools/fio-randwrite-direct1.log |

## Post-Write Drain

| Tool | Drain seconds | Pending bytes | Dirty bytes | Buffer dirty bytes |
| --- | ---: | ---: | ---: | ---: |
| fio-seqwrite-direct0 | 25 | 0 | 0 | 0 |
| fio-seqwrite-direct1 | 28 | 0 | 0 | 0 |
| fio-randwrite-direct0 | 25 | 0 | 0 | 0 |
| fio-randwrite-direct1 | 57 | 0 | 0 | 0 |

## Fio

| Tool | Workload | Direct | BS | Jobs | Read BW | Read IOPS | Write BW | Write IOPS | Read P99 | Write P99 | Raw |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |---: | ---: | ---: |
| fio-randwrite-direct0 | randwrite | 0 | 4m | 4 | 0.00 B/s | 0.00 | 200.59 MiB/s | 50.15 | 0.000 ms | 81.265 ms | results/fio-randwrite-direct0.json |
| fio-randwrite-direct1 | randwrite | 1 | 4m | 4 | 0.00 B/s | 0.00 | 203.08 MiB/s | 50.77 | 0.000 ms | 0.016 ms | results/fio-randwrite-direct1.json |
| fio-seqwrite-direct0 | write | 0 | 4m | 1 | 0.00 B/s | 0.00 | 224.78 MiB/s | 56.20 | 0.000 ms | 44.827 ms | results/fio-seqwrite-direct0.json |
| fio-seqwrite-direct1 | write | 1 | 4m | 1 | 0.00 B/s | 0.00 | 234.98 MiB/s | 58.74 | 0.000 ms | 0.014 ms | results/fio-seqwrite-direct1.json |

## Fio Runtime Accounting

Use `active_io_runtime` for close/flush tail detection; fio `job_runtime_ms` can aggregate multiple jobs under group reporting.

| Tool | Direct | Script wall | fio job_runtime | wall-job_runtime | wall/job_runtime | active_io_runtime | wall-active_io | wall/active_io | Tail marker |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| fio-randwrite-direct0 | 0 | 26 s | 102.037 s | -76.037 s | 0.25x | 25.525 s | +0.475 s | 1.02x | fio job_runtime aggregates jobs |
| fio-randwrite-direct1 | 1 | 21 s | 80.189 s | -59.189 s | 0.26x | 20.051 s | +0.949 s | 1.05x | fio job_runtime aggregates jobs |
| fio-seqwrite-direct0 | 0 | 22 s | 21.086 s | +0.914 s | 1.04x | 21.087 s | +0.913 s | 1.04x | - |
| fio-seqwrite-direct1 | 1 | 20 s | 20.001 s | -0.001 s | 1.00x | 20.002 s | -0.002 s | 1.00x | fio job_runtime aggregates jobs |

## Fully Drained Write Throughput

Actual fio bytes divided by `active_io_runtime + post_write_drain`; unlike foreground bandwidth, this includes the time required to empty the filesystem writeback queue.

| Tool | Active I/O | Drain | Complete | Read | Write | Total | Raw |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| fio-randwrite-direct0 | 25.525 s | 25.000 s | 50.525 s | 0.00 MiB/s | 101.34 MiB/s | 101.34 MiB/s | fully-drained-throughput.tsv |
| fio-randwrite-direct1 | 20.051 s | 57.000 s | 77.051 s | 0.00 MiB/s | 52.85 MiB/s | 52.85 MiB/s | fully-drained-throughput.tsv |
| fio-seqwrite-direct0 | 21.087 s | 25.000 s | 46.087 s | 0.00 MiB/s | 102.85 MiB/s | 102.85 MiB/s | fully-drained-throughput.tsv |
| fio-seqwrite-direct1 | 20.002 s | 28.000 s | 48.002 s | 0.00 MiB/s | 97.91 MiB/s | 97.91 MiB/s | fully-drained-throughput.tsv |

## Latency Percentiles

### Read

| Workload | p1 | p5 | p25 | p50 | p75 | p90 | p95 | p99 | p99.9 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |

### Write

| Workload | p1 | p5 | p25 | p50 | p75 | p90 | p95 | p99 | p99.9 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| fio-randwrite-direct0 | 0.000 ms | 0.000 ms | 0.000 ms | 23.986 ms | 0.000 ms | 0.000 ms | 53.740 ms | 81.265 ms | 10401.874 ms |
| fio-randwrite-direct1 | 0.000 ms | 0.000 ms | 0.000 ms | 0.005 ms | 0.000 ms | 0.000 ms | 0.007 ms | 0.016 ms | 0.058 ms |
| fio-seqwrite-direct0 | 0.000 ms | 0.000 ms | 0.000 ms | 10.289 ms | 0.000 ms | 0.000 ms | 32.637 ms | 44.827 ms | 868.221 ms |
| fio-seqwrite-direct1 | 0.000 ms | 0.000 ms | 0.000 ms | 0.005 ms | 0.000 ms | 0.000 ms | 0.008 ms | 0.014 ms | 0.024 ms |

## Redis Diagnostics

| Tool | Top commandstats | Details |
| --- | --- | --- |
| fio-randwrite-direct0 | evalsha: calls=775, usec/call=76.34<br>exec: calls=1284, usec/call=5.29<br>rpush: calls=743, usec/call=6.38<br>get: calls=2039, usec/call=2.11<br>incrby: calls=743, usec/call=4.90 | diagnostics/redis-fio-randwrite-direct0-after.txt |
| fio-randwrite-direct1 | evalsha: calls=573, usec/call=77.59<br>exec: calls=1028, usec/call=5.46<br>rpush: calls=601, usec/call=5.74<br>get: calls=1597, usec/call=2.03<br>incrby: calls=560, usec/call=3.99 | diagnostics/redis-fio-randwrite-direct1-after.txt |
| fio-seqwrite-direct0 | exec: calls=1186, usec/call=7.24<br>evalsha: calls=100, usec/call=79.44<br>get: calls=1265, usec/call=3.54<br>multi: calls=1186, usec/call=1.82<br>hget: calls=1207, usec/call=1.25 | diagnostics/redis-fio-seqwrite-direct0-after.txt |
| fio-seqwrite-direct1 | exec: calls=1176, usec/call=7.60<br>evalsha: calls=98, usec/call=81.02<br>get: calls=1255, usec/call=3.57<br>multi: calls=1176, usec/call=1.92<br>hget: calls=1196, usec/call=1.54 | diagnostics/redis-fio-seqwrite-direct1-after.txt |

## BrewFS Stats

Counters are per-tool deltas when matching before/after snapshots exist; dirty, live, and inflight values are after-tool gauges.

| Tool | Cache hit | FUSE read | FUSE write | Dirty | Live dirty | Recent pending | Recent uploaded | Read buffer | S3 ops | S3 avg latency | Details |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| fio-randwrite-direct0 | 0.0% (0/0) | 0.0 MiB | 5120.0 MiB | 3060.0 MiB | 0.0 MiB | 3060.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=518 | GET=506.48 ms, PUT=288.40 ms | diagnostics/stats-fio-randwrite-direct0-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=743 ops/5120.0 MiB/226746.3 ms, foreground=stage 226.75s/commit_wait 3.34s, flush_wait=4 ops/0.06s/4 slices, stage_fail=0, commit_before_stage=604, remote_inflight=3060.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=21, max_buffer_dirty=3566.0 MiB, max_live_dirty=922.0 MiB, max_live_slices=138, max_recent_pending=3516.0 MiB, max_recent_uploaded=0.0 MiB, max_stage_inflight=660.0 MiB, max_remote_inflight=3516.0 MiB, last_buffer_dirty=3091.0 MiB, slices=create 743/reuse 4377/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=743 avg=6.9 MiB blocks=1.73/batch partial_tail=0.01 (size 0/max 1/flush 3/auto 6/age 0), partial_origin=normal 10/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 6/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 6/cached 0/mixed 0/unknown 0, freeze=size 81/flush 4/auto 536/max 122/age 0 |
| fio-randwrite-direct0-post-write-drained | 0.0% (0/0) | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=763 | GET=506.48 ms, PUT=159.47 ms | diagnostics/stats-fio-randwrite-direct0-post-write-drained-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=0 ops/0.0 MiB/0.0 ms, foreground=stage 0.00s/commit_wait 0.00s, flush_wait=0 ops/0.00s/0 slices, stage_fail=0, commit_before_stage=0, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 743/reuse 4377/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=0 avg=n/a blocks=0.00/batch partial_tail=0.00 (size 0/max 0/flush 0/auto 0/age 0), partial_origin=normal 0/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 0/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 0/cached 0/mixed 0/unknown 0, freeze=size 81/flush 4/auto 536/max 122/age 0 |
| fio-randwrite-direct0-post-write-runner-drained | 88.2% (1036/1175) | 512.0 MiB | 5120.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=135, PUT=1301 | GET=506.48 ms, PUT=209.11 ms | diagnostics/stats-fio-randwrite-direct0-post-write-runner-drained-after.txt; range=0, full=135, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=743 ops/5120.0 MiB/226746.3 ms, foreground=stage 226.75s/commit_wait 3.34s, flush_wait=4 ops/0.06s/4 slices, stage_fail=0, commit_before_stage=604, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 743/reuse 4377/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=743 avg=6.9 MiB blocks=1.73/batch partial_tail=0.01 (size 0/max 1/flush 3/auto 6/age 0), partial_origin=normal 10/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 6/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 6/cached 0/mixed 0/unknown 0, freeze=size 81/flush 4/auto 536/max 122/age 0 |
| fio-randwrite-direct1 | 52.9% (81/153) | 0.0 MiB | 4072.0 MiB | 3084.0 MiB | 0.0 MiB | 3084.0 MiB | 0.0 MiB | 0.0 MiB | GET=73, PUT=320 | GET=34.71 ms, PUT=421.49 ms | diagnostics/stats-fio-randwrite-direct1-after.txt; range=0, full=73, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=551 ops/4072.0 MiB/414034.3 ms, foreground=stage 414.03s/commit_wait 3.94s, flush_wait=4 ops/0.08s/4 slices, stage_fail=0, commit_before_stage=455, remote_inflight=3084.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=16, max_buffer_dirty=3560.0 MiB, max_live_dirty=1064.0 MiB, max_live_slices=132, max_recent_pending=3552.0 MiB, max_recent_uploaded=0.0 MiB, max_stage_inflight=876.0 MiB, max_remote_inflight=3552.0 MiB, last_buffer_dirty=3240.0 MiB, slices=create 551/reuse 3521/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=551 avg=7.4 MiB blocks=1.85/batch partial_tail=0.00 (size 0/max 0/flush 0/auto 0/age 0), partial_origin=normal 0/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 0/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 0/cached 0/mixed 0/unknown 0, freeze=size 64/flush 4/auto 385/max 98/age 0 |
| fio-randwrite-direct1-post-write-drained | 52.8% (324/614) | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=290, PUT=1093 | GET=90.30 ms, PUT=157.34 ms | diagnostics/stats-fio-randwrite-direct1-post-write-drained-after.txt; range=0, full=290, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=0 ops/0.0 MiB/0.0 ms, foreground=stage 0.00s/commit_wait 0.00s, flush_wait=0 ops/0.00s/0 slices, stage_fail=0, commit_before_stage=0, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 551/reuse 3521/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=0 avg=n/a blocks=0.00/batch partial_tail=0.00 (size 0/max 0/flush 0/auto 0/age 0), partial_origin=normal 0/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 0/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 0/cached 0/mixed 0/unknown 0, freeze=size 64/flush 4/auto 385/max 98/age 0 |
| fio-randwrite-direct1-post-write-runner-drained | 84.7% (4342/5127) | 2048.0 MiB | 4072.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=765, PUT=1274 | GET=385.78 ms, PUT=241.71 ms | diagnostics/stats-fio-randwrite-direct1-post-write-runner-drained-after.txt; range=0, full=765, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=551 ops/4072.0 MiB/414034.3 ms, foreground=stage 414.03s/commit_wait 3.94s, flush_wait=4 ops/0.08s/4 slices, stage_fail=0, commit_before_stage=455, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 551/reuse 3521/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=551 avg=7.4 MiB blocks=1.85/batch partial_tail=0.00 (size 0/max 0/flush 0/auto 0/age 0), partial_origin=normal 0/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 0/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 0/cached 0/mixed 0/unknown 0, freeze=size 64/flush 4/auto 385/max 98/age 0 |
| fio-seqwrite-direct0 | 0.0% (0/0) | 0.0 MiB | 4740.0 MiB | 3012.0 MiB | 0.0 MiB | 3012.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=434 | GET=0.00 ms, PUT=283.17 ms | diagnostics/stats-fio-seqwrite-direct0-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=77 ops/4740.0 MiB/22961.9 ms, foreground=stage 22.96s/commit_wait 1.23s, flush_wait=2 ops/0.07s/2 slices, stage_fail=0, commit_before_stage=77, remote_inflight=3012.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=18, max_buffer_dirty=3076.0 MiB, max_live_dirty=85.0 MiB, max_live_slices=2, max_recent_pending=3074.0 MiB, max_recent_uploaded=0.0 MiB, max_stage_inflight=448.0 MiB, max_remote_inflight=3074.0 MiB, last_buffer_dirty=3074.0 MiB, slices=create 77/reuse 4664/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=77 avg=61.6 MiB blocks=15.42/batch partial_tail=0.04 (size 0/max 0/flush 2/auto 1/age 0), partial_origin=normal 3/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 1/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 1/cached 0/mixed 0/unknown 0, freeze=size 74/flush 2/auto 1/max 0/age 0 |
| fio-seqwrite-direct0-post-write-drained | 0.0% (0/0) | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=751 | GET=0.00 ms, PUT=164.59 ms | diagnostics/stats-fio-seqwrite-direct0-post-write-drained-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=0 ops/0.0 MiB/0.0 ms, foreground=stage 0.00s/commit_wait 0.00s, flush_wait=0 ops/0.00s/0 slices, stage_fail=0, commit_before_stage=0, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 77/reuse 4664/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=0 avg=n/a blocks=0.00/batch partial_tail=0.00 (size 0/max 0/flush 0/auto 0/age 0), partial_origin=normal 0/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 0/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 0/cached 0/mixed 0/unknown 0, freeze=size 74/flush 2/auto 1/max 0/age 0 |
| fio-seqwrite-direct0-post-write-runner-drained | 0.0% (0/0) | 0.0 MiB | 4740.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=1187 | GET=0.00 ms, PUT=209.89 ms | diagnostics/stats-fio-seqwrite-direct0-post-write-runner-drained-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=77 ops/4740.0 MiB/22961.9 ms, foreground=stage 22.96s/commit_wait 1.23s, flush_wait=2 ops/0.07s/2 slices, stage_fail=0, commit_before_stage=77, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 77/reuse 4664/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=77 avg=61.6 MiB blocks=15.42/batch partial_tail=0.04 (size 0/max 0/flush 2/auto 1/age 0), partial_origin=normal 3/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 1/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 1/cached 0/mixed 0/unknown 0, freeze=size 74/flush 2/auto 1/max 0/age 0 |
| fio-seqwrite-direct1 | 0.0% (0/0) | 0.0 MiB | 4700.0 MiB | 3036.0 MiB | 0.0 MiB | 3036.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=424 | GET=714.50 ms, PUT=269.94 ms | diagnostics/stats-fio-seqwrite-direct1-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=76 ops/4700.0 MiB/21777.3 ms, foreground=stage 21.78s/commit_wait 0.35s, flush_wait=1 ops/0.05s/1 slices, stage_fail=0, commit_before_stage=76, remote_inflight=3036.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=16, max_buffer_dirty=3079.0 MiB, max_live_dirty=59.0 MiB, max_live_slices=1, max_recent_pending=3079.0 MiB, max_recent_uploaded=0.0 MiB, max_stage_inflight=576.0 MiB, max_remote_inflight=3079.0 MiB, last_buffer_dirty=2911.0 MiB, slices=create 76/reuse 4624/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=76 avg=61.8 MiB blocks=15.49/batch partial_tail=0.05 (size 2/max 0/flush 0/auto 2/age 0), partial_origin=normal 4/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 2/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 2/cached 0/mixed 0/unknown 0, freeze=size 73/flush 1/auto 2/max 0/age 0 |
| fio-seqwrite-direct1-post-write-drained | 0.0% (0/0) | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=753 | GET=714.50 ms, PUT=185.88 ms | diagnostics/stats-fio-seqwrite-direct1-post-write-drained-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=0 ops/0.0 MiB/0.0 ms, foreground=stage 0.00s/commit_wait 0.00s, flush_wait=0 ops/0.00s/0 slices, stage_fail=0, commit_before_stage=0, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 76/reuse 4624/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=0 avg=n/a blocks=0.00/batch partial_tail=0.00 (size 0/max 0/flush 0/auto 0/age 0), partial_origin=normal 0/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 0/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 0/cached 0/mixed 0/unknown 0, freeze=size 73/flush 1/auto 2/max 0/age 0 |
| fio-seqwrite-direct1-post-write-runner-drained | 88.5% (1021/1154) | 512.0 MiB | 4700.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=129, PUT=1177 | GET=714.50 ms, PUT=216.16 ms | diagnostics/stats-fio-seqwrite-direct1-post-write-runner-drained-after.txt; range=0, full=129, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=76 ops/4700.0 MiB/21777.3 ms, foreground=stage 21.78s/commit_wait 0.35s, flush_wait=1 ops/0.05s/1 slices, stage_fail=0, commit_before_stage=76, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 76/reuse 4624/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=76 avg=61.8 MiB blocks=15.49/batch partial_tail=0.05 (size 2/max 0/flush 0/auto 2/age 0), partial_origin=normal 4/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 2/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 2/cached 0/mixed 0/unknown 0, freeze=size 73/flush 1/auto 2/max 0/age 0 |
