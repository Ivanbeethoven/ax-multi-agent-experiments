import ast,hashlib,io,json,subprocess,tarfile
from pathlib import Path
P=Path(__file__).resolve().parent
tests=[]
for p in P.glob('*.py'):
    ast.parse(p.read_text(encoding='utf-8'));tests.append('syntax:'+p.name)
old=json.loads((P/'compose-original.json').read_text());new=json.loads((P/'compose.json').read_text())
v=new['services']['perf']['volumes'];ov=old['services']['perf']['volumes']
assert len(v)==len(ov)+1
new['services']['perf']['volumes']=ov
assert new==old;tests.append('compose_only_three_readonly_script_bind_changes')
case=(P/'run-profile-case.py').read_text()
assert "'PERF_FIO_SIZE': '512m'" in case and "'PERF_FIO_RUNTIME': '20'" in case
assert "else '0 1'" in case and "else 'fio-seqwrite fio-randwrite'" in case
assert 'else 4\n' in case;tests.append('same_direct_matrix_and_workload_four_predecessor_scenes')
dur=(P/'verify_remote_durability.py').read_text()
LOG='warn,brewfs::chunk::compact::worker=debug,brewfs::cadapter::s3=debug'
assert dur.replace("frozenset(('"+LOG+"', 'warn',","frozenset(('warn',")== (P/'durability-original.py').read_text()
tests.append('durability_only_fixed_warn_visible_log_filter')
container=(P/'run-profile-container.sh').read_text(encoding='utf-8')
assert container.count('profile604_hook.py')==3
assert container.index('profile604_hook.py stop')>container.index('    wait_for_fio_post_write_drain "$tool" || fio_status=1')
assert container.index('profile604_hook.py stop')<container.index('        verify_fio_remote_durability "$tool" "$work_dir" || fio_status=1')
tests.append('profile_stops_after_cpu_boundary_before_remote_durability')
receipt={'passed':True,'checks':tests,'scope':'Static preparation only, no FUSE or perf pair executed'}
(P/'static-checks.json').write_text(json.dumps(receipt,indent=2)+'\n')
manifest={p.name:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(P.iterdir()) if p.is_file() and p.name!='manifest.json'}
(P/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
b=io.BytesIO()
with tarfile.open(fileobj=b,mode='w:gz') as tar:
    for p in sorted(P.iterdir()):
        if p.is_file():tar.add(p,arcname=p.name)
subprocess.run(['ssh','rbm','mkdir -p /home/dev/ax-issue447-profile-prefix-604 && tar -xzf - -C /home/dev/ax-issue447-profile-prefix-604'],input=b.getvalue(),check=True,timeout=90)
print(json.dumps({'sha256':hashlib.sha256(b.getvalue()).hexdigest(),'bytes':len(b.getvalue()),'checks':len(tests),'files':len(manifest)+1}))
