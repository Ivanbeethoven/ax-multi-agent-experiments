"""Remaining previously frozen target guards; standard numeric HOLD stays separate."""
import datetime,hashlib,json,os,subprocess,sys,traceback
from pathlib import Path
ROOT=Path('/home/dev/ax-perf-issues-corrected-validation/compose')
assert json.loads((ROOT/'matrices/diagnostic-profile606/receipt.json').read_text())['passed'] is True
for arm,trial in [('baseline',605),('candidate',606)]:
    prior=json.loads((ROOT/'trials'/f'ax447-corrected-{arm}-regression-profile-{trial}'/'receipt.json').read_text())
    assert prior['qualified'] is True and prior['status']==0
assert subprocess.run(['pgrep','-x','perf'],stdout=subprocess.PIPE).returncode==1
assert json.loads((ROOT/'matrices/regression-corrected512-01/receipt.json').read_text())['passed']
assert json.loads((ROOT/'matrices/regression-corrected512-01/comparison.json').read_text())['evidence_gates_passed']
pins={'run-workspace-guards.py':'ac005713768a840764ca2cee1b6421d506c3ead14c9fb98bd4b563d7d6909da4',
      'run-row-long-guards.py':'fcf727ef0831f6f91cdbdc6178e69e089c9ca76b650d7c179318c86c5b705ea9'}
OUT=ROOT/'matrices/corrected-metadata512-01';OUT.mkdir(exist_ok=False)
phases=[('workspace-paired',['run-workspace-guards.py','corrected51201','--compare']),
        ('row-long-paired',['run-row-long-guards.py','correctedlong51201'])]
record={'passed':False,'standard_performance_status':'HOLD:601/603 repeated randwrite/direct1 CPU/GiB regression',
        'scope':'Independent previously authorized #445/#446 targets on actual4f/c8; no old7b result relabeling',
        'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'phases':[],
        'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'runtime_envelope':'This native client unit CPU300%/Memory16GiB; Redis1CPU2GiB/RustFS2CPU8GiB separate Docker caps'}
def save():(OUT/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
try:
    for name,args in phases:
        assert hashlib.sha256((ROOT/args[0]).read_bytes()).hexdigest()==pins[args[0]]
        space=os.statvfs(ROOT)
        assert space.f_bavail*space.f_frsize>=max(256*1024**3,space.f_blocks*space.f_frsize//5)
        assert space.f_favail>=space.f_files//5
        step={'name':name,'argv':[sys.executable,str(ROOT/args[0]),*args[1:]],
              'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'script_sha256':pins[args[0]],'free_bytes_before':space.f_bavail*space.f_frsize}
        record['phases'].append(step);save()
        with (OUT/(name+'.log')).open('w') as log:
            p=subprocess.run(step['argv'],stdout=log,stderr=subprocess.STDOUT)
        step.update(exit_code=p.returncode,finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
        assert p.returncode==0,name+' failed; preserve raw artifacts'
    record['passed']=True
except Exception:
    record['error']=traceback.format_exc();raise
finally:
    record['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
