#!/usr/bin/env python3
"""Run both strict known-byte arms; an additional FUSE freshness proof is required."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path('/home/dev/ax-perf-issues-corrected-validation/compose')
OUT = ROOT/'known-tail-qualification-v4-01'
OUT.mkdir(exist_ok=False)
assert hashlib.sha256((ROOT/'known_tail_oracle.py').read_bytes()).hexdigest() == 'f916abb1e9560b8dc1341bb17b02093b171155d6dfa2feee276a87ffaeea1384'
receipt = {'completed':False,'qualified':False,'performance_acceptance':False,
           'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'scope':'Force fresh attributes then preserve strict known-byte and attribute gates; helper success alone cannot qualify without the separate real-FUSE freshness trace proof',
           'external_fuse_trace_proof_required':True,
           'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'stages':[]}


def save():
    (OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')


for arm in ('baseline','candidate'):
    stat = os.statvfs(ROOT)
    assert stat.f_bavail*stat.f_frsize-(4<<30) >= stat.f_blocks*stat.f_frsize//5
    assert stat.f_favail-10000 >= stat.f_files//5
    command = [sys.executable,str(ROOT/'run-compose-case.py'),arm,'known-tail-oracle','502']
    step = {'arm':arm,'command':command,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'capacity_preflight':{'free_bytes':stat.f_bavail*stat.f_frsize,'reserve_bytes':4<<30,
                                  'free_inodes':stat.f_favail,'minimum_free_fraction':0.2}}
    receipt['stages'].append(step)
    save()
    with (OUT/(arm+'.log')).open('wb') as log:
        result = subprocess.run(command,stdout=log,stderr=subprocess.STDOUT)
    trial_path = ROOT/'trials'/f'ax447-corrected-{arm}-known-tail-oracle-502'/'receipt.json'
    trial = json.loads(trial_path.read_text())
    step.update(exit_code=result.returncode,case_qualified=trial['qualified'],receipt=str(trial_path),
                finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
    assert not (trial_path.parent/'remaining-owned-containers.json').read_text().strip()
    save()
receipt.update(completed=True,helper_all_passed=all(s['case_qualified'] and s['exit_code']==0 for s in receipt['stages']),
               finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
save()
raise SystemExit(0 if receipt['helper_all_passed'] else 1)
