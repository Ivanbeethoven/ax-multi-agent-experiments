#include "fio.h"
#include <stddef.h>
#include <stdio.h>

_Static_assert(DDIR_WRITE == 1, "write direction changed");
_Static_assert(DDIR_SYNC_FILE_RANGE == 5, "range-sync direction changed");
_Static_assert(DDIR_RWDIR_SYNC_CNT == 4, "total count changed");
_Static_assert(sizeof(((struct thread_stat *)0)->total_io_u) == 4 * sizeof(uint64_t), "total array changed");
_Static_assert(offsetof(struct thread_stat, short_io_u) == offsetof(struct thread_stat, total_io_u) + sizeof(((struct thread_stat *)0)->total_io_u), "adjacency changed");
_Static_assert(offsetof(struct thread_stat, total_io_u) + DDIR_SYNC_FILE_RANGE * sizeof(uint64_t) == offsetof(struct thread_stat, short_io_u) + DDIR_WRITE * sizeof(uint64_t), "alias address differs");

int main(void) {
    printf("{\"sizeof_thread_stat\":%zu,\"sizeof_uint64_t\":%zu,\"total_io_u_offset\":%zu,\"total_io_u_bytes\":%zu,\"short_io_u_offset\":%zu,\"short_io_u_bytes\":%zu,\"range_sync_index_address_offset\":%zu,\"write_short_address_offset\":%zu,\"ddir_write\":%d,\"ddir_sync_file_range\":%d,\"ddir_sync_predicate\":%d}\n",
        sizeof(struct thread_stat), sizeof(uint64_t),
        offsetof(struct thread_stat, total_io_u), sizeof(((struct thread_stat *)0)->total_io_u),
        offsetof(struct thread_stat, short_io_u), sizeof(((struct thread_stat *)0)->short_io_u),
        offsetof(struct thread_stat, total_io_u) + DDIR_SYNC_FILE_RANGE * sizeof(uint64_t),
        offsetof(struct thread_stat, short_io_u) + DDIR_WRITE * sizeof(uint64_t),
        DDIR_WRITE, DDIR_SYNC_FILE_RANGE, ddir_sync(DDIR_SYNC_FILE_RANGE));
    return 0;
}
