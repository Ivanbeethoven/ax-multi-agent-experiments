# BrewFS Perf Report

Meta backend: redis

## Summary

| Tool | Status | Seconds | Log |
| --- | --- | ---: | --- |
| fio-randwrite-direct0 | pass | 25 | tools/fio-randwrite-direct0.log |

## Post-Write Drain

| Tool | Drain seconds | Pending bytes | Dirty bytes | Buffer dirty bytes |
| --- | ---: | ---: | ---: | ---: |
| fio-randwrite-direct0 | 44 | 0 | 0 | 0 |

## Fio

| Tool | Workload | Direct | BS | Jobs | Read BW | Read IOPS | Write BW | Write IOPS | Read P99 | Write P99 | Raw |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |---: | ---: | ---: |
| fio-randwrite-direct0 | randwrite | 0 | 4m | 4 | 0.00 B/s | 0.00 | 165.92 MiB/s | 41.48 | 0.000 ms | 68.682 ms | results/fio-randwrite-direct0.json |

## Fio Runtime Accounting

Use `active_io_runtime` for close/flush tail detection; fio `job_runtime_ms` can aggregate multiple jobs under group reporting.

| Tool | Direct | Script wall | fio job_runtime | wall-job_runtime | wall/job_runtime | active_io_runtime | wall-active_io | wall/active_io | Tail marker |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| fio-randwrite-direct0 | 0 | 25 s | 97.386 s | -72.386 s | 0.26x | 24.349 s | +0.651 s | 1.03x | fio job_runtime aggregates jobs |

## Fully Drained Write Throughput

Actual fio bytes divided by `active_io_runtime + post_write_drain`; unlike foreground bandwidth, this includes the time required to empty the filesystem writeback queue.

| Tool | Active I/O | Drain | Complete | Read | Write | Total | Raw |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| fio-randwrite-direct0 | 24.349 s | 44.000 s | 68.349 s | 0.00 MiB/s | 59.11 MiB/s | 59.11 MiB/s | fully-drained-throughput.tsv |

## Latency Percentiles

### Read

| Workload | p1 | p5 | p25 | p50 | p75 | p90 | p95 | p99 | p99.9 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |

### Write

| Workload | p1 | p5 | p25 | p50 | p75 | p90 | p95 | p99 | p99.9 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| fio-randwrite-direct0 | 0.000 ms | 0.000 ms | 0.000 ms | 15.008 ms | 0.000 ms | 0.000 ms | 42.729 ms | 68.682 ms | 17112.760 ms |

## Redis Diagnostics

| Tool | Top commandstats | Details |
| --- | --- | --- |
| fio-randwrite-direct0 | evalsha: calls=544, usec/call=53.12<br>exec: calls=1014, usec/call=3.24<br>get: calls=1538, usec/call=1.29<br>rpush: calls=512, usec/call=3.62<br>incrby: calls=512, usec/call=2.64 | diagnostics/redis-fio-randwrite-direct0-after.txt |

## BrewFS Stats

Counters are per-tool deltas when matching before/after snapshots exist; dirty, live, and inflight values are after-tool gauges.

| Tool | Cache hit | FUSE read | FUSE write | Dirty | Live dirty | Recent pending | Recent uploaded | Read buffer | S3 ops | S3 avg latency | Details |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| fio-randwrite-direct0 | 0.0% (0/0) | 0.0 MiB | 4040.0 MiB | 3072.0 MiB | 0.0 MiB | 3072.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=247 | GET=0.00 ms, PUT=577.22 ms | diagnostics/stats-fio-randwrite-direct0-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=512 ops/4040.0 MiB/56476.9 ms, foreground=stage 56.48s/commit_wait 2.32s, flush_wait=4 ops/0.03s/4 slices, stage_fail=0, commit_before_stage=359, remote_inflight=3072.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=20, max_buffer_dirty=3652.0 MiB, max_live_dirty=1032.0 MiB, max_live_slices=143, max_recent_pending=3644.0 MiB, max_recent_uploaded=0.0 MiB, max_stage_inflight=472.0 MiB, max_remote_inflight=3644.0 MiB, last_buffer_dirty=3172.0 MiB, slices=create 513/reuse 3528/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=512 avg=7.9 MiB blocks=1.98/batch partial_tail=0.02 (size 0/max 0/flush 4/auto 6/age 0), partial_origin=normal 10/cached 0/mixed 0/unknown 0, auto_detail=age 2/idle 4/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 6/cached 0/mixed 0/unknown 0, freeze=size 64/flush 5/auto 300/max 144/age 0 |
| fio-randwrite-direct0-post-write-drained | 0.0% (0/0) | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=768 | GET=0.00 ms, PUT=298.68 ms | diagnostics/stats-fio-randwrite-direct0-post-write-drained-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=0 ops/0.0 MiB/0.0 ms, foreground=stage 0.00s/commit_wait 0.00s, flush_wait=0 ops/0.00s/0 slices, stage_fail=0, commit_before_stage=0, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 513/reuse 3528/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=0 avg=n/a blocks=0.00/batch partial_tail=0.00 (size 0/max 0/flush 0/auto 0/age 0), partial_origin=normal 0/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 0/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 0/cached 0/mixed 0/unknown 0, freeze=size 64/flush 5/auto 300/max 144/age 0 |
| fio-randwrite-direct0-post-write-runner-drained | 0.0% (0/0) | 0.0 MiB | 4040.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=1016 | GET=0.00 ms, PUT=366.11 ms | diagnostics/stats-fio-randwrite-direct0-post-write-runner-drained-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=513 ops/4040.0 MiB/56477.9 ms, foreground=stage 56.48s/commit_wait 2.32s, flush_wait=5 ops/0.03s/5 slices, stage_fail=0, commit_before_stage=360, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 513/reuse 3528/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=513 avg=7.9 MiB blocks=1.98/batch partial_tail=0.02 (size 0/max 0/flush 5/auto 6/age 0), partial_origin=normal 11/cached 0/mixed 0/unknown 0, auto_detail=age 2/idle 4/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 6/cached 0/mixed 0/unknown 0, freeze=size 64/flush 5/auto 300/max 144/age 0 |
