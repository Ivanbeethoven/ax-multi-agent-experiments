"""Fixed longer real Shared-workspace row guard; preserves the earlier short results."""
from contextlib import contextmanager
import argparse
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import traceback

import boto3
from botocore.config import Config

ROOT = Path('/home/dev/ax-perf-issues-corrected-validation/compose')
from summarize_row_long import validate_result

OPERATIONS_PER_THREAD = 65536
REPETITIONS = 6
ROW_HELPER = Path('/home/dev/ax-issue-446-workspace-guard/workspace_row_guard.py')
ROW_HELPER_SHA256 = 'f27bda51f89d9d3cd2240143a3292c80d3f7b5a6c13970bb375243a717501695'

parser = argparse.ArgumentParser()
parser.add_argument('campaign', help='Unique lowercase campaign suffix')
args = parser.parse_args()
assert args.campaign.isalnum() and args.campaign.islower()
arms_to_run = ['baseline','candidate']
project = 'ax447-corrected-rowlong-' + args.campaign
out = ROOT / 'workspace' / project
out.mkdir(parents=True, exist_ok=False)
images = json.loads((ROOT / 'image-manifest.json').read_text())
pins = json.loads((ROOT / 'binary-manifest.json').read_text())
specs = {arm: json.loads((ROOT / f'{arm}-build-spec.json').read_text()) for arm in ('baseline', 'candidate')}
binaries = {arm: Path(spec['worktree']) / 'target/docker/brewfs' for arm, spec in specs.items()}
producer = Path(specs['baseline']['worktree']) / 'target/docker/packed_v3_snapshot_fixture'
base_env = {k: v for k, v in os.environ.items() if not k.startswith(
    ('BREWFS_', 'COMPOSE_', 'PERF_', 'RUSTFS_', 'REDIS_', 'AWS_', 'AX447_'))}
base_env.update(AWS_ACCESS_KEY_ID='rustfsadmin', AWS_SECRET_ACCESS_KEY='rustfsadmin',
                AWS_DEFAULT_REGION='us-east-1', AWS_REGION='us-east-1',
                AWS_EC2_METADATA_DISABLED='true', NO_PROXY='127.0.0.1,localhost',
                RUST_LOG='warn', NO_COLOR='1', GIT_OPTIONAL_LOCKS='0')
packed_limits = {'roots':16 << 20, 'metadata_owned':256 << 20, 'plans':32 << 20,
                 'control':1 << 20, 'stored':32 << 20, 'raw':32 << 20,
                 'decode_workspace':8 << 20, 'output':32 << 20}
base_env.update({'BREWFS_PACKED_V3_'+pool.upper()+'_BUDGET_BYTES':str(size)
                 for pool,size in packed_limits.items()})
service_env = dict(base_env, COMPOSE_PROJECT_NAME=project,
    AX447_FROZEN_SOURCE=specs['baseline']['worktree'], AX447_RUNNER_IMAGE='ax447-runner:'+project,
    PERF_CONTAINER_REDIS_BREWFS_PERF=project+'-redis',
    PERF_CONTAINER_RUSTFS_BREWFS_PERF_REDIS=project+'-rustfs',
    PERF_CONTAINER_MINIO_BREWFS_PERF_REDIS=project+'-minio',
    REDIS_HOST_PORT='26379', RUSTFS_S3_HOST_PORT='29000', RUSTFS_CONSOLE_HOST_PORT='29001')
for key, field in [('TOOLS','tools'),('REDIS','redis'),('RUSTFS','rustfs'),('AWSCLI','awscli')]:
    service_env['AX447_'+key+'_IMAGE'] = images[field]['reference']
compose = ['docker', 'compose', '-f', str(ROOT/'compose.json')]
summary = {'project': project, 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'source': specs, 'binary_pins': pins, 'images': images, 'passed': False,
           'arms_run':arms_to_run,'comparison_requested':True,
           'phase': 'preflight', 'mount_exits': [], 'row_cases': [],
           'fixed_plan': {'keys':128,'threads':[1,8],'operations_per_thread':OPERATIONS_PER_THREAD,
                          'repetitions':REPETITIONS,'value_bytes':8,'row_ttl_ms':600000,
                          'row_budget_bytes':64 << 20,'order':'AB for even repetitions, BA for odd'},
           'supersedes_short_results':False,
           'packed_native_metrics': 'unsupported: frozen source registers row extension first',
           'row_budget_scope': 'Candidate enforces retained-byte admission; baseline ignores the byte flag and uses its original entry/TTL bound. Identical small hot working sets fit both.',
           'packed_budget_limits_bytes': packed_limits,
           'packed_budget_source': 'ca07159 wire005/budget.rs V3BudgetLimits::default and V3MountBudget::from_env; explicit equal env limits, native counters unavailable',
           'service_limits': {'redis':{'cpus':1,'memory_bytes':2 << 30},
                              'rustfs':{'cpus':2,'memory_bytes':8 << 30}},
           'scope': 'real Shared workspace hot fgetxattr; only unresolved 128-key 1/8-thread shapes, fixed longer work; original short rounds preserved'}
mount_points = []
row_input_hash = None
row_workloads = {}
summary['harness_sha256'] = {
    str(path): hashlib.sha256(path.read_bytes()).hexdigest()
    for path in (Path(__file__), Path(__file__).with_name('summarize_row_long.py'), ROW_HELPER)}
assert summary['harness_sha256'][str(ROW_HELPER)] == ROW_HELPER_SHA256, 'frozen row helper changed'

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')

def invoke(argv, path, env=base_env, timeout=60, check=True):
    p = subprocess.run(list(map(str, argv)), env=env, stdout=subprocess.PIPE,
                       stderr=subprocess.PIPE, timeout=timeout)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.with_suffix('.stdout').write_bytes(p.stdout)
    path.with_suffix('.stderr').write_bytes(p.stderr)
    if check and p.returncode:
        raise RuntimeError(f'{argv[0]} exited {p.returncode}; see {path}')
    return p

def mounted(point):
    return any(row.split()[4] == str(point) for row in Path('/proc/self/mountinfo').read_text().splitlines())

@contextmanager
def mount_arm(arm, label, endpoint, row_budget=64 << 20):
    run = out / label
    run.mkdir(parents=True, exist_ok=False)
    point = run / 'mount'; point.mkdir()
    mount_points.append(point)
    namespace = 'ax447-' + args.campaign + '-' + label
    data = dict(backend='s3', s3=dict(bucket=bucket, endpoint=endpoint, region='us-east-1',
                                    force_path_style=True, rustfs_ec_block_size_hint='auto'))
    write(run/'data.json', {'data': data})
    cli = [binaries[arm], 'workspace', '--meta-backend', 'redis', '--meta-url', redis_url,
           '--workspace-namespace', namespace]
    init = invoke([*cli, 'init-packed-volume', '--manifest-key', manifest_key,
                   '--data-config', run/'data.json'], run/'init', timeout=60)
    workspace = json.loads(init.stdout)['workspace_id']
    config = dict(volume_format='workspace-v1', volume={'format':'workspace-v1'}, workspace=workspace,
                  workspace_namespace=namespace, data=data,
                  meta={'backend':'redis','redis':{'url':redis_url},
                        'open_file_cache_ttl_ms':600000,'open_file_cache_capacity':65536},
                  layout=dict(chunk_size=67108864, block_size=4194304),
                  fuse=dict(workers=8, max_background=128, cache_ttl_ms=0, keep_cache=False),
                  cache=dict(cache_root=str(run/'cache'), writeback_mode='upload_before_commit',
                             read_memory_bytes=536870912, read_ssd_bytes=0, compression='none'))
    write(run/'mount-config.json', config)
    env = dict(base_env, BREWFS_FUSE_READ_DIRECT_IO='1', BREWFS_PACKED_METADATA_CACHE_BYTES=str(256 << 20),
               BREWFS_WORKSPACE_ROW_CACHE_BYTES=str(row_budget), BREWFS_WORKSPACE_ROW_CACHE_TTL_MS='600000')
    argv = [str(binaries[arm]), 'mount', '--config', str(run/'mount-config.json'), str(point)]
    write(run/'mount-receipt.json', {'argv':argv,'workspace_id':workspace,
                                   'environment':{k:v for k,v in env.items() if k.startswith('BREWFS_')}})
    proc = None
    with (run/'mount.log').open('wb') as log:
        try:
            proc = subprocess.Popen(argv, env=env, stdout=log, stderr=subprocess.STDOUT)
            deadline = time.monotonic()+30
            while not mounted(point):
                if proc.poll() is not None:
                    raise RuntimeError(f'{label} mount exited early: {proc.returncode}')
                if time.monotonic() >= deadline:
                    raise TimeoutError(f'{label} mount readiness timed out')
                time.sleep(.1)
            yield point, run
        finally:
            started = time.monotonic_ns()
            unmount = None
            unmount_error = None
            if mounted(point):
                try:
                    unmount = invoke(['fusermount3','-u',point], run/'unmount', timeout=5, check=False).returncode
                except Exception as error:
                    unmount_error = repr(error)
            code = None
            forced = False
            if proc is not None:
                try:
                    code = proc.wait(timeout=8)
                except subprocess.TimeoutExpired:
                    forced = True
                    proc.terminate()
                    try:
                        code = proc.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        proc.kill(); code = proc.wait(timeout=5)
            cleanup = dict(label=label, exit_code=code, forced=forced,
                           unmount_exit_code=unmount, mount_absent=not mounted(point),
                           unmount_error=unmount_error,
                           teardown_ns=time.monotonic_ns()-started)
            summary['mount_exits'].append(cleanup)
            write(run/'cleanup.json', cleanup)
            if code != 0 or forced or mounted(point) or unmount not in (None,0) or unmount_error:
                raise RuntimeError(f'{label} did not stop cleanly')

def row_case(arm, stage, repetition, keys, threads, operations):
    global row_input_hash
    label = f'row-{stage}-{arm}-k{keys}-t{threads}-r{repetition}'
    with mount_arm(arm, label, direct_endpoint) as (point, run):
        helper = ROW_HELPER
        command = [sys.executable, helper, 'prepare', '--mount',point,'--manifest',run/'input.json',
                   '--output',run/'prepare.json','--label',arm,'--files','128','--value-bytes','8']
        invoke(command,run/'prepare-command',timeout=120)
        command = [sys.executable,helper,'hot','--mount',point,'--manifest',run/'input.json',
                   '--output',run/'result.json','--label',arm,'--repetition',str(repetition),
                   '--keys',str(keys),'--threads',str(threads),'--ops-per-thread',str(operations)]
        if arm == 'candidate': command.append('--require-byte-metrics')
        invoke(command,run/'hot-command',timeout=180)
        result = json.loads((run/'result.json').read_text())
        validate_result(result, arm, repetition, threads)
        if row_input_hash is None:
            row_input_hash = result['canonical_input_sha256']
        assert result['canonical_input_sha256'] == row_input_hash
        shape = (keys,threads,operations)
        if shape not in row_workloads:
            row_workloads[shape] = result['workload_sha256']
        assert result['workload_sha256'] == row_workloads[shape]
        summary['row_cases'].append({'arm':arm,'stage':stage,'repetition':repetition,
                                     'keys':keys,'threads':threads,'operations_per_thread':operations,'path':str(run/'result.json')})

def cancel(signum, frame):
    raise TimeoutError('workspace campaign terminated')

signal.signal(signal.SIGTERM,cancel)
with Path('/home/dev/.ax-rbm-heavy.lock').open('w') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX)
    active = subprocess.run(['pgrep','-ax','cargo|rustc|fio|smallfiles'],capture_output=True,text=True)
    assert active.returncode == 1, active.stdout
    try:
        control_path = next(line.split(':',2)[2] for line in Path('/proc/self/cgroup').read_text().splitlines()
                            if line.startswith('0::'))
        control = Path('/sys/fs/cgroup') / control_path.lstrip('/')
        quota,period = (control/'cpu.max').read_text().split()
        memory_max = (control/'memory.max').read_text().strip()
        summary['client_unit_limits']={'cgroup':control_path,'cpu_max':f'{quota} {period}',
                                       'memory_max_bytes':memory_max}
        assert quota != 'max' and int(quota) == 3 * int(period), 'run in a unit with CPUQuota=300%'
        assert memory_max == str(16 << 30), 'run in a unit with MemoryMax=16G'
        for arm in arms_to_run:
            binary = binaries[arm]
            assert pins[arm]['commit'] == specs[arm]['commit']
            repo = specs[arm]['worktree']
            git = ['git','-c','safe.directory='+repo,'-C',repo]
            assert invoke([*git,'rev-parse','HEAD'],out/('source-'+arm)).stdout.decode().strip() == specs[arm]['commit']
            assert invoke([*git,'rev-parse','HEAD^{tree}'],out/('tree-'+arm)).stdout.decode().strip() == specs[arm]['tree']
            assert not invoke([*git,'diff','HEAD','--name-only'],out/('clean-'+arm)).stdout
            with binary.open('rb') as stream:
                assert hashlib.file_digest(stream,'sha256').hexdigest() == pins[arm]['sha256']
        assert pins['producer']['commit'] == 'ca07159f3da4b670e4aeb878faef928e69bc1634'
        assert pins['producer']['sha256'] == '8c4d65dbe8daaeaffb7f6084474a9a839df418c66d2aced6226842a5b8997d72'
        with producer.open('rb') as stream:
            assert hashlib.file_digest(stream,'sha256').hexdigest() == pins['producer']['sha256']
        for name,image in images.items():
            p = invoke(['docker','image','inspect',image['reference'],'--format','{{.Id}}'],
                       out/('preflight-image-'+name),timeout=15)
            assert p.stdout.decode().strip() == image['id']
        for port in (26379,29000,29001):
            p = invoke(['ss','-H','-ltn',f'sport = :{port}'],out/f'port-{port}')
            assert not p.stdout, f'Port {port} is already owned'
        summary['phase']='services'
        invoke([*compose,'config','--format','json'],out/'compose-config',env=service_env)
        invoke([*compose,'up','-d','--wait','redis','rustfs'],out/'services-up',env=service_env,timeout=240)
        invoke([sys.executable,ROOT/'verify-rustfs-runtime.py',project+'-rustfs',out/'rustfs-runtime-pin.json'],
               out/'runtime-pin-command',timeout=30)
        summary['rustfs_runtime_pin']=json.loads((out/'rustfs-runtime-pin.json').read_text())
        direct_endpoint='http://127.0.0.1:29000'; redis_url='redis://127.0.0.1:26379/0'
        bucket='ax447-workspace-fixture'
        s3=boto3.client('s3',endpoint_url=direct_endpoint,region_name='us-east-1',
                        aws_access_key_id='rustfsadmin',aws_secret_access_key='rustfsadmin',
                        config=Config(signature_version='s3v4',connect_timeout=3,read_timeout=30,
                                      retries={'total_max_attempts':1},s3={'addressing_style':'path'}))
        s3.create_bucket(Bucket=bucket)
        summary['phase']='fixture'
        source=out/'source';source.mkdir();expected={}
        for directory in range(8):
            folder=source/f'd{directory:02}';folder.mkdir()
            for file in range(16):
                relative=f'd{directory:02}/f{file:02}'
                data=hashlib.sha256(('ax447:'+relative).encode()).digest()*128
                (source/relative).write_bytes(data)
                os.utime(source/relative,(1,1))
                expected[relative]=hashlib.sha256(data).hexdigest()
            os.utime(folder,(1,1))
        os.utime(source,(1,1));write(out/'expected-files.json',expected)
        manifest_path=out/'manifest-key'
        invoke([producer,'--source-directory',source,'--source-consistency','best-effort-detected',
                '--source-hardlink-policy','visible-links','--output-dir',out/'objects',
                '--manifest-output',manifest_path,'--bucket',bucket,'--endpoint',direct_endpoint,
                '--region','us-east-1','--force-path-style','true','--prefix','base',
                '--metadata-codec','raw','--data-codec','raw','--inline-data','off',
                '--chunk-size','67108864','--block-size','4194304',
                '--s3-rustfs-ec-block-size-hint','auto'],out/'producer',timeout=180)
        manifest_key=manifest_path.read_text().strip()
        response=s3.get_object(Bucket=bucket,Key=manifest_key)
        try:
            assert 0 < response['ContentLength'] <= 64 << 20
            manifest_bytes=response['Body'].read(64 << 20)
            assert len(manifest_bytes) == response['ContentLength']
        finally: response['Body'].close()
        (out/'manifest.bin').write_bytes(manifest_bytes)
        summary.update(manifest_key=manifest_key,manifest_sha256=hashlib.sha256(manifest_bytes).hexdigest(),
                       input_sha256=hashlib.sha256(json.dumps(expected,sort_keys=True).encode()).hexdigest())
        # Every long arm already verifies a stable warm row working set before timing.
        # No repeated fill/memory cases or short performance waves in this campaign.
        summary['phase']='comparison'
        for repetition in range(REPETITIONS):
            order=('baseline','candidate') if repetition%2==0 else ('candidate','baseline')
            for threads in (1,8):
                for arm in order:
                    row_case(arm,'compare',repetition,128,threads,OPERATIONS_PER_THREAD)
                    write(out/'progress.json',summary)
        assert len(summary['row_cases']) == REPETITIONS * 2 * 2
        summary['passed']=True
        summary['phase']='complete'
    except Exception:
        summary['error']=traceback.format_exc()
        raise
    finally:
        remaining_mounts=[str(point) for point in mount_points if mounted(point)]
        if remaining_mounts:
            summary['services_cleanup']={'skipped':True,'reason':'owned FUSE mount still present; preserve backend for recovery',
                                         'remaining_mounts':remaining_mounts}
            summary['passed']=False
        else:
            try:
                cleanup=invoke([*compose,'down','-v'],out/'services-down',env=service_env,timeout=60,check=False)
                remaining=invoke(['docker','ps','-a','--filter',f'label=com.docker.compose.project={project}',
                                  '--format','{{.ID}}'],out/'remaining-owned-containers',timeout=20)
                summary['services_cleanup']={'exit_code':cleanup.returncode,'containers_absent':not remaining.stdout}
                summary['passed'] = summary['passed'] and cleanup.returncode==0 and not remaining.stdout
            except Exception:
                summary['services_cleanup']={'error':traceback.format_exc()}
                summary['passed']=False
        summary['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        write(out/'summary.json',summary)
    if not summary['passed']: raise SystemExit(1)
