# BrewFS Perf Report

Meta backend: redis

## Summary

| Tool | Status | Seconds | Log |
| --- | --- | ---: | --- |
| fio-seqwrite-direct0 | pass | 21 | tools/fio-seqwrite-direct0.log |
| fio-seqwrite-direct1 | pass | 20 | tools/fio-seqwrite-direct1.log |
| fio-randwrite-direct0 | pass | 24 | tools/fio-randwrite-direct0.log |
| fio-randwrite-direct1 | pass | 25 | tools/fio-randwrite-direct1.log |

## Post-Write Drain

| Tool | Drain seconds | Pending bytes | Dirty bytes | Buffer dirty bytes |
| --- | ---: | ---: | ---: | ---: |
| fio-seqwrite-direct0 | 25 | 0 | 0 | 0 |
| fio-seqwrite-direct1 | 28 | 0 | 0 | 0 |
| fio-randwrite-direct0 | 25 | 0 | 0 | 0 |
| fio-randwrite-direct1 | 53 | 0 | 0 | 0 |

## Fio

| Tool | Workload | Direct | BS | Jobs | Read BW | Read IOPS | Write BW | Write IOPS | Read P99 | Write P99 | Raw |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |---: | ---: | ---: |
| fio-randwrite-direct0 | randwrite | 0 | 4m | 4 | 0.00 B/s | 0.00 | 204.23 MiB/s | 51.06 | 0.000 ms | 73.925 ms | results/fio-randwrite-direct0.json |
| fio-randwrite-direct1 | randwrite | 1 | 4m | 4 | 0.00 B/s | 0.00 | 176.18 MiB/s | 44.05 | 0.000 ms | 0.013 ms | results/fio-randwrite-direct1.json |
| fio-seqwrite-direct0 | write | 0 | 4m | 1 | 0.00 B/s | 0.00 | 224.76 MiB/s | 56.19 | 0.000 ms | 42.205 ms | results/fio-seqwrite-direct0.json |
| fio-seqwrite-direct1 | write | 1 | 4m | 1 | 0.00 B/s | 0.00 | 233.06 MiB/s | 58.27 | 0.000 ms | 0.013 ms | results/fio-seqwrite-direct1.json |

## Fio Runtime Accounting

Use `active_io_runtime` for close/flush tail detection; fio `job_runtime_ms` can aggregate multiple jobs under group reporting.

| Tool | Direct | Script wall | fio job_runtime | wall-job_runtime | wall/job_runtime | active_io_runtime | wall-active_io | wall/active_io | Tail marker |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| fio-randwrite-direct0 | 0 | 24 s | 96.713 s | -72.713 s | 0.25x | 24.189 s | -0.189 s | 0.99x | fio job_runtime aggregates jobs |
| fio-randwrite-direct1 | 1 | 25 s | 100.876 s | -75.876 s | 0.25x | 25.224 s | -0.224 s | 0.99x | fio job_runtime aggregates jobs |
| fio-seqwrite-direct0 | 0 | 21 s | 20.803 s | +0.197 s | 1.01x | 20.804 s | +0.196 s | 1.01x | - |
| fio-seqwrite-direct1 | 1 | 20 s | 20.011 s | -0.011 s | 1.00x | 20.012 s | -0.012 s | 1.00x | fio job_runtime aggregates jobs |

## Fully Drained Write Throughput

Actual fio bytes divided by `active_io_runtime + post_write_drain`; unlike foreground bandwidth, this includes the time required to empty the filesystem writeback queue.

| Tool | Active I/O | Drain | Complete | Read | Write | Total | Raw |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| fio-randwrite-direct0 | 24.189 s | 25.000 s | 49.189 s | 0.00 MiB/s | 100.43 MiB/s | 100.43 MiB/s | fully-drained-throughput.tsv |
| fio-randwrite-direct1 | 25.224 s | 53.000 s | 78.224 s | 0.00 MiB/s | 56.81 MiB/s | 56.81 MiB/s | fully-drained-throughput.tsv |
| fio-seqwrite-direct0 | 20.804 s | 25.000 s | 45.804 s | 0.00 MiB/s | 102.09 MiB/s | 102.09 MiB/s | fully-drained-throughput.tsv |
| fio-seqwrite-direct1 | 20.012 s | 28.000 s | 48.012 s | 0.00 MiB/s | 97.14 MiB/s | 97.14 MiB/s | fully-drained-throughput.tsv |

## Latency Percentiles

### Read

| Workload | p1 | p5 | p25 | p50 | p75 | p90 | p95 | p99 | p99.9 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |

### Write

| Workload | p1 | p5 | p25 | p50 | p75 | p90 | p95 | p99 | p99.9 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| fio-randwrite-direct0 | 0.000 ms | 0.000 ms | 0.000 ms | 24.510 ms | 0.000 ms | 0.000 ms | 46.399 ms | 73.925 ms | 10267.656 ms |
| fio-randwrite-direct1 | 0.000 ms | 0.000 ms | 0.000 ms | 0.005 ms | 0.000 ms | 0.000 ms | 0.007 ms | 0.013 ms | 0.072 ms |
| fio-seqwrite-direct0 | 0.000 ms | 0.000 ms | 0.000 ms | 10.420 ms | 0.000 ms | 0.000 ms | 32.899 ms | 42.205 ms | 238.027 ms |
| fio-seqwrite-direct1 | 0.000 ms | 0.000 ms | 0.000 ms | 0.005 ms | 0.000 ms | 0.000 ms | 0.007 ms | 0.013 ms | 0.031 ms |

## Redis Diagnostics

| Tool | Top commandstats | Details |
| --- | --- | --- |
| fio-randwrite-direct0 | evalsha: calls=736, usec/call=77.14<br>exec: calls=1239, usec/call=5.33<br>rpush: calls=705, usec/call=6.45<br>get: calls=1956, usec/call=2.16<br>incrby: calls=705, usec/call=4.96 | diagnostics/redis-fio-randwrite-direct0-after.txt |
| fio-randwrite-direct1 | evalsha: calls=656, usec/call=83.51<br>exec: calls=1122, usec/call=4.78<br>rpush: calls=714, usec/call=7.38<br>get: calls=1775, usec/call=2.06<br>incrby: calls=638, usec/call=5.32 | diagnostics/redis-fio-randwrite-direct1-after.txt |
| fio-seqwrite-direct0 | exec: calls=1170, usec/call=7.78<br>evalsha: calls=98, usec/call=77.29<br>get: calls=1248, usec/call=3.75<br>multi: calls=1170, usec/call=1.84<br>hget: calls=1190, usec/call=1.45 | diagnostics/redis-fio-seqwrite-direct0-after.txt |
| fio-seqwrite-direct1 | exec: calls=1167, usec/call=7.01<br>evalsha: calls=96, usec/call=75.35<br>get: calls=1244, usec/call=3.35<br>multi: calls=1167, usec/call=1.69<br>hget: calls=1187, usec/call=1.20 | diagnostics/redis-fio-seqwrite-direct1-after.txt |

## BrewFS Stats

Counters are per-tool deltas when matching before/after snapshots exist; dirty, live, and inflight values are after-tool gauges.

| Tool | Cache hit | FUSE read | FUSE write | Dirty | Live dirty | Recent pending | Recent uploaded | Read buffer | S3 ops | S3 avg latency | Details |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| fio-randwrite-direct0 | 0.0% (0/0) | 0.0 MiB | 4940.0 MiB | 3064.0 MiB | 0.0 MiB | 3064.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=477 | GET=553.82 ms, PUT=298.51 ms | diagnostics/stats-fio-randwrite-direct0-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=705 ops/4940.0 MiB/185601.0 ms, foreground=stage 185.60s/commit_wait 2.74s, flush_wait=4 ops/0.03s/4 slices, stage_fail=0, commit_before_stage=546, remote_inflight=3064.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=20, max_buffer_dirty=3564.0 MiB, max_live_dirty=924.0 MiB, max_live_slices=139, max_recent_pending=3528.0 MiB, max_recent_uploaded=0.0 MiB, max_stage_inflight=572.0 MiB, max_remote_inflight=3528.0 MiB, last_buffer_dirty=3117.0 MiB, slices=create 705/reuse 4235/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=705 avg=7.0 MiB blocks=1.76/batch partial_tail=0.02 (size 0/max 0/flush 3/auto 11/age 0), partial_origin=normal 14/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 11/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 11/cached 0/mixed 0/unknown 0, freeze=size 79/flush 4/auto 511/max 111/age 0 |
| fio-randwrite-direct0-post-write-drained | 0.0% (0/0) | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=765 | GET=553.82 ms, PUT=158.19 ms | diagnostics/stats-fio-randwrite-direct0-post-write-drained-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=0 ops/0.0 MiB/0.0 ms, foreground=stage 0.00s/commit_wait 0.00s, flush_wait=0 ops/0.00s/0 slices, stage_fail=0, commit_before_stage=0, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 705/reuse 4235/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=0 avg=n/a blocks=0.00/batch partial_tail=0.00 (size 0/max 0/flush 0/auto 0/age 0), partial_origin=normal 0/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 0/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 0/cached 0/mixed 0/unknown 0, freeze=size 79/flush 4/auto 511/max 111/age 0 |
| fio-randwrite-direct0-post-write-runner-drained | 87.8% (1037/1181) | 512.0 MiB | 4940.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=142, PUT=1258 | GET=553.82 ms, PUT=209.72 ms | diagnostics/stats-fio-randwrite-direct0-post-write-runner-drained-after.txt; range=0, full=142, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=705 ops/4940.0 MiB/185601.0 ms, foreground=stage 185.60s/commit_wait 2.74s, flush_wait=4 ops/0.03s/4 slices, stage_fail=0, commit_before_stage=546, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 705/reuse 4235/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=705 avg=7.0 MiB blocks=1.76/batch partial_tail=0.02 (size 0/max 0/flush 3/auto 11/age 0), partial_origin=normal 14/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 11/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 11/cached 0/mixed 0/unknown 0, freeze=size 79/flush 4/auto 511/max 111/age 0 |
| fio-randwrite-direct1 | 53.2% (82/154) | 0.0 MiB | 4444.0 MiB | 3076.0 MiB | 0.0 MiB | 3076.0 MiB | 0.0 MiB | 0.0 MiB | GET=72, PUT=429 | GET=31.50 ms, PUT=401.15 ms | diagnostics/stats-fio-randwrite-direct1-after.txt; range=0, full=72, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=626 ops/4444.0 MiB/133676.7 ms, foreground=stage 133.68s/commit_wait 3.01s, flush_wait=4 ops/0.17s/4 slices, stage_fail=0, commit_before_stage=495, remote_inflight=3076.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=21, max_buffer_dirty=3603.0 MiB, max_live_dirty=1125.0 MiB, max_live_slices=142, max_recent_pending=3571.0 MiB, max_recent_uploaded=0.0 MiB, max_stage_inflight=524.0 MiB, max_remote_inflight=3572.0 MiB, last_buffer_dirty=3145.0 MiB, slices=create 626/reuse 3818/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=626 avg=7.1 MiB blocks=1.79/batch partial_tail=0.03 (size 2/max 0/flush 3/auto 11/age 0), partial_origin=normal 16/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 11/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 11/cached 0/mixed 0/unknown 0, freeze=size 70/flush 3/auto 428/max 125/age 0 |
| fio-randwrite-direct1-post-write-drained | 53.7% (325/605) | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=281, PUT=1087 | GET=77.13 ms, PUT=156.31 ms | diagnostics/stats-fio-randwrite-direct1-post-write-drained-after.txt; range=0, full=281, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=0 ops/0.0 MiB/0.0 ms, foreground=stage 0.00s/commit_wait 0.00s, flush_wait=0 ops/0.00s/0 slices, stage_fail=0, commit_before_stage=0, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 626/reuse 3818/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=0 avg=n/a blocks=0.00/batch partial_tail=0.00 (size 0/max 0/flush 0/auto 0/age 0), partial_origin=normal 0/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 0/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 0/cached 0/mixed 0/unknown 0, freeze=size 70/flush 3/auto 428/max 125/age 0 |
| fio-randwrite-direct1-post-write-runner-drained | 84.8% (4376/5160) | 2048.0 MiB | 4444.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=769, PUT=1394 | GET=415.48 ms, PUT=246.10 ms | diagnostics/stats-fio-randwrite-direct1-post-write-runner-drained-after.txt; range=0, full=769, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=626 ops/4444.0 MiB/133676.7 ms, foreground=stage 133.68s/commit_wait 3.01s, flush_wait=4 ops/0.17s/4 slices, stage_fail=0, commit_before_stage=495, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 626/reuse 3818/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=626 avg=7.1 MiB blocks=1.79/batch partial_tail=0.03 (size 2/max 0/flush 3/auto 11/age 0), partial_origin=normal 16/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 11/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 11/cached 0/mixed 0/unknown 0, freeze=size 70/flush 3/auto 428/max 125/age 0 |
| fio-seqwrite-direct0 | 0.0% (0/0) | 0.0 MiB | 4676.0 MiB | 3012.0 MiB | 0.0 MiB | 3012.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=420 | GET=0.00 ms, PUT=293.32 ms | diagnostics/stats-fio-seqwrite-direct0-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=76 ops/4676.0 MiB/21722.9 ms, foreground=stage 21.72s/commit_wait 0.92s, flush_wait=2 ops/0.01s/2 slices, stage_fail=0, commit_before_stage=76, remote_inflight=3012.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=17, max_buffer_dirty=3074.0 MiB, max_live_dirty=82.0 MiB, max_live_slices=2, max_recent_pending=3072.0 MiB, max_recent_uploaded=0.0 MiB, max_stage_inflight=320.0 MiB, max_remote_inflight=3072.0 MiB, last_buffer_dirty=3073.0 MiB, slices=create 76/reuse 4601/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=76 avg=61.5 MiB blocks=15.41/batch partial_tail=0.04 (size 0/max 0/flush 2/auto 1/age 0), partial_origin=normal 3/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 1/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 1/cached 0/mixed 0/unknown 0, freeze=size 73/flush 2/auto 1/max 0/age 0 |
| fio-seqwrite-direct0-post-write-drained | 0.0% (0/0) | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=751 | GET=0.00 ms, PUT=163.62 ms | diagnostics/stats-fio-seqwrite-direct0-post-write-drained-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=0 ops/0.0 MiB/0.0 ms, foreground=stage 0.00s/commit_wait 0.00s, flush_wait=0 ops/0.00s/0 slices, stage_fail=0, commit_before_stage=0, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 76/reuse 4601/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=0 avg=n/a blocks=0.00/batch partial_tail=0.00 (size 0/max 0/flush 0/auto 0/age 0), partial_origin=normal 0/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 0/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 0/cached 0/mixed 0/unknown 0, freeze=size 73/flush 2/auto 1/max 0/age 0 |
| fio-seqwrite-direct0-post-write-runner-drained | 0.0% (0/0) | 0.0 MiB | 4676.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=1171 | GET=0.00 ms, PUT=210.14 ms | diagnostics/stats-fio-seqwrite-direct0-post-write-runner-drained-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=76 ops/4676.0 MiB/21722.9 ms, foreground=stage 21.72s/commit_wait 0.92s, flush_wait=2 ops/0.01s/2 slices, stage_fail=0, commit_before_stage=76, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 76/reuse 4601/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=76 avg=61.5 MiB blocks=15.41/batch partial_tail=0.04 (size 0/max 0/flush 2/auto 1/age 0), partial_origin=normal 3/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 1/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 1/cached 0/mixed 0/unknown 0, freeze=size 73/flush 2/auto 1/max 0/age 0 |
| fio-seqwrite-direct1 | 100.0% (8/8) | 0.0 MiB | 4664.0 MiB | 3000.0 MiB | 56.0 MiB | 2944.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=420 | GET=574.22 ms, PUT=276.15 ms | diagnostics/stats-fio-seqwrite-direct1-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=73 ops/4608.0 MiB/17827.4 ms, foreground=stage 17.83s/commit_wait 0.27s, flush_wait=0 ops/0.00s/0 slices, stage_fail=0, commit_before_stage=73, remote_inflight=3000.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=17, max_buffer_dirty=3078.0 MiB, max_live_dirty=68.0 MiB, max_live_slices=2, max_recent_pending=3072.0 MiB, max_recent_uploaded=0.0 MiB, max_stage_inflight=256.0 MiB, max_remote_inflight=3072.0 MiB, last_buffer_dirty=2955.0 MiB, slices=create 74/reuse 4590/reject_unique 0/reject_prefix 0, live_slices=1 avg=56.0 MiB, origin=normal 1/cached 0/mixed 0/unknown 0, upload_batch=74 avg=63.0 MiB blocks=15.77/batch partial_tail=0.03 (size 1/max 0/flush 0/auto 1/age 0), partial_origin=normal 2/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 1/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 1/cached 0/mixed 0/unknown 0, freeze=size 72/flush 1/auto 1/max 0/age 0 |
| fio-seqwrite-direct1-post-write-drained | 0.0% (0/0) | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=746 | GET=574.22 ms, PUT=183.51 ms | diagnostics/stats-fio-seqwrite-direct1-post-write-drained-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=0 ops/0.0 MiB/0.0 ms, foreground=stage 0.00s/commit_wait 0.00s, flush_wait=0 ops/0.00s/0 slices, stage_fail=0, commit_before_stage=0, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 74/reuse 4590/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=0 avg=n/a blocks=0.00/batch partial_tail=0.00 (size 0/max 0/flush 0/auto 0/age 0), partial_origin=normal 0/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 0/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 0/cached 0/mixed 0/unknown 0, freeze=size 72/flush 1/auto 1/max 0/age 0 |
| fio-seqwrite-direct1-post-write-runner-drained | 88.6% (1021/1153) | 512.0 MiB | 4664.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=129, PUT=1167 | GET=574.22 ms, PUT=217.61 ms | diagnostics/stats-fio-seqwrite-direct1-post-write-runner-drained-after.txt; range=0, full=129, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=74 ops/4664.0 MiB/17965.3 ms, foreground=stage 17.97s/commit_wait 0.27s, flush_wait=1 ops/0.07s/1 slices, stage_fail=0, commit_before_stage=74, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 74/reuse 4590/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=74 avg=63.0 MiB blocks=15.77/batch partial_tail=0.03 (size 1/max 0/flush 0/auto 1/age 0), partial_origin=normal 2/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 1/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 1/cached 0/mixed 0/unknown 0, freeze=size 72/flush 1/auto 1/max 0/age 0 |
