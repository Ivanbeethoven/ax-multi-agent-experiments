"""Actual FUSE fill guard; imported by the owner of the isolated mount lifecycle.

No credentials, HTTP Authorization, or signed URL queries enter the event log.
The proxy delays only exact GroupMeta ranges decoded from fixture containers.
"""
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
import hashlib
from http.client import HTTPConnection
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import os
from pathlib import Path
import socket
import struct
from threading import Barrier, Lock, Thread
import time
from urllib.parse import unquote, urlsplit


def group_ranges(key, prefix, object_bytes):
    """Parse instrumentation targets; production still authenticates the object.

    The dedicated source-directory producer writes one group per container.
    Reject unsupported/malformed shapes instead of guessing offsets.
    """
    if prefix[:8] != b'BRFGC005':
        return []
    if len(prefix) < 4096 + 24 + 108:
        raise ValueError('truncated group-container directory')
    version, = struct.unpack_from('<H', prefix, 8)
    header, = struct.unpack_from('<I', prefix, 12)
    declared, = struct.unpack_from('<Q', prefix, 24)
    if (version, header, declared) != (5, 4096, object_bytes):
        raise ValueError('group-container header identity or object size differs')
    if prefix[4096:4100] != b'GC05' or prefix[4109:4112] != bytes(3):
        raise ValueError('invalid GC05 prefix')
    count, frames = struct.unpack_from('<II', prefix, 4112)
    if count != 1:
        raise ValueError('guard requires one group per source-directory container')
    start = 4120
    group_id, offset, stored, raw = struct.unpack_from('<QQII', prefix, start)
    first_len, last_len = struct.unpack_from('<HH', prefix, start + 104)
    directory_end = start + 108 + first_len + last_len
    if not 0 < first_len <= 1024 or not 0 < last_len <= 1024:
        raise ValueError('invalid group name bounds')
    if directory_end > len(prefix):
        raise ValueError('directory exceeds bounded inventory prefix')
    if not 0 < stored <= 256 * 1024 or raw != stored or prefix[start + 24] != 0:
        raise ValueError('guard requires bounded raw GroupMeta')
    if offset < directory_end or offset + stored > object_bytes - 64:
        raise ValueError('metadata range exceeds container bounds')
    return [dict(key=key, group_id=group_id, offset=offset, length=stored,
                 range=f'bytes={offset}-{offset + stored - 1}', object_bytes=object_bytes,
                 frame_count=frames, object_key_sha256=hashlib.sha256(key.encode()).hexdigest())]


def inventory_from_s3(s3, bucket, prefix='base/'):
    """Call outside measurements, using the direct backend endpoint.

    Producer --bucket uploads objects itself; --output-dir is not an upload
    instruction. Read the exact manifest key from --manifest-output. This
    inventory mechanically proves objects exist before either reader arm.
    """
    targets = []
    objects = []
    for page in s3.get_paginator('list_objects_v2').paginate(Bucket=bucket, Prefix=prefix):
        for obj in page.get('Contents', []):
            key, size = obj['Key'], obj['Size']
            response = s3.get_object(Bucket=bucket, Key=key, Range='bytes=0-8191')
            try:
                data = response['Body'].read(8193)
            finally:
                response['Body'].close()
            if len(data) > 8192:
                raise ValueError('backend ignored bounded inventory range')
            objects.append(dict(key=key, bytes=size, prefix_sha256=hashlib.sha256(data).hexdigest()))
            targets.extend(group_ranges(key, data, size))
    if len({(t['key'], t['range']) for t in targets}) != len(targets):
        raise ValueError('duplicate GroupMeta identity')
    if len({t['key'] for t in targets if t['frame_count']}) < 8:
        raise ValueError('fixture has fewer than eight payload group containers')
    return dict(objects=sorted(objects, key=lambda x: x['key']),
                targets=sorted(targets, key=lambda x: (x['key'], x['range'])))


class FillProbe:
    def __init__(self, bucket, targets, delay_seconds):
        if not 0 <= delay_seconds <= 1:
            raise ValueError('delay outside bounded diagnostic interval')
        self.targets = {('/' + bucket + '/' + t['key'], t['range']): t for t in targets}
        if len(self.targets) != len(targets):
            raise ValueError('duplicate target')
        self.delay_seconds = delay_seconds
        self.lock = Lock()
        self.enabled = False
        self.active = 0
        self.target_active = 0
        self.max_target_active = 0
        self.events = []
        self.errors = 0
        self.endpoint = None
        self.request_audit = []

    def begin_wave(self):
        with self.lock:
            if self.active or self.enabled:
                raise RuntimeError('proxy is not quiescent before wave')
            self.events = []
            self.errors = 0
            self.target_active = self.max_target_active = 0
            self.enabled = True

    def wait_idle(self):
        started = time.monotonic_ns()
        deadline = time.monotonic() + 5
        while True:
            with self.lock:
                if not self.active:
                    return time.monotonic_ns() - started
            if time.monotonic() >= deadline:
                raise TimeoutError('proxy did not become quiescent before reads')
            time.sleep(.001)

    def finish_wave(self):
        started = time.monotonic_ns()
        deadline = time.monotonic() + 5
        while True:
            with self.lock:
                if not self.active:
                    self.enabled = False
                    return dict(request_audit=[dict(e) for e in self.request_audit], events=[dict(e) for e in self.events], errors=self.errors,
                                max_target_active=self.max_target_active,
                                after_read_drain_ns=time.monotonic_ns() - started,
                                injected_delay_seconds=self.delay_seconds)
            if time.monotonic() >= deadline:
                raise TimeoutError('proxy did not become quiescent after reads')
            time.sleep(.001)


@contextmanager
def delayed_group_meta_proxy(upstream_port, bucket, targets, delay_seconds=.05):
    probe = FillProbe(bucket, targets, delay_seconds)

    class Handler(BaseHTTPRequestHandler):
        protocol_version = 'HTTP/1.1'

        def setup(self):
            super().setup()
            self.connection.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)

        def log_message(self, *_):
            pass

        def forward(self):
            upstream = HTTPConnection('127.0.0.1', upstream_port, timeout=30)
            event = None
            with probe.lock:
                probe.active += 1
                identity = (unquote(urlsplit(self.path).path), self.headers.get('Range'))
                target = probe.targets.get(identity) if self.command == 'GET' else None
                audit = dict(method=self.command,path=identity[0],range=identity[1],wave_enabled=probe.enabled,target_match=target is not None,entered_ns=time.monotonic_ns())
                probe.request_audit.append(audit)
                if probe.enabled and target is not None:
                    probe.target_active += 1
                    probe.max_target_active = max(probe.max_target_active, probe.target_active)
                    event = dict(object_key_sha256=target['object_key_sha256'], range=target['range'],
                                 group_id=target['group_id'], entered_ns=time.monotonic_ns(),
                                 status=None, bytes=0)
                    probe.events.append(event)
            try:
                if event is not None:
                    time.sleep(probe.delay_seconds)
                    event['forward_started_ns'] = time.monotonic_ns()
                # Preserve signed headers, request-target, and body bytes. The
                # setup path creates the upper bucket with PUT; operator cleanup
                # may additionally issue POST DeleteObjects and DELETE Bucket.
                # Do not decode AWS content-encoding or reframe HTTP chunks.
                lengths = self.headers.get_all('Content-Length', [])
                transfer = self.headers.get('Transfer-Encoding')
                if transfer and (lengths or transfer.lower() != 'chunked'):
                    raise ValueError('unsupported request framing')
                if lengths and (len(set(lengths)) != 1 or not lengths[0].isdigit()):
                    raise ValueError('invalid request length')
                upstream.putrequest(self.command, self.path,
                                    skip_host=True, skip_accept_encoding=True)
                for name, value in self.headers.raw_items():
                    upstream.putheader(name, value)
                upstream.endheaders()

                def copy_exact(length):
                    while length:
                        data = self.rfile.read(min(length, 64 << 10))
                        if not data:
                            raise EOFError('truncated request body')
                        upstream.send(data)
                        length -= len(data)

                if transfer:
                    while True:
                        line = self.rfile.readline((64 << 10) + 1)
                        if len(line) > 64 << 10 or not line.endswith(b'\r\n'):
                            raise ValueError('invalid request chunk line')
                        size = int(line.split(b';', 1)[0], 16)
                        if size < 0:
                            raise ValueError('negative request chunk')
                        upstream.send(line)
                        if size == 0:
                            while True:
                                trailer = self.rfile.readline((64 << 10) + 1)
                                if len(trailer) > 64 << 10 or not trailer.endswith(b'\r\n'):
                                    raise ValueError('invalid request trailer')
                                upstream.send(trailer)
                                if trailer == b'\r\n':
                                    break
                            break
                        copy_exact(size)
                        ending = self.rfile.read(2)
                        if ending != b'\r\n':
                            raise ValueError('invalid request chunk ending')
                        upstream.send(ending)
                elif lengths:
                    copy_exact(int(lengths[0]))
                response = upstream.getresponse()
                audit['status'] = response.status
                audit['content_length'] = response.getheader('Content-Length')
                if event is not None:
                    event['status'] = response.status
                if response.status >= 400:
                    with probe.lock:
                        if probe.enabled:
                            probe.errors += 1
                # HEAD and 204/304 have no response body. Otherwise stream the
                # opaque entity bytes for every method, including S3 error XML.
                has_body = self.command != 'HEAD' and response.status not in (204, 304)
                close_delimited = has_body and response.getheader('Content-Length') is None
                self.send_response_only(response.status)
                for name, value in response.getheaders():
                    if name.lower() not in ('connection', 'transfer-encoding'):
                        self.send_header(name, value)
                if close_delimited:
                    # http.client removes transfer framing while reading; use
                    # connection-close framing without buffering or changing bytes.
                    self.send_header('Connection', 'close')
                    self.close_connection = True
                self.end_headers()
                if has_body:
                    while data := response.read(64 << 10):
                        self.wfile.write(data)
                        if event is not None:
                            event['bytes'] += len(data)
            except Exception as exc:
                with probe.lock:
                    if probe.enabled:
                        probe.errors += 1
                if event is not None:
                    event['error_type'] = type(exc).__name__
                self.close_connection = True
            finally:
                upstream.close()
                with probe.lock:
                    probe.active -= 1
                    if event is not None:
                        event['finished_ns'] = time.monotonic_ns()
                        probe.target_active -= 1

        do_GET = do_HEAD = do_PUT = do_POST = do_DELETE = forward

    with ThreadingHTTPServer(('127.0.0.1', 0), Handler) as server:
        server.daemon_threads = True
        probe.endpoint = f'http://127.0.0.1:{server.server_port}'
        thread = Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            yield probe
        finally:
            server.shutdown()
            thread.join()


def pread_wave(mount_point, relative_paths, expected_sha256, threads, probe, distinct_groups):
    """One cold wave; caller owns fresh mount, lease, budgets, and teardown."""
    if len(relative_paths) != 8 or threads not in (1, 8) or distinct_groups not in (1, 8):
        raise ValueError('guard requires eight reads, one/eight threads and groups')
    root = Path(mount_point).resolve()
    files = []
    try:
        for relative in relative_paths:
            if Path(relative).is_absolute() or '..' in Path(relative).parts:
                raise ValueError('unsafe fixture path')
            path = Path(relative)
            # Warm only the common parent lookup; leaf lookup remains inside the wave.
            parent_fd = os.open(root / path.parent, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
            files.append((parent_fd, path.name))
        # Parent opendir does not read its children. Leaf open and pread start
        # together after the barrier, so lookup cannot prewarm the target GroupMeta.
        barrier = Barrier(threads + 1)

        def reader(worker):
            barrier.wait(timeout=15)
            reads = []
            for index in range(worker, len(files), threads):
                started = time.monotonic_ns()
                parent_fd, leaf = files[index]
                fd = os.open(leaf, os.O_RDONLY | os.O_NOFOLLOW, dir_fd=parent_fd)
                try:
                    data = os.pread(fd, 4096, 0)
                finally:
                    os.close(fd)
                ended = time.monotonic_ns()
                digest = hashlib.sha256(data).hexdigest()
                relative = relative_paths[index]
                reads.append(dict(path=relative, bytes=len(data), sha256=digest,
                                  started_ns=started, finished_ns=ended,
                                  passed=len(data) == 4096 and digest == expected_sha256[relative]))
            return reads

        with ThreadPoolExecutor(max_workers=threads) as pool:
            futures = [pool.submit(reader, worker) for worker in range(threads)]
            setup_idle_wait_ns = probe.wait_idle()
            probe.begin_wave()
            started = time.monotonic_ns()
            barrier.wait(timeout=15)
            reads = [read for future in futures for read in future.result(timeout=60)]
            ended = time.monotonic_ns()
        observed = probe.finish_wave()
        events = observed['events']
        identities = {(event['object_key_sha256'], event['range']) for event in events}
        reasons = []
        setup_targets = {(row['path'], row['range']) for row in observed['request_audit']
                         if row['target_match'] and not row['wave_enabled']}
        wave_targets = {(row['path'], row['range']) for row in observed['request_audit']
                        if row['target_match'] and row['wave_enabled']}
        if setup_targets & wave_targets:
            reasons.append('a measured GroupMeta was already fetched during setup')
        if not all(read['passed'] for read in reads):
            reasons.append('payload readback differs')
        if len(events) != distinct_groups or len(identities) != distinct_groups:
            reasons.append('wave did not fetch each expected distinct GroupMeta exactly once')
        if observed['errors'] or any(event['status'] != 206 for event in events):
            reasons.append('proxy observed a backend failure/non-range response')
        for event in events:
            left, right = map(int, event['range'].removeprefix('bytes=').split('-'))
            if event['bytes'] != right - left + 1:
                reasons.append('targeted response length differs')
        return dict(passed=not reasons, reasons=reasons, threads=threads,
                    distinct_groups=distinct_groups, read_wall_ns=ended - started,
                    setup_idle_wait_ns=setup_idle_wait_ns,
                    reads=reads, proxy=observed,
                    leaf_open_pread_wall_ns=ended - started,
                    setup_target_groups=len(setup_targets),
                    scope='real Shared workspace FUSE leaf lookup/open+pread with controlled GroupMeta-only proxy delay; parent setup excluded')
    finally:
        for parent_fd, _leaf in files:
            os.close(parent_fd)
