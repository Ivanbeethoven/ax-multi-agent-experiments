#!/usr/bin/env python3
"""Two diagnostic prefix runs. No acceptance or inferred performance result."""
import fcntl,hashlib,json,os,re,shutil,signal,subprocess,sys,time,traceback
from pathlib import Path
R=Path('/home/dev/ax-perf-issues-corrected-validation/compose')
D=R/'profiling-prefix-604'
O=R/'matrices/diagnostic-profile604'
O.mkdir(parents=True,exist_ok=False)
record={'diagnostic_only':True,'performance_accepted':False,'attribution_usable':False,'passed':False,'arms':[],
        'started_unix_ns':time.time_ns(),'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
def save(path,data):
    tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(data,indent=2)+'\n');tmp.replace(path)
def digest(path):
    with path.open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def run(cmd,**kw):return subprocess.check_output(cmd,text=True,**kw)
def anchor():
    a=time.time_ns();m=time.monotonic_ns();b=time.time_ns()
    return {'realtime_before_ns':a,'monotonic_ns':m,'realtime_after_ns':b}
def stat(pid):
    text=Path(f'/proc/{pid}/stat').read_text();f=text[text.rfind(')')+2:].split()
    return {'raw':text,'starttime_ticks':int(f[19]),'utime_ticks':int(f[11]),'stime_ticks':int(f[12])}
def map_pid(project,request,expected_sha):
    ids=run(['docker','ps','-q','--filter','label=com.docker.compose.project='+project,
             '--filter','label=com.docker.compose.service=perf']).split()
    assert len(ids)==1,ids
    rows=run(['docker','top',ids[0],'-eo','pid,comm']).splitlines()[1:]
    matches=[]
    for row in rows:
        pid=int(row.split()[0]);base=Path(f'/proc/{pid}')
        s=(base/'status').read_text()
        ns=next((line.split()[1:] for line in s.splitlines() if line.startswith('NSpid:')),[])
        if ns and int(ns[-1])==request['pid']:
            actual=stat(pid);f=request['proc_stat'].split(') ',1)[1].split()
            assert actual['starttime_ticks']==int(f[19])
            actual_sha=digest(base/'exe');assert actual_sha==expected_sha,(actual_sha,expected_sha)
            matches.append((pid,{'host_pid':pid,'namespace_pids':ns,'container':ids[0],
                                'start':actual,'exe_sha256':actual_sha,'cmdline':(base/'cmdline').read_bytes().replace(b'\0',b' ').decode(),
                                'tasks_before':sorted(int(x.name) for x in (base/'task').iterdir())}))
    assert len(matches)==1,matches
    return matches[0]
def symbols(pid,target,binary):
    root=target/'symfs';root.mkdir()
    src=Path(f'/proc/{pid}/root')
    maps=Path(f'/proc/{pid}/maps').read_text();(target/'maps.txt').write_text(maps)
    entries=[]
    for path in sorted(set(line.split(maxsplit=5)[-1] for line in maps.splitlines() if len(line.split(maxsplit=5))==6)):
        if not path.startswith('/') or path.endswith(' (deleted)'):continue
        original=src/path.lstrip('/');dest=root/path.lstrip('/')
        if not original.is_file():continue
        dest.parent.mkdir(parents=True,exist_ok=True)
        if path=='/usr/local/bin/brewfs':dest.symlink_to(binary)
        else:shutil.copyfile(original,dest)
        entries.append({'mapped_path':path,'sha256':digest(dest),'bytes':dest.stat().st_size,'link_to_frozen_binary':dest.is_symlink()})
    save(target/'symbol-files.json',entries)
    assert any(x['mapped_path']=='/usr/local/bin/brewfs' for x in entries)
    return root
def finish_perf(perf,target,pid,symroot):
    perf.send_signal(signal.SIGINT)
    code=perf.wait(timeout=30)
    # perf 6.8 writes its complete file then propagates the requested SIGINT.
    assert code in (0,-signal.SIGINT),code
    stderr=(target/'perf-record.stderr').read_text()
    assert 'Captured and wrote' in stderr,stderr
    save(target/'perf-stop.json',{'exit_code':code,'requested_signal':'SIGINT','clock':anchor(),'pid_stat':stat(pid),
                                 'tasks_after':sorted(int(p.name) for p in Path(f'/proc/{pid}/task').iterdir())})
    raw=target/'perf.data'
    save(target/'raw-identity.json',{'path':str(raw),'sha256':digest(raw),'bytes':raw.stat().st_size,
                                  'archive_scope':'RBM raw archive only; never Git/Windows delivery'})
def decode_perf(target,symroot):
    raw=target/'perf.data'
    # Static decode runs after the complete case; copied exact libraries retain symbol identity.
    commands={
      'script.txt':['perf','script','-i',str(raw),'--symfs',str(symroot),'--ns','-F','comm,pid,tid,cpu,time,event,ip,sym,dso,period'],
      'report.txt':['perf','report','-i',str(raw),'--symfs',str(symroot),'--stdio','--no-children','--percent-limit','0.1'],
      'header.txt':['perf','report','-i',str(raw),'--header-only','--stdio'],
      'event-list.txt':['perf','evlist','-i',str(raw),'-v']}
    statuses={}
    for name,cmd in commands.items():
        with (target/name).open('w') as out,(target/(name+'.stderr')).open('w') as err:
            statuses[name]={'command':cmd,'exit_code':subprocess.run(cmd,stdout=out,stderr=err).returncode}
    save(target/'decode-status.json',statuses)
    assert statuses['script.txt']['exit_code']==0
    script=(target/'script.txt').read_text()
    # Retain only record metadata, never dump DWARF stack memory into deliverables.
    counts={};lost=[]
    with (target/'raw-event-decode.stderr').open('w') as err:
        rawproc=subprocess.Popen(['perf','script','-i',str(raw),'-D'],stdout=subprocess.PIPE,stderr=err,text=True)
        for line in rawproc.stdout:
            types=re.findall(r'PERF_RECORD_[A-Z_]+',line)
            for name in types:counts[name]=counts.get(name,0)+1
            if 'PERF_RECORD_LOST' in line or 'PERF_RECORD_THROTTLE' in line:lost.append(line.rstrip())
        assert rawproc.wait()==0
    quality={'attribution_usable':False,'attribution_requires':'Independent phase/clock/sample coverage and meaningful-stack review; zero lost/throttled events alone is insufficient',
             'brewfs_symbol_present':'brewfs::' in script,'unknown_mentions':script.count('[unknown]'),
             'sample_header_lines':sum(bool(re.search(r'\s[0-9]+\.[0-9]+:',x)) for x in script.splitlines()),
             'record_type_counts':counts,'lost_event_lines':lost,
             'scope':'Stack truncation cannot be inferred solely from absent lost records; raw 8192-byte stacks retained for reanalysis.'}
    save(target/'quality.json',quality)
    assert quality['brewfs_symbol_present'],'No resolved BrewFS symbols; diagnostic attribution invalid'

try:
  with Path('/home/dev/.ax-rbm-heavy.lock').open('w') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX)
    assert subprocess.run(['pgrep','-ax','cargo|rustc|fio|smallfiles'],stdout=subprocess.PIPE).returncode==1
    frozen=json.loads((D/'manifest.json').read_text())
    for name,info in frozen.items():assert digest(D/name)==info['sha256'],name
    pins=json.loads((R/'binary-manifest.json').read_text())
    for arm in ('baseline','candidate'):
      project=f'ax447-corrected-{arm}-regression-profile-604'
      spec=json.loads((R/f'{arm}-build-spec.json').read_text());repo=Path(spec['worktree'])
      capacity=os.statvfs(R);free=capacity.f_bavail*capacity.f_frsize;total=capacity.f_blocks*capacity.f_frsize
      assert free-256*1024**3>=total//5 and capacity.f_favail-100000>=capacity.f_files//5
      before=set((repo/'docker/compose-xfstests/artifacts').glob('perf-run-*'))
      step={'arm':arm,'project':project,'capacity_preflight':{'free_bytes':free,'total_bytes':total,'reserve_bytes':256*1024**3},'started':anchor()}
      record['arms'].append(step);save(O/'receipt.json',record)
      env=dict(os.environ,AX447_INHERITED_HEAVY_LOCK_FD=str(lock.fileno()))
      perf=None;started=False;stopped=False;profile=None;pid=None;handles=[]
      with (O/(arm+'.log')).open('w') as log,(O/(arm+'-resources.jsonl')).open('w') as resources:
        case=subprocess.Popen([sys.executable,str(D/'run-profile-case.py'),arm,'regression-profile','604'],env=env,
                              pass_fds=(lock.fileno(),),stdout=log,stderr=subprocess.STDOUT)
        try:
          while case.poll() is None:
            now=anchor();space=os.statvfs(R)
            assert space.f_bavail*space.f_frsize>=space.f_blocks*space.f_frsize//5 and space.f_favail>=space.f_files//5
            new=set((repo/'docker/compose-xfstests/artifacts').glob('perf-run-*'))-before
            assert len(new)<=1
            artifact=next(iter(new)) if new else None
            if artifact:
              profile=artifact/'profile604';req=profile/'start-request.json'
              if req.exists() and not started:
                request=json.loads(req.read_text());pid,identity=map_pid(project,request,pins[arm]['sha256'])
                save(profile/'process-identity.json',identity)
                symroot=symbols(pid,profile,repo/'target/docker/brewfs')
                # A disabled recorder gives a positive control ACK before target starts.
                ctl=profile/'control.fifo';ack=profile/'control-ack.fifo';os.mkfifo(ctl);os.mkfifo(ack)
                cfd=os.open(ctl,os.O_RDWR|os.O_NONBLOCK);afd=os.open(ack,os.O_RDWR|os.O_NONBLOCK)
                handles.extend([cfd,afd])
                cmd=['perf','record','-e','cpu-clock','-F','49','--strict-freq','--call-graph','dwarf,8192',
                     '--clockid','mono','--timestamp','--sample-cpu','--namespaces','--no-buildid-cache',
                     '-D','-1','--control',f'fifo:{ctl},{ack}','-p',str(pid),'-o',str(profile/'perf.data')]
                stderr=(profile/'perf-record.stderr').open('w');handles.append(stderr)
                perf=subprocess.Popen(cmd,stdout=stderr,stderr=stderr)
                os.write(cfd,b'enable\n');deadline=time.monotonic()+20;answer=b''
                while b'ack\n' not in answer:
                  assert perf.poll() is None,'perf exited before enabling'
                  if time.monotonic()>deadline:raise RuntimeError('perf enable ACK timeout')
                  try:answer+=os.read(afd,4096)
                  except BlockingIOError:time.sleep(.05)
                save(profile/'perf-start.json',{'command':cmd,'clock':anchor(),'perf_pid':perf.pid,'control_ack':answer.decode(),
                                              'pid_stat':stat(pid),'all_threads':'perf -p expands existing thread group; inheritance enabled for new threads',
                                              'tasks':sorted(int(x.name) for x in Path(f'/proc/{pid}/task').iterdir())})
                save(profile/'start-ack.json',{'passed':True,'clock':anchor()});started=True
              if started and not stopped:
                assert perf.poll() is None,'perf exited during target'
                now['mount_pid']=pid;now['mount_stat']=stat(pid)
                now['pressure']={n:Path('/proc/pressure/'+n).read_text() for n in ('cpu','memory','io')}
                now['meminfo']=Path('/proc/meminfo').read_text()
                if (profile/'stop-request.json').exists():
                  finish_perf(perf,profile,pid,symroot);perf=None;stopped=True
                  save(profile/'stop-ack.json',{'passed':True,'clock':anchor()})
            now['capacity']={'free_bytes':space.f_bavail*space.f_frsize,'total_bytes':space.f_blocks*space.f_frsize,'free_inodes':space.f_favail,'total_inodes':space.f_files}
            resources.write(json.dumps(now)+'\n');resources.flush()
            time.sleep(.2 if started and not stopped else 1)
          assert case.returncode==0,case.returncode
          assert started and stopped
          decode_perf(profile,symroot)
          receipt=json.loads((R/'trials'/project/'receipt.json').read_text())
          assert receipt['qualified'] and receipt['status']==0
          rows=[json.loads(x) for x in (artifact/'capacity-scenes.jsonl').read_text().splitlines()]
          assert len(rows)==8 and all(x['passed'] for x in rows)
          assert {x['tool'] for x in rows}=={'fio-'+mode+'-direct'+str(d) for mode in ('seqwrite','randwrite') for d in (0,1)}
          step.update(passed=True,finished=anchor(),artifact=str(artifact),receipt=str(R/'trials'/project/'receipt.json'))
          save(O/'receipt.json',record)
        finally:
          if perf is not None and perf.poll() is None:
            perf.send_signal(signal.SIGINT);perf.wait(timeout=30)
          for h in handles:
            if isinstance(h,int):os.close(h)
            else:h.close()
          if case.poll() is None:
            # Stop only this diagnostic project's workload; let normal failure cleanup preserve it.
            ids=run(['docker','ps','-q','--filter','label=com.docker.compose.project='+project,'--filter','label=com.docker.compose.service=perf']).split()
            for cid in ids:subprocess.run(['docker','stop','--time','30',cid],check=True)
            case.wait(timeout=90)
    record['passed']=True
except Exception:
    record['error']=traceback.format_exc();raise
finally:
    record['finished']=anchor();save(O/'receipt.json',record)
