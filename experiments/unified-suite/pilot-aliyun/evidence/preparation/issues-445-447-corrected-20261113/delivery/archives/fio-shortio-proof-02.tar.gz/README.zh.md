# fio 3.39 同步请求写入 short_ios 的复现

未修改的上游 fio 3.39 已在本地复现：每次 4 KiB 写入都完整返回，打开每写一次的 `sync_file_range` 后，JSON 的 `write.short_ios` 仍增加到 4,095。关闭该选项时为零。两组均完整写入、读回并验证 16 MiB 的 `0x5a`。

| 检查 | 未开启 range sync | 每次写入后 range sync |
| --- | ---: | ---: |
| pwrite 系统调用 | 4,096 | 4,096 |
| 每次请求 / 实际返回字节 | 4,096 / 4,096 | 4,096 / 4,096 |
| 成功 sync_file_range | 0 | 4,095 |
| JSON write.short_ios | 0 | 4,095 |
| pread 全长读回 | 4,096 次 | 4,096 次 |

原因在完成计数。[ioengines.c](https://github.com/axboe/fio/blob/fio-3.39/ioengines.c) 对同步操作也按原始 direction 下标增加 `total_io_u`；[io_ddir.h](https://github.com/axboe/fio/blob/fio-3.39/io_ddir.h) 的 `DDIR_SYNC_FILE_RANGE` 是 5，而 [stat.h](https://github.com/axboe/fio/blob/fio-3.39/stat.h) 的 `total_io_u` 只有四个元素，后面紧接 `short_io_u`。该越界地址恰为 `short_io_u[DDIR_WRITE]`，并由 JSON 输出。

独立检查者使用真实 `fio.h` 和生成的配置头编译 ABI probe，六个静态断言通过：`total_io_u` 起始偏移 150,736、大小 32；`short_io_u` 起始偏移 150,768。`total_io_u[5]` 与 `short_io_u[1]` 的地址偏移均为 150,776。独立下载的七个源文件与官方 tag 逐字一致。早先考虑的同步返回值/resid 路径未被用作结论。

复现使用相同的 16 MiB、4 KiB、单线程 psync、pattern verification 和 `end_fsync=1` 参数，唯一对照变量为 `sync_file_range=wait_before,write,wait_after:1`。逐个核验 strace 中真实请求与返回值；两组文件摘要均为 `55c7e25571a69216de25162f191bb2847201a09ee7efe46b5bada034acc695d5`。这次诊断的耗时不作为性能证据。

正式缓存写入的八臂原始 `short_ios=4095` 全部保留，不归零、不改写。当前证据解释上游版本的统计问题；本地构建与云端 tools 镜像的可执行文件身份不同，云端同镜像普通文件诊断单独记录。BrewFS CPU 指标来自进程计数，涵盖写入、fio 内部 pattern 读回以及 strict drain；不能称为纯写系统调用 CPU。

第一次本地执行仅保留了控制台结果，后续调用无法访问 `/tmp` 中的原始文件，未据此验收；此次在持久共享目录重新执行并逐文件核验。原脚本与该失败归档尝试的回执一起保留。所附上游源码按其 COPYING 许可证保存。
