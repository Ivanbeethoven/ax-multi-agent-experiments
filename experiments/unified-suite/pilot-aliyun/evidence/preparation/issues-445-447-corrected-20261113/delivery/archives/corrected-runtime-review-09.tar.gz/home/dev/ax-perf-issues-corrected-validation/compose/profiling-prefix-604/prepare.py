import ast,difflib,hashlib,json
from pathlib import Path
P=Path(__file__).resolve().parent
S=P.parent/'corrected-preparation-01'
R='/home/dev/ax-perf-issues-corrected-validation/compose'
D=R+'/profiling-prefix-604'
LOG='warn,brewfs::chunk::compact::worker=debug,brewfs::cadapter::s3=debug'
def put(name,text):
    (P/name).write_text(text,encoding='utf-8',newline='\n')
def delta(name,old,new):
    put(name,''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='frozen',tofile='diagnostic604')))
old=(S/'run-compose-case-final-capacity.py').read_text()
assert hashlib.sha256(old.encode()).hexdigest()=='a6621e4987ca488487ea45e455d7fd473ba3620ea518475c898e227941584085'
new=old.replace("choices=['cached-smoke', 'cached', 'randwrite-gate', 'known-tail-oracle', 'regression']","choices=['regression-profile']")
new=new.replace("'GIT_OPTIONAL_LOCKS': '0', 'RUST_LOG': 'warn'",f"'GIT_OPTIONAL_LOCKS': '0', 'RUST_LOG': '{LOG}'")
new=new.replace("str(ROOT / 'compose.json')",f"'{D}/compose.json'")
new=new.replace("(ROOT / 'compose.json').read_bytes()",f"Path('{D}/compose.json').read_bytes()")
new=new.replace("(ROOT / 'run-measured-perf-in-container.sh').read_bytes()",f"Path('{D}/run-profile-container.sh').read_bytes()")
new=new.replace("(ROOT/'verify_remote_durability.py').read_bytes()",f"Path('{D}/verify_remote_durability.py').read_bytes()")
new=new.replace("else 'fio-seqwrite fio-randwrite fio-randrw'","else 'fio-seqwrite fio-randwrite'")
new=new.replace("else 6\n","else 4\n")
ast.parse(new);put('run-profile-case.py',new);delta('case.patch',old,new)
old=(S/'run-measured-perf-in-container.sh').read_text(encoding='utf-8')
assert hashlib.sha256(old.encode()).hexdigest()=='4d605c4848fa8a163d631d248a19e8019416b3b644501830749e746aa6799025'
new=old.replace('    local tool="$1" phase="$2" client_pid client_stat ticks\n','    local tool="$1" phase="$2" client_pid client_stat ticks\n    if [[ "$tool" == fio-randwrite-direct1 ]]; then\n        python3 /usr/local/bin/profile604_hook.py clock "$artifact_dir" "$tool" "$phase" || return 1\n    fi\n',1)
new=new.replace('    start="$(date +%s)"\n    record_client_cpu', '    if [[ "$tool" == fio-randwrite-direct1 ]]; then\n        python3 /usr/local/bin/profile604_hook.py start "$artifact_dir" "$tool" || return 1\n    fi\n    start="$(date +%s)"\n    record_client_cpu',1)
new=new.replace('    wait_for_fio_post_write_drain "$tool" || fio_status=1\n','    wait_for_fio_post_write_drain "$tool" || fio_status=1\n    if [[ "$tool" == fio-randwrite-direct1 ]]; then\n        python3 /usr/local/bin/profile604_hook.py stop "$artifact_dir" "$tool" || fio_status=1\n    fi\n',1)
put('run-profile-container.sh',new);delta('container.patch',old,new)
old=(P/'durability-original.py').read_text()
new=old.replace("frozenset(('warn',",f"frozenset(('{LOG}', 'warn',",1)
ast.parse(new);put('verify_remote_durability.py',new);delta('durability-log-filter.patch',old,new)
c=json.loads((P/'compose-original.json').read_text())
v=c['services']['perf']['volumes']
v[v.index(R+'/run-measured-perf-in-container.sh:/usr/local/bin/run_perf_in_container.sh:ro')]=D+'/run-profile-container.sh:/usr/local/bin/run_perf_in_container.sh:ro'
v[v.index(R+'/verify_remote_durability.py:/usr/local/bin/verify_remote_durability.py:ro')]=D+'/verify_remote_durability.py:/usr/local/bin/verify_remote_durability.py:ro'
v.append(D+'/profile_hook.py:/usr/local/bin/profile604_hook.py:ro')
put('compose.json',json.dumps(c,indent=2)+'\n')
plan={'diagnostic_only':True,'performance_accepted':False,'trial':604,'order':['baseline','candidate'],
      'scenes':['fio-seqwrite-direct0','fio-seqwrite-direct1','fio-randwrite-direct0','fio-randwrite-direct1'],
      'profile_target':'fio-randwrite-direct1','event':'cpu-clock','frequency':49,'call_graph':'dwarf,8192','clock':'mono',
      'scope':'All threads of actual mount PID; includes active and strict drain, excludes cold-remount verification. Preserve existing FIO argv, default compaction, budgets, 512GiB hardware and error/capacity/durability gates.',
      'logging':LOG,'durability_change':'Only exact additional WARN-visible diagnostic filter; all byte/PID/cache/error assertions unchanged',
      'extra_pre_target_work':'Read prior regular workload file inode/path/size for chunk-id attribution; native before metrics remain original',
      'raw_perf_data':'Preserve on RBM with SHA/size, exclude Git/Windows delivery; human-readable derived stacks and quality remain deliverable',
      'uncertainty':'Sampling/logging changes timing; no profile result substitutes for performance acceptance. Unknown/truncated/lost stacks retained.'}
put('plan.json',json.dumps(plan,indent=2)+'\n')
print(json.dumps({'prepared':str(P)}))
