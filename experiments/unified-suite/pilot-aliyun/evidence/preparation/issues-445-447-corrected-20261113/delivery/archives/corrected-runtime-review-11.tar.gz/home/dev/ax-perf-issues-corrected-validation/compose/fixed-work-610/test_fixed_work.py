#!/usr/bin/env python3
"""No filesystem workload: stub the frozen shell lifecycle and test strict parsing."""
import copy
import importlib.util
import json
import os
import subprocess
import tempfile
import unittest
from pathlib import Path

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('assessor', HERE / 'assess_fixed_work.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)


class FixedWork(unittest.TestCase):
    def argv(self, script, runtime, extra):
        text = Path(script).read_text()
        start = text.index('run_fio_profile() {')
        end = text.index('\nrun_object_put_bench()', start)
        function = text[start:end]
        with tempfile.TemporaryDirectory(prefix='argv-', dir=HERE) as directory:
            directory = Path(directory)
            capture = directory / 'argv.bin'
            stub = '''
set -euo pipefail
env_or_default() { local first="$1" second="$2" fallback="$3"; printf '%s' "${!first:-${!second:-$fallback}}"; }
record_scene_capacity() { :; }
rm() { :; }
mkdir() { :; }
append_fio_observation_args() { :; }
append_fio_log_summary() { :; }
wait_for_fio_post_write_drain() { :; }
verify_fio_remote_durability() { :; }
run_logged_tool() { printf '%s\\0' "$@" > "$CAPTURE"; }
err() { echo "$*" >&2; return 1; }
'''
            env = {k: v for k, v in os.environ.items() if not k.startswith(('PERF_', 'BREWFS_'))}
            env.update(mount_dir=str(directory / 'mount'), artifact_dir=str(directory / 'artifact'),
                       CAPTURE=str(capture), PERF_FIO_RANDWRITE_RUNTIME=str(runtime),
                       PERF_FIO_RANDWRITE_ARGS=extra, PERF_FIO_RANDWRITE_DIRECT='1',
                       PERF_FIO_RANDWRITE_SIZE='512m', PERF_FIO_DIRECT_MATRIX='')
            run = subprocess.run(['bash'], input=stub + '\n' + function + '\nrun_fio_profile fio-randwrite randwrite\n',
                                 env=env, text=True, capture_output=True)
            self.assertEqual(run.returncode, 0, run.stdout + run.stderr)
            return capture.read_bytes().decode().split('\0')[:-1]

    def test_fixed_runtime_zero_has_no_time_based_or_runtime(self):
        args = self.argv(HERE / 'run-fixed-container.sh', 0, '--io_size=1g')
        self.assertNotIn('--time_based', args)
        self.assertFalse(any(x.startswith('--runtime') for x in args))
        for x in ['--io_size=1g', '--direct=1', '--bs=4m', '--size=512m', '--numjobs=4', '--iodepth=1']:
            self.assertIn(x, args)

    def test_default_positive_runtime_retains_existing_time_based(self):
        args = self.argv(HERE / 'run-fixed-container.sh', 20, '')
        self.assertIn('--runtime=20', args)
        self.assertIn('--time_based', args)

    def test_host_forwards_all_fixed_work_parameters(self):
        host = (HERE / 'run-fixed-host.sh').read_text()
        for field in ['ARGS', 'DIRECT', 'RUNTIME', 'SIZE', 'NUMJOBS', 'BS', 'IOENGINE', 'IODEPTH']:
            self.assertIn('-e PERF_FIO_RANDWRITE_' + field, host)

    def fixture(self, root):
        tool = 'fio-randwrite'
        def put(name, value):
            path = root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(value) if not isinstance(value, str) else value)
        argv = 'run_observed_fio fio-randwrite --rw=randwrite --bs=4m --size=512m --numjobs=4 --ioengine=io_uring --iodepth=1 --direct=1 --io_size=1g --randseed=20261031 --randrepeat=1'
        put(f'tools/{tool}.argv', argv)
        zero = {'io_bytes': 0, 'total_ios': 0, 'short_ios': 0, 'drop_ios': 0}
        write = dict(zero, io_bytes=4 << 30, total_ios=1024, lat_ns={'percentile': {'99.000000': 123}})
        put(f'results/{tool}.json', {'jobs': [{'error': 0, 'read': zero, 'write': write}]})
        put(f'remote-durability/{tool}/receipt.json', {'passed': True, 'phase': 'complete', 'file_count': 4,
            'logical_bytes': 2 << 30, 'new_cache_was_empty': True, 'old_cache_preserved': True,
            'unmount': {'old_process_terminated': True, 'forced': False},
            'old_mount': {'executable_sha256': 'abc'}, 'new_mount': {'executable_sha256': 'abc'}})
        put('client-cpu-summary.json', {'tools': [{'tool': tool, 'pid': 123, 'starttime_ticks': 22,
            'observations': [{'pid': 123, 'starttime_ticks': 22, 'observed_ns': n} for n in [1, 20, 40]],
            'tool_and_drain_cpu': {'total_s': 12}}]})
        put('precise-phase-summary.json', {'tools': [{'tool': tool, 'tool_start_ns': 2, 'tool_return_ns': 19,
            'strict_drain_start_ns': 21, 'strict_drained_ns': 39,
            'precise_tool_to_strict_drained_ns': 37, 'precise_tool_wall_ns': 17}]})
        put('capacity-scenes.jsonl', '\n'.join(json.dumps({'tool': tool, 'phase': phase, 'passed': True}) for phase in ['before_scene', 'after_scene']))
        return put

    def assess_with(self, change=None):
        with tempfile.TemporaryDirectory(prefix='assess-', dir=HERE) as directory:
            root = Path(directory)
            self.fixture(root)
            if change:
                change(root)
            return mod.assess(root)

    def test_accepts_exact_complete_fixed_work(self):
        self.assertTrue(self.assess_with()['correctness_passed'])

    def test_rejects_time_based(self):
        with self.assertRaises(AssertionError):
            self.assess_with(lambda p: (p / 'tools/fio-randwrite.argv').write_text((p / 'tools/fio-randwrite.argv').read_text() + ' --time_based'))

    def test_rejects_partial_bytes(self):
        def change(p):
            f = p / 'results/fio-randwrite.json'; d = json.loads(f.read_text());d['jobs'][0]['write']['io_bytes'] -= 4 << 20;f.write_text(json.dumps(d))
        with self.assertRaises(AssertionError):self.assess_with(change)

    def test_rejects_failed_durability(self):
        def change(p):
            f=p/'remote-durability/fio-randwrite/receipt.json';d=json.loads(f.read_text());d['passed']=False;f.write_text(json.dumps(d))
        with self.assertRaises(AssertionError):self.assess_with(change)

    def test_rejects_changed_pid(self):
        def change(p):
            f=p/'client-cpu-summary.json';d=json.loads(f.read_text());d['tools'][0]['observations'][2]['pid']=456;f.write_text(json.dumps(d))
        with self.assertRaises(AssertionError):self.assess_with(change)

    def test_rejects_missing_short_io_metric(self):
        def change(p):
            f=p/'results/fio-randwrite.json';d=json.loads(f.read_text());del d['jobs'][0]['write']['short_ios'];f.write_text(json.dumps(d))
        with self.assertRaises(KeyError):self.assess_with(change)

    def test_rejects_duplicate_capacity_phase(self):
        def change(p):
            f=p/'capacity-scenes.jsonl';f.write_text(f.read_text().replace('after_scene','before_scene'))
        with self.assertRaises(AssertionError):self.assess_with(change)

    def test_rejects_old_full_matrix(self):
        old=Path('/home/dev/ax-perf-issues-validation/corrected-runtime-review-06/artifacts/baseline/perf-run-1794524573-25351')
        with self.assertRaises(AssertionError):mod.assess(old)


if __name__ == '__main__':
    unittest.main(verbosity=2)
