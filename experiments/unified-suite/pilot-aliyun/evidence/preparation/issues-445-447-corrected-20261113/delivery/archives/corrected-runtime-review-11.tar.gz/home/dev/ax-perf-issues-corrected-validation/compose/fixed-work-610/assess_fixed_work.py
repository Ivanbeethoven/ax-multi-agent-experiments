#!/usr/bin/env python3
"""Strict artifact facts for one fixed-work arm; never accept a different scene."""
import hashlib
import json
import shlex
from pathlib import Path

TOOL = 'fio-randwrite'
EXPECTED_BYTES = 4 << 30


def assess(artifact):
    artifact = Path(artifact)
    inputs = {}

    def read(rel):
        p = artifact / rel
        b = p.read_bytes()
        inputs[rel] = hashlib.sha256(b).hexdigest()
        return b.decode()

    for p in artifact.rglob('*.invalid'):
        raise ValueError('Invalid artifact marker: ' + str(p))
    fio_files = sorted((artifact / 'results').glob('fio*.json'))
    assert [p.name for p in fio_files] == [TOOL + '.json'], [p.name for p in fio_files]
    argv = shlex.split(read('tools/' + TOOL + '.argv'))
    options = {}
    for arg in argv:
        if arg.startswith('--'):
            key, _, value = arg[2:].partition('=')
            options[key] = value
    expected = {'rw': 'randwrite', 'bs': '4m', 'size': '512m', 'numjobs': '4',
                'ioengine': 'io_uring', 'iodepth': '1', 'direct': '1', 'io_size': '1g',
                'randseed': '20261031', 'randrepeat': '1'}
    for key, value in expected.items():
        assert options.get(key) == value, (key, options.get(key), value)
    assert 'runtime' not in options and 'time_based' not in options
    fio = json.loads(read('results/' + TOOL + '.json'))
    assert fio['jobs'] and all(job.get('error') == 0 for job in fio['jobs'])
    for job in fio['jobs']:
        for operation in ['read', 'write']:
            assert job[operation]['short_ios'] == 0
            assert job[operation]['drop_ios'] == 0
    write_bytes = sum(job['write']['io_bytes'] for job in fio['jobs'])
    write_ios = sum(job['write']['total_ios'] for job in fio['jobs'])
    assert write_bytes == EXPECTED_BYTES and write_ios == 1024, (write_bytes, write_ios)
    assert sum(job['read']['io_bytes'] for job in fio['jobs']) == 0
    receipts = list((artifact / 'remote-durability').glob('*/receipt.json'))
    assert len(receipts) == 1 and receipts[0].parent.name == TOOL
    durability = json.loads(read('remote-durability/' + TOOL + '/receipt.json'))
    assert durability['passed'] and durability['phase'] == 'complete'
    assert durability['file_count'] == 4 and durability['logical_bytes'] == 2 << 30
    assert durability['new_cache_was_empty'] and durability['old_cache_preserved']
    assert durability['unmount']['old_process_terminated'] and not durability['unmount']['forced']
    assert durability['old_mount']['executable_sha256'] == durability['new_mount']['executable_sha256']
    cpu = json.loads(read('client-cpu-summary.json'))['tools']
    phase = json.loads(read('precise-phase-summary.json'))['tools']
    assert len(cpu) == len(phase) == 1 and cpu[0]['tool'] == phase[0]['tool'] == TOOL
    cpu, phase = cpu[0], phase[0]
    assert len(cpu['observations']) == 3
    assert all(x['pid'] == cpu['pid'] and x['starttime_ticks'] == cpu['starttime_ticks'] for x in cpu['observations'])
    stamps = [x['observed_ns'] for x in cpu['observations']]
    assert stamps == sorted(stamps) and len(set(stamps)) == 3
    assert phase['tool_start_ns'] < phase['tool_return_ns'] <= phase['strict_drain_start_ns'] < phase['strict_drained_ns']
    full_s = phase['precise_tool_to_strict_drained_ns'] / 1e9
    active_s = phase['precise_tool_wall_ns'] / 1e9
    cpu_s = cpu['tool_and_drain_cpu']['total_s']
    assert full_s > 0 and active_s > 0 and cpu_s > 0
    capacity = [json.loads(line) for line in read('capacity-scenes.jsonl').splitlines()]
    assert len(capacity) == 2 and all(x['tool'] == TOOL and x['passed'] for x in capacity)
    assert {x['phase'] for x in capacity} == {'before_scene', 'after_scene'}
    return {'artifact': str(artifact), 'correctness_passed': True, 'performance_accepted': False,
            'write_bytes': write_bytes, 'write_ios': write_ios,
            'active_s': active_s, 'active_plus_strict_drain_s': full_s,
            'cpu': cpu, 'cpu_per_gib_s': cpu_s / 4,
            'active_mib_s': 4096 / active_s, 'active_plus_drain_mib_s': 4096 / full_s,
            'fio_write_latency': [job['write']['lat_ns'] for job in fio['jobs']],
            'durability': durability, 'inputs_sha256': inputs}
