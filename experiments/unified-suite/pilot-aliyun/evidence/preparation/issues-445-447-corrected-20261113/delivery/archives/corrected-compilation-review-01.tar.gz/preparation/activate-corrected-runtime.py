#!/usr/bin/env python3
"""Bind corrected runtime artifacts only after every compilation gate passed."""
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

ROOT = Path('/srv/perf-issues-corrected-20261112')
RUN = Path('/home/dev/ax-perf-issues-corrected-validation/compose')
GATES = ROOT/'qualification'
HEADS = {'baseline': '4f982f45c153a0c31e3e9cd8ff642ec7659c98fd',
         'candidate': 'c8f5f16aefe811540782b952481982179a1bfd6f'}
PUBLICATION = 'e2c964c55fafdcced34af58e840ebddda1cf9ea4'
TREES = {'baseline': '26e00a546990b3852b6d4ef1b12471e0f4a0a4e5',
         'candidate': '142c8d384fbb2939f2cde4e3e7497b122b2c0f53'}
FEATURES = 'fuse-io-uring-runtime,workspace-overlay,observability,rustfs-ec-block-size-hint'
TEST_COMMAND = ['cargo', 'test', '--locked', '--workspace', '--lib', '--bins',
                '--no-default-features', '--features', FEATURES]
PRODUCER = Path('/srv/perf-issues-445-447/artifacts/baseline/packed_v3_snapshot_fixture')
PRODUCER_SHA = '8c4d65dbe8daaeaffb7f6084474a9a839df418c66d2aced6226842a5b8997d72'


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def read(path):
    return json.loads(path.read_text())


def write(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


env = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
assert not (RUN/'activation-receipt.json').exists()
for name in ('baseline-build-spec.json', 'candidate-build-spec.json', 'binary-manifest.json'):
    assert not (RUN/name).exists(), 'Never overwrite a bound runtime campaign'

with Path('/home/dev/.ax-rbm-heavy.lock').open('w') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX)
    assert subprocess.run(['pgrep', '-ax', 'cargo|rustc|fio|smallfiles|brewfs'],
                          capture_output=True).returncode == 1
    assert not subprocess.check_output(['docker', 'ps', '-q'], text=True).strip()
    required_units = ['ax447-corrected-release-pair-01',
                      'ax447-corrected-baseline-release-01',
                      'ax447-corrected-candidate-release-01',
                      'ax447-corrected-baseline-exact-01']
    units = {}
    for unit in required_units:
        output = subprocess.check_output(['systemctl', 'show', unit, '-p', 'ActiveState',
                                          '-p', 'ExecMainStatus'], text=True)
        props = dict(line.split('=', 1) for line in output.splitlines())
        assert props == {'ExecMainStatus': '0', 'ActiveState': 'inactive'}, (unit, props)
        units[unit] = props
    assert read(ROOT/'evidence/release-controller-01/receipt.json')['passed'] is True
    ci_path = GATES/'cleanup-ci/ci-final.json'
    ci = read(ci_path)
    assert ci['local_ci_gate_passed'] is True
    assert ci['publication_source_commit'] == PUBLICATION
    assert ci['runtime_candidate_commit'] == HEADS['candidate']
    assert ci['strict_default_command'] == 'cargo clippy --locked --workspace --all-targets -- -D warnings'
    assert any(x['name'] == 'strict-default-clippy' and x['exit'] == 0 for x in ci['gates'])
    for gate in ci['gates']:
        assert gate['exit'] == 0
        log = Path(gate['log'])
        assert not log.is_absolute() and '..' not in log.parts
        assert digest(ci_path.parent/log) == gate['log_sha256']
    projection_path = GATES/'publication-proof/receipt.json'
    projection = read(projection_path)
    # The imported proof has its own full tracked-entry and exact-line checks.
    assert projection['passed'] is True
    assert projection['runtime_head'] == HEADS['candidate']
    assert projection['runtime_tree'] == TREES['candidate']
    assert projection['publication_head'] == PUBLICATION
    assert projection['publication_tree'] == '0a8f932b621235e967ddba0ac4b8c7ff89eb03e2'
    assert projection['allowed_path'] == 'src/vfs/io/writer/cached_write_watermarks_bench.rs'
    for check in ('only_one_exact_iterator_replacement', 'excluded_by_release_cfg',
                  'all_other_tracked_entries_identical'):
        assert projection[check] is True
    tests = {}
    for arm, path in [('baseline', ROOT/'evidence/baseline-exact-features-01/receipt.json'),
                      ('candidate', GATES/'candidate-exact/receipt.json')]:
        receipt = read(path)
        assert receipt['passed'] is True and receipt['default_features'] is False
        assert receipt['features'] == FEATURES and receipt['requested_arms'] == [arm]
        assert receipt['rustc'].startswith('rustc 1.99.1 ')
        assert len(receipt['arms']) == 1
        item = receipt['arms'][0]
        assert item['arm'] == arm
        assert item['commit'] == (PUBLICATION if arm == 'candidate' else HEADS[arm])
        assert item['tree'] == ('0a8f932b621235e967ddba0ac4b8c7ff89eb03e2'
                                if arm == 'candidate' else TREES[arm])
        assert item['command'] == TEST_COMMAND and item['exit_code'] == 0
        assert item['source_still_clean'] is True and item['tested_executables']
        assert digest(path.parent/(arm+'.log')) == item['log_sha256']
        log_text = (path.parent/(arm+'.log')).read_text(errors='replace')
        executed_paths = set(re.findall(r'^\s+Running unittests .* \(([^)]+)\)$', log_text, re.M))
        assert executed_paths == {entry['path'] for entry in item['tested_executables']}
        assert len(item['tested_executables']) == len(executed_paths)
        for entry in item['tested_executables']:
            assert re.fullmatch(r'[0-9a-f]{64}', entry['sha256'])
            assert isinstance(entry['bytes'], int) and entry['bytes'] > 0
            assert Path(entry['path']).is_absolute()
        assert item['environment']['CARGO_BUILD_JOBS'] == '3'
        assert item['environment']['RUST_TEST_THREADS'] == '3'
        assert item['environment']['CARGO_PROFILE_DEV_DEBUG'] == '0'
        assert receipt['actual_unit']['CPUQuotaPerSecUSec'] == '3s'
        assert int(receipt['actual_unit']['MemoryMax']) == 38*1024**3
        tests[arm] = {'receipt': str(path), 'sha256': digest(path),
                      'test_host': receipt['test_host'], 'commit': item['commit']}
    rbm_unit = read(GATES/'candidate-exact/unit-final.json')
    assert rbm_unit['ActiveState'] == 'inactive' and rbm_unit['ExecMainStatus'] == '0'
    assert digest(RUN/'review-manifest-04.json') == '0234e3402c344a1457a8ee929836ba9296a1564d4153398909dce227680c1c98'
    frozen = read(RUN/'review-manifest-04.json')
    assert len(frozen['files']) == 43
    for relative, expected in frozen['files'].items():
        assert digest(RUN/relative) == expected, relative
    assert digest(PRODUCER) == PRODUCER_SHA
    images = read(RUN/'image-manifest.json')
    for item in images.values():
        actual = subprocess.check_output(['docker', 'image', 'inspect', item['reference'],
                                          '--format', '{{.Id}}'], text=True).strip()
        assert actual == item['id']
    pins, specs = {}, {}
    for arm in ('baseline', 'candidate'):
        identity_path = ROOT/'evidence'/(arm+'-release-01')/'artifact-identity.json'
        identity = read(identity_path)
        assert identity['passed'] is True and identity['exit_code'] == 0
        assert identity['source'] == {'commit': HEADS[arm], 'tree': TREES[arm], 'dirty': False}
        assert identity['source_after'] == identity['source']
        assert identity['command'] == ['cargo', 'build', '--release', '--locked',
            '--no-default-features', '--features', FEATURES, '--bin', 'brewfs', '-vv']
        source = Path('/home/dev/ax-issue447-corrected-'+arm)
        assert subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'],
                                       env=env, text=True).strip() == HEADS[arm]
        assert not subprocess.check_output(['git', '-C', str(source), 'status', '--porcelain'],
                                           env=env, text=True).strip()
        artifact = ROOT/'artifacts'/arm/'brewfs'
        assert digest(artifact) == identity['binary']['sha256']
        text = subprocess.check_output([str(artifact), '--version'], text=True, stderr=subprocess.STDOUT)
        plain = re.sub(r'\x1b\[[0-9;]*m', '', text)
        assert re.search(r'^commit: '+HEADS[arm]+r'$', plain, re.M)
        assert re.search(r'^dirty: false$', plain, re.M)
        destination = source/'target/docker'
        destination.mkdir(parents=True, exist_ok=True)
        assert not (destination/'brewfs').exists()
        shutil.copy2(artifact, destination/'brewfs')
        assert digest(destination/'brewfs') == identity['binary']['sha256']
        specs[arm] = {'arm': arm, 'worktree': str(source), 'commit': HEADS[arm],
                      'tree': TREES[arm], 'dirty': False,
                      'output_directory': str(identity_path.parent),
                      'release_identity_sha256': digest(identity_path),
                      'publication_source': PUBLICATION if arm == 'candidate' else HEADS[arm],
                      'runtime_identity_scope': 'Measured runtime commit remains explicit; publication differs only by independently proven test-only code'}
        pins[arm] = {'commit': HEADS[arm], 'sha256': identity['binary']['sha256']}
    producer_copy = Path(specs['baseline']['worktree'])/'target/docker/packed_v3_snapshot_fixture'
    assert not producer_copy.exists()
    shutil.copy2(PRODUCER, producer_copy)
    assert digest(producer_copy) == PRODUCER_SHA
    pins['producer'] = {'commit': 'ca07159f3da4b670e4aeb878faef928e69bc1634', 'sha256': PRODUCER_SHA}
    for arm, spec in specs.items():
        write(RUN/(arm+'-build-spec.json'), spec)
    write(RUN/'binary-manifest.json', pins)
    write(RUN/'activation-receipt.json', {
        'passed': True, 'runtime_qualified': False,
        'at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'scope': 'All source, compilation, identity, and harness prerequisites passed; no runtime results yet',
        'script_sha256': digest(Path(__file__)), 'units': units, 'runtime_sources': HEADS,
        'publication_source': PUBLICATION, 'binary': pins, 'exact_tests': tests,
        'ci_sha256': digest(ci_path), 'projection_sha256': digest(projection_path),
        'frozen_harness_manifest_sha256': digest(RUN/'review-manifest-04.json'),
        'same_host_runtime': os.uname().nodename,
        'test_host_difference': 'Exact-feature tests run baseline on the cloud and candidate on RBM; all FUSE performance runs use this one cloud host.'})
print(json.dumps({'activation_passed': True, 'runtime_qualified': False, 'pins': pins}), flush=True)
