#!/usr/bin/env python3
"""Diagnostic-only handshake; original FIO and drain remain unchanged."""
import argparse, json, os, subprocess, time
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument('action',choices=['start','stop','clock'])
p.add_argument('artifact'); p.add_argument('tool'); p.add_argument('phase',nargs='?',default='')
a=p.parse_args()
if a.tool != 'fio-randwrite-direct1':
    raise SystemExit(0)
d=Path(a.artifact)/'profile605'; d.mkdir(exist_ok=True)
pid=int(Path('/run/brewfs/perf-mount.pid').read_text())
stat=Path(f'/proc/{pid}/stat').read_text()
row={'action':a.action,'phase':a.phase,'tool':a.tool,'pid':pid,'proc_stat':stat,
     'realtime_before_ns':time.time_ns(),'monotonic_ns':time.monotonic_ns()}
row['realtime_after_ns']=time.time_ns()
if a.action == 'clock':
    with (d/'clock-markers.jsonl').open('a') as f:f.write(json.dumps(row)+'\n')
else:
    if a.action=='start':
        # Record only already existing regular workload files, before target I/O.
        manifest=[]
        for expected in sorted((Path(a.artifact)/'remote-durability').glob('*/expected.json')):
            manifest.append({'expected_path':str(expected),'expected':json.loads(expected.read_text())})
        row['predecessor_expected_manifests']=manifest
        # The generated mount path is the last argument of the pinned mount.
        argv=Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0')
        mount=Path([x.decode() for x in argv if x][-1])
        files=[]
        for path in sorted(path for directory in mount.glob('.perf-fio-*') if directory.is_dir() for path in directory.iterdir()):
            if path.is_file():
                s=path.stat()
                files.append({'path':str(path),'relative_path':str(path.relative_to(mount)),
                              'ino':s.st_ino,'size':s.st_size,'mtime_ns':s.st_mtime_ns})
        assert len(files)<=32
        row['existing_scene_files']=files
    request=d/(a.action+'-request.json')
    assert not request.exists()
    tmp=request.with_suffix('.tmp');tmp.write_text(json.dumps(row,indent=2)+'\n');tmp.rename(request)
    deadline=time.monotonic()+60
    ack=d/(a.action+'-ack.json')
    while not ack.exists():
        if time.monotonic()>deadline:raise RuntimeError('profile handshake timed out: '+a.action)
        time.sleep(.05)
    answer=json.loads(ack.read_text())
    assert answer['passed'] is True,answer
    if a.action=='start':
        before={'realtime_ns':time.time_ns(),'monotonic_ns':time.monotonic_ns()}
        raw=subprocess.check_output(['timeout','--foreground','5s','cat',str(mount/'.stats')])
        (d/'stats-after-enable-before-tool.txt').write_bytes(raw.replace(b'\0',b''))
        after={'realtime_ns':time.time_ns(),'monotonic_ns':time.monotonic_ns()}
        (d/'stats-after-enable-clock.json').write_text(json.dumps({'before':before,'after':after},indent=2)+'\n')
