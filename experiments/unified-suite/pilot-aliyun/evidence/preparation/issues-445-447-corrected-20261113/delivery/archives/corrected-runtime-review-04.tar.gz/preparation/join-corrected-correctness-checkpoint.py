#!/usr/bin/env python3
"""Join exact failure-shape regressions with independent known bytes and FUSE trace."""
import datetime
import hashlib
import json
from pathlib import Path

ROOT = Path('/home/dev/ax-perf-issues-corrected-validation/compose')
TRACE_SHA = 'a2b7ca1acded0094d3d28327d021f325d4ed2ba5614865b144590462df5e1a78'
HELPER_SHA = 'f916abb1e9560b8dc1341bb17b02093b171155d6dfa2feee276a87ffaeea1384'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read(path):
    return json.loads(path.read_text())


pins = read(ROOT/'binary-manifest.json')
images = read(ROOT/'image-manifest.json')
record = {'passed':False,'stage':'corrected-readwrite-correctness','accepted_cases':[],
          'trace_proofs':{},'source':{},'binary':pins,
          'scope':'Correctness prerequisites only; the full standard and target performance gates remain pending',
          'script_sha256':sha(Path(__file__)),'performance_acceptance':False,
          'prior_failed_stages_preserved':['correctness-prerequisites-01','known-tail-diagnostic-v3-01']}
assert read(ROOT/'activation-receipt.json')['passed'] is True
assert sha(ROOT/'known_tail_oracle.py') == HELPER_SHA
for arm in ('baseline','candidate'):
    spec = read(ROOT/(arm+'-build-spec.json'))
    record['source'][arm] = spec
    for case,trial in [('randwrite-gate',500),('known-tail-oracle',502)]:
        path = ROOT/'trials'/f'ax447-corrected-{arm}-{case}-{trial}'/'receipt.json'
        item = read(path)
        assert item['qualified'] is True and item['status'] == 0
        assert item['binary'] == pins[arm] and item['source'] == spec and item['images'] == images
        for field,name in [('case_harness_sha256','run-compose-case.py'),
                           ('container_harness_sha256','run-measured-perf-in-container.sh'),
                           ('durability_helper_sha256','verify_remote_durability.py')]:
            assert item[field] == sha(ROOT/name)
        assert len(item['artifact_directories']) == 1
        artifact = Path(item['artifact_directories'][0])
        assert read(path.parent/'services/error-gate.json')['passed'] is True
        assert not (path.parent/'remaining-owned-containers.json').read_text().strip()
        if case == 'randwrite-gate':
            assert read(artifact/'remote-durability/fio-randwrite-direct0/receipt.json')['passed'] is True
        else:
            assert item['known_tail_helper_sha256'] == HELPER_SHA
            for phase in ('write-a','check-a','write-b','verify-b'):
                details = read(artifact/'known-tail-oracle'/(phase+'.json'))
                assert details['passed'] is True and details['reasons'] == []
            before = read(artifact/'known-tail-oracle/check-a.json')
            after = read(artifact/'known-tail-oracle/verify-b.json')
            for phase in (before,after):
                assert phase['fuse_write_proof']['passed'] is True
                assert phase['fuse_write_proof']['all_write_flags_zero'] is True
                assert phase['fuse_write_proof']['request_bytes'] == 4<<20
            assert after['fresh_cache_validation']['passed'] is True and after['old_cache_preserved'] is True
            proof_path = ROOT/'known-tail-trace-proofs'/(arm+'-502.json')
            proof = read(proof_path)
            assert proof['passed'] is True and proof['reasons'] == [] and len(proof['checks']) == 4
            assert proof['artifact_dir'] == str(artifact) and proof['verifier_sha256'] == TRACE_SHA
            assert proof['op_log_sha256'] == sha(artifact/'brewfs_fuse_ops.log')
            for name,digest in proof['phase_json_sha256'].items():
                relative = Path(name)
                assert not relative.is_absolute() and '..' not in relative.parts
                assert sha(artifact/relative) == digest
            for raw,expected in proof['inputs'].items():
                source = Path(raw)
                assert source.is_relative_to(artifact)
                assert source.stat().st_size == expected['bytes'] and sha(source) == expected['sha256']
            record['trace_proofs'][arm] = {'path':str(proof_path),'sha256':sha(proof_path),
                                         'op_log_sha256':proof['op_log_sha256'],'verifier_sha256':TRACE_SHA}
        record['accepted_cases'].append({'arm':arm,'case':case,'trial':trial,
                                         'receipt':str(path),'receipt_sha256':sha(path)})
record.update(passed=True,at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              helper_sha256=HELPER_SHA,trace_verifier_sha256=TRACE_SHA)
with (ROOT/'correctness-checkpoint-02.json').open('x') as stream:
    json.dump(record,stream,indent=2)
    stream.write('\n')
print(json.dumps({'passed':True,'stage':record['stage'],'accepted_cases':4,'trace_proofs':2}),flush=True)
