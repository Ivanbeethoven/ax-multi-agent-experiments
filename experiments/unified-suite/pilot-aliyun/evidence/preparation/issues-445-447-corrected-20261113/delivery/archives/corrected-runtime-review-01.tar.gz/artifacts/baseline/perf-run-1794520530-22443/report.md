# BrewFS Perf Report

Meta backend: redis

## Summary

| Tool | Status | Seconds | Log |
| --- | --- | ---: | --- |
| fio-randwrite-direct0 | pass | 22 | tools/fio-randwrite-direct0.log |

## Post-Write Drain

| Tool | Drain seconds | Pending bytes | Dirty bytes | Buffer dirty bytes |
| --- | ---: | ---: | ---: | ---: |
| fio-randwrite-direct0 | 44 | 0 | 0 | 0 |

## Fio

| Tool | Workload | Direct | BS | Jobs | Read BW | Read IOPS | Write BW | Write IOPS | Read P99 | Write P99 | Raw |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |---: | ---: | ---: |
| fio-randwrite-direct0 | randwrite | 0 | 4m | 4 | 0.00 B/s | 0.00 | 175.02 MiB/s | 43.76 | 0.000 ms | 61.080 ms | results/fio-randwrite-direct0.json |

## Fio Runtime Accounting

Use `active_io_runtime` for close/flush tail detection; fio `job_runtime_ms` can aggregate multiple jobs under group reporting.

| Tool | Direct | Script wall | fio job_runtime | wall-job_runtime | wall/job_runtime | active_io_runtime | wall-active_io | wall/active_io | Tail marker |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| fio-randwrite-direct0 | 0 | 22 s | 89.578 s | -67.578 s | 0.25x | 22.397 s | -0.397 s | 0.98x | fio job_runtime aggregates jobs |

## Fully Drained Write Throughput

Actual fio bytes divided by `active_io_runtime + post_write_drain`; unlike foreground bandwidth, this includes the time required to empty the filesystem writeback queue.

| Tool | Active I/O | Drain | Complete | Read | Write | Total | Raw |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| fio-randwrite-direct0 | 22.397 s | 44.000 s | 66.397 s | 0.00 MiB/s | 59.04 MiB/s | 59.04 MiB/s | fully-drained-throughput.tsv |

## Latency Percentiles

### Read

| Workload | p1 | p5 | p25 | p50 | p75 | p90 | p95 | p99 | p99.9 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |

### Write

| Workload | p1 | p5 | p25 | p50 | p75 | p90 | p95 | p99 | p99.9 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| fio-randwrite-direct0 | 0.000 ms | 0.000 ms | 0.000 ms | 14.877 ms | 0.000 ms | 0.000 ms | 42.729 ms | 61.080 ms | 17112.760 ms |

## Redis Diagnostics

| Tool | Top commandstats | Details |
| --- | --- | --- |
| fio-randwrite-direct0 | evalsha: calls=541, usec/call=55.04<br>exec: calls=984, usec/call=3.09<br>get: calls=1506, usec/call=1.25<br>rpush: calls=510, usec/call=3.68<br>incrby: calls=510, usec/call=2.79 | diagnostics/redis-fio-randwrite-direct0-after.txt |

## BrewFS Stats

Counters are per-tool deltas when matching before/after snapshots exist; dirty, live, and inflight values are after-tool gauges.

| Tool | Cache hit | FUSE read | FUSE write | Dirty | Live dirty | Recent pending | Recent uploaded | Read buffer | S3 ops | S3 avg latency | Details |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| fio-randwrite-direct0 | 0.0% (0/0) | 0.0 MiB | 3920.0 MiB | 3072.0 MiB | 0.0 MiB | 3072.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=218 | GET=0.00 ms, PUT=600.74 ms | diagnostics/stats-fio-randwrite-direct0-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=511 ops/3920.0 MiB/71804.8 ms, foreground=stage 71.80s/commit_wait 2.19s, flush_wait=5 ops/0.08s/5 slices, stage_fail=0, commit_before_stage=380, remote_inflight=3072.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=19, max_buffer_dirty=3564.0 MiB, max_live_dirty=1076.0 MiB, max_live_slices=149, max_recent_pending=3536.0 MiB, max_recent_uploaded=0.0 MiB, max_stage_inflight=488.0 MiB, max_remote_inflight=3536.0 MiB, last_buffer_dirty=3116.0 MiB, slices=create 511/reuse 3410/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=511 avg=7.7 MiB blocks=1.93/batch partial_tail=0.02 (size 0/max 0/flush 5/auto 4/age 0), partial_origin=normal 9/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 4/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 4/cached 0/mixed 0/unknown 0, freeze=size 63/flush 5/auto 299/max 144/age 0 |
| fio-randwrite-direct0-post-write-drained | 0.0% (0/0) | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=765 | GET=0.00 ms, PUT=298.88 ms | diagnostics/stats-fio-randwrite-direct0-post-write-drained-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=0 ops/0.0 MiB/0.0 ms, foreground=stage 0.00s/commit_wait 0.00s, flush_wait=0 ops/0.00s/0 slices, stage_fail=0, commit_before_stage=0, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 511/reuse 3410/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=0 avg=n/a blocks=0.00/batch partial_tail=0.00 (size 0/max 0/flush 0/auto 0/age 0), partial_origin=normal 0/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 0/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 0/cached 0/mixed 0/unknown 0, freeze=size 63/flush 5/auto 299/max 144/age 0 |
| fio-randwrite-direct0-post-write-runner-drained | 0.0% (0/0) | 0.0 MiB | 3920.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=985 | GET=0.00 ms, PUT=365.59 ms | diagnostics/stats-fio-randwrite-direct0-post-write-runner-drained-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=511 ops/3920.0 MiB/71804.8 ms, foreground=stage 71.80s/commit_wait 2.19s, flush_wait=5 ops/0.08s/5 slices, stage_fail=0, commit_before_stage=380, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 511/reuse 3410/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=511 avg=7.7 MiB blocks=1.93/batch partial_tail=0.02 (size 0/max 0/flush 5/auto 4/age 0), partial_origin=normal 9/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 4/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 4/cached 0/mixed 0/unknown 0, freeze=size 63/flush 5/auto 299/max 144/age 0 |
