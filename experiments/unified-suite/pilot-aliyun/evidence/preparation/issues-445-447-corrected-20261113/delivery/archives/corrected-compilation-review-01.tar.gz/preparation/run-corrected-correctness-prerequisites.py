#!/usr/bin/env python3
"""Run the preserved failure shape and known-byte oracle before performance."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import traceback

ROOT = Path('/home/dev/ax-perf-issues-corrected-validation/compose')
activation = json.loads((ROOT/'activation-receipt.json').read_text())
assert activation['passed'] is True
OUT = ROOT/'correctness-prerequisites-01'
OUT.mkdir(exist_ok=False)
receipt = {'passed': False, 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'activation_sha256': hashlib.sha256((ROOT/'activation-receipt.json').read_bytes()).hexdigest(),
           'scope': 'Correctness qualification only; no numbers from these cases are accepted as performance evidence',
           'stages': []}


def save():
    (OUT/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')


try:
    for case in ('randwrite-gate', 'known-tail-oracle'):
        for arm in ('baseline', 'candidate'):
            command = [sys.executable, str(ROOT/'run-compose-case.py'), arm, case, '500']
            step = {'arm': arm, 'case': case, 'trial': 500, 'command': command,
                    'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat()}
            receipt['stages'].append(step)
            save()
            with (OUT/(arm+'-'+case+'.log')).open('wb') as log:
                result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT)
            step['exit_code'] = result.returncode
            step['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
            save()
            assert result.returncode == 0, 'Failed prerequisites are fatal; preserve original artifacts'
            path = ROOT/'trials'/f'ax447-corrected-{arm}-{case}-500'/'receipt.json'
            trial = json.loads(path.read_text())
            assert trial['qualified'] is True and trial['status'] == 0
            assert trial['binary'] == activation['binary'][arm]
            assert trial['source']['commit'] == activation['runtime_sources'][arm]
            step['receipt'] = str(path)
            step['receipt_sha256'] = hashlib.sha256(path.read_bytes()).hexdigest()
            save()
    receipt['passed'] = True
except Exception:
    receipt['error'] = traceback.format_exc()
    raise
finally:
    receipt['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
print(json.dumps({'correctness_prerequisites_passed': receipt['passed']}), flush=True)
