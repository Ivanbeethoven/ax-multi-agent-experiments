#!/usr/bin/env python3
"""Three independent fixed-work pairs; all historical results remain separate."""
import fcntl
import hashlib
import json
import os
import subprocess
import sys
import time
import traceback
from pathlib import Path

from assess_fixed_work import assess

ROOT = Path('/home/dev/ax-perf-issues-corrected-validation/compose')
HERE = ROOT / 'fixed-work-610'
OUT = ROOT / 'matrices/fixed-work-randwrite1-610'
OUT.mkdir(parents=True, exist_ok=False)
checkpoint = json.loads((ROOT / 'correctness-checkpoint-02.json').read_text())
assert checkpoint['passed'] is True and checkpoint['stage'] == 'corrected-readwrite-correctness'
assert len(checkpoint['accepted_cases']) == 4 and set(checkpoint['trace_proofs']) == {'baseline', 'candidate'}
record = {'scope': 'Fresh namespace fixed-work foreground and strict writeback drain; not complete later compaction lifecycle',
          'historical_601_603_replaced': False, 'performance_accepted': False, 'passed': False,
          'pairs': [], 'started_unix_ns': time.time_ns()}


def save():
    (OUT / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


try:
    with Path('/home/dev/.ax-rbm-heavy.lock').open('w') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        assert subprocess.run(['pgrep', '-ax', 'cargo|rustc|fio|smallfiles'], stdout=subprocess.PIPE).returncode == 1
        manifest = json.loads((HERE / 'manifest.json').read_text())
        for name, item in manifest.items():
            assert sha(HERE / name) == item['sha256'], name
        record['manifest_sha256'] = sha(HERE / 'manifest.json')
        for trial, order in [(610, ['baseline', 'candidate']), (611, ['candidate', 'baseline']), (612, ['baseline', 'candidate'])]:
            pair = {'trial': trial, 'order': order, 'arms': {}}
            record['pairs'].append(pair)
            save()
            for arm in order:
                project = f'ax447-corrected-{arm}-fixed-work-randwrite1-{trial}'
                for command in [
                    ['docker', 'ps', '-a', '-q', '--filter', 'label=com.docker.compose.project=' + project],
                    ['docker', 'volume', 'ls', '-q', '--filter', 'label=com.docker.compose.project=' + project],
                ]:
                    assert not subprocess.check_output(command, text=True).strip(), 'Existing project must not be reused: ' + project
                env = dict(os.environ, AX447_INHERITED_HEAVY_LOCK_FD=str(lock.fileno()))
                space = os.statvfs(ROOT)
                reserve = 256 * 1024 ** 3
                minimum = max(32 * 1024 ** 3, space.f_blocks * space.f_frsize // 5)
                assert space.f_bavail * space.f_frsize - reserve >= minimum
                assert space.f_favail - 100000 >= space.f_files // 5
                pair.setdefault('capacity_preflight', {})[arm] = {
                    'free_bytes': space.f_bavail * space.f_frsize, 'reserve_bytes': reserve,
                    'minimum_remaining_bytes': minimum, 'free_inodes': space.f_favail,
                    'reserved_inodes': 100000, 'total_inodes': space.f_files}
                save()
                with (OUT / f'{trial}-{arm}.log').open('w') as log:
                    process = subprocess.Popen([sys.executable, str(HERE / 'run-fixed-case.py'), arm, 'fixed-work-randwrite1', str(trial)],
                                               env=env, pass_fds=(lock.fileno(),), stdout=log, stderr=subprocess.STDOUT)
                    capacity_passed = True
                    with (OUT / f'{trial}-{arm}-capacity.jsonl').open('w') as samples:
                        while True:
                            current = os.statvfs(ROOT)
                            sample = {'unix_ns': time.time_ns(), 'free_bytes': current.f_bavail * current.f_frsize,
                                      'total_bytes': current.f_blocks * current.f_frsize,
                                      'free_inodes': current.f_favail, 'total_inodes': current.f_files}
                            sample['passed'] = sample['free_bytes'] >= sample['total_bytes'] // 5 and current.f_favail >= current.f_files // 5
                            samples.write(json.dumps(sample) + '\n')
                            samples.flush()
                            if not sample['passed'] and capacity_passed:
                                capacity_passed = False
                                ids = subprocess.check_output(['docker', 'ps', '-q', '--filter', 'label=com.docker.compose.project=' + project,
                                                               '--filter', 'label=com.docker.compose.service=perf'], text=True).split()
                                for cid in ids:
                                    subprocess.run(['docker', 'stop', '--time', '30', cid], check=True, stdout=log, stderr=subprocess.STDOUT)
                            try:
                                status = process.wait(timeout=2)
                                break
                            except subprocess.TimeoutExpired:
                                pass
                assert capacity_passed, 'Capacity floor crossed; fixed-work result invalid'
                receipt_path = ROOT / 'trials' / project / 'receipt.json'
                receipt = json.loads(receipt_path.read_text())
                assert status == 0 and receipt['qualified'] and receipt['status'] == 0
                assert len(receipt['artifact_directories']) == 1
                assert not (receipt_path.parent / 'remaining-owned-containers.json').read_text().strip()
                artifact = Path(receipt['artifact_directories'][0])
                # Existing frozen postprocessors reconstruct the same three CPU boundaries.
                subprocess.run([sys.executable, str(ROOT / 'summarize-compose-phases.py'), str(artifact)], check=True)
                subprocess.run([sys.executable, str(ROOT / 'summarize-client-cpu.py'), str(artifact),
                                '--output', str(artifact / 'client-cpu-summary.json')], check=True)
                facts = assess(artifact)
                facts['trial_receipt_sha256'] = sha(receipt_path)
                facts['new_project_preflight'] = True
                pair['arms'][arm] = facts
                save()
            base, cand = pair['arms']['baseline'], pair['arms']['candidate']
            assert base['write_bytes'] == cand['write_bytes'] == 4 << 30
            pair['candidate_over_baseline'] = {key: cand[key] / base[key] for key in
                ['cpu_per_gib_s', 'active_s', 'active_plus_strict_drain_s', 'active_mib_s', 'active_plus_drain_mib_s']}
            save()
        record['passed'] = True
except Exception:
    record['error'] = traceback.format_exc()
    raise
finally:
    record['finished_unix_ns'] = time.time_ns()
    save()
