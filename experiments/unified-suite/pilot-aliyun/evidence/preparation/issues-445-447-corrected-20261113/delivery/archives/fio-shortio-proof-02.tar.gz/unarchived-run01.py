import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import tarfile
import urllib.request

root = Path('/tmp/ax-fio-shortio-339-20261113')
root.mkdir(exist_ok=False)
evidence = root / 'evidence'
evidence.mkdir()
url = 'https://codeload.github.com/axboe/fio/tar.gz/refs/tags/fio-3.39'
archive = root / 'fio-3.39.tar.gz'
archive.write_bytes(urllib.request.urlopen(url, timeout=60).read())
with tarfile.open(archive) as handle:
    handle.extractall(root, filter='data')
source = root / 'fio-fio-3.39'
assert source.is_dir()

def run(name, argv, cwd=source):
    start = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (evidence / (name + '.log')).open('wb') as output:
        result = subprocess.run(argv, cwd=cwd, stdout=output, stderr=subprocess.STDOUT)
    record = {'started_at': start, 'argv': argv, 'cwd': str(cwd), 'exit_code': result.returncode,
              'finished_at': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    (evidence / (name + '-command.json')).write_text(json.dumps(record, indent=2) + '\n')
    result.check_returncode()

run('configure', ['./configure', '--disable-native'])
run('build', ['make', '-j1', 'fio'])
run('version', [str(source / 'fio'), '--version'])
run('host', ['uname', '-a'])
for name in ['ioengines.c', 'io_ddir.h', 'stat.h', 'io_u.c', 'backend.c', 'engines/sync.c', 'config-host.h']:
    dest = evidence / 'source' / name
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes((source / name).read_bytes())

results = []
for sync in [False, True]:
    name = 'sync' if sync else 'no-sync'
    data = root / ('data-' + name)
    data.mkdir()
    args = [str(source / 'fio'), '--name=brewfs-bigwrite', '--directory=' + str(data),
            '--rw=write', '--bs=4k', '--size=16m', '--numjobs=1', '--ioengine=psync',
            '--iodepth=1', '--direct=0', '--end_fsync=1', '--refill_buffers',
            '--group_reporting', '--eta=never', '--buffer_pattern=0x5a',
            '--verify=pattern', '--verify_pattern=0x5a', '--do_verify=1', '--verify_fatal=1',
            '--lat_percentiles=1', '--clat_percentiles=1', '--slat_percentiles=1',
            '--percentile_list=50:95:99:99.9', '--randseed=20261031', '--randrepeat=1',
            '--output-format=json', '--output=' + str(evidence / (name + '.json'))]
    if sync:
        args.append('--sync_file_range=wait_before,write,wait_after:1')
    trace = evidence / (name + '.strace')
    run(name, ['strace', '-f', '-qq', '-yy', '-s', '0', '-e',
               'trace=pwrite64,pread64,sync_file_range,fsync', '-o', str(trace)] + args)
    job = json.loads((evidence / (name + '.json')).read_text())['jobs'][0]
    lines = trace.read_text().splitlines()
    writes = [line for line in lines if 'pwrite64(' in line and str(data) in line]
    reads = [line for line in lines if 'pread64(' in line and str(data) in line]
    syncs = [line for line in lines if 'sync_file_range(' in line and str(data) in line]
    assert len(writes) == 4096 and all(re.search(r', 4096, \d+\)\s+= 4096$', line) for line in writes)
    assert len(reads) == 4096 and all(re.search(r', 4096, \d+\)\s+= 4096$', line) for line in reads)
    assert len(syncs) == (4095 if sync else 0) and all(line.endswith('= 0') for line in syncs)
    assert job['error'] == 0 and job['write']['io_bytes'] == 16 * 1024 * 1024
    assert job['read']['io_bytes'] == 16 * 1024 * 1024
    assert job['write']['short_ios'] == (4095 if sync else 0)
    assert job['read']['short_ios'] == 0
    results.append({'case': name, 'pwrite_syscalls': len(writes), 'all_pwrite_lengths': 4096,
                    'all_pwrite_returns': 4096, 'pread_syscalls': len(reads),
                    'successful_sync_file_range_syscalls': len(syncs),
                    'fio_write_short_ios': job['write']['short_ios'], 'fio_error': job['error'],
                    'data_sha256': hashlib.sha256(next(data.iterdir()).read_bytes()).hexdigest()})

receipt = {'source_url': url, 'source_archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
           'source_tag': 'fio-3.39', 'binary_sha256': hashlib.sha256((source / 'fio').read_bytes()).hexdigest(),
           'environment': 'Local Ubuntu WSL regular filesystem; not cloud FUSE or the measured tools-image binary',
           'scope': 'Independent unmodified upstream fio-3.39 reproduction of short_ios accounting; these timings are not performance evidence',
           'results': results}
(evidence / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
manifest = [{'path': str(p.relative_to(evidence)), 'bytes': p.stat().st_size,
             'sha256': hashlib.sha256(p.read_bytes()).hexdigest()}
            for p in sorted(evidence.rglob('*')) if p.is_file()]
(evidence / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(receipt, indent=2), flush=True)
