# BrewFS Perf Report

Meta backend: redis

## Summary

| Tool | Status | Seconds | Log |
| --- | --- | ---: | --- |
| fio-bigwrite | pass | 1 | tools/fio-bigwrite.log |

## Post-Write Drain

| Tool | Drain seconds | Pending bytes | Dirty bytes | Buffer dirty bytes |
| --- | ---: | ---: | ---: | ---: |
| fio-bigwrite | 4 | 0 | 0 | 0 |

## Fio

| Tool | Workload | Direct | BS | Jobs | Read BW | Read IOPS | Write BW | Write IOPS | Read P99 | Write P99 | Raw |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |---: | ---: | ---: |
| fio-bigwrite | write | 0 | 4k | 1 | 1.42 GiB/s | 372,363.64 | 36.04 MiB/s | 9,225.23 | 0.059 ms | 0.129 ms | results/fio-bigwrite.json |

## Fio Runtime Accounting

Use `active_io_runtime` for close/flush tail detection; fio `job_runtime_ms` can aggregate multiple jobs under group reporting.

| Tool | Direct | Script wall | fio job_runtime | wall-job_runtime | wall/job_runtime | active_io_runtime | wall-active_io | wall/active_io | Tail marker |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| fio-bigwrite | 0 | 1 s | 0.454 s | +0.546 s | 2.20x | 0.444 s | +0.556 s | 2.25x | close/flush tail |

## Fully Drained Write Throughput

Actual fio bytes divided by `active_io_runtime + post_write_drain`; unlike foreground bandwidth, this includes the time required to empty the filesystem writeback queue.

| Tool | Active I/O | Drain | Complete | Read | Write | Total | Raw |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| fio-bigwrite | 0.444 s | 4.000 s | 4.444 s | 3.60 MiB/s | 3.60 MiB/s | 7.20 MiB/s | fully-drained-throughput.tsv |

## Latency Percentiles

### Read

| Workload | p1 | p5 | p25 | p50 | p75 | p90 | p95 | p99 | p99.9 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| fio-bigwrite | 0.000 ms | 0.000 ms | 0.000 ms | 0.001 ms | 0.000 ms | 0.000 ms | 0.001 ms | 0.059 ms | 0.131 ms |

### Write

| Workload | p1 | p5 | p25 | p50 | p75 | p90 | p95 | p99 | p99.9 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| fio-bigwrite | 0.000 ms | 0.000 ms | 0.000 ms | 0.096 ms | 0.000 ms | 0.000 ms | 0.116 ms | 0.129 ms | 0.153 ms |

## Redis Diagnostics

| Tool | Top commandstats | Details |
| --- | --- | --- |
| fio-bigwrite | exec: calls=4097, usec/call=0.92<br>get: calls=4101, usec/call=0.41<br>multi: calls=4097, usec/call=0.16<br>hget: calls=4099, usec/call=0.14<br>evalsha: calls=6, usec/call=70.17 | diagnostics/redis-fio-bigwrite-after.txt |

## BrewFS Stats

Counters are per-tool deltas when matching before/after snapshots exist; dirty, live, and inflight values are after-tool gauges.

| Tool | Cache hit | FUSE read | FUSE write | Dirty | Live dirty | Recent pending | Recent uploaded | Read buffer | S3 ops | S3 avg latency | Details |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| fio-bigwrite | 0.0% (0/0) | 16.0 MiB | 16.0 MiB | 16.0 MiB | 0.0 MiB | 16.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=0 | GET=0.00 ms, PUT=6.62 ms | diagnostics/stats-fio-bigwrite-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=1 ops/16.0 MiB/11.1 ms, foreground=stage 0.01s/commit_wait 0.00s, flush_wait=1 ops/0.02s/1 slices, stage_fail=0, commit_before_stage=1, remote_inflight=16.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=1, max_buffer_dirty=0.0 MiB, max_live_dirty=0.0 MiB, max_live_slices=0, max_recent_pending=0.0 MiB, max_recent_uploaded=0.0 MiB, max_stage_inflight=0.0 MiB, max_remote_inflight=0.0 MiB, last_buffer_dirty=0.0 MiB, slices=create 2/reuse 4095/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=1 avg=16.0 MiB blocks=4.00/batch partial_tail=0.00 (size 0/max 0/flush 0/auto 0/age 0), partial_origin=normal 0/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 0/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 0/cached 0/mixed 0/unknown 0, freeze=size 0/flush 2/auto 0/max 0/age 0 |
| fio-bigwrite-post-write-drained | 0.0% (0/0) | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=0 | GET=0.00 ms, PUT=52.11 ms | diagnostics/stats-fio-bigwrite-post-write-drained-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=0 ops/0.0 MiB/0.0 ms, foreground=stage 0.00s/commit_wait 0.00s, flush_wait=0 ops/0.00s/0 slices, stage_fail=0, commit_before_stage=0, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 2/reuse 4095/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=0 avg=n/a blocks=0.00/batch partial_tail=0.00 (size 0/max 0/flush 0/auto 0/age 0), partial_origin=normal 0/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 0/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 0/cached 0/mixed 0/unknown 0, freeze=size 0/flush 2/auto 0/max 0/age 0 |
| fio-bigwrite-post-write-runner-drained | 0.0% (0/0) | 16.0 MiB | 16.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=5 | GET=0.00 ms, PUT=52.11 ms | diagnostics/stats-fio-bigwrite-post-write-runner-drained-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=2 ops/16.0 MiB/11.4 ms, foreground=stage 0.01s/commit_wait 0.00s, flush_wait=2 ops/0.02s/2 slices, stage_fail=0, commit_before_stage=2, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 2/reuse 4095/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=2 avg=8.0 MiB blocks=2.50/batch partial_tail=0.50 (size 0/max 0/flush 1/auto 0/age 0), partial_origin=normal 0/cached 1/mixed 0/unknown 0, auto_detail=age 0/idle 0/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 0/cached 0/mixed 0/unknown 0, freeze=size 0/flush 2/auto 0/max 0/age 0 |

## FUSE Op Trace

- brewfs_fuse_ops.log: 21,122 lines
