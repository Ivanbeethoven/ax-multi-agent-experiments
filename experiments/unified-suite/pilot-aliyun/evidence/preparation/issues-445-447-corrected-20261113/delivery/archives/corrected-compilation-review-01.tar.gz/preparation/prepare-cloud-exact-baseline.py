#!/usr/bin/env python3
"""After both release units exit, independently copy the old debug cache and test baseline."""
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/srv/perf-issues-corrected-20261112')
SOURCE = Path('/srv/packed/target/debug')
TARGET = ROOT/'target-exact-baseline'
OUT = ROOT/'evidence/baseline-exact-cache-copy-01'
UNIT = 'ax447-corrected-baseline-exact-01'
OUT.mkdir(parents=True, exist_ok=False)
receipt = {'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
           'source': str(SOURCE), 'target': str(TARGET), 'copied': False,
           'rule': 'No source target writes and no source/destination hardlinks; preserve at least 32GiB and 20% inodes after conservative build reserve'}


def save():
    (OUT/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')


with Path('/home/dev/.ax-rbm-heavy.lock').open('w') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX)
    try:
        controller = json.loads((ROOT/'evidence/release-controller-01/receipt.json').read_text())
        assert controller['passed'] is True
        assert subprocess.run(['pgrep','-x','cargo|rustc|fio|smallfiles'],capture_output=True).returncode == 1
        for arm in ('baseline','candidate'):
            state = subprocess.check_output(['systemctl','show','ax447-corrected-'+arm+'-release-01',
                                             '-p','ActiveState','--value'],text=True).strip()
            assert state not in ('active','activating','deactivating'), state
        assert not TARGET.exists()
        entries = [p for p in SOURCE.rglob('*')]
        size = sum(p.lstat().st_size for p in entries if p.is_file() and not p.is_symlink())
        before = os.statvfs(ROOT)
        free = before.f_bavail*before.f_frsize
        reserve = 20*1024**3
        required_free = max(32*1024**3, int(before.f_blocks*before.f_frsize*.2))
        receipt.update(source_regular_bytes=size, source_entries=len(entries),
                       free_bytes_before=free, conservative_new_build_reserve_bytes=reserve,
                       minimum_remaining_bytes=required_free,
                       predicted_remaining_bytes=free-size-reserve,
                       free_inodes_before=before.f_favail, total_inodes=before.f_files)
        assert free-size-reserve >= required_free, 'disk headroom insufficient; revert to RBM plan'
        assert before.f_favail-3*len(entries) >= before.f_files*.2, 'inode headroom insufficient'
        save()
        TARGET.mkdir()
        subprocess.run(['cp','--recursive','--preserve=mode,timestamps','--reflink=auto',
                        str(SOURCE),str(TARGET/'debug')],check=True)
        shutil.copy2(SOURCE.parent/'.rustc_info.json', TARGET/'.rustc_info.json')
        checked = 0
        for old in entries:
            if old.is_file() and not old.is_symlink():
                new = TARGET/'debug'/old.relative_to(SOURCE)
                a,b = old.stat(),new.stat()
                assert a.st_size == b.st_size
                assert (a.st_dev,a.st_ino) != (b.st_dev,b.st_ino), 'source/destination hardlink'
                checked += 1
        after = os.statvfs(ROOT)
        assert after.f_bavail*after.f_frsize-reserve >= required_free
        receipt.update(copied=True, regular_file_inode_pairs_checked=checked,
                       free_bytes_after=after.f_bavail*after.f_frsize,
                       free_inodes_after=after.f_favail,
                       rustc_info_sha256=hashlib.sha256((TARGET/'.rustc_info.json').read_bytes()).hexdigest())
    finally:
        receipt['finished_at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
        save()

command = [sys.executable, '/srv/perf-issues-corrected-preparation-01/run-exact-feature-tests.py',
           '--spec', str(ROOT/'source-freeze/build-spec.json'), '--unit', UNIT,
           '--arms', 'baseline', '--target', str(TARGET),
           '--output', str(ROOT/'evidence/baseline-exact-features-01')]
raise SystemExit(subprocess.run(command, env=dict(os.environ,GIT_OPTIONAL_LOCKS='0')).returncode)
