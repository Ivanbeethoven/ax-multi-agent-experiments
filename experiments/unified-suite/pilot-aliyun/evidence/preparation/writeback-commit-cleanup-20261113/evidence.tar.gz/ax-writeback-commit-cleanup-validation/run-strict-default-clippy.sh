#!/bin/bash
set -euo pipefail
exec 9>/home/dev/.ax-rbm-heavy.lock
flock -n 9 || exit 75
if pgrep -x 'cargo|rustc|clippy-driver|fio|smallfiles' >/dev/null; then exit 75; fi
export PATH=/root/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin:$PATH RUSTUP_TOOLCHAIN=stable-x86_64-unknown-linux-gnu CARGO_HOME=/root/.cargo
export CARGO_TERM_COLOR=never GIT_OPTIONAL_LOCKS=0 CARGO_TARGET_DIR=/home/dev/ax-issues-target CARGO_BUILD_JOBS=3 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 RUST_TEST_THREADS=3
export GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=safe.directory GIT_CONFIG_VALUE_0=/home/dev/ax-writeback-commit-cleanup
cd /home/dev/ax-writeback-commit-cleanup
out=/home/dev/ax-writeback-commit-cleanup-validation/strict-default-clippy-01
mkdir -p "$out"
sha256sum src/vfs/io/writer.rs src/vfs/io/writer/commit_cleanup_tests.rs > "$out/source.sha256"
date -u +%FT%TZ > "$out/start.txt"
set +e
timeout -k 15 1800 cargo clippy --locked --workspace --all-targets -- -D warnings > "$out/clippy.log" 2>&1
rc=$?
set -e
echo "$rc" > "$out/exit.txt"
date -u +%FT%TZ > "$out/end.txt"
exit "$rc"
