#!/bin/bash
set -euo pipefail
exec 9>/home/dev/.ax-rbm-heavy.lock
flock -n 9 || exit 75
if pgrep -x 'cargo|rustc|clippy-driver|fio|smallfiles' >/dev/null; then exit 75; fi
python3 /home/dev/ax-writeback-commit-cleanup-validation/recheck-native-export.py
