#!/bin/bash
set -euo pipefail
exec 9>/home/dev/.ax-rbm-heavy.lock
flock -n 9 || exit 75
if pgrep -x 'cargo|rustc|clippy-driver|fio|smallfiles' >/dev/null; then exit 75; fi
export PATH=/root/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin:$PATH RUSTUP_TOOLCHAIN=stable-x86_64-unknown-linux-gnu CARGO_HOME=/root/.cargo
export CARGO_TERM_COLOR=never GIT_OPTIONAL_LOCKS=0 CARGO_TARGET_DIR=/home/dev/ax-issues-target CARGO_BUILD_JOBS=3 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 RUST_TEST_THREADS=3
export GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=safe.directory GIT_CONFIG_VALUE_0=/home/dev/ax-writeback-commit-cleanup
cd /home/dev/ax-writeback-commit-cleanup
out=/home/dev/ax-writeback-commit-cleanup-validation/testfix-gates-01
mkdir "$out"
python3 - <<'PY' > "$out/source-binding.json"
import subprocess, pathlib, json, hashlib
head='e2c964c55fafdcced34af58e840ebddda1cf9ea4'
repo='/home/dev/ax-writeback-commit-cleanup-freeze.git'
base='7b8445042fda8e6cd5ec9a3bedc0eb606a45d8b3'
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==base
status=subprocess.check_output(['git','status','--porcelain=v1'],text=True).splitlines()
expected=[' M src/vfs/io/writer.rs',' M src/vfs/io/writer/cached_write_watermarks_bench.rs','?? src/vfs/io/writer/commit_cleanup_tests.rs']
assert sorted(status)==sorted(expected),status
files={}
for path in [x[3:] for x in expected]:
    actual=pathlib.Path(path).read_bytes()
    committed=subprocess.check_output(['git','--git-dir='+repo,'show',head+':'+path])
    assert actual==committed,path
    files[path]=hashlib.sha256(actual).hexdigest()
print(json.dumps({'source_head':head,'active_base_head':base,'active_source_equivalent_to_commit':True,'files':files},indent=2))
PY
sha256sum src/vfs/io/writer.rs src/vfs/io/writer/commit_cleanup_tests.rs src/vfs/io/writer/cached_write_watermarks_bench.rs > "$out/source.sha256"
rustc --version --verbose > "$out/toolchain.txt"
run_gate() {
 local name=$1; shift
 printf '%s %s start\n' "$(date -u +%FT%TZ)" "$name" >> "$out/progress.log"
 set +e
 timeout -k 15 1800 "$@" > "$out/$name.log" 2>&1
 rc=$?
 set -e
 printf '%s %s exit=%s\n' "$(date -u +%FT%TZ)" "$name" "$rc" >> "$out/progress.log"
 test "$rc" = 0
}
run_gate fmt cargo fmt --all --check
run_gate strict-default-clippy cargo clippy --locked --workspace --all-targets -- -D warnings
run_gate superset-clippy cargo clippy --locked --workspace --all-targets --features workspace-overlay,observability,rustfs-ec-block-size-hint
run_gate diff git diff --check
sha256sum -c "$out/source.sha256" > "$out/final-source-check.log"
printf '%s all gates passed\n' "$(date -u +%FT%TZ)" >> "$out/progress.log"
