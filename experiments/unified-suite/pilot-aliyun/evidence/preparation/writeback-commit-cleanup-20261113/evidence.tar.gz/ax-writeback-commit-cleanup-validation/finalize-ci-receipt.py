from pathlib import Path
import json,re,hashlib,datetime
root=Path('/home/dev/ax-writeback-commit-cleanup-validation');out=root/'green-02'
progress=(out/'progress.log').read_text();assert 'all gates passed' in progress
starts={};stages=[]
for line in progress.splitlines():
    cols=line.split()
    if len(cols)==3 and cols[2]=='start': starts[cols[1]]=datetime.datetime.fromisoformat(cols[0].replace('Z','+00:00'))
    elif len(cols)==3 and cols[2].startswith('exit='):
        rc=int(cols[2].split('=')[1]);assert rc==0,line
        end=datetime.datetime.fromisoformat(cols[0].replace('Z','+00:00'));stages.append({'gate':cols[1],'exit':rc,'wall_seconds':(end-starts[cols[1]]).total_seconds()})
assert {'focused','repeat-focused','actual-features','check','build','tokio','uring','tests','clippy','strict-default-clippy','actual-clippy','diff'} <= {x['gate'] for x in stages}
qual=json.loads((root/'qualification-v2-receipt.json').read_text())
for rel,expected in qual['source_files_sha256'].items(): assert hashlib.sha256((Path('/home/dev/ax-writeback-commit-cleanup')/rel).read_bytes()).hexdigest()==expected
summary={}
for name in ['focused','writeback','cache-writeback','actual-features','tests']:
    text=(out/(name+'.log')).read_text();counts=[{'passed':int(a),'failed':int(b),'ignored':int(c)} for a,b,c in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)];assert counts,name;assert all(c['failed']==0 for c in counts)
    summary[name]=counts
logs={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(root.rglob('*')) if p.is_file() and (p.suffix in ['.log','.exit','.sha256'] or p.name in ['source.sha256','final-source-check.log'])}
receipt={'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'qualification_commit':qual['commit'],'qualification_tree':qual['tree'],'production_and_test_sha256':qual['source_files_sha256'],'default_and_superset_ci_passed':True,'exact_measurement_feature_tests':'pending independent two-head qualification by agent447','real_fuse_durability_and_performance':'pending independent two-head qualification by agent447','red':{'actual_same_executable_failures':4,'assertion':'uploaded and metadata-committed slice left stale recoverable stage','initial_zero-test_filter_invocation_excluded':True},'prior_full_suite_failure':{'retained':'green-01/actual-features.log','failed':1,'passed':2840,'ignored':485,'reason':'native effective export first nonzero lookup received ENOMEM; underlying LimitExceeded reason unavailable','same_executable_isolated_rechecks_passed':5,'root_cause_not_claimed':True,'passed_in_final_superset':True},'final_test_summaries':summary,'same_executable_repetitions':json.loads((out/'focused-repeat-receipt.json').read_text()),'feature_scope':{'superset_log_name':'actual-features','superset':'defaults (fuse-io-uring-runtime,gateway-s3,gateway-webdav) plus workspace-overlay,observability,rustfs-ec-block-size-hint','exact_measurement_not_substituted':'--no-default-features --features fuse-io-uring-runtime,workspace-overlay,observability,rustfs-ec-block-size-hint'},'resources':{'cpu_quota_percent':300,'memory_max_gib':38,'cargo_jobs':3,'rust_test_threads':3,'shared_heavy_lock':'/home/dev/.ax-rbm-heavy.lock','cargo_incremental':0,'cargo_profile_dev_debug':0},'stage_wall_seconds_ci_only':stages,'artifact_sha256':logs,'limitations':['The new handshake prevents new metadata-last cleanup omissions; it does not retroactively delete previously stranded records.','Existing best-effort filesystem error semantics are preserved.','Unit tests explicitly invoke the real SSD overlay; they do not substitute for production cfg(not(test)) fresh-cache FUSE validation.']}
(root/'final-ci-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'commit':qual['commit'],'default_and_superset_ci_passed':True,'receipt_sha256':hashlib.sha256((root/'final-ci-receipt.json').read_bytes()).hexdigest(),'stages':len(stages)},indent=2))
