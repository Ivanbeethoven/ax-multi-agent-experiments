#!/bin/bash
set -euo pipefail
exec 9>/home/dev/.ax-rbm-heavy.lock
flock -n 9 || exit 75
if pgrep -x 'cargo|rustc|clippy-driver|fio|smallfiles' >/dev/null; then exit 75; fi
export PATH=/root/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin:$PATH RUSTUP_TOOLCHAIN=stable-x86_64-unknown-linux-gnu CARGO_HOME=/root/.cargo
export CARGO_TERM_COLOR=never GIT_OPTIONAL_LOCKS=0 CARGO_TARGET_DIR=/home/dev/ax-issues-target CARGO_BUILD_JOBS=3 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 RUST_TEST_THREADS=3
export GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=safe.directory GIT_CONFIG_VALUE_0=/home/dev/ax-writeback-commit-cleanup
cd /home/dev/ax-writeback-commit-cleanup
out=/home/dev/ax-writeback-commit-cleanup-validation/green-02
mkdir -p "$out"
sha256sum src/vfs/io/writer.rs src/vfs/io/writer/commit_cleanup_tests.rs > "$out/source.sha256"
git rev-parse HEAD > "$out/base-commit.txt"
git diff --binary > "$out/tracked.patch"
cp src/vfs/io/writer/commit_cleanup_tests.rs "$out/tests.rs"
rustc --version --verbose > "$out/toolchain.txt"
run_gate() {
 local name=$1; shift
 printf '%s %s start\n' "$(date -u +%FT%TZ)" "$name" >> "$out/progress.log"
 set +e
 timeout -k 15 1800 "$@" > "$out/$name.log" 2>&1
 rc=$?
 set -e
 printf '%s %s exit=%s\n' "$(date -u +%FT%TZ)" "$name" "$rc" >> "$out/progress.log"
 test "$rc" = 0
}
run_gate fmt cargo fmt --all --check
run_gate focused cargo test --locked --workspace --lib --bins --features workspace-overlay,observability,rustfs-ec-block-size-hint commit_cleanup_tests -- --nocapture --test-threads=1
run_gate repeat-focused python3 /home/dev/ax-writeback-commit-cleanup-validation/repeat-focused.py "$out"
run_gate writeback cargo test --locked --workspace --lib --bins --features workspace-overlay,observability,rustfs-ec-block-size-hint commit_before_upload -- --nocapture --test-threads=3
run_gate cache-writeback cargo test --locked --workspace --lib --bins --features workspace-overlay,observability,rustfs-ec-block-size-hint vfs::cache::write_back -- --test-threads=3
run_gate actual-features cargo test --locked --workspace --lib --bins --features workspace-overlay,observability,rustfs-ec-block-size-hint
for f in run_perf_in_container.sh run_redis_perf.sh run_juicefs_perf_in_container.sh run_juicefs_perf.sh; do run_gate "$f" bash -n docker/compose-xfstests/"$f"; done
for f in test_perf_report_delta.sh test_juicefs_direct_matrix.sh test_juicefs_perf_report.sh; do run_gate "$f" bash docker/compose-xfstests/"$f"; done
run_gate check cargo check --locked --workspace
run_gate build cargo build --locked --workspace
cargo metadata --no-deps --format-version 1 > "$out/metadata.json"
if python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); members=set(d["workspace_members"]);sys.exit(not any(p["name"]=="rfuse3" and p["id"] in members for p in d["packages"]))' "$out/metadata.json"; then
 for feature in tokio-runtime io-uring-runtime async-io-runtime; do run_gate "rfuse3-$feature" cargo check --locked -p rfuse3 --no-default-features --features "$feature"; done
fi
run_gate tokio cargo check --locked -p brewfs --no-default-features --features fuse-tokio-runtime
run_gate uring cargo check --locked -p brewfs --no-default-features --features fuse-io-uring-runtime
run_gate tests cargo test --locked --workspace --lib --bins
run_gate clippy cargo clippy --locked --workspace
run_gate strict-default-clippy cargo clippy --locked --workspace --all-targets -- -D warnings
run_gate actual-clippy cargo clippy --locked --workspace --all-targets --features workspace-overlay,observability,rustfs-ec-block-size-hint
run_gate diff git diff --check
sha256sum -c "$out/source.sha256" > "$out/final-source-check.log"
printf '%s all gates passed\n' "$(date -u +%FT%TZ)" >> "$out/progress.log"
