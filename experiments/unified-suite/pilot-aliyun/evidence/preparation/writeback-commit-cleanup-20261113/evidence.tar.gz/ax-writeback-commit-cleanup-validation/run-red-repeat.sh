#!/bin/bash
set -euo pipefail
exec 9>/home/dev/.ax-rbm-heavy.lock
flock -n 9 || exit 75
if pgrep -x 'cargo|rustc|clippy-driver|fio|smallfiles' >/dev/null; then exit 75; fi
out=/home/dev/ax-writeback-commit-cleanup-validation
exe=/home/dev/ax-issues-target/debug/deps/brewfs-e280641cc0a640ae
sha256sum "$exe" > "$out/red-executable.sha256"
for n in 1 2 3; do
 set +e
 timeout 30 "$exe" vfs::io::writer::commit_cleanup_tests::commit_before_upload_cleans_stage_when_metadata_finishes_last --exact --nocapture > "$out/red-repeat-$n.log" 2>&1
 rc=$?
 set -e
 echo "$rc" > "$out/red-repeat-$n.exit"
 test "$rc" = 101
 grep -F 'uploaded and metadata-committed slice left stale recoverable stage:' "$out/red-repeat-$n.log"
done
