from pathlib import Path
import time,subprocess,json,datetime
root=Path('/home/dev/ax-writeback-commit-cleanup-validation')
progress=root/'green-01/progress.log'
deadline=time.monotonic()+2000
while time.monotonic()<deadline:
    text=progress.read_text() if progress.exists() else ''
    if 'actual-features exit=0' in text:
        receipt={'reason':'Intentional boundary stop after v1 complete superset tests; replace test-only B completion synchronization before final gates. Production SHA unchanged.','time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed_progress':text}
        (root/'green-01/boundary-stop.json').write_text(json.dumps(receipt,indent=2)+'\n')
        subprocess.run(['systemctl','stop','ax-writeback-cleanup-green-01.service'],check=True)
        break
    active=subprocess.run(['systemctl','is-active','--quiet','ax-writeback-cleanup-green-01.service']).returncode==0
    if not active: break
    time.sleep(0.1)
else:
    raise RuntimeError('bounded boundary watcher timeout')
