from pathlib import Path
import re,subprocess,json,hashlib,datetime
root=Path('/home/dev/ax-writeback-commit-cleanup-validation');out=root/'native-export-recheck-01';out.mkdir(exist_ok=True)
text=(root/'green-01/actual-features.log').read_text();paths=set(re.findall(r'Running unittests src/lib\.rs \((/home/dev/ax-issues-target/debug/deps/brewfs-[a-z0-9]+)\)',text));assert len(paths)==1,paths
exe=Path(paths.pop());test='workspace_overlay::stores::kv_store::packed_reader_pins::packed_reader_pin_tests::native_effective_export_tests::actual_native_effective_roundtrip_preserves_ids_hardlinks_holes_cold_and_native_hash'
rows=[]
for n in range(1,6):
 p=subprocess.run([str(exe),test,'--exact','--nocapture'],capture_output=True,text=True,timeout=60)
 f=out/f'run-{n}.log';f.write_text(p.stdout+p.stderr)
 rows.append({'run':n,'exit':p.returncode,'log':f.name,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
 print(n,p.returncode,flush=True)
(out/'receipt.json').write_text(json.dumps({'test':test,'executable':str(exe),'executable_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'runs':rows,'full_suite_failure_retained':True},indent=2)+'\n')
