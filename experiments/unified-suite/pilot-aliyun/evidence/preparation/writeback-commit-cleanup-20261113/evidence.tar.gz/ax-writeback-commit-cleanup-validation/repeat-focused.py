from pathlib import Path
import re,sys,subprocess,json,hashlib
out=Path(sys.argv[1]);text=(out/'focused.log').read_text()
exe_paths=set(re.findall(r'Running unittests src/lib\.rs \((/home/dev/ax-issues-target/debug/deps/brewfs-[a-z0-9]+)\)',text))
assert len(exe_paths)==1,exe_paths
exe=Path(exe_paths.pop());before=hashlib.sha256(exe.read_bytes()).hexdigest()
rows=[]
for n in range(1,4):
    p=subprocess.run([str(exe),'vfs::io::writer::commit_cleanup_tests','--nocapture','--test-threads=1'],capture_output=True,text=True,timeout=60)
    log=out/f'focused-repeat-{n}.log';log.write_text(p.stdout+p.stderr)
    assert p.returncode==0,(n,p.returncode)
    assert 'test result: ok. 3 passed; 0 failed;' in p.stdout,(n,p.stdout)
    rows.append({'run':n,'exit':p.returncode,'passed':3,'log':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()})
assert hashlib.sha256(exe.read_bytes()).hexdigest()==before
(out/'focused-repeat-receipt.json').write_text(json.dumps({'executable':str(exe),'executable_sha256':before,'runs':rows,'same_executable_verified':True},indent=2)+'\n')
print(json.dumps({'executable_sha256':before,'passed_runs':len(rows),'tests_per_run':3}))
