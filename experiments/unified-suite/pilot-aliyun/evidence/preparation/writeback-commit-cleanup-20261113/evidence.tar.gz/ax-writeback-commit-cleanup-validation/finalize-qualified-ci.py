#!/usr/bin/env python3
"""Record separate full-suite and test-only strict-lint qualification facts."""
import datetime as dt
import hashlib
import json
from pathlib import Path
import re
import subprocess

root = Path('/home/dev/ax-writeback-commit-cleanup-validation')


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(name):
    return json.loads((root / name).read_text())


def gates(directory):
    found = {}
    for line in (root / directory / 'progress.log').read_text().splitlines():
        bits = line.split()
        if len(bits) != 3 or bits[1] == 'all':
            continue
        timestamp, name, state = bits
        row = found.setdefault(name, {'name': name, 'directory': directory})
        if state == 'start':
            row['start_utc'] = timestamp
        elif state.startswith('exit='):
            row['end_utc'] = timestamp
            row['exit'] = int(state.split('=')[1])
            row['elapsed_seconds'] = (dt.datetime.fromisoformat(timestamp) - dt.datetime.fromisoformat(row['start_utc'])).total_seconds()
            log = root / directory / (name + '.log')
            row['log'] = str(log.relative_to(root))
            row['log_sha256'] = sha(log)
    return found


def counts(name):
    rows = []
    for match in re.finditer(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in ([0-9.]+)s', (root / name).read_text()):
        status, passed, failed, ignored, measured, filtered, elapsed = match.groups()
        rows.append({'status': status, 'passed': int(passed), 'failed': int(failed), 'ignored': int(ignored), 'measured': int(measured), 'filtered': int(filtered), 'seconds': float(elapsed)})
    assert rows, name
    return {'rows': rows, 'total_passed': sum(x['passed'] for x in rows), 'total_failed': sum(x['failed'] for x in rows), 'total_ignored': sum(x['ignored'] for x in rows)}


main = gates('green-02')
tail = gates('testfix-gates-01')
assert 'all gates passed' in (root / 'testfix-gates-01/progress.log').read_text()
assert all(tail[x]['exit'] == 0 for x in ['fmt', 'strict-default-clippy', 'superset-clippy', 'diff'])
assert main['strict-default-clippy']['exit'] == 101
required = ['fmt', 'focused', 'repeat-focused', 'writeback', 'cache-writeback', 'actual-features', 'run_perf_in_container.sh', 'run_redis_perf.sh', 'run_juicefs_perf_in_container.sh', 'run_juicefs_perf.sh', 'test_perf_report_delta.sh', 'test_juicefs_direct_matrix.sh', 'test_juicefs_perf_report.sh', 'check', 'build', 'tokio', 'uring', 'tests', 'clippy']
assert all(main[x]['exit'] == 0 for x in required)
assert 'chunks_exact_to_as_chunks' in (root / 'green-02/strict-default-clippy.log').read_text()
full_default = counts('green-02/tests.log')
full_superset = counts('green-02/actual-features.log')
assert (full_default['total_passed'], full_default['total_failed'], full_default['total_ignored']) == (1362, 0, 266)
assert (full_superset['total_passed'], full_superset['total_failed'], full_superset['total_ignored']) == (2858, 0, 485)
equivalence = load('testfix-release-equivalence.json')
source_binding = load('testfix-gates-01/source-binding.json')
assert source_binding['source_head'] == equivalence['publication_source_commit']
for path, digest in source_binding['files'].items():
    assert sha(Path('/home/dev/ax-writeback-commit-cleanup') / path) == digest
for name in ['red-02.log', 'red-repeat-1.log', 'red-repeat-2.log', 'red-repeat-3.log']:
    text = (root / name).read_text()
    assert 'stale recoverable stage' in text and '0 passed; 1 failed' in text
repeat = load('green-02/focused-repeat-receipt.json')
assert repeat['same_executable_verified'] and len(repeat['runs']) == 3
assert all(x['exit'] == 0 and x['passed'] == 3 for x in repeat['runs'])
for x in repeat['runs']:
    assert sha(root / 'green-02' / x['log']) == x['sha256']
old_failure = counts('green-01/actual-features.log')
assert old_failure['total_failed'] == 1
warning_blocks = []
for block in re.split(r'(?=^warning:)', (root / 'testfix-gates-01/superset-clippy.log').read_text(), flags=re.M):
    if re.search(r'--> src/', block):
        warning_blocks.append(block.strip())
report = {
    'schema': 1,
    'recorded_utc': dt.datetime.now(dt.timezone.utc).isoformat(),
    'local_date_timezone': 'Asia/Shanghai',
    'correctness_commit': equivalence['runtime_candidate_commit'],
    'publication_source_commit': equivalence['publication_source_commit'],
    'publication_tree': equivalence['publication_tree'],
    'runtime_candidate_commit': equivalence['runtime_candidate_commit'],
    'source_binding': source_binding,
    'release_equivalence_proof': {'path': 'testfix-release-equivalence.json', 'sha256': sha(root / 'testfix-release-equivalence.json')},
    'local_ci_gate_passed': True,
    'performance_acceptance_passed': False,
    'performance_acceptance_state': 'pending corrected baseline/candidate exact-feature tests and fresh-cache actual FUSE qualification owned by agent 447',
    'full_tests_default': full_default,
    'full_tests_superset': full_superset,
    'focused': counts('green-02/focused.log'),
    'commit_before_upload': counts('green-02/writeback.log'),
    'writeback_cache': counts('green-02/cache-writeback.log'),
    'same_executable_repeats': repeat,
    'full_suite_source': 'c8f5f16a; final e2 child only changes an ignored cfg(test) benchmark post-timing verification loop; full suite rerun waived explicitly by root, strict lint rerun required and passed',
    'feature_scope': {
        'default': 'defaults enabled: fuse-io-uring-runtime,gateway-s3,gateway-webdav',
        'superset': 'defaults enabled plus workspace-overlay,observability,rustfs-ec-block-size-hint',
        'exact_runtime': '--no-default-features --features fuse-io-uring-runtime,workspace-overlay,observability,rustfs-ec-block-size-hint',
        'exact_runtime_full_tests': 'pending; not represented by the superset result'
    },
    'gates': [main[x] for x in required] + list(tail.values()),
    'strict_default_command': 'cargo clippy --locked --workspace --all-targets -- -D warnings',
    'superset_clippy_command': 'cargo clippy --locked --workspace --all-targets --features workspace-overlay,observability,rustfs-ec-block-size-hint',
    'superset_warning_scope': 'Frozen pre-cleanup workspace code warnings and vendor warnings retained; superset extra gate is not a -D warnings command.',
    'superset_workspace_warning_blocks': warning_blocks,
    'failures_preserved': [
        {'path': 'red-01.log', 'meaning': 'Initial short exact filter selected zero tests; excluded from evidence.'},
        {'paths': ['red-02.log', 'red-repeat-1.log', 'red-repeat-2.log', 'red-repeat-3.log'], 'meaning': 'Four deterministic original-code assertion failures after actual upload completion and metadata completion; actual stage residual verified.'},
        {'path': 'green-01/actual-features.log', 'result': old_failure, 'meaning': 'Earlier full superset failed native effective export lookup with errno12. Isolated 5/5 rechecks are diagnostic only. Packed LimitExceeded maps to errno12, so OS OOM or cleanup causality is not established. Later full v2 suite passed without budget or assertion changes.'},
        {'path': 'green-02/strict-default-clippy.log', 'meaning': 'Strict lint rejected preexisting ignored benchmark chunks_exact loop; fixed by separate test-only child and strict gate rerun.'}
    ],
    'lifecycle_scope': {
        'state_handoff': 'Under one SliceState lock, either publish Committed while upload incomplete and let uploader retire the stage, or reserve metadata-side retirement while upload complete and publish Committed only after existing cleanup returns.',
        'late_uploader': 'Per-slice marker suppresses duplicate promotion after metadata-side retirement.',
        'unchanged': 'Epoch skip/orphan branches, invalidation ordering, payload accounting, and best-effort filesystem remove error behavior.',
        'production_ssd_fallback': 'Tests exercise real FsWriteBackCache overlay directly. cfg(not(test)) DataWriter fallback and actual remote durability remain downstream real FUSE gates.'
    }
}
(root / 'ci-final.json').write_text(json.dumps(report, indent=2) + '\n')
timing = ['| Gate | Source | Elapsed | Result |', '|---|---|---:|---|']
for x in report['gates']:
    if x['name'] in ['focused', 'actual-features', 'check', 'build', 'tokio', 'uring', 'tests', 'clippy', 'strict-default-clippy', 'superset-clippy']:
        timing.append(f"| {x['name']} | {x['directory']} | {x['elapsed_seconds']:.0f} s | exit {x['exit']} |")
text = f'''# Writeback commit cleanup qualification

Recorded on 2026-11-13 (Asia/Shanghai). Raw log timestamps are UTC.

Correctness commit `{report['correctness_commit']}` fixes a reproducible commit-before-upload race: metadata can finish after the uploader has skipped stage cleanup, leaving an obsolete sealed record visible to the SSD overlay. The fix atomically assigns cleanup to one completion path. When upload has already finished, cleanup runs before Committed publication; a marker prevents a late uploader from promoting the same record again.

Four original-code runs failed the actual residual-stage assertion. The unchanged regression and two enhanced real FileWriter/FsWriteBackCache tests pass, including three additional runs of the same test executable. The enhanced tests hold actual cleanup, verify flush remains pending and payload stays charged, then verify known A/B remote data and the SSD overlay.

Default full tests: **1,362 passed, 266 ignored**. Superset full tests: **2,858 passed, 485 ignored**. The official strict default all-targets Clippy gate passes after separate test-only commit `{report['publication_source_commit']}`. That commit changes one ignored benchmark verification loop after all timing samples; all other 2,001 tracked modes and blob IDs are identical. The runtime binaries and future measurements remain identified as c8f5f16a. The extra superset all-targets Clippy gate passes; its command does not use `-D warnings`. It retains warnings in frozen pre-cleanup workspace code: row_cache.rs fetch_update deprecation, a collapsible if and two manual slice-size calculations, and wire005/read_cache.rs type complexity. Raw warning blocks are included in the JSON alongside vendor warnings in the full logs.

The superset enables default features plus workspace-overlay, observability and rustfs-ec-block-size-hint. It is distinct from the no-default-features runtime build. Both corrected heads still require the exact runtime-feature full tests and actual FUSE fresh-cache durability/performance validation managed by agent 447. This receipt does not approve runtime performance or a PR.

All failures remain archived: the initial zero-test RED invocation, four meaningful RED failures, the earlier native-export errno12 full-suite failure, and the strict benchmark lint failure. The native-export error was not attributed to OS memory or cleanup without evidence; its five isolated passes were diagnostic, and the later complete suite passed. No budget or assertions were relaxed.

Existing filesystem promotion/remove error handling remains best effort. Epoch-skip and orphan paths are unchanged. Unit tests invoke the real SSD overlay method explicitly; they do not substitute for production cfg(not(test)) FUSE fallback verification.

Gate elapsed times include compilation and execution and are not performance measurements:

{chr(10).join(timing)}

See `ci-final.json` for commands, exact counts, per-log SHA256 and source identities; `testfix-release-equivalence.json` and `testfix-tree-manifests.json` prove the release-source equivalence. Historical receipts retain their state as originally recorded.
'''
(root / 'qualification-review.md').write_text(text)
excluded = {'.index', '.pyc'}
manifest = {}
for p in sorted(root.rglob('*')):
    if not p.is_file() or p.suffix in excluded or '__pycache__' in p.parts or p.name == 'artifact-sha256.json':
        continue
    manifest[str(p.relative_to(root))] = {'bytes': p.stat().st_size, 'sha256': sha(p)}
(root / 'artifact-sha256.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'passed': True, 'ci_final_sha256': sha(root / 'ci-final.json'), 'review_sha256': sha(root / 'qualification-review.md'), 'manifest_sha256': sha(root / 'artifact-sha256.json'), 'artifact_count': len(manifest)}, indent=2))
