#!/bin/bash
set -euo pipefail
exec 9>/home/dev/.ax-rbm-heavy.lock
flock -n 9 || exit 75
if pgrep -x 'cargo|rustc|clippy-driver|fio|smallfiles' >/dev/null; then exit 75; fi
export PATH=/root/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin:$PATH RUSTUP_TOOLCHAIN=stable-x86_64-unknown-linux-gnu CARGO_HOME=/root/.cargo
export CARGO_TERM_COLOR=never GIT_OPTIONAL_LOCKS=0 CARGO_TARGET_DIR=/home/dev/ax-issues-target CARGO_BUILD_JOBS=3 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0
export GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=safe.directory GIT_CONFIG_VALUE_0=/home/dev/ax-writeback-commit-cleanup
cd /home/dev/ax-writeback-commit-cleanup
set +e
timeout -k 15 60 cargo test --locked --lib --features workspace-overlay,observability,rustfs-ec-block-size-hint vfs::io::writer::commit_cleanup_tests::commit_before_upload_cleans_stage_when_metadata_finishes_last -- --exact --nocapture > /home/dev/ax-writeback-commit-cleanup-validation/red-02.log 2>&1
rc=$?
printf '%s\n' "$rc" > /home/dev/ax-writeback-commit-cleanup-validation/red-02.exit
exit "$rc"
