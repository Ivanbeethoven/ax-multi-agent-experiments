# BrewFS Perf Report

Meta backend: redis

## Summary

| Tool | Status | Seconds | Log |
| --- | --- | ---: | --- |
| fio-bigwrite | fail(1) | 1 | tools/fio-bigwrite.log |

## Post-Write Drain

| Tool | Drain seconds | Pending bytes | Dirty bytes | Buffer dirty bytes |
| --- | ---: | ---: | ---: | ---: |
| fio-bigwrite | 14 | 0 | 0 | 0 |

## Fio

| Tool | Workload | Direct | BS | Jobs | Read BW | Read IOPS | Write BW | Write IOPS | Read P99 | Write P99 | Raw |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |---: | ---: | ---: |
| fio-bigwrite | write | 0 | 4k | 1 | 54.69 MiB/s | 14,000.00 | 34.22 MiB/s | 8,760.18 | 0.081 ms | 3.064 ms | results/fio-bigwrite.json |

## Fio Runtime Accounting

Use `active_io_runtime` for close/flush tail detection; fio `job_runtime_ms` can aggregate multiple jobs under group reporting.

| Tool | Direct | Script wall | fio job_runtime | wall-job_runtime | wall/job_runtime | active_io_runtime | wall-active_io | wall/active_io | Tail marker |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| fio-bigwrite | 0 | 1 s | 0.103 s | +0.897 s | 9.71x | 0.104 s | +0.896 s | 9.62x | close/flush tail |

## Fully Drained Write Throughput

Actual fio bytes divided by `active_io_runtime + post_write_drain`; unlike foreground bandwidth, this includes the time required to empty the filesystem writeback queue.

| Tool | Active I/O | Drain | Complete | Read | Write | Total | Raw |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| fio-bigwrite | 0.104 s | 14.000 s | 14.104 s | 0.00 MiB/s | 0.07 MiB/s | 0.07 MiB/s | fully-drained-throughput.tsv |

## Latency Percentiles

### Read

| Workload | p1 | p5 | p25 | p50 | p75 | p90 | p95 | p99 | p99.9 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| fio-bigwrite | 0.000 ms | 0.000 ms | 0.000 ms | 0.001 ms | 0.000 ms | 0.044 ms | 0.081 ms | 0.081 ms | 0.081 ms |

### Write

| Workload | p1 | p5 | p25 | p50 | p75 | p90 | p95 | p99 | p99.9 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| fio-bigwrite | 0.093 ms | 0.094 ms | 0.000 ms | 0.106 ms | 0.000 ms | 0.196 ms | 0.453 ms | 3.064 ms | 4.817 ms |

## Redis Diagnostics

| Tool | Top commandstats | Details |
| --- | --- | --- |
| fio-bigwrite | evalsha: calls=7, usec/call=72.29<br>exec: calls=257, usec/call=0.98<br>get: calls=263, usec/call=0.43<br>script|load: calls=1, usec/call=108.00<br>config|resetstat: calls=1, usec/call=51.00 | diagnostics/redis-fio-bigwrite-after.txt |

## BrewFS Stats

Counters are per-tool deltas when matching before/after snapshots exist; dirty, live, and inflight values are after-tool gauges.

| Tool | Cache hit | FUSE read | FUSE write | Dirty | Live dirty | Recent pending | Recent uploaded | Read buffer | S3 ops | S3 avg latency | Details |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| fio-bigwrite | 0.0% (0/0) | 0.2 MiB | 1.0 MiB | 1.5 MiB | 1.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=2 | GET=0.00 ms, PUT=8.50 ms | diagnostics/stats-fio-bigwrite-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=3 ops/0.9 MiB/1.5 ms, foreground=stage 0.00s/commit_wait 0.00s, flush_wait=2 ops/0.00s/2 slices, stage_fail=0, commit_before_stage=1, remote_inflight=0.5 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=1, max_buffer_dirty=0.0 MiB, max_live_dirty=0.0 MiB, max_live_slices=0, max_recent_pending=0.0 MiB, max_recent_uploaded=0.0 MiB, max_stage_inflight=0.0 MiB, max_remote_inflight=0.0 MiB, last_buffer_dirty=0.0 MiB, slices=create 4/reuse 130/reject_unique 0/reject_prefix 0, live_slices=2 avg=0.5 MiB, origin=normal 0/cached 2/mixed 0/unknown 0, upload_batch=3 avg=0.3 MiB blocks=1.00/batch partial_tail=1.00 (size 0/max 0/flush 3/auto 0/age 0), partial_origin=normal 0/cached 3/mixed 0/unknown 0, auto_detail=age 0/idle 0/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 0/cached 0/mixed 0/unknown 0, freeze=size 0/flush 3/auto 0/max 0/age 0 |
| fio-bigwrite-post-write-drained | 0.0% (0/0) | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=0 | GET=0.00 ms, PUT=8.50 ms | diagnostics/stats-fio-bigwrite-post-write-drained-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=0 ops/0.0 MiB/0.0 ms, foreground=stage 0.00s/commit_wait 0.00s, flush_wait=0 ops/0.00s/0 slices, stage_fail=0, commit_before_stage=0, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 4/reuse 130/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=0 avg=n/a blocks=0.00/batch partial_tail=0.00 (size 0/max 0/flush 0/auto 0/age 0), partial_origin=normal 0/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 0/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 0/cached 0/mixed 0/unknown 0, freeze=size 0/flush 3/auto 0/max 0/age 0 |
| fio-bigwrite-post-write-runner-drained | 0.0% (0/0) | 0.2 MiB | 1.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=2 | GET=0.00 ms, PUT=8.50 ms | diagnostics/stats-fio-bigwrite-post-write-runner-drained-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=3 ops/0.9 MiB/1.5 ms, foreground=stage 0.00s/commit_wait 0.00s, flush_wait=3 ops/0.08s/4 slices, stage_fail=0, commit_before_stage=1, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 4/reuse 130/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=3 avg=0.3 MiB blocks=1.00/batch partial_tail=1.00 (size 0/max 0/flush 3/auto 0/age 0), partial_origin=normal 0/cached 3/mixed 0/unknown 0, auto_detail=age 0/idle 0/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 0/cached 0/mixed 0/unknown 0, freeze=size 0/flush 3/auto 0/max 0/age 0 |

## FUSE Op Trace

- brewfs_fuse_ops.log: 1,370 lines
