#!/usr/bin/env python3
"""Run only inside an already mounted Shared workspace; never mount or unmount it."""
import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import sys
import threading
import time

ATTRIBUTE = b"user.ax_row_cache_guard"
PREFIX = "brewfs_workspace_row_cache_"
HITS, MISSES = PREFIX + "hits_total", PREFIX + "misses_total"
RETAINED, CAPACITY = PREFIX + "retained_bytes", PREFIX + "capacity_bytes"
METRIC = re.compile(r"^([A-Za-z_:][A-Za-z0-9_:]*(?:\{[^\n]*\})?)\s+(\S+)(?:\s+\S+)?$")


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(",", ":")).encode()


def digest(value):
    return hashlib.sha256(value).hexdigest()


def relative_path(value):
    path = PurePosixPath(value)
    if path.is_absolute() or not path.parts or any(p in (".", "..") for p in path.parts):
        raise ValueError("fixture paths must stay relative to the supplied mount")
    return Path(*path.parts)


def expected_value(index, size):
    unit = b"ax" + index.to_bytes(6, "little")
    return (unit * ((size + 7) // 8))[:size]


def outside_mount(path, mount):
    if path.resolve().is_relative_to(mount.resolve()):
        raise ValueError("evidence output must be outside the mounted workspace")


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def parse_stats(raw):
    fields = {}
    for line in raw.splitlines():
        match = METRIC.fullmatch(line.strip())
        if match:
            key, value = match.groups()
            if key.startswith(PREFIX) and key in fields:
                raise ValueError("duplicate native row-cache counter: " + key)
            fields[key] = value
    for key in (HITS, MISSES):
        if key not in fields or not fields[key].isdigit():
            raise ValueError("missing or invalid native row-cache counter: " + key)
    for key in (RETAINED, CAPACITY):
        if key in fields and not fields[key].isdigit():
            raise ValueError("invalid native byte counter: " + key)
    return {
        "raw": raw,
        "fields": fields,
        "row": {key: int(fields[key]) if key in fields else None
                for key in (HITS, MISSES, RETAINED, CAPACITY)},
        "unsupported_row_fields": [key for key in (RETAINED, CAPACITY) if key not in fields],
    }


def read_stats(mount):
    return parse_stats((mount / ".stats").read_text(encoding="utf-8"))


def counter_delta(before, after):
    result = {key: after["row"][key] - before["row"][key] for key in (HITS, MISSES)}
    if any(value < 0 for value in result.values()):
        raise ValueError("native counters decreased or the mount changed")
    return result


def byte_checks(samples, require):
    missing = any(sample["unsupported_row_fields"] for sample in samples)
    return {
        "supported": not missing,
        "required_fields_present": not require or not missing,
        "observed_within_capacity": None if missing else all(
            sample["row"][RETAINED] <= sample["row"][CAPACITY]
            for sample in samples if not sample["unsupported_row_fields"]),
        "sampled_retained_max_bytes": max(
            (sample["row"][RETAINED] for sample in samples
             if sample["row"][RETAINED] is not None), default=None),
        "sampling_note": "Sampled retained ownership, not a continuous peak or process RSS.",
    }


def prepare(args):
    if not 1 <= args.files <= 4096 or not 1 <= args.value_bytes <= 32768:
        raise ValueError("use 1..4096 files and 1..32768 value bytes (below Linux's 64KiB limit)")
    outside_mount(args.manifest, args.mount)
    root = args.mount / relative_path(args.subdir)
    root.mkdir(exist_ok=False)
    entries = []
    for index in range(args.files):
        relative = f"group-{index // 32:04d}/file-{index:06d}"
        path = root / relative
        path.parent.mkdir(exist_ok=True)
        value = expected_value(index, args.value_bytes)
        with path.open("xb") as handle:
            os.setxattr(handle.fileno(), ATTRIBUTE, value)
        entries.append({"index": index, "path": relative, "value_sha256": digest(value)})
    manifest = {"schema": 1, "relative_root": args.subdir,
                "attribute": ATTRIBUTE.decode(), "value_pattern": "ax-u48le-repeat",
                "value_bytes": args.value_bytes, "files": entries}
    write_json(args.manifest, manifest)
    return {"passed": True, "prepared_files": len(entries),
            "canonical_input_sha256": digest(canonical(manifest))}


def load_fixture(args):
    manifest = json.loads(args.manifest.read_text(encoding="utf-8"))
    if manifest["schema"] != 1 or manifest["attribute"] != ATTRIBUTE.decode():
        raise ValueError("unsupported fixture manifest")
    size = manifest["value_bytes"]
    if manifest["value_pattern"] != "ax-u48le-repeat" or not 1 <= size <= 32768:
        raise ValueError("unsupported fixture value pattern or size")
    if not 1 <= len(manifest["files"]) <= 4096:
        raise ValueError("invalid fixture file count")
    root = args.mount / relative_path(manifest["relative_root"])
    fds, values = [], []
    try:
        for index, entry in enumerate(manifest["files"]):
            value = expected_value(index, size)
            if entry["index"] != index or entry["value_sha256"] != digest(value):
                raise ValueError("fixture manifest value identity mismatch")
            fds.append(os.open(root / relative_path(entry["path"]), os.O_RDONLY | os.O_NOFOLLOW))
            values.append(value)
        return manifest, fds, values
    except BaseException:
        for fd in fds:
            os.close(fd)
        raise


def verify_get(fd, value):
    if os.getxattr(fd, ATTRIBUTE) != value:
        raise AssertionError("fgetxattr returned an incorrect value")


def hot(args, manifest, fds, values):
    if manifest["value_bytes"] != 8:
        raise ValueError("hot latency guard requires exactly 8-byte values; use memory-smoke separately")
    if args.keys > len(fds) or args.keys not in (1, 128) or args.threads not in (1, 8):
        raise ValueError("hot guard uses 1/128 available keys and 1/8 threads")
    if not 1 <= args.ops_per_thread <= 1000000:
        raise ValueError("invalid operations per thread")
    for key in range(args.keys):
        verify_get(fds[key], values[key])
    warm_before = read_stats(args.mount)
    for key in range(args.keys):
        verify_get(fds[key], values[key])
    before = read_stats(args.mount)
    warm_delta = counter_delta(warm_before, before)
    warm_ok = warm_delta[MISSES] == 0 and warm_delta[HITS] >= args.keys
    workload = {"kind": "hot-fgetxattr", "keys": args.keys, "threads": args.threads,
                "ops_per_thread": args.ops_per_thread, "value_bytes": 8,
                "key_order": "(operation_index + thread_index) % keys",
                "every_value_verified": True}
    report = {"workload": workload, "warm_before": warm_before, "before": before,
              "warm_delta": warm_delta, "warm_stable": warm_ok}
    if not warm_ok:
        report.update(passed=False, failure="warm Xattr working set did not remain cached")
        return report
    barrier = threading.Barrier(args.threads + 1)

    def worker(thread_index):
        barrier.wait()
        start = time.perf_counter_ns()
        for operation in range(args.ops_per_thread):
            key = (operation + thread_index) % args.keys
            verify_get(fds[key], values[key])
        return {"thread": thread_index, "successful_calls": args.ops_per_thread,
                "wall_ns": time.perf_counter_ns() - start}

    with concurrent.futures.ThreadPoolExecutor(max_workers=args.threads) as executor:
        futures = [executor.submit(worker, index) for index in range(args.threads)]
        start_cpu, start_wall = time.process_time_ns(), time.perf_counter_ns()
        barrier.wait()
        results = [future.result() for future in futures]
        elapsed, client_cpu = time.perf_counter_ns() - start_wall, time.process_time_ns() - start_cpu
    after = read_stats(args.mount)
    delta = counter_delta(before, after)
    operations = sum(result["successful_calls"] for result in results)
    checks = byte_checks([warm_before, before, after], args.require_byte_metrics)
    report.update(after=after, delta=delta, threads=results, successful_calls=operations,
                  wall_ns=elapsed, client_process_cpu_ns=client_cpu,
                  client_cpu_note="Python caller process only; excludes BrewFS/backend CPU.",
                  byte_checks=checks,
                  passed=delta[MISSES] == 0 and delta[HITS] >= operations
                  and checks["required_fields_present"]
                  and checks["observed_within_capacity"] is not False)
    return report


def memory_smoke(args, manifest, fds, values):
    if manifest["value_bytes"] != 32768:
        raise ValueError("memory smoke uses 32KiB values, separately from the 8-byte hot guard")
    before = read_stats(args.mount)
    samples = [before]
    for _ in range(2):
        for fd, value in zip(fds, values):
            verify_get(fd, value)
            samples.append(read_stats(args.mount))
    checks = byte_checks(samples, args.require_byte_metrics)
    delta = counter_delta(before, samples[-1])
    touched = delta[HITS] + delta[MISSES] >= 2 * len(fds)
    return {"workload": {"kind": "large-xattr-memory-smoke", "passes": 2,
                         "keys": len(fds), "value_bytes": manifest["value_bytes"],
                         "every_value_verified": True, "performance_claim": False},
            "samples": samples, "delta": delta, "row_path_touched": touched,
            "byte_checks": checks, "passed": touched and checks["required_fields_present"]
            and checks["observed_within_capacity"] is not False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=("prepare", "hot", "memory-smoke"))
    parser.add_argument("--mount", type=Path, required=True)
    parser.add_argument("--manifest", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--label", default="unlabelled")
    parser.add_argument("--repetition", type=int, default=0)
    parser.add_argument("--subdir", default=".ax-row-cache-guard-hot")
    parser.add_argument("--files", type=int, default=128)
    parser.add_argument("--value-bytes", type=int, default=8)
    parser.add_argument("--keys", type=int, default=128)
    parser.add_argument("--threads", type=int, default=1)
    parser.add_argument("--ops-per-thread", type=int, default=1024)
    parser.add_argument("--require-byte-metrics", action="store_true")
    args = parser.parse_args()
    outside_mount(args.output, args.mount)
    report = {"schema": 1, "label": args.label, "repetition": args.repetition,
              "command": args.command, "argv": sys.argv, "mount": str(args.mount),
              "harness_sha256": digest(Path(__file__).read_bytes())}
    fds = []
    try:
        if args.command == "prepare":
            report.update(prepare(args))
        else:
            manifest, fds, values = load_fixture(args)
            report["canonical_input_sha256"] = digest(canonical(manifest))
            report.update(hot(args, manifest, fds, values) if args.command == "hot"
                          else memory_smoke(args, manifest, fds, values))
            report["workload_sha256"] = digest(canonical(report["workload"]))
    except Exception as error:
        report.update(passed=False, failure=f"{type(error).__name__}: {error}")
    finally:
        for fd in fds:
            os.close(fd)
    write_json(args.output, report)
    print(json.dumps({key: report.get(key) for key in
                      ("passed", "failure", "canonical_input_sha256", "workload_sha256", "wall_ns")}))
    return 0 if report.get("passed") else 1


if __name__ == "__main__":
    raise SystemExit(main())
