#!/bin/bash
set -euo pipefail
exec 9>/home/dev/.ax-rbm-heavy.lock
flock 9
if pgrep -x 'cargo|rustc|fio|smallfiles' >/dev/null; then echo 'Existing heavy process; leaving'; exit 75; fi
root=/home/dev/ax-perf-issues-validation/compose
out="$root/service-smoke-04"
mkdir -p "$out"
export COMPOSE_PROJECT_NAME=ax447-service-smoke-ec4
export AX447_FROZEN_SOURCE=/home/dev/ax-issue447-perf-baseline
export AX447_RUNNER_IMAGE=ax447-runner:ax447-service-smoke
export PERF_CONTAINER_REDIS_BREWFS_PERF=$COMPOSE_PROJECT_NAME-redis
export PERF_CONTAINER_RUSTFS_BREWFS_PERF_REDIS=$COMPOSE_PROJECT_NAME-rustfs
export PERF_CONTAINER_MINIO_BREWFS_PERF_REDIS=$COMPOSE_PROJECT_NAME-minio
export REDIS_HOST_PORT=26379 RUSTFS_S3_HOST_PORT=29000 RUSTFS_CONSOLE_HOST_PORT=29001
export AX447_TOOLS_IMAGE=$(python3 -c 'import json;print(json.load(open("/home/dev/ax-perf-issues-validation/compose/image-manifest.json"))["tools"]["reference"])')
export AX447_REDIS_IMAGE=$(python3 -c 'import json;print(json.load(open("/home/dev/ax-perf-issues-validation/compose/image-manifest.json"))["redis"]["reference"])')
export AX447_RUSTFS_IMAGE=$(python3 -c 'import json;print(json.load(open("/home/dev/ax-perf-issues-validation/compose/image-manifest.json"))["rustfs"]["reference"])')
export AX447_AWSCLI_IMAGE=$(python3 -c 'import json;print(json.load(open("/home/dev/ax-perf-issues-validation/compose/image-manifest.json"))["awscli"]["reference"])')
for port in 26379 29000 29001; do
 if [[ -n "$(ss -H -ltn "sport = :$port")" ]]; then echo "Port $port occupied; leaving owner intact"; exit 75; fi
done
compose=(docker compose -f "$root/compose.json")
cleanup() {
 "${compose[@]}" down -v > "$out/cleanup.log" 2>&1 || true
}
trap cleanup EXIT
printf '%s starting owned services\n' "$(date -u +%FT%TZ)" > "$out/progress.log"
"${compose[@]}" config --format json > "$out/rendered-compose.json"
timeout -k 10 120 docker compose -f "$root/service-smoke-build.json" build probe > "$out/thin-build.log" 2>&1
timeout -k 10 240 "${compose[@]}" up -d --wait redis rustfs > "$out/up.log" 2>&1
python3 "$root/verify-rustfs-runtime.py" "$PERF_CONTAINER_RUSTFS_BREWFS_PERF_REDIS" "$out/rustfs-runtime-pin.json" > "$out/runtime-check.log"
timeout -k 10 210 "${compose[@]}" run --rm rustfs-init > "$out/init.log" 2>&1
timeout -k 10 90 "${compose[@]}" run --rm --entrypoint /bin/sh rustfs-init -ec '
printf 0123456789abcdef > /tmp/payload
aws --endpoint-url http://rustfs:9000 --cli-connect-timeout 5 --cli-read-timeout 15 s3api put-object --bucket brewfs-data --key smoke.txt --body /tmp/payload
aws --endpoint-url http://rustfs:9000 --cli-connect-timeout 5 --cli-read-timeout 15 s3api get-object --bucket brewfs-data --key smoke.txt --range bytes=4-7 /tmp/range
[ "$(cat /tmp/range)" = 4567 ]
echo EXACT_RANGE_READBACK_PASSED
' > "$out/range-readback.log" 2>&1
python3 "$root/service-smoke-large-probe.py"
printf '%s service smoke passed\n' "$(date -u +%FT%TZ)" >> "$out/progress.log"
