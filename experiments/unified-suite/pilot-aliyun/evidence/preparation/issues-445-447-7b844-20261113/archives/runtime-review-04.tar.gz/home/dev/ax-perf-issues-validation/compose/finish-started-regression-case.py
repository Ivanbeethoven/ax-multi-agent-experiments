from pathlib import Path
import subprocess,json,time,os,signal,datetime
r=Path('/home/dev/ax-perf-issues-validation/compose');rev=json.loads((r/'regression-plan-revision-01.json').read_text());pid=rev['paused_parent_pid'];child=rev['running_child']['pid']
while True:
 p=Path(f'/proc/{child}/stat')
 if not p.exists() or p.read_text().rsplit(')',1)[1].split()[0]=='Z':break
 time.sleep(5)
receipt=json.loads((r/'trials/ax447-baseline-regression-smoke-1/receipt.json').read_text());assert 'finished_at' in receipt
# The started child has returned, so terminating only the stopped controller cannot interrupt a test.
subprocess.run(['systemctl','kill','--signal=SIGKILL','--kill-whom=main',rev['unit']],check=True)
record={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reason':'Stopped unstarted repetitions under root plan revision; started case completed normally','started_case_status':receipt['status'],'old_matrix_not_a_complete_campaign':True}
(r/'regression-plan-revision-complete.json').write_text(json.dumps(record,indent=2)+'\n')
assert receipt['status']==0,'Started smoke failed; preserve and inspect'
assert len(receipt['artifact_directories'])==1;a=Path(receipt['artifact_directories'][0])
subprocess.run(['python3',str(r/'summarize-compose-phases.py'),str(a)],check=True)
subprocess.run(['python3',str(r/'summarize-client-cpu.py'),str(a),'--output',str(a/'client-cpu-summary.json')],check=True)
(r/'review-snapshot-window.ready').write_text('Started smoke completed; no next benchmark is running.\n')
while not (r/'review-snapshot-window.done').exists():time.sleep(5)
subprocess.run(['systemd-run','--unit=ax447-regression-pair','-p','CPUQuota=300%','-p','MemoryMax=16G','-p','RuntimeMaxSec=3600','-p',f'StandardOutput=append:{r}/regression-pair.log','-p',f'StandardError=append:{r}/regression-pair.log','python3',str(r/'run-regression-guard-pair.py')],check=True)
