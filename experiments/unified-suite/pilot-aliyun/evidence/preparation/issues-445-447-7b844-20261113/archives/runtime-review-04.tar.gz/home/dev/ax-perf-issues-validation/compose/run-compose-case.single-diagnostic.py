"""Run one owned, source-frozen ordinary-volume compose trial."""
import argparse
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time
import yaml

ROOT = Path('/home/dev/ax-perf-issues-validation/compose')
parser = argparse.ArgumentParser()
parser.add_argument('arm', choices=['baseline', 'candidate'])
parser.add_argument('case', choices=['cached-smoke', 'cached', 'regression-smoke', 'regression'])
parser.add_argument('trial', type=int)
parser.add_argument('--sync', choices=['range', 'fsync'], default='range')
args = parser.parse_args()
spec = json.loads((ROOT / f'{args.arm}-build-spec.json').read_text())
repo = Path(spec['worktree'])
manifest = json.loads((ROOT / 'binary-manifest.json').read_text())[args.arm]
images = json.loads((ROOT / 'image-manifest.json').read_text())
project = f'ax447-{args.arm}-{args.case}-{args.trial}'
assert re.fullmatch(r'ax447-[a-z0-9-]+', project)
out = ROOT / 'trials' / project
out.mkdir(parents=True, exist_ok=False)
env = {k: v for k, v in os.environ.items() if not k.startswith(
    ('PERF_', 'BREWFS_', 'COMPOSE_', 'RUSTFS_', 'REDIS_', 'MINIO_', 'AWS_', 'AX447_'))}
env.update({
    'GIT_OPTIONAL_LOCKS': '0', 'RUST_LOG': 'error',
    'GIT_CONFIG_COUNT': '1', 'GIT_CONFIG_KEY_0': 'safe.directory',
    'GIT_CONFIG_VALUE_0': str(repo),
    'AX447_FROZEN_SOURCE': str(repo), 'COMPOSE_PROJECT_NAME': project,
    'BREWFS_PERF_COMPOSE_FILE': str(ROOT / 'compose.json'),
    'BREWFS_PERF_DOCKERFILE': str(ROOT / 'runner.Dockerfile'),
    'AX447_TOOLS_IMAGE': images['tools']['reference'],
    'AX447_REDIS_IMAGE': images['redis']['reference'],
    'AX447_RUSTFS_IMAGE': images['rustfs']['reference'],
    'AX447_AWSCLI_IMAGE': images['awscli']['reference'],
    'AX447_RUNNER_IMAGE': f'ax447-runner:{project}',
    'PERF_CONTAINER_REDIS_BREWFS_PERF': project + '-redis',
    'PERF_CONTAINER_RUSTFS_BREWFS_PERF_REDIS': project + '-rustfs',
    'PERF_CONTAINER_MINIO_BREWFS_PERF_REDIS': project + '-minio',
    'REDIS_HOST_PORT': '26379', 'RUSTFS_S3_HOST_PORT': '29000',
    'RUSTFS_CONSOLE_HOST_PORT': '29001',
    'BREWFS_REUSE_HOST_BINARY': '1', 'PERF_LOG_TO_CONSOLE': 'false',
    'PERF_FIO_RANDSEED': '20261031', 'PERF_FIO_RANDREPEAT': '1',
    'PERF_FIO_DROP_CACHES': 'false', 'PERF_FIO_REQUIRE_DROP_CACHES': 'false',
    'PERF_FIO_COLD_READ': 'false', 'PERF_FIO_COLD_READ_DROP_CACHES': 'false',
    'PERF_FIO_COLD_READ_CLEAR_CACHE': 'false',
    'BREWFS_READ_MEMORY_BYTES': '4294967296', 'BREWFS_WRITE_MEMORY_BYTES': '4294967296',
    'BREWFS_READ_SSD_BYTES': '8589934592', 'BREWFS_WRITE_SSD_BYTES': '4294967296',
    'BREWFS_MEMORY_BUDGET_BYTES': '12884901888',
    'BREWFS_COMPRESSION': 'none', 'BREWFS_VERIFY_CACHE_CHECKSUM': 'full',
    'PERF_FIO_PREFILL_DRAIN': 'true', 'PERF_FIO_PREFILL_REMOUNT': 'true',
    'PERF_FIO_POST_WRITE_DRAIN': 'true', 'PERF_FIO_POST_WRITE_DRAIN_TIMEOUT_SECS': '180',
    'PERF_FIO_PREFILL_DRAIN_TIMEOUT_SECS': '180',
})
if args.case.startswith('cached'):
    env.update({
        'BREWFS_FUSE_WRITEBACK': '1',
        'RUST_LOG': 'brewfs=info,asyncfuse::raw::logfs=debug' if args.case == 'cached-smoke' else 'error',
        'BREWFS_FUSE_OP_LOG': '1' if args.case == 'cached-smoke' else '0',
        'PERF_FIO_BIGWRITE_SIZE': '512k' if args.case == 'cached-smoke' else '16m',
        'PERF_FIO_BIGWRITE_BS': '4k', 'PERF_FIO_BIGWRITE_NUMJOBS': '1',
        'PERF_FIO_BIGWRITE_IOENGINE': 'psync', 'PERF_FIO_BIGWRITE_IODEPTH': '1',
        'PERF_FIO_BIGWRITE_DIRECT': '0',
        'PERF_FIO_BIGWRITE_ARGS': (
            '--buffer_pattern=0x5a --verify=pattern --verify_pattern=0x5a '
            '--do_verify=1 --verify_fatal=1 ' +
            ('--sync_file_range=wait_before,write,wait_after:1' if args.sync == 'range' else '--fsync=1')),
    })
    tools = 'fio-bigwrite'
else:
    env.update({
        'BREWFS_FUSE_WRITEBACK': '0', 'BREWFS_FUSE_OP_LOG': '0',
        'PERF_FIO_SIZE': '32m' if args.case == 'regression-smoke' else '512m',
        'PERF_FIO_RUNTIME': '3' if args.case == 'regression-smoke' else '20',
        'PERF_FIO_DIRECT_MATRIX': '0 1',
        'PERF_FIO_PREP_VERIFY_SHA256': 'true',
    })
    tools = 'fio-seqwrite fio-randwrite fio-randrw'

def git(*parts):
    return subprocess.check_output(['git', *parts], cwd=repo, env=env, text=True).strip()

binary = repo / 'target/docker/brewfs'
lock_path = Path('/home/dev/.ax-rbm-heavy.lock')
inherited_fd = os.environ.get('AX447_INHERITED_HEAVY_LOCK_FD')
lock_stream = os.fdopen(os.dup(int(inherited_fd)), 'w') if inherited_fd else lock_path.open('w')
with lock_stream as lock:
    actual,expected = os.fstat(lock.fileno()),lock_path.stat()
    assert (actual.st_dev,actual.st_ino) == (expected.st_dev,expected.st_ino)
    fcntl.flock(lock, fcntl.LOCK_EX | (fcntl.LOCK_NB if inherited_fd else 0))
    active = subprocess.run(['pgrep', '-ax', 'cargo|rustc|fio|smallfiles'], capture_output=True, text=True)
    assert active.returncode == 1, active.stdout
    assert git('rev-parse', 'HEAD') == spec['commit'] == manifest['commit']
    assert git('rev-parse', 'HEAD^{tree}') == spec['tree']
    assert not git('diff', 'HEAD', '--name-only')
    for image in images.values():
        actual_id = subprocess.check_output(['docker', 'image', 'inspect', image['reference'],
                                             '--format', '{{.Id}}'], text=True).strip()
        assert actual_id == image['id']
    with binary.open('rb') as handle:
        assert hashlib.file_digest(handle, 'sha256').hexdigest() == manifest['sha256']
    command = ['bash', str(ROOT / 'run-isolated-redis-perf.sh'), '--s3',
               '--writeback-throughput-profile', '--tools', tools]
    selected = {k: v for k, v in env.items() if k.startswith(
        ('AX447_', 'PERF_', 'BREWFS_', 'COMPOSE_', 'REDIS_', 'RUSTFS_'))}
    selected['RUST_LOG'] = env['RUST_LOG']
    receipt = {'arm': args.arm, 'case': args.case, 'trial': args.trial, 'sync': args.sync,
               'source': spec, 'binary': manifest, 'images': images, 'environment': selected,
               'command': command, 'started_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
               'harness_sha256': hashlib.sha256((ROOT / 'run-isolated-redis-perf.sh').read_bytes()).hexdigest(),
               'compose_sha256': hashlib.sha256((ROOT / 'compose.json').read_bytes()).hexdigest(),
               'container_harness_sha256': hashlib.sha256((ROOT / 'run-measured-perf-in-container.sh').read_bytes()).hexdigest()}
    (out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    with (out / 'rendered-compose.json').open('w') as handle:
        subprocess.run(['docker', 'compose', '-f', str(ROOT / 'compose.json'), 'config', '--format', 'json'],
                       env=env, check=True, stdout=handle)
    artifacts = repo / 'docker/compose-xfstests/artifacts'
    before = set(artifacts.glob('perf-run-*'))
    start = time.monotonic()
    with (out / 'console.log').open('w') as handle:
        status = subprocess.run(['timeout', '-k', '20', '1800', *command], env=env,
                                cwd=repo, stdout=handle, stderr=subprocess.STDOUT).returncode
    receipt.update(status=status, complete_wall_seconds=time.monotonic()-start,
                   finished_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                   artifact_directories=[str(p) for p in sorted(set(artifacts.glob('perf-run-*')) - before)])
    (out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    if status == 0:
        receipt['mounted_config_checks'] = []
        for artifact in receipt['artifact_directories']:
            config_path = Path(artifact) / 'backend.yml'
            config = yaml.safe_load(config_path.read_text())
            assert config['data']['s3']['rustfs_ec_block_size_hint'] == 'auto'
            for key,value in [('read_memory_bytes',4 << 30),('write_memory_bytes',4 << 30),
                              ('read_ssd_bytes',8 << 30),('write_ssd_bytes',4 << 30),
                              ('memory_budget_bytes',12 << 30)]:
                assert config['cache'][key] == value
            pin = json.loads((Path(artifact)/'rustfs-runtime-pin.json').read_text())
            assert pin['passed']
            receipt['mounted_config_checks'].append({'path':str(config_path),
                'sha256':hashlib.sha256(config_path.read_bytes()).hexdigest(),
                'client_hint':'auto','cache_budgets_match':True,'rustfs_runtime_pin_passed':True})
        (out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
    with (out / 'remaining-owned-containers.json').open('w') as handle:
        subprocess.run(['docker', 'ps', '-a', '--filter', f'label=com.docker.compose.project={project}',
                        '--format', '{{json .}}'], stdout=handle, check=True)
    print(json.dumps({'trial': project, 'exit_code': status, 'wall_seconds': receipt['complete_wall_seconds'],
                      'artifacts': receipt['artifact_directories']}))
    raise SystemExit(status)
