"""Keep every paired real-path result; do not infer production throughput."""
import argparse
import json
from pathlib import Path
import statistics

p = argparse.ArgumentParser()
p.add_argument('campaign', type=Path)
a = p.parse_args()
summary = json.loads((a.campaign/'summary.json').read_text())
assert summary['passed'], 'Campaign correctness/cleanup did not pass'
groups = {}
for entry in summary['waves']:
    if entry['stage'] != 'compare':
        continue
    assert entry['passed']
    key = ('fill', entry['keys'], entry['threads'])
    groups.setdefault(key, {}).setdefault(entry['arm'], {})[entry['repetition']] = entry
for entry in summary['row_cases']:
    if entry['stage'] != 'compare':
        continue
    data = json.loads(Path(entry['path']).read_text())
    assert data['passed'] and data['warm_stable']
    key = ('row', entry['keys'], entry['threads'])
    groups.setdefault(key, {}).setdefault(entry['arm'], {})[entry['repetition']] = data
assert len(groups) == 8, 'Expected four fill and four row shapes'
result = {'scope': summary['scope'], 'source': summary['source'],
          'input_sha256': summary['input_sha256'], 'cases': [],
          'native_packed_metrics': summary['packed_native_metrics'],
          'qualification': 'Correctness/cleanup passed; inspect every paired performance guard below.'}
for (kind, keys, threads), arms in sorted(groups.items()):
    assert set(arms) == {'baseline','candidate'}
    assert set(arms['baseline']) == set(arms['candidate']) == set(range(6))
    field = 'read_wall_ns' if kind == 'fill' else 'wall_ns'
    pairs = []
    for rep in range(6):
        old,new = arms['baseline'][rep],arms['candidate'][rep]
        assert old[field] > 0 and new[field] > 0
        pair = {'repetition':rep,'baseline_wall_ns':old[field],'candidate_wall_ns':new[field],
                'candidate_over_baseline':new[field]/old[field]}
        if kind == 'fill':
            pair.update(baseline_target_concurrency=old['proxy']['max_target_active'],
                        candidate_target_concurrency=new['proxy']['max_target_active'],
                        baseline_target_fetches=len(old['proxy']['events']),
                        candidate_target_fetches=len(new['proxy']['events']))
            assert len(old['proxy']['events']) == len(new['proxy']['events']) == keys
        else:
            assert old['canonical_input_sha256'] == new['canonical_input_sha256']
            assert old['workload_sha256'] == new['workload_sha256']
            pair.update(baseline_client_cpu_ns=old['client_process_cpu_ns'],
                        candidate_client_cpu_ns=new['client_process_cpu_ns'],
                        baseline_row_delta=old['delta'],candidate_row_delta=new['delta'],
                        candidate_byte_checks=new['byte_checks'])
        pairs.append(pair)
    ratios=[row['candidate_over_baseline'] for row in pairs]
    result['cases'].append({'kind':kind,'keys':keys,'threads':threads,'pairs':pairs,
        'baseline_median_wall_ns':statistics.median(row['baseline_wall_ns'] for row in pairs),
        'candidate_median_wall_ns':statistics.median(row['candidate_wall_ns'] for row in pairs),
        'paired_candidate_over_baseline_min':min(ratios),
        'paired_candidate_over_baseline_max':max(ratios),
        'every_pair_faster':all(ratio<1 for ratio in ratios),
        'pairs_above_five_percent_slower':[row['repetition'] for row in pairs if row['candidate_over_baseline']>1.05]})
(a.campaign/'paired-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'cases':len(result['cases']), 'guards_to_review':[
    {'kind':case['kind'],'keys':case['keys'],'threads':case['threads'],
     'slow_pairs':case['pairs_above_five_percent_slower']}
    for case in result['cases'] if case['pairs_above_five_percent_slower']]},indent=2))
