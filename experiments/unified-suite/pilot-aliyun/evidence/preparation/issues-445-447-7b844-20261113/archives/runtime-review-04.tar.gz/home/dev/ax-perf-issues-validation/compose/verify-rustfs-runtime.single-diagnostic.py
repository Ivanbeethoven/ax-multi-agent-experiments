"""Verify only owned RustFS identity, enabled configuration and resource limits."""
import argparse
import datetime
import json
from pathlib import Path
import subprocess

p=argparse.ArgumentParser()
p.add_argument('container')
p.add_argument('output',type=Path)
a=p.parse_args()
assert a.container.startswith('ax447-') and a.container.endswith('-rustfs')
root=Path('/home/dev/ax-perf-issues-validation/compose')
pin=json.loads((root/'rustfs-source-image-receipt.json').read_text())
container=json.loads(subprocess.check_output(['docker','inspect',a.container,'--format','{{json .}}'],text=True))
image=json.loads(subprocess.check_output(['docker','image','inspect',container['Image'],'--format','{{json .}}'],text=True))
environment=dict(value.split('=',1) for value in container['Config']['Env'] if '=' in value)
flags={key:environment.get(key) for key in pin['required_service_flags']}
result={'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'container':a.container,
        'actual_image_id':image['Id'],'actual_oci_revision':image['Config']['Labels']['org.opencontainers.image.revision'],
        'source_remote_commit':pin['remote_commit'],'flags':flags,
        'nano_cpus':container['HostConfig']['NanoCpus'],'memory_bytes':container['HostConfig']['Memory'],
        'scope':'Identity and enabled configuration only; not hint acceptance or physical layout benefit.'}
result['passed']=(result['actual_image_id']==pin['image_id'] and result['actual_oci_revision']==pin['remote_commit']
                  and flags==pin['required_service_flags']
                  and result['nano_cpus']==2_000_000_000 and result['memory_bytes']==8 << 30)
a.output.parent.mkdir(parents=True,exist_ok=True)
a.output.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
if not result['passed']: raise SystemExit('RustFS runtime pin/configuration mismatch')
