#!/bin/bash
set -euo pipefail
exec 9>/home/dev/.ax-rbm-heavy.lock
flock 9
if pgrep -x 'cargo|rustc|fio|smallfiles' >/dev/null; then echo 'Existing heavy process; leaving'; exit 75; fi
out=/home/dev/ax-perf-issues-validation/compose/images
printf '%s build tools image\n' "$(date -u +%FT%TZ)" >> "$out/progress.log"
DOCKER_BUILDKIT=0 timeout -k 10 900 docker build --force-rm --memory 4g --memory-swap 4g --cpu-quota 200000 --cpu-period 100000 --iidfile "$out/tools-image-id.txt" -t ax447-tools:20261112 /home/dev/ax-perf-issues-validation/compose/tools-context > "$out/build-tools.log" 2>&1
docker image inspect ax447-tools:20261112 --format '{{json .}}' > "$out/inspect-tools.json"
docker run --rm --name ax447-tools-fio-help --cpus 1 --memory 512m --entrypoint fio ax447-tools:20261112 --cmdhelp=sync_file_range > "$out/fio-sync-file-range-help.log" 2>&1
docker run --rm --name ax447-tools-package-list --cpus 1 --memory 512m --entrypoint dpkg-query ax447-tools:20261112 -W > "$out/tools-packages.txt" 2>&1
printf '%s tools image passed\n' "$(date -u +%FT%TZ)" >> "$out/progress.log"
