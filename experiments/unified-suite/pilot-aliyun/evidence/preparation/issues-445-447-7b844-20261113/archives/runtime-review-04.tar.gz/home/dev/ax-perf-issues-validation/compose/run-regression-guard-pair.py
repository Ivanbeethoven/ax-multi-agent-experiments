from pathlib import Path
import subprocess,json,fcntl,os,sys,hashlib,datetime,traceback
r=Path('/home/dev/ax-perf-issues-validation/compose');out=r/'matrices/regression-pair';out.mkdir(exist_ok=False)
record={'plan_revision':'regression-plan-revision-01.json','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'passed':False,'phases':[],'script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'case_script_sha256':hashlib.sha256((r/'run-compose-case.py').read_bytes()).hexdigest()}
try:
 with Path('/home/dev/.ax-rbm-heavy.lock').open('w') as lock:
  fcntl.flock(lock,fcntl.LOCK_EX);env=dict(os.environ,AX447_INHERITED_HEAVY_LOCK_FD=str(lock.fileno()))
  for arm in ['baseline','candidate']:
   identity=f'ax447-{arm}-regression-0'
   with (out/f'{identity}.log').open('w') as log:
    cp=subprocess.run([sys.executable,str(r/'run-compose-case.py'),arm,'regression','0','--sync','range'],env=env,pass_fds=(lock.fileno(),),stdout=log,stderr=subprocess.STDOUT)
   step={'arm':arm,'case':'regression','trial':0,'exit_code':cp.returncode,'receipt':str(r/'trials'/identity/'receipt.json')};record['phases'].append(step);(out/'receipt.json').write_text(json.dumps(record,indent=2))
   assert cp.returncode==0,identity+' failed'
   receipt=json.loads(Path(step['receipt']).read_text());assert len(receipt['artifact_directories'])==1;a=Path(receipt['artifact_directories'][0])
   assert not (r/'trials'/identity/'remaining-owned-containers.json').read_text().strip()
   subprocess.run([sys.executable,str(r/'summarize-compose-phases.py'),str(a)],check=True,stdout=(out/f'{arm}-phases.log').open('w'))
   subprocess.run([sys.executable,str(r/'summarize-client-cpu.py'),str(a),'--output',str(a/'client-cpu-summary.json')],check=True)
   assert len(json.loads((a/'precise-phase-summary.json').read_text())['tools'])==6
 record['passed']=True
except Exception:
 record['error']=traceback.format_exc();raise
finally:
 record['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
