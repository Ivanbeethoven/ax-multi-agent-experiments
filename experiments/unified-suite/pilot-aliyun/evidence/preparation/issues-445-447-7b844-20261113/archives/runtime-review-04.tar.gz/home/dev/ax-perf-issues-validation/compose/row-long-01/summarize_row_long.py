#!/usr/bin/env python3
"""Validate every long row arm and retain all six AB/BA pairs for review."""
import argparse
import json
from pathlib import Path
import statistics

OPERATIONS = 65536
ROW_HELPER_SHA256 = 'f27bda51f89d9d3cd2240143a3292c80d3f7b5a6c13970bb375243a717501695'
PREFIX = 'brewfs_workspace_row_cache_'
HITS, MISSES = PREFIX+'hits_total', PREFIX+'misses_total'


def validate_result(data, arm, repetition, threads):
    assert arm in ('baseline','candidate') and repetition in range(6) and threads in (1,8)
    assert data['passed'] and data['warm_stable'], 'arm correctness/warm gate failed'
    assert data['label'] == arm and data['repetition'] == repetition
    assert data['harness_sha256'] == ROW_HELPER_SHA256, 'row helper identity changed'
    expected = {'kind':'hot-fgetxattr','keys':128,'threads':threads,'ops_per_thread':OPERATIONS,
                'value_bytes':8,'key_order':'(operation_index + thread_index) % keys',
                'every_value_verified':True}
    assert data['workload'] == expected, 'fixed workload changed'
    calls = OPERATIONS * threads
    assert data['successful_calls'] == calls
    assert len(data['threads']) == threads
    assert sorted(row['thread'] for row in data['threads']) == list(range(threads))
    assert all(row['successful_calls'] == OPERATIONS and row['wall_ns'] > 0 for row in data['threads'])
    assert data['warm_delta'][MISSES] == 0 and data['warm_delta'][HITS] >= 128
    assert data['delta'][MISSES] == 0 and data['delta'][HITS] >= calls
    assert data['wall_ns'] > 0 and data['client_process_cpu_ns'] > 0
    checks = data['byte_checks']
    assert checks['required_fields_present'] and checks['observed_within_capacity'] is not False
    if arm == 'candidate':
        assert checks['supported'] and checks['observed_within_capacity'] is True
    return data


def summarize(campaign):
    summary = json.loads((campaign/'summary.json').read_text())
    assert summary['passed'], 'campaign correctness/cleanup did not pass'
    assert summary['fixed_plan'] == {'keys':128,'threads':[1,8],'operations_per_thread':OPERATIONS,
        'repetitions':6,'value_bytes':8,'row_ttl_ms':600000,'row_budget_bytes':64 << 20,
        'order':'AB for even repetitions, BA for odd'}
    assert len(summary['row_cases']) == 24
    expected_order = [(arm,rep,threads) for rep in range(6) for threads in (1,8)
                      for arm in (('baseline','candidate') if rep%2==0 else ('candidate','baseline'))]
    assert [(e['arm'],e['repetition'],e['threads']) for e in summary['row_cases']] == expected_order, 'paired execution order changed'
    groups = {1:{}, 8:{}}
    canonical = None
    for entry in summary['row_cases']:
        assert entry['stage'] == 'compare' and entry['keys'] == 128
        assert entry['operations_per_thread'] == OPERATIONS
        threads, arm, rep = entry['threads'], entry['arm'], entry['repetition']
        data = validate_result(json.loads(Path(entry['path']).read_text()), arm, rep, threads)
        if canonical is None: canonical = data['canonical_input_sha256']
        assert data['canonical_input_sha256'] == canonical, 'input identity changed across arms'
        assert (arm,rep) not in groups[threads], 'duplicate arm'
        groups[threads][arm,rep] = data
    result = {'scope':summary['scope'],'source':summary['source'], 'binary_pins':summary['binary_pins'],
        'input_sha256':summary['input_sha256'],'row_canonical_input_sha256':canonical,
        'harness_sha256':summary['harness_sha256'],'fixed_plan':summary['fixed_plan'],
        'supersedes_short_results':False,'cases':[],
        'cpu_note':'Helper client_process_cpu_ns is Python caller CPU, not BrewFS CPU.',
        'qualification':'All correctness/cleanup gates passed; preserve every pair and assess performance separately.'}
    for threads, rows in groups.items():
        assert set(rows) == {(arm,rep) for arm in ('baseline','candidate') for rep in range(6)}
        pairs=[]; workload_hash=None
        for rep in range(6):
            old,new = rows['baseline',rep],rows['candidate',rep]
            assert old['workload_sha256'] == new['workload_sha256']
            if workload_hash is None: workload_hash=old['workload_sha256']
            assert old['workload_sha256'] == workload_hash
            pairs.append({'repetition':rep,'order':['baseline','candidate'] if rep%2==0 else ['candidate','baseline'],
                'baseline_wall_ns':old['wall_ns'],'candidate_wall_ns':new['wall_ns'],
                'candidate_over_baseline':new['wall_ns']/old['wall_ns'],
                'baseline_client_cpu_ns':old['client_process_cpu_ns'],'candidate_client_cpu_ns':new['client_process_cpu_ns'],
                'successful_calls_per_arm':OPERATIONS*threads,
                'baseline_row_delta':old['delta'],'candidate_row_delta':new['delta'],
                'candidate_byte_checks':new['byte_checks']})
        ratios=[p['candidate_over_baseline'] for p in pairs]
        result['cases'].append({'keys':128,'threads':threads,'workload_sha256':workload_hash,'pairs':pairs,
            'baseline_median_wall_ns':statistics.median(p['baseline_wall_ns'] for p in pairs),
            'candidate_median_wall_ns':statistics.median(p['candidate_wall_ns'] for p in pairs),
            'paired_candidate_over_baseline_min':min(ratios),'paired_candidate_over_baseline_max':max(ratios),
            'paired_candidate_over_baseline_median':statistics.median(ratios),
            'every_pair_faster':all(r < 1 for r in ratios),
            'pairs_above_five_percent_slower':[p['repetition'] for p in pairs if p['candidate_over_baseline']>1.05]})
    return result


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('campaign',type=Path)
    args=parser.parse_args()
    result=summarize(args.campaign)
    (args.campaign/'paired-summary.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'cases':len(result['cases']),'all_pairs_faster':all(c['every_pair_faster'] for c in result['cases']),
        'slow_pairs':[{k:c[k] for k in ('keys','threads','pairs_above_five_percent_slower')} for c in result['cases']]},indent=2))


if __name__ == '__main__': main()
