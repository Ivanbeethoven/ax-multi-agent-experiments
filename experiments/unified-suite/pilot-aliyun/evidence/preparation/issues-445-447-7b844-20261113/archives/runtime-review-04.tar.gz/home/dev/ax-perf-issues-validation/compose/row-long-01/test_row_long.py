import ast
import copy
import hashlib
import json
from pathlib import Path
import py_compile
import tempfile
import unittest
import summarize_row_long as guard

BASE=Path(__file__).parent


def result(arm='candidate', rep=0, threads=1):
    return {'passed':True,'warm_stable':True,'label':arm,'repetition':rep,
      'harness_sha256':guard.ROW_HELPER_SHA256,
      'workload':{'kind':'hot-fgetxattr','keys':128,'threads':threads,'ops_per_thread':65536,
                  'value_bytes':8,'key_order':'(operation_index + thread_index) % keys','every_value_verified':True},
      'successful_calls':65536*threads,
      'threads':[{'thread':i,'successful_calls':65536,'wall_ns':1000} for i in range(threads)],
      'warm_delta':{guard.HITS:128,guard.MISSES:0},'delta':{guard.HITS:65536*threads,guard.MISSES:0},
      'wall_ns':1000000 if arm=='baseline' else 900000,'client_process_cpu_ns':500,
      'byte_checks':{'supported':arm=='candidate','required_fields_present':True,
                     'observed_within_capacity':True if arm=='candidate' else None},
      'canonical_input_sha256':'same-input','workload_sha256':'same-workload-'+str(threads)}


class RowLongTests(unittest.TestCase):
    def test_valid_shapes_and_baseline_unsupported_byte_metrics(self):
        for arm in ('baseline','candidate'):
            for t in (1,8): guard.validate_result(result(arm,0,t),arm,0,t)
    def test_reject_wrong_calls(self):
        r=result();r['successful_calls']-=1
        with self.assertRaises(AssertionError):guard.validate_result(r,'candidate',0,1)
    def test_reject_miss(self):
        r=result();r['delta'][guard.MISSES]=1
        with self.assertRaises(AssertionError):guard.validate_result(r,'candidate',0,1)
    def test_reject_insufficient_hits(self):
        r=result();r['delta'][guard.HITS]=65535
        with self.assertRaises(AssertionError):guard.validate_result(r,'candidate',0,1)
    def test_reject_workload_changes(self):
        for key,value in [('ops_per_thread',1024),('keys',1),('value_bytes',16),('every_value_verified',False)]:
            r=result();r['workload'][key]=value
            with self.assertRaises(AssertionError):guard.validate_result(r,'candidate',0,1)
    def test_reject_candidate_budget_missing_or_exceeded(self):
        for key,value in [('supported',False),('required_fields_present',False),('observed_within_capacity',False)]:
            r=result();r['byte_checks'][key]=value
            with self.assertRaises(AssertionError):guard.validate_result(r,'candidate',0,1)
    def test_reject_helper_changed(self):
        r=result();r['harness_sha256']='changed'
        with self.assertRaises(AssertionError):guard.validate_result(r,'candidate',0,1)
    def test_original_mount_lifecycle_preserved_exactly(self):
        sources=[(BASE/name).read_text() for name in ('run-workspace-guards.py.before','run-row-long-guards.py')]
        funcs=[]
        for source in sources:
            node=next(n for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name=='mount_arm')
            funcs.append(ast.get_source_segment(source,node))
        self.assertEqual(*funcs)
        self.assertIn("BREWFS_WORKSPACE_ROW_CACHE_TTL_MS='600000'",funcs[1])
        self.assertIn('row_budget=64 << 20',funcs[1])
    def test_exact_24_arm_order_without_running_executor(self):
        tree=ast.parse((BASE/'run-row-long-guards.py').read_text())
        loop=next(n for n in ast.walk(tree) if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='repetition')
        calls=[]
        env={'REPETITIONS':6,'OPERATIONS_PER_THREAD':65536,'row_case':lambda *a:calls.append(a),'write':lambda *a:None,'out':Path('/unused'),'summary':{}}
        exec(compile(ast.fix_missing_locations(ast.Module(body=[loop],type_ignores=[])),'only-loop','exec'),env)
        expected=[]
        for rep in range(6):
            for t in (1,8):
                for arm in (('baseline','candidate') if rep%2==0 else ('candidate','baseline')):
                    expected.append((arm,'compare',rep,128,t,65536))
        self.assertEqual(calls,expected)
        self.assertEqual(len(calls),24)
        self.assertFalse(any(isinstance(n,ast.FunctionDef) and n.name in ('fill_case','memory_case') for n in ast.walk(tree)))
    def test_frozen_helper_unchanged(self):
        self.assertEqual(hashlib.sha256((BASE/'workspace_row_guard.py.frozen').read_bytes()).hexdigest(),guard.ROW_HELPER_SHA256)
    def test_compile_only_no_environment_io(self):
        for name in ('run-row-long-guards.py','summarize_row_long.py'):
            py_compile.compile(str(BASE/name),doraise=True)
    def test_summary_preserves_every_pair_and_catches_duplicate(self):
        with tempfile.TemporaryDirectory() as tmp:
            base=Path(tmp); entries=[]
            for rep in range(6):
                for t in (1,8):
                    for arm in (('baseline','candidate') if rep%2==0 else ('candidate','baseline')):
                        path=base/f'{arm}-{rep}-{t}.json';path.write_text(json.dumps(result(arm,rep,t)))
                        entries.append(dict(arm=arm,repetition=rep,threads=t,stage='compare',keys=128,operations_per_thread=65536,path=str(path)))
            s={'passed':True,'fixed_plan':{'keys':128,'threads':[1,8],'operations_per_thread':65536,'repetitions':6,'value_bytes':8,'row_ttl_ms':600000,'row_budget_bytes':64<<20,'order':'AB for even repetitions, BA for odd'},'row_cases':entries,'scope':'synthetic test','source':{},'binary_pins':{},'input_sha256':'fixture','harness_sha256':{}}
            (base/'summary.json').write_text(json.dumps(s))
            out=guard.summarize(base)
            self.assertEqual(len(out['cases']),2)
            self.assertTrue(all(len(c['pairs'])==6 and c['every_pair_faster'] for c in out['cases']))
            self.assertFalse(out['supersedes_short_results'])
            s['row_cases'][-1]=s['row_cases'][0]
            (base/'summary.json').write_text(json.dumps(s))
            with self.assertRaises(AssertionError):guard.summarize(base)

if __name__=='__main__':unittest.main(verbosity=2)
