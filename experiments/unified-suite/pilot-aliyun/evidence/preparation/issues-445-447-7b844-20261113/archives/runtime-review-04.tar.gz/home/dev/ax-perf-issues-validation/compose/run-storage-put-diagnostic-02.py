from pathlib import Path
import subprocess,json,fcntl,time,hashlib,datetime,os
import boto3
from botocore.config import Config
r=Path('/home/dev/ax-perf-issues-validation/compose');out=r/'storage-put-diagnostic-02';out.mkdir(exist_ok=False)
image=json.loads((r/'image-manifest.json').read_text())['rustfs']['reference'];rows=[];flags=['RUSTFS_EC_BLOCK_SIZE_HINT_ENABLE','RUSTFS_EC_BLOCK_SIZE_HINT_FLEET_CONFIRMED','RUSTFS_EC_READ_QUANTUM_ENABLE','RUSTFS_EC_READ_QUANTUM_FLEET_CONFIRMED']
with Path('/home/dev/.ax-rbm-heavy.lock').open('w') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX);assert not subprocess.check_output(['docker','ps','-q'],text=True).strip()
 for topology in ['single','ec4']:
  d=out/topology;d.mkdir();data=d/'data';data.mkdir();os.chown(data,10001,10001);name='ax447-storage-'+topology
  paths=['/data'] if topology=='single' else ['/data/d0','/data/d1','/data/d2','/data/d3']
  if topology=='ec4':
   for x in range(4):
    (data/f'd{x}').mkdir();os.chown(data/f'd{x}',10001,10001)
  command=['docker','run','-d','--name',name,'--label','ax447.owner=storage-diagnostic','--cpus=2','--memory=8g','-p','127.0.0.1:29000:9000','-v',str(data)+':/data']
  for k,v in [('RUSTFS_ACCESS_KEY','rustfsadmin'),('RUSTFS_SECRET_KEY','rustfsadmin'),*[(f,'true') for f in flags]]:command+=['-e',k+'='+v]
  command += [image,'--address',':9000','--console-enable','--access-key','rustfsadmin','--secret-key','rustfsadmin',*paths]
  (d/'argv.json').write_text(json.dumps(command,indent=2));subprocess.run(command,check=True,stdout=(d/'container-id').open('w'))
  try:
   import urllib.request
   for retry in range(60):
    try:
     with urllib.request.urlopen('http://127.0.0.1:29000/health',timeout=1) as response:assert response.status==200
     break
    except Exception:time.sleep(.5)
   else:raise RuntimeError('service not healthy')
   inspect=json.loads(subprocess.check_output(['docker','inspect',name],text=True))[0]
   (d/'runtime.json').write_text(json.dumps({'image':inspect['Image'],'path':inspect['Path'],'args':inspect['Args'],'cpus':inspect['HostConfig']['NanoCpus'],'memory':inspect['HostConfig']['Memory'],'mounts':inspect['Mounts']},indent=2))
   client=boto3.client('s3',endpoint_url='http://127.0.0.1:29000',region_name='us-east-1',aws_access_key_id='rustfsadmin',aws_secret_access_key='rustfsadmin',config=Config(signature_version='s3v4',connect_timeout=3,read_timeout=10,retries={'total_max_attempts':1},s3={'addressing_style':'path','payload_signing_enabled':False}))
   client.create_bucket(Bucket='ax447-object-diagnostic')
   observed=[]
   def capture(request,**kw):
    allowed={'content-length','content-md5','transfer-encoding','content-encoding','x-amz-decoded-content-length','x-amz-meta-rustfs-ec-block-size-hint','x-amz-sdk-checksum-algorithm','x-amz-content-sha256'}
    observed.append({k:(v.decode() if isinstance(v,bytes) else str(v)) for k,v in request.headers.items() if k.lower() in allowed})
   client.meta.events.register('before-send.s3.PutObject',capture)
   for size in [32,1048576,4194308]:
    for hint in [None,1048576]:
     data_bytes=(b'AX447-object-diagnostic:'+bytes(range(32)))*((size//55)+1);data_bytes=(data_bytes+b'Z'*size)[:size]
     key=f'n{size}-hint{hint}';row={'topology':topology,'bytes':size,'hint':hint,'payload_sha256':hashlib.sha256(data_bytes).hexdigest()};before=len(observed)
     try:
      result=client.put_object(Bucket='ax447-object-diagnostic',Key=key,Body=data_bytes,Metadata={} if hint is None else {'rustfs-ec-block-size-hint':str(hint)})
      row['put_status']=result['ResponseMetadata']['HTTPStatusCode'];row['response_headers']={k:v for k,v in result['ResponseMetadata']['HTTPHeaders'].items() if k.startswith('x-rustfs-')}
      get=client.get_object(Bucket='ax447-object-diagnostic',Key=key);body=get['Body'].read();get['Body'].close();row['readback_passed']=body==data_bytes
     except Exception as e:
      row['error_type']=type(e).__name__
      if hasattr(e,'response'):row['error']=e.response.get('Error');row['http_status']=e.response.get('ResponseMetadata',{}).get('HTTPStatusCode')
      else:row['error']=str(e)
     row['request_headers']=observed[before:];rows.append(row);(out/'results.json').write_text(json.dumps(rows,indent=2))
  finally:
   with (d/'server.log').open('w') as f:subprocess.run(['docker','logs',name],stdout=f,stderr=subprocess.STDOUT,check=False)
   subprocess.run(['docker','rm','-f',name],check=True,stdout=(d/'removed.txt').open('w'))
(out/'complete.json').write_text(json.dumps({'finished_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'separate storage protocol/topology diagnostic; source/image/fourflags retained, not qualification data','cases':len(rows)},indent=2))
print(json.dumps(rows,indent=2))
