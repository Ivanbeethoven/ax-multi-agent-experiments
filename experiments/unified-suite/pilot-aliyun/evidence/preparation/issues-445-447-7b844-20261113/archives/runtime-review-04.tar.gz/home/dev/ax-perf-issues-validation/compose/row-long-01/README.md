# Fixed longer real row-path comparison

Prepared only in a new rbm directory; no cloud access, service changes, benchmark execution or Rust edits. The starting executor is the exact runtime-review-02 archived `run-workspace-guards.py`, SHA256 f5a49e7e064b3b1b78b31c105f38c56049631bf08c5525257c3c105cdc709999. The original short workspace-ec4v2 results remain unchanged and are not superseded or deleted.

Copy only `run-row-long-guards.py` and `summarize_row_long.py` into the existing owned compose directory. They are new names and do not overwrite the previous executor. `row-long-executor.diff` is the readable old-to-fork comparison; `row-long-new-files.patch` adds the new executor, summarizer and local tests without modifying the old file. Local tests additionally need the archived `.before` and `.frozen` copies from this directory.

The existing `workspace_row_guard.py` stays byte-for-byte frozen at f27bda51f89d9d3cd2240143a3292c80d3f7b5a6c13970bb375243a717501695; the executor rejects a changed helper. It retains normal Shared workspace initialization/mount/lease and teardown exactly, the baseline-only Packed producer once per campaign, identical manifest and input hashes for both arms, Redis/RustFS lifecycle and EC4 runtime verifier, binary/source/image identity checks, fixed client CPU3/16GiB, all existing Packed budgets, row TTL600000ms, row budget64MiB, and fixed8-byte values. Baseline ignores the candidate-specific row byte flag, as already documented by the original executor; the same small hot set fits both policies.

Only 128-key hot fgetxattr with 1 and8 threads is run. Every thread performs exactly65536 operations. Six paired repetitions alternate baseline/candidate and candidate/baseline; there are24 fresh-workspace arms, with each arm's working set warm-validated before timing. No fill, memory, single-key, or separate short performance waves are rerun. Every get validates its expected bytes using the unchanged helper. The executor independently requires precise total/per-thread success counts, zero measured misses, hits at least the call count, warm gate, matching helper/workload/input identity, and candidate native byte counters present and within capacity. This is not a change to Rust or a bypass of failed short results.

Execution, by the resource owner only, after ensuring no concurrent workload:

```
# Use a unique campaign name; output is .../compose/workspace/ax447-rowlong-<name>.
# Run under the existing isolated systemd CPUQuota=300%, MemoryMax=16G envelope,
# with a bounded RuntimeMaxSec (1800 seconds is ample for this fixed plan).
python3 /home/dev/ax-perf-issues-validation/compose/run-row-long-guards.py ec4long01
python3 /home/dev/ax-perf-issues-validation/compose/summarize_row_long.py /home/dev/ax-perf-issues-validation/compose/workspace/ax447-rowlong-ec4long01
```

The executor acquires its existing host heavy lock and checks for cargo/rustc/fio/smallfiles; it does not bypass scheduling. Each helper invocation remains bounded at180seconds. Per-arm progress is written only after the arm passes. All cleanup gates remain in place. The summarizer rejects incorrect arm/order/count/input/workload results and preserves every paired wall time, ratio, raw delta, budget check and Python caller CPU time. It reports every pair above5% slower and every-pair-faster independently; correctness pass does not automatically approve performance. Caller CPU is not BrewFS process CPU.

Validation:12 stdlib tests pass in the final local run; Python compilation and git apply --check pass. Tests inspect the actual AST loop to prove all24 calls/order/operation counts without executing the full script, compare the complete mount_arm function byte-for-byte against the archived source, verify frozen helper identity, reject counter/budget/workload failures, and summarize synthetic six-pair results without touching services. No actual long performance measurements are claimed here.
