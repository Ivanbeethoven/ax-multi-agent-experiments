from pathlib import Path
import boto3,hashlib,json
from botocore.config import Config
p=Path('/home/dev/ax-perf-issues-validation/compose/service-smoke-04')
c=boto3.client('s3',endpoint_url='http://127.0.0.1:29000',region_name='us-east-1',aws_access_key_id='rustfsadmin',aws_secret_access_key='rustfsadmin',config=Config(signature_version='s3v4',retries={'total_max_attempts':1},s3={'addressing_style':'path','payload_signing_enabled':False}))
b=b'A'*(4<<20)+b'CRC4';r=c.put_object(Bucket='brewfs-data',Key='large-smoke.bin',Body=b,Metadata={'rustfs-ec-block-size-hint':'1048576'});o=c.get_object(Bucket='brewfs-data',Key='large-smoke.bin');v=o['Body'].read();o['Body'].close();assert v==b
(p/'large-object-readback.json').write_text(json.dumps({'bytes':len(b),'expected_sha256':hashlib.sha256(b).hexdigest(),'actual_sha256':hashlib.sha256(v).hexdigest(),'put_http':r['ResponseMetadata']['HTTPStatusCode'],'hint':'1048576','response_headers':{k:v for k,v in r['ResponseMetadata']['HTTPHeaders'].items() if k.startswith('x-rustfs-')},'passed':True},indent=2)+'\n')
