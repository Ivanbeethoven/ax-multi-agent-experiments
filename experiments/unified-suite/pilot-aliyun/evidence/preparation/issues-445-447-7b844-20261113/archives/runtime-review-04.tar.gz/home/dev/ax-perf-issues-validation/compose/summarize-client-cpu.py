"""Summarize raw BrewFS process CPU snapshots, with process identity checks."""
import argparse
import json
from pathlib import Path


def parse_stat(raw):
    end = raw.rfind(")")
    if end < 0:
        raise ValueError("Missing process comm field")
    pid = int(raw.split(" ", 1)[0])
    fields = raw[end + 2:].split()
    if len(fields) < 20:
        raise ValueError("Truncated /proc/PID/stat row")
    user, system, starttime = (int(fields[i]) for i in (11, 12, 19))
    if min(pid, user, system, starttime) < 0:
        raise ValueError("Negative process field")
    return {"pid": pid, "starttime_ticks": starttime,
            "user_ticks": user, "system_ticks": system}


def summarize(artifact):
    hz = int((artifact / "client-cpu-clock-ticks.txt").read_text().strip())
    if not 0 < hz <= 1_000_000:
        raise ValueError("Invalid USER_HZ")
    observations = {}
    for line in (artifact / "client-cpu-raw.tsv").read_text().splitlines():
        tool, phase, timestamp, raw = line.split("\t", 3)
        key = (tool, phase)
        if key in observations:
            raise ValueError(f"Duplicate CPU phase: {key}")
        observations[key] = {"observed_ns": int(timestamp), **parse_stat(raw)}
    results = []
    for (tool, phase), begin in observations.items():
        if phase != "tool_start":
            continue
        returned = observations[(tool, "tool_return")]
        drained = observations[(tool, "post-write_extended_drained")]
        rows = (begin, returned, drained)
        if len({(x["pid"], x["starttime_ticks"]) for x in rows}) != 1:
            raise ValueError(f"BrewFS process changed during {tool}")
        for previous, current in zip(rows, rows[1:]):
            if current["observed_ns"] <= previous["observed_ns"]:
                raise ValueError(f"Nonmonotonic observation time: {tool}")
            for field in ("user_ticks", "system_ticks"):
                if current[field] < previous[field]:
                    raise ValueError(f"CPU counter decreased: {tool}/{field}")
        def delta(a, b):
            user = (b["user_ticks"] - a["user_ticks"]) / hz
            system = (b["system_ticks"] - a["system_ticks"]) / hz
            return {"user_s": user, "system_s": system,
                    "total_s": user + system}
        results.append({"tool": tool, "pid": begin["pid"],
                        "starttime_ticks": begin["starttime_ticks"],
                        "tool_cpu": delta(begin, returned),
                        "post_tool_drain_cpu": delta(returned, drained),
                        "tool_and_drain_cpu": delta(begin, drained),
                        "observations": list(rows)})
    if not results:
        raise ValueError("No measured CPU interval")
    return {"scope": "BrewFS process user/system CPU, all threads; excludes FIO and RustFS",
            "sampling": "before tool_start, after tool_return, after strict drain; CPU ticks are not nanosecond wall times",
            "user_hz": hz, "tools": results}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("artifact", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    result = summarize(args.artifact)
    text = json.dumps(result, indent=2) + "\n"
    if args.output:
        args.output.write_text(text)
    else:
        print(text, end="")


if __name__ == "__main__":
    main()
