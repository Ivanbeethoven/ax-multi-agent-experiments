ARG AX447_TOOLS_IMAGE
FROM ${AX447_TOOLS_IMAGE}
COPY target/docker/brewfs /usr/local/bin/brewfs
