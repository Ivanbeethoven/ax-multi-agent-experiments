"""Hold the common lock across a complete paired ordinary-volume campaign."""
import argparse
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import traceback

ROOT=Path('/home/dev/ax-perf-issues-validation/compose')
p=argparse.ArgumentParser()
p.add_argument('case',choices=['cached','regression'])
p.add_argument('campaign')
p.add_argument('--sync',choices=['range','fsync'],default='range')
p.add_argument('--first-trial',type=int,default=0)
p.add_argument('--smoke-trial',type=int,default=1)
a=p.parse_args()
assert a.campaign.isalnum() and a.campaign.islower()
out=ROOT/'matrices'/f'{a.case}-{a.campaign}'
out.mkdir(parents=True,exist_ok=False)
receipt={'case':a.case,'sync':a.sync,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'phases':[],'passed':False,'harness_sha256':hashlib.sha256((ROOT/'run-compose-case.py').read_bytes()).hexdigest(),
         'matrix_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
         'cpu_parser_sha256':hashlib.sha256((ROOT/'summarize-client-cpu.py').read_bytes()).hexdigest()}
with Path('/home/dev/.ax-rbm-heavy.lock').open('w') as lock:
    fcntl.flock(lock,fcntl.LOCK_EX)
    env=dict(os.environ,AX447_INHERITED_HEAVY_LOCK_FD=str(lock.fileno()))
    def run(arm,case,trial,phase,rep):
        identity=f'ax447-{arm}-{case}-{trial}'
        command=[sys.executable,str(ROOT/'run-compose-case.py'),arm,case,str(trial),'--sync',a.sync]
        with (out/(identity+'.log')).open('w') as stream:
            result=subprocess.run(command,env=env,pass_fds=(lock.fileno(),),stdout=stream,stderr=subprocess.STDOUT)
        step={'arm':arm,'phase':phase,'repetition':rep,'trial':trial,'exit_code':result.returncode,
              'receipt':str(ROOT/'trials'/identity/'receipt.json')}
        receipt['phases'].append(step)
        (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
        assert result.returncode==0, f'{identity} failed; preserve logs before changing anything'
        case_receipt=json.loads(Path(step['receipt']).read_text())
        assert len(case_receipt['artifact_directories'])==1
        artifact=Path(case_receipt['artifact_directories'][0])
        remaining=ROOT/'trials'/identity/'remaining-owned-containers.json'
        assert remaining.read_text().strip()=='', 'Owned containers remained after runner cleanup'
        if case=='cached-smoke':
            subprocess.run([sys.executable,str(ROOT/'check-cached-write-smoke.py'),
                            str(artifact/'brewfs_fuse_ops.log'),'--bytes',str(512 << 10),
                            '--output',str(artifact/'cached-write-touch-proof.json')],check=True,
                           stdout=(out/(identity+'-touch.log')).open('w'))
        subprocess.run([sys.executable,str(ROOT/'summarize-compose-phases.py'),str(artifact)],check=True,
                       stdout=(out/(identity+'-phases.log')).open('w'))
        subprocess.run([sys.executable,str(ROOT/'summarize-client-cpu.py'),str(artifact),
                        '--output',str(artifact/'client-cpu-summary.json')],check=True,
                       stdout=(out/(identity+'-cpu.log')).open('w'))
    try:
        for arm in ('baseline','candidate'):
            run(arm,a.case+'-smoke',a.smoke_trial,'smoke',0)
        for repetition in range(3):
            order=('baseline','candidate') if repetition%2==0 else ('candidate','baseline')
            for arm in order:
                run(arm,a.case,a.first_trial+repetition,'compare',repetition)
        receipt['passed']=True
    except Exception:
        receipt['error']=traceback.format_exc()
        raise
    finally:
        receipt['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
