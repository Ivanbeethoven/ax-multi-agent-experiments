#!/bin/bash
set -euo pipefail
exec 9>/home/dev/.ax-rbm-heavy.lock
flock 9
if pgrep -x 'cargo|rustc|fio|smallfiles' >/dev/null; then echo 'Existing heavy process; leaving'; exit 75; fi
out=/home/dev/ax-perf-issues-validation/compose/images
mkdir -p "$out"
for ref in redis:7.2-alpine amazon/aws-cli:2.31.24 debian:trixie-slim; do
    name=${ref//[:\/]/_}
    printf '%s pull %s\n' "$(date -u +%FT%TZ)" "$ref" >> "$out/progress.log"
    timeout -k 10 300 docker pull "$ref" > "$out/pull-$name.log" 2>&1
    docker image inspect "$ref" --format '{{json .}}' > "$out/inspect-$name.json"
    printf '%s pulled %s\n' "$(date -u +%FT%TZ)" "$ref" >> "$out/progress.log"
done
printf '%s image pulls passed\n' "$(date -u +%FT%TZ)" >> "$out/progress.log"
