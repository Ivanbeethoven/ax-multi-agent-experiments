# Frozen issue qualification runner

The three source commits and completed CI are in ../final-source-receipt.json.
All prepared tools/service image identities are in image-manifest.json. The tool
image uses a local named reference because BuildKit treats bare sha256:ID as a
repository name; the runner asserts the exact image ID before every trial.
Redis/RustFS/aws-cli use RepoDigest references. No image is pulled during timing.

Only this task's projects, containers, volumes and high ports may be used.
A busy port fails rather than stopping its owner. No host drop_caches or global
Docker cleanup is allowed. The service smoke is non-performance setup and its
first image-reference failure remains in service-smoke/.

Wait for the two cloud release receipts before creating binary-manifest.json:
{ "baseline": {"commit": "ca07159...", "sha256": "..."},
  "candidate": {"commit": "7b844504...", "sha256": "..."} }
Install each verified unstripped binary at its own worktree target/docker/brewfs.
Both build specs require clean source identity; hashes must come from the actual
binary transfer, not a rebuilt substitute. Use the same standard release profile,
Rust 1.99.1 and no-default features fuse-io-uring-runtime,workspace-overlay,
observability,rustfs-ec-block-size-hint. The executor acquires the shared heavy
lock and refuses other cargo/rustc/fio/smallfiles before starting each case.

First execute service-smoke.sh with a systemd timeout/resource cap. Then:

    python3 run-compose-case.py baseline cached-smoke 0
    python3 run-compose-case.py candidate cached-smoke 0

Each case creates a fresh owned project. Inspect receipt.json's artifact path;
run check-cached-write-smoke.py on brewfs_fuse_ops.log with --bytes 524288 and an
explicit --output path. It must find exactly 128 disjoint 4096B cached requests on
one inode, all unique IDs nonzero. Fio verifies every byte with pattern 0x5a.
If sync_file_range does not generate this shape, preserve the failure and rerun
both arms with --sync fsync; never compare different synchronization modes.

After both smoke proofs, run cached trials 0/1/2 in baseline,candidate;
candidate,baseline; baseline,candidate order. These use 16MiB, 4096B, one psync job,
kernel writeback enabled, final fsync and strict drain. Diagnostic op logging is
disabled during timing. Byte budgets, image IDs and all external harness files
must remain identical across arms.

Run regression-smoke on both arms, then the same six-case alternating schedule
for regression. The three profiles seqwrite/randwrite/randrw each run direct 0/1,
512MiB/job, 20 seconds and a fixed seed. Kernel writeback is explicitly disabled for
this regression guard; it is not an optimization-path speedup measurement.

Analyze artifacts using the unchanged canonical tools/perf/compare_artifacts.py
from the clean baseline. Preserve every raw tool,latency,wall,active+drain,PUT/read
amplification,dirty-tail and teardown result. Require all fio jobs error 0, all
profile summaries pass, no *.invalid markers, and zero strict-drain pending/dirty
fields. Do not select only active throughput. The wrapper records whole runner
wall including service teardown, full environment, rendered Compose, source and
binary identities, and any remaining owned containers.

Workspace paths are separate: use ca Shared workspace CLI (historical format
label workspace-v1), then run /home/dev/ax-issue-446-workspace-guard row helper
and agent 445's distinct-group Packed pread helper. Their native-hit/proxy touch
proofs must pass before timing. Ordinary-volume data does not cover those caches.

Workspace campaign executable: run-workspace-guards.py. Run in an owned systemd unit with CPUQuota=300%, MemoryMax=16G and a timeout; it asserts actual cgroup limits. Use a unique alphanumeric lowercase campaign suffix and --compare only after source/binary receipts are installed. It performs all exact-path smokes before six alternating paired repetitions, with strict cleanup. The baseline row cache has its original entry/TTL bound, not the candidate retained-byte admission limit.

run-compose-matrix.py holds the shared heavy lock for a complete cached or regression campaign, using an inherited checked descriptor for each run-compose-case child. It first verifies both smoke results and then runs three alternating paired repetitions. This prevents unrelated heavy jobs entering between paired arms. summarize-compose-phases.py derives nanosecond whole-tool and tool-to-strict-drained times from existing phase-boundaries.tsv; canonical perf-summary seconds remain preserved. The strict three stable samples and two-second drain interval are unchanged.
