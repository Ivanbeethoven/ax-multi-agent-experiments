import argparse,json,hashlib
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('log',type=Path);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
raw=a.log.read_bytes();errors=[]
for number,line in enumerate(raw.decode(errors='replace').splitlines(),1):
 try:row=json.loads(line)
 except ValueError:
  if '[FATAL]' in line:errors.append({'line':number,'kind':'fatal_startup'})
  continue
 if isinstance(row,dict) and (row.get('level')=='ERROR' or int(row.get('status_code',0))>=500):
  errors.append({'line':number,'level':row.get('level'),'target':row.get('target'),'status_code':row.get('status_code'),'event':row.get('event')})
result={'passed':not errors,'log':str(a.log),'log_sha256':hashlib.sha256(raw).hexdigest(),'error_count':len(errors),'errors':errors,'scope':'Qualification requires no server ERROR or HTTP5xx; do not infer persistence from dirty=0.'}
a.output.write_text(json.dumps(result,indent=2)+'\n')
if errors:raise SystemExit('RustFS failure observed; qualification refused')
