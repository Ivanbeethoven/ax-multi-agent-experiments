"""Retain subsecond complete tool/drain costs from existing runner boundaries."""
import argparse
import csv
import hashlib
import json
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument('artifact',type=Path)
a=p.parse_args()
summary_path=a.artifact/'perf-summary.tsv'
phase_path=a.artifact/'phase-boundaries.tsv'
with summary_path.open() as stream:
    rows=list(csv.DictReader(stream,delimiter='\t'))
assert rows and all(row['status']=='pass' for row in rows)
assert not list(a.artifact.glob('*.invalid'))
phases={}
for line in phase_path.read_text().splitlines():
    tool,phase,stamp=line.split('\t')
    if stamp=='timestamp_ns': continue
    key=(tool,phase)
    assert key not in phases, f'Duplicate boundary {key}'
    phases[key]=int(stamp)
result={'artifact':str(a.artifact),
        'phase_sha256':hashlib.sha256(phase_path.read_bytes()).hexdigest(),
        'summary_sha256':hashlib.sha256(summary_path.read_bytes()).hexdigest(),
        'clock':'existing date +%s%N wall-clock boundaries; require nondecreasing timestamps',
        'scope':'Includes fio startup, operation, verification, close/final fsync; strict drain retains its configured stable-observation interval.',
        'tools':[]}
for row in rows:
    tool=row['tool'];start=phases[(tool,'tool_start')];returned=phases[(tool,'tool_return')]
    assert returned>=start
    item={'tool':tool,'canonical_integer_seconds':int(row['seconds']),
          'tool_start_ns':start,'tool_return_ns':returned,
          'precise_tool_wall_ns':returned-start}
    if tool.startswith(('fio-seqwrite','fio-randwrite','fio-randrw','fio-bigwrite')):
        drain_start=phases[(tool,'post-write_drain_start')]
        drained=phases[(tool,'post-write_extended_drained')]
        assert drained>=drain_start>=returned
        item.update(strict_drain_start_ns=drain_start,strict_drained_ns=drained,
                    precise_tool_to_strict_drained_ns=drained-start,
                    post_return_to_strict_drained_ns=drained-returned)
    result['tools'].append(item)
(a.artifact/'precise-phase-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
