from pathlib import Path
import subprocess,json,fcntl,os,sys,hashlib,datetime,traceback
r=Path('/home/dev/ax-perf-issues-validation/compose');out=r/'diagnostic-randrw-01';out.mkdir(exist_ok=False)
record={'scope':'Isolate the identical32MiB/3s randrw prefill/remount/read scene, without preceding unrelated seq/randwrite cases; diagnostic logging enabled; no performance qualification.','order':['candidate','baseline'],'cases':[],'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'script_sha256':hashlib.sha256((r/'run-randrw-diagnostic.py').read_bytes()).hexdigest()}
with Path('/home/dev/.ax-rbm-heavy.lock').open('w') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX);env=dict(os.environ,AX447_INHERITED_HEAVY_LOCK_FD=str(lock.fileno()))
 for arm,trial in [('candidate',200),('baseline',201)]:
  identity=f'ax447-{arm}-regression-smoke-{trial}'
  with (out/f'{arm}.log').open('w') as log:cp=subprocess.run([sys.executable,str(r/'run-randrw-diagnostic.py'),arm,'regression-smoke',str(trial)],env=env,pass_fds=(lock.fileno(),),stdout=log,stderr=subprocess.STDOUT)
  rec=json.loads((r/'trials'/identity/'receipt.json').read_text());record['cases'].append({'arm':arm,'exit_code':cp.returncode,'receipt':str(r/'trials'/identity/'receipt.json')})
  for service in ['redis','rustfs']:
   with (out/f'{arm}-{service}.log').open('w') as log:subprocess.run(['docker','logs',identity+'-'+service],stdout=log,stderr=subprocess.STDOUT,check=False)
  # Capture only fixture object names and sizes, never credential/header values.
  import boto3
  from botocore.config import Config
  client=boto3.client('s3',endpoint_url='http://127.0.0.1:29000',region_name='us-east-1',aws_access_key_id='rustfsadmin',aws_secret_access_key='rustfsadmin',config=Config(signature_version='s3v4',retries={'total_max_attempts':1},s3={'addressing_style':'path'}))
  inventories=[]
  for bucket in client.list_buckets()['Buckets']:
   objects=[]
   for page in client.get_paginator('list_objects_v2').paginate(Bucket=bucket['Name']):objects += [{'key':x['Key'],'size':x['Size']} for x in page.get('Contents',[])]
   inventories.append({'bucket':bucket['Name'],'objects':objects})
  (out/f'{arm}-s3-inventory.json').write_text(json.dumps(inventories,indent=2))
  subprocess.run(['docker','compose','-p',identity,'-f',str(r/'trials'/identity/'rendered-compose.json'),'down','-v'],check=True,stdout=(out/f'{arm}-cleanup.log').open('w'),stderr=subprocess.STDOUT)
  assert not subprocess.check_output(['docker','ps','-a','--filter',f'label=com.docker.compose.project={identity}','--format','{{.ID}}'],text=True).strip()
  (out/'receipt.json').write_text(json.dumps(record,indent=2))
record['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'receipt.json').write_text(json.dumps(record,indent=2)+'\n')
