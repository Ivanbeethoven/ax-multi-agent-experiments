"""Require operation-log proof before claiming a cached-write workload."""
import argparse
from collections import Counter, defaultdict
import json
from pathlib import Path
import re

p = argparse.ArgumentParser()
p.add_argument('log', type=Path)
p.add_argument('--bytes', type=int, default=512 * 1024)
p.add_argument('--request-bytes', type=int, default=4096)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
assert a.bytes % a.request_bytes == 0
groups = defaultdict(list)
for line in a.log.read_text(errors='replace').splitlines():
    if '[write] REQ' not in line:
        continue
    unique = re.search(r'\bunique:\s*(\d+)', line)
    fields = dict(re.findall(r'\b(inode|fh|offset|data_len|write_flags|flags)=(\d+)', line))
    assert unique and len(fields) == 6, line
    row = {k: int(v) for k, v in fields.items()}
    row['unique'] = int(unique.group(1))
    groups[row['inode']].append(row)

expected_offsets = list(range(0, a.bytes, a.request_bytes))
result = {'log': str(a.log), 'expected_bytes': a.bytes, 'expected_requests': len(expected_offsets),
          'request_bytes': a.request_bytes, 'inodes': {}, 'proven_inodes': []}
for inode, rows in groups.items():
    cached = [r for r in rows if r['write_flags'] & 1]
    proven = (len(cached) == len(expected_offsets)
              and sorted(r['offset'] for r in cached) == expected_offsets
              and all(r['unique'] > 0 and r['data_len'] == a.request_bytes for r in cached)
              and len({r['unique'] for r in cached}) == len(cached))
    result['inodes'][str(inode)] = {
        'writes': len(rows), 'cached_writes': len(cached),
        'length_histogram': dict(Counter(r['data_len'] for r in rows)),
        'nonzero_unique': all(r['unique'] > 0 for r in rows),
        'exact_disjoint_cached_request_shape': proven,
    }
    if proven:
        result['proven_inodes'].append(inode)
result['passed'] = len(result['proven_inodes']) == 1
a.output.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
if not result['passed']:
    raise SystemExit('Expected one inode with exact 4KiB cached writes and nonzero unique IDs')
