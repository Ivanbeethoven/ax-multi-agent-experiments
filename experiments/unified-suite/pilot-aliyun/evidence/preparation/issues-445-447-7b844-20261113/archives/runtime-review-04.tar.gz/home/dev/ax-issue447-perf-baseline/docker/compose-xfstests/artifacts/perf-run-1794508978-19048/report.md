# BrewFS Perf Report

Meta backend: redis

## Summary

| Tool | Status | Seconds | Log |
| --- | --- | ---: | --- |
| fio-randwrite-direct0 | pass | 29 | tools/fio-randwrite-direct0.log |
| fio-randwrite-direct0-remote-durability | fail(1) | 0 | tools/receipt.json |

## Post-Write Drain

| Tool | Drain seconds | Pending bytes | Dirty bytes | Buffer dirty bytes |
| --- | ---: | ---: | ---: | ---: |
| fio-randwrite-direct0 | 38 | 0 | 0 | 0 |

## Fio

| Tool | Workload | Direct | BS | Jobs | Read BW | Read IOPS | Write BW | Write IOPS | Read P99 | Write P99 | Raw |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |---: | ---: | ---: |
| fio-randwrite-direct0 | randwrite | 0 | 4m | 4 | 0.00 B/s | 0.00 | 137.61 MiB/s | 34.40 | 0.000 ms | 78.119 ms | results/fio-randwrite-direct0.json |

## Fio Runtime Accounting

Use `active_io_runtime` for close/flush tail detection; fio `job_runtime_ms` can aggregate multiple jobs under group reporting.

| Tool | Direct | Script wall | fio job_runtime | wall-job_runtime | wall/job_runtime | active_io_runtime | wall-active_io | wall/active_io | Tail marker |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| fio-randwrite-direct0 | 0 | 29 s | 116.731 s | -87.731 s | 0.25x | 29.184 s | -0.184 s | 0.99x | fio job_runtime aggregates jobs |

## Fully Drained Write Throughput

Actual fio bytes divided by `active_io_runtime + post_write_drain`; unlike foreground bandwidth, this includes the time required to empty the filesystem writeback queue.

| Tool | Active I/O | Drain | Complete | Read | Write | Total | Raw |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| fio-randwrite-direct0 | 29.184 s | 38.000 s | 67.184 s | 0.00 MiB/s | 59.78 MiB/s | 59.78 MiB/s | fully-drained-throughput.tsv |

## Latency Percentiles

### Read

| Workload | p1 | p5 | p25 | p50 | p75 | p90 | p95 | p99 | p99.9 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |

### Write

| Workload | p1 | p5 | p25 | p50 | p75 | p90 | p95 | p99 | p99.9 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| fio-randwrite-direct0 | 0.000 ms | 0.000 ms | 0.000 ms | 14.090 ms | 0.000 ms | 0.000 ms | 38.535 ms | 78.119 ms | 17112.760 ms |

## Redis Diagnostics

| Tool | Top commandstats | Details |
| --- | --- | --- |
| fio-randwrite-direct0 | evalsha: calls=539, usec/call=54.09<br>exec: calls=1008, usec/call=3.02<br>rpush: calls=501, usec/call=3.69<br>get: calls=1521, usec/call=1.19<br>incrby: calls=501, usec/call=2.57 | diagnostics/redis-fio-randwrite-direct0-after.txt |

## BrewFS Stats

Counters are per-tool deltas when matching before/after snapshots exist; dirty, live, and inflight values are after-tool gauges.

| Tool | Cache hit | FUSE read | FUSE write | Dirty | Live dirty | Recent pending | Recent uploaded | Read buffer | S3 ops | S3 avg latency | Details |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| fio-randwrite-direct0 | 0.0% (0/0) | 0.0 MiB | 4016.0 MiB | 3056.0 MiB | 0.0 MiB | 3056.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=244 | GET=0.00 ms, PUT=707.32 ms | diagnostics/stats-fio-randwrite-direct0-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=502 ops/4016.0 MiB/62389.3 ms, foreground=stage 62.39s/commit_wait 1.01s, flush_wait=5 ops/0.03s/5 slices, stage_fail=0, commit_before_stage=366, remote_inflight=3056.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=25, max_buffer_dirty=3648.0 MiB, max_live_dirty=983.0 MiB, max_live_slices=143, max_recent_pending=3648.0 MiB, max_recent_uploaded=0.0 MiB, max_stage_inflight=492.0 MiB, max_remote_inflight=3648.0 MiB, last_buffer_dirty=3076.0 MiB, slices=create 502/reuse 3515/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=502 avg=8.0 MiB blocks=2.00/batch partial_tail=0.00 (size 0/max 0/flush 1/auto 0/age 0), partial_origin=normal 1/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 0/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 0/cached 0/mixed 0/unknown 0, freeze=size 64/flush 5/auto 280/max 153/age 0 |
| fio-randwrite-direct0-post-write-drained | 0.0% (0/0) | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=759 | GET=0.00 ms, PUT=259.27 ms | diagnostics/stats-fio-randwrite-direct0-post-write-drained-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=0 ops/0.0 MiB/0.0 ms, foreground=stage 0.00s/commit_wait 0.00s, flush_wait=0 ops/0.00s/0 slices, stage_fail=0, commit_before_stage=0, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 502/reuse 3515/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=0 avg=n/a blocks=0.00/batch partial_tail=0.00 (size 0/max 0/flush 0/auto 0/age 0), partial_origin=normal 0/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 0/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 0/cached 0/mixed 0/unknown 0, freeze=size 64/flush 5/auto 280/max 153/age 0 |
| fio-randwrite-direct0-post-write-runner-drained | 0.0% (0/0) | 0.0 MiB | 4016.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=1005 | GET=0.00 ms, PUT=368.05 ms | diagnostics/stats-fio-randwrite-direct0-post-write-runner-drained-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=502 ops/4016.0 MiB/62389.3 ms, foreground=stage 62.39s/commit_wait 1.01s, flush_wait=5 ops/0.03s/5 slices, stage_fail=0, commit_before_stage=366, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 502/reuse 3515/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=502 avg=8.0 MiB blocks=2.00/batch partial_tail=0.00 (size 0/max 0/flush 1/auto 0/age 0), partial_origin=normal 1/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 0/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 0/cached 0/mixed 0/unknown 0, freeze=size 64/flush 5/auto 280/max 153/age 0 |
