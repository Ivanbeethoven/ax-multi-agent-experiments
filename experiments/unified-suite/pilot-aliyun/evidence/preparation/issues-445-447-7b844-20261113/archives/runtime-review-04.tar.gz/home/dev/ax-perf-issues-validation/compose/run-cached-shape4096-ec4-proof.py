from pathlib import Path
import subprocess,json,fcntl,os,sys,hashlib
r=Path('/home/dev/ax-perf-issues-validation/compose')
with Path('/home/dev/.ax-rbm-heavy.lock').open('w') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 env=dict(os.environ,AX447_INHERITED_HEAVY_LOCK_FD=str(lock.fileno()))
 for arm in ['baseline','candidate']:
  subprocess.run([sys.executable,str(r/'run-cached-shape4096-ec4.py'),arm,'cached-smoke','300','--sync','range'],env=env,pass_fds=(lock.fileno(),),check=True)
  receipt=json.loads((r/f'trials/ax447-{arm}-cached-smoke-300/receipt.json').read_text());assert len(receipt['artifact_directories'])==1
  a=Path(receipt['artifact_directories'][0])
  subprocess.run([sys.executable,str(r/'check-cached-write-smoke.py'),str(a/'brewfs_fuse_ops.log'),'--bytes',str(16<<20),'--output',str(a/'cached-write-touch-proof.json')],check=True)
  subprocess.run([sys.executable,str(r/'summarize-client-cpu.py'),str(a),'--output',str(a/'client-cpu-summary.json')],check=True)
(r/'cached-shape4096-ec4-complete.json').write_text(json.dumps({'passed':True,'diagnostic_only':True,'timing_excluded':'operation logging enabled','case_script_sha256':hashlib.sha256((r/'run-cached-shape4096-ec4.py').read_bytes()).hexdigest()},indent=2))
