#!/usr/bin/env python3
from pathlib import Path
import datetime,hashlib,json,os,re,shutil,subprocess,sys,time
root=Path('/srv/perf-issues-445-447')
arm=sys.argv[1]
assert arm in ('baseline','candidate')
sha={'baseline':'ca07159f3da4b670e4aeb878faef928e69bc1634','candidate':'7b8445042fda8e6cd5ec9a3bedc0eb606a45d8b3'}[arm]
source=root/arm
out=root/'evidence'/(arm+'-01');out.mkdir(parents=True,exist_ok=False)
artifact=root/'artifacts'/arm;artifact.mkdir(parents=True,exist_ok=False)
env=dict(os.environ)
env.update(PATH='/root/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin:/root/.cargo/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin',CARGO_HOME='/root/.cargo',CARGO_TARGET_DIR=str(root/'target'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_RELEASE_DEBUG='0',GIT_OPTIONAL_LOCKS='0')
for key in ('CARGO_PROFILE_RELEASE_OPT_LEVEL','CARGO_PROFILE_RELEASE_LTO','CARGO_PROFILE_RELEASE_CODEGEN_UNITS','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER'):
 assert not env.get(key), 'unexpected compiler override: '+key
def git(*args):return subprocess.check_output(['git','-C',str(source),*args],env=env,text=True).strip()
assert git('rev-parse','HEAD')==sha and not git('status','--porcelain')
features='fuse-io-uring-runtime,workspace-overlay,observability,rustfs-ec-block-size-hint'
command=['cargo','build','--release','--locked','--no-default-features','--features',features,'--bin','brewfs']
if arm=='baseline':command += ['--bin','packed_v3_snapshot_fixture']
receipt=dict(arm=arm,commit=sha,tree=git('rev-parse','HEAD^{tree}'),branch=git('branch','--show-current'),dirty=False,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),command=command,build_env={k:env[k] for k in ('CARGO_HOME','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_INCREMENTAL','CARGO_PROFILE_RELEASE_DEBUG','GIT_OPTIONAL_LOCKS')},cpu_quota_percent=300,memory_max_bytes=20*1024**3)
receipt['rustc']=subprocess.check_output(['rustc','-Vv'],env=env,text=True)
receipt['cargo']=subprocess.check_output(['cargo','-V'],env=env,text=True).strip()
assert 'rustc 1.99.1' in receipt['rustc']
(out/'source-and-command.json').write_text(json.dumps(receipt,indent=2)+'\n')
start=time.monotonic()
with (out/'build.log').open('wb') as log:
 result=subprocess.run(command+['-vv'],cwd=source,env=env,stdout=log,stderr=subprocess.STDOUT)
receipt.update(exit_code=result.returncode,elapsed_seconds=time.monotonic()-start,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
(out/'build-result.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert result.returncode==0,'cargo failed: see build.log'
assert git('rev-parse','HEAD')==sha and not git('status','--porcelain')
commands=[line for line in (out/'build.log').read_text(errors='replace').splitlines() if 'Running `' in line and '--crate-name brewfs ' in line]
assert commands,'no actual brewfs rustc command found'
(out/'actual-rustc-commands.txt').write_text('\n'.join(commands)+'\n')
files={}
for name in (['brewfs','packed_v3_snapshot_fixture'] if arm=='baseline' else ['brewfs']):
 target=artifact/name;shutil.copy2(root/'target/release'/name,target)
 with target.open('rb') as stream:files[name]=hashlib.file_digest(stream,'sha256').hexdigest()
version=subprocess.run([str(artifact/'brewfs'),'--version'],env=env,capture_output=True,text=True,check=True)
text=version.stdout+version.stderr
(out/'binary-version.txt').write_text(text)
plain=re.sub(r'\x1b\[[0-9;]*m','',text)
assert re.search(r'^commit: '+sha+r'$',plain,re.M)
assert re.search(r'^dirty: false$',plain,re.M)
receipt['binaries_sha256']=files;receipt['source_still_clean']=True
(out/'artifact-identity.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'arm':arm,'commit':sha,'binaries_sha256':files,'elapsed_seconds':receipt['elapsed_seconds']}),flush=True)
