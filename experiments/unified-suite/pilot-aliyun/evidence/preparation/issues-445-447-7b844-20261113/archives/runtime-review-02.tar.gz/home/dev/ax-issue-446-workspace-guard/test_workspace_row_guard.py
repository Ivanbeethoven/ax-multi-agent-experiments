import types
import unittest
import os
import tempfile
from pathlib import Path
from unittest.mock import patch

import workspace_row_guard as guard


def stats(hits=0, misses=0, retained=None, capacity=None):
    raw = f"{guard.HITS} {hits}\n{guard.MISSES} {misses}\n"
    if retained is not None:
        raw += f"{guard.RETAINED} {retained}\n"
    if capacity is not None:
        raw += f"{guard.CAPACITY} {capacity}\n"
    return guard.parse_stats(raw)


class GuardTests(unittest.TestCase):
    def test_required_native_counters_are_not_defaulted(self):
        for raw in ("", f"{guard.HITS} 0\n", f"{guard.HITS} nan\n{guard.MISSES} 0\n"):
            with self.assertRaises(ValueError):
                guard.parse_stats(raw)

    def test_duplicate_native_counter_rejected(self):
        with self.assertRaises(ValueError):
            guard.parse_stats(f"{guard.HITS} 0\n{guard.HITS} 1\n{guard.MISSES} 0\n")

    def test_old_binary_byte_fields_remain_unsupported(self):
        sample = stats()
        self.assertIsNone(sample["row"][guard.RETAINED])
        checks = guard.byte_checks([sample], False)
        self.assertFalse(checks["supported"])
        self.assertIsNone(checks["observed_within_capacity"])
        self.assertIsNone(checks["sampled_retained_max_bytes"])
        self.assertFalse(guard.byte_checks([sample], True)["required_fields_present"])

    def test_byte_budget_excess_is_a_failure(self):
        self.assertFalse(guard.byte_checks([stats(retained=513, capacity=512)], True)
                         ["observed_within_capacity"])

    def test_counter_reset_is_rejected(self):
        with self.assertRaises(ValueError):
            guard.counter_delta(stats(10, 4), stats(9, 4))

    def run_hot(self, final_misses, require_bytes=False, warm_misses=0):
        args = types.SimpleNamespace(keys=1, threads=1, ops_per_thread=2,
                                     mount=Path("unused"), require_byte_metrics=require_bytes)
        with patch.object(guard, "verify_get") as get, patch.object(
            guard, "read_stats", side_effect=[stats(), stats(1, warm_misses), stats(999, final_misses)]
        ):
            result = guard.hot(args, {"value_bytes": 8}, [7], [b"abcdefgh"])
            return result, get.call_count

    def test_permission_hits_cannot_hide_xattr_misses(self):
        result, calls = self.run_hot(1)
        self.assertFalse(result["passed"])
        self.assertEqual(calls, 4)
        self.assertEqual(result["delta"][guard.MISSES], 1)

    def test_unstable_warmup_stops_before_timing(self):
        result, calls = self.run_hot(1, warm_misses=1)
        self.assertFalse(result["passed"])
        self.assertEqual(calls, 2)
        self.assertNotIn("wall_ns", result)

    def test_stable_baseline_can_report_missing_new_fields(self):
        result, _ = self.run_hot(0)
        self.assertTrue(result["passed"])
        self.assertFalse(result["byte_checks"]["supported"])
        result, _ = self.run_hot(0, require_bytes=True)
        self.assertFalse(result["passed"])

    def test_fixture_paths_reject_escape(self):
        for value in ("/outside", "../outside", "a/../../outside", "."):
            with self.assertRaises(ValueError):
                guard.relative_path(value)

    @unittest.skipUnless(hasattr(os, "getxattr"), "Linux fd xattr smoke")
    def test_linux_fd_values_and_two_mount_input_identity(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            identities = []
            for label in ("baseline", "candidate"):
                mount = root / label
                mount.mkdir()
                args = types.SimpleNamespace(mount=mount, manifest=root / (label + ".json"),
                                             subdir="fixture", files=2, value_bytes=8)
                identities.append(guard.prepare(args)["canonical_input_sha256"])
                _, fds, values = guard.load_fixture(args)
                try:
                    for fd, value in zip(fds, values):
                        guard.verify_get(fd, value)
                finally:
                    for fd in fds:
                        os.close(fd)
            self.assertEqual(*identities)


if __name__ == "__main__":
    unittest.main()
