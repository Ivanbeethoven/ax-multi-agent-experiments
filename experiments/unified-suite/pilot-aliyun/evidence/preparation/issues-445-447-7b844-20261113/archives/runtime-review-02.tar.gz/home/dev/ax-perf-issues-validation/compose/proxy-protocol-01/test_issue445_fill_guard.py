import hashlib
from http.client import HTTPConnection
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import struct
from threading import Barrier, Thread
import unittest
from concurrent.futures import ThreadPoolExecutor

from issue445_fill_guard import group_ranges, delayed_group_meta_proxy


def fixture_prefix():
    data = bytearray(8192)
    data[:8] = b'BRFGC005'
    struct.pack_into('<H', data, 8, 5)
    struct.pack_into('<I', data, 12, 4096)
    struct.pack_into('<Q', data, 24, 16384)
    data[4096:4100] = b'GC05'
    struct.pack_into('<II', data, 4112, 1, 1)
    struct.pack_into('<QQII', data, 4120, 7, 4608, 128, 128)
    struct.pack_into('<HH', data, 4224, 3, 3)
    data[4228:4234] = b'f00f15'
    return data


class GroupInventoryTests(unittest.TestCase):
    def test_exact_group_range_and_noncontainer(self):
        rows = group_ranges('base/objects/one', fixture_prefix(), 16384)
        self.assertEqual(rows[0]['range'], 'bytes=4608-4735')
        self.assertEqual(rows[0]['group_id'], 7)
        self.assertEqual(rows[0]['frame_count'], 1)
        self.assertEqual(group_ranges('index', b'BRFII005', 100), [])

    def test_object_and_metadata_bounds_are_checked(self):
        with self.assertRaises(ValueError):
            group_ranges('k', fixture_prefix(), 16385)
        data = fixture_prefix()
        struct.pack_into('<Q', data, 4128, 16380)
        with self.assertRaises(ValueError):
            group_ranges('k', data, 16384)

    def test_truncation_and_unsupported_multi_group_are_rejected(self):
        with self.assertRaises(ValueError):
            group_ranges('k', fixture_prefix()[:4200], 16384)
        data = fixture_prefix()
        struct.pack_into('<I', data, 4112, 2)
        with self.assertRaises(ValueError):
            group_ranges('k', data, 16384)


class ProxyTests(unittest.TestCase):
    def test_exact_target_matching_concurrent_events_and_no_signed_query_leak(self):
        class Backend(BaseHTTPRequestHandler):
            def log_message(self, *_):
                pass

            def do_GET(self):
                self.send_response(206)
                self.send_header('Content-Length', '128')
                self.end_headers()
                self.wfile.write(b'x' * 128)

            def do_HEAD(self):
                self.send_response(200)
                self.send_header('Content-Length', '128')
                self.end_headers()

        targets = [dict(key=f'base/k{i}', range='bytes=4608-4735', group_id=i,
                        object_key_sha256=hashlib.sha256(f'base/k{i}'.encode()).hexdigest())
                   for i in range(8)]
        with ThreadingHTTPServer(('127.0.0.1', 0), Backend) as backend:
            thread = Thread(target=backend.serve_forever, daemon=True)
            thread.start()
            try:
                with delayed_group_meta_proxy(backend.server_port, 'bucket', targets, .05) as probe:
                    port = int(probe.endpoint.rsplit(':', 1)[1])

                    def get(i, barrier=None, range_header='bytes=4608-4735', method='GET'):
                        if barrier:
                            barrier.wait(timeout=5)
                        connection = HTTPConnection('127.0.0.1', port, timeout=5)
                        try:
                            connection.request(method, f'/bucket/base/k{i}?signature=never-log',
                                               headers={'Range': range_header, 'Authorization': 'never-log'})
                            response = connection.getresponse()
                            data = response.read()
                            self.assertIn(response.status, (200, 206))
                            return data
                        finally:
                            connection.close()

                    # Requests before the wave are neither delayed nor recorded.
                    self.assertEqual(len(get(0)), 128)
                    probe.begin_wave()
                    get(0, method='HEAD')
                    get(0, range_header='bytes=0-127')
                    barrier = Barrier(8)
                    with ThreadPoolExecutor(max_workers=8) as pool:
                        self.assertEqual([len(x) for x in pool.map(lambda i: get(i, barrier), range(8))], [128] * 8)
                    observed = probe.finish_wave()
                    self.assertEqual(observed['errors'], 0)
                    self.assertEqual(len(observed['events']), 8)
                    self.assertEqual(len({e['object_key_sha256'] for e in observed['events']}), 8)
                    self.assertGreater(observed['max_target_active'], 1)
                    self.assertTrue(all(e['status'] == 206 and e['bytes'] == 128 for e in observed['events']))
                    self.assertNotIn('never-log', json.dumps(observed))
                    self.assertTrue(all(e['entered_ns'] <= e['forward_started_ns'] <= e['finished_ns']
                                        for e in observed['events']))
            finally:
                backend.shutdown()
                thread.join()


if __name__ == '__main__':
    unittest.main()
