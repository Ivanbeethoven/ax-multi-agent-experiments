"""Local HTTP protocol checks: all credentials here are fixed test strings."""
from contextlib import contextmanager, redirect_stderr
from http.client import HTTPConnection
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from io import StringIO
import hashlib
import json
from threading import Thread
import unittest

from issue445_fill_guard import delayed_group_meta_proxy


@contextmanager
def backend_and_proxy(respond):
    seen = []

    class Backend(BaseHTTPRequestHandler):
        protocol_version = 'HTTP/1.1'

        def log_message(self, *_):
            pass

        def forward(self):
            # Capture only fixed synthetic test headers in memory, never logs.
            body = bytearray()
            if self.headers.get('Transfer-Encoding') == 'chunked':
                while True:
                    line = self.rfile.readline()
                    body.extend(line)
                    size = int(line.split(b';', 1)[0], 16)
                    if size:
                        body.extend(self.rfile.read(size + 2))
                    else:
                        while True:
                            trailer = self.rfile.readline()
                            body.extend(trailer)
                            if trailer == b'\r\n':
                                break
                        break
            else:
                body.extend(self.rfile.read(int(self.headers.get('Content-Length', '0'))))
            seen.append((self.command, self.path, list(self.headers.raw_items()), bytes(body)))
            respond(self)

        do_GET = do_HEAD = do_PUT = do_POST = do_DELETE = forward

    targets = [dict(key='base/k0', range='bytes=4608-4735', group_id=7,
                    object_key_sha256=hashlib.sha256(b'base/k0').hexdigest())]
    with ThreadingHTTPServer(('127.0.0.1', 0), Backend) as backend:
        thread = Thread(target=backend.serve_forever, daemon=True)
        thread.start()
        try:
            with delayed_group_meta_proxy(backend.server_port, 'bucket', targets, .05) as probe:
                yield probe, seen
        finally:
            backend.shutdown()
            thread.join()


def request(probe, method, body, headers, path='/bucket/base/k0?signature=test-only-never-log'):
    connection = HTTPConnection('127.0.0.1', int(probe.endpoint.rsplit(':', 1)[1]), timeout=5)
    try:
        connection.putrequest(method, path, skip_host=True, skip_accept_encoding=True)
        for name, value in headers:
            connection.putheader(name, value)
        connection.endheaders(body)
        response = connection.getresponse()
        return response.status, response.getheaders(), response.read()
    finally:
        connection.close()


class ProtocolTests(unittest.TestCase):
    def test_empty_bucket_put_and_xml_post_delete_preserve_headers_and_bodies(self):
        responses = [(200, b''), (200, b'<Created/>'), (200, b'<Deleted/>'), (204, b'')]

        def respond(handler):
            status, body = responses.pop(0)
            handler.send_response_only(status)
            if status != 204:
                handler.send_header('Content-Length', str(len(body)))
            handler.end_headers()
            handler.wfile.write(body)

        with backend_and_proxy(respond) as (probe, seen):
            probe.begin_wave()
            requests = [('PUT', b''), ('PUT', b'<CreateBucketConfiguration>cn-test</CreateBucketConfiguration>'),
                        ('POST', b'<Delete><Key>binary-\x00&amp;</Key></Delete>'), ('DELETE', b'')]
            for method, body in requests:
                headers = [('Host', 'signed.example:9000'), ('Content-Length', str(len(body))),
                           ('Authorization', 'test-only-never-log'), ('Range', 'bytes=4608-4735'),
                           ('x-amz-content-sha256', hashlib.sha256(body).hexdigest()),
                           ('x-meta-duplicate', 'one'), ('x-meta-duplicate', 'two')]
                status, _, returned = request(probe, method, body, headers)
                self.assertIn(status, (200, 204))
                self.assertEqual(seen[-1], (method, '/bucket/base/k0?signature=test-only-never-log', headers, body))
                self.assertEqual(returned, {1:b'', 2:b'<Created/>', 3:b'<Deleted/>', 4:b''}[len(seen)])
            observed = probe.finish_wave()
            self.assertEqual(observed['events'], [])
            self.assertEqual(observed['errors'], 0)
            self.assertNotIn('test-only-never-log', json.dumps(observed))

    def test_aws_encoded_content_length_body_and_error_xml_are_opaque(self):
        body = bytes(range(256)) * 513 + b'\r\n0;chunk-signature=test-only\r\n\r\n'
        error = b'<Error><Code>BucketAlreadyOwnedByYou</Code></Error>'

        def respond(handler):
            handler.send_response_only(409)
            handler.send_header('Content-Length', str(len(error)))
            handler.end_headers()
            handler.wfile.write(error)

        with backend_and_proxy(respond) as (probe, seen):
            probe.begin_wave()
            headers = [('Host', 'signed.example'), ('Content-Length', str(len(body))),
                       ('Content-Encoding', 'aws-chunked'), ('x-amz-trailer', 'x-amz-checksum-crc32'),
                       ('Authorization', 'test-only-never-log')]
            captured = StringIO()
            with redirect_stderr(captured):
                status, _, returned = request(probe, 'PUT', body, headers)
            self.assertEqual(status, 409)
            self.assertEqual(returned, error)
            self.assertEqual(seen[0][2:], (headers, body))
            observed = probe.finish_wave()
            self.assertEqual(observed['events'], [])
            self.assertEqual(observed['errors'], 1)
            self.assertNotIn('test-only-never-log', captured.getvalue() + json.dumps(observed))

    def test_http_chunk_extensions_trailers_and_chunked_response(self):
        raw = (b'3;chunk-signature=test-only-A\r\nabc\r\n'
               b'2;chunk-signature=test-only-B\r\n\x00\xff\r\n'
               b'0;chunk-signature=test-only-Z\r\nx-amz-checksum-crc32: test-only\r\n\r\n')
        response_raw = b'3\r\n<Ok\r\n2\r\n/>\r\n0\r\n\r\n'

        def respond(handler):
            handler.send_response_only(200)
            handler.send_header('Transfer-Encoding', 'chunked')
            handler.end_headers()
            handler.wfile.write(response_raw)

        with backend_and_proxy(respond) as (probe, seen):
            probe.begin_wave()
            headers = [('Host', 'signed.example'), ('Transfer-Encoding', 'chunked'),
                       ('Trailer', 'x-amz-checksum-crc32'), ('Authorization', 'test-only-never-log')]
            status, response_headers, returned = request(probe, 'POST', raw, headers)
            self.assertEqual(status, 200)
            self.assertEqual(returned, b'<Ok/>')
            self.assertEqual(seen[0][2:], (headers, raw))
            self.assertIn(('Connection', 'close'), response_headers)
            observed = probe.finish_wave()
            self.assertEqual(observed['events'], [])
            self.assertEqual(observed['errors'], 0)

    def test_head_without_content_length_has_no_body(self):
        def respond(handler):
            handler.send_response_only(200)
            handler.end_headers()

        with backend_and_proxy(respond) as (probe, seen):
            probe.begin_wave()
            status, _, body = request(probe, 'HEAD', b'', [('Host', 'signed.example')])
            self.assertEqual((status, body), (200, b''))
            self.assertEqual(probe.finish_wave()['events'], [])
            self.assertEqual(len(seen), 1)


if __name__ == '__main__':
    unittest.main()
