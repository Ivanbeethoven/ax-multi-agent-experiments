# Issue 445 experiment proxy protocol correction

This isolated helper change fixes setup, not BrewFS or the timed read workload. The prior real workspace smoke stopped before measurement because `init-packed-volume` creates its private upper bucket with PUT and the proxy returned 501. Preserve that failed smoke. Both measured arms must use this same final helper SHA.

The verified ca source path is recorded in `source-path.json`: initialization needs PUT (empty in us-east-1, XML in other regions); explicit upper-bucket cleanup also needs POST DeleteObjects and DELETE Bucket. The existing init/mount endpoint configuration is unchanged.

The helper now forwards GET/HEAD/PUT/POST/DELETE. It preserves the original request-target, every request header including duplicates and signed Host, and exact request body bytes, including AWS content encoding and HTTP chunk extensions/trailers. Non-HEAD response bodies, including error XML, are streamed. A lengthless/chunked response uses close-delimited downstream framing after the standard library removes HTTP transfer framing; entity bytes remain unchanged. HEAD/204/304 correctly have no response body. No authorization headers, signed queries, or bodies are logged. Invalid/conflicting request framing closes the connection.

Exact GroupMeta matching and injected delay remain GET-only. Existing tests still prove eight concurrent exact GET ranges are recorded, HEAD and non-target ranges are not, and signed queries do not leak. New tests prove empty bucket PUT, region XML PUT, POST XML, DELETE 204, duplicated/signed headers, a >128KiB AWS-encoded binary body, error XML, original chunk signatures/trailers, chunked response entities, and HEAD without Content-Length. Synthetic credentials in tests are fixed test-only strings.

Validation: old helper + the new empty-PUT test fails with HTTP 501 (`red-empty-put.log`); new helper passes all eight local HTTP/inventory tests (`green-all.log`, 2.616 seconds). `git apply --check` passes. This is a protocol correctness check, not a real S3/FUSE performance result. The next full workspace smoke is still required; do not reuse the previous failed attempt as performance evidence.

Files:
- `proxy-protocol.patch`: helper delta plus new protocol test file, applies against original helper SHA 8da9283d0c1b3bda52ab436f9185a9751f2ef7aec6a1eedf7bd02c1c3728c47f.
- `issue445_fill_guard.py`: complete corrected helper for guarded installation.
- `test_issue445_fill_guard.py`: unchanged original four tests.
- `test_issue445_proxy_protocol.py`: four new protocol regression tests.
- `test-receipt.json`, RED/GREEN logs, `source-path.json`, `artifact-sha256.json`: review evidence.

Reproduce locally on rbm:

```sh
cd /home/dev/ax-issue-445-proxy-protocol-01
python3 -m unittest -v test_issue445_fill_guard test_issue445_proxy_protocol
```

The shared originals under `/home/dev/ax-packed-build` were not changed. No cloud/worker was accessed, no Rust source or binary was changed, and no heavy build or workload was started.
