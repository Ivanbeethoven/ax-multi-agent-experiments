# Remote durability hard gate for Issues qualification

Prepared on rbm only. This is a harness change; it does not change either frozen BrewFS binary, RustFS, image, resource budget, or the measured fio argv. No cloud workloads were run by this implementation task. Real FUSE qualification remains agent447's next step.

## Integration

- Verify the existing container script SHA256 is `46455b580c2580c6e78a33bb7b1fd4664fd8589960e4b2162f8d9ff6be9b1057`; apply `durability-gate.patch` in an isolated copy of its directory. The patch adds the stdlib helper and local tests and changes only that script's post-write gate.
- Read-only bind `verify_remote_durability.py` at `/usr/local/bin/verify_remote_durability.py` in both arms. No PyYAML or new image dependency is needed.
- Keep formal arms at `RUST_LOG=warn`. The exact diagnostic filters `brewfs=info,asyncfuse::raw::logfs=debug` and `warn,asyncfuse::raw::logfs=debug` are also accepted because their BrewFS WARN records remain visible. Other filters fail closed. The helper checks the real process environment as well as its caller.
- Keep `PERF_FIO_POST_WRITE_DRAIN=true`, the owned config `/run/brewfs/config.yaml`, mount `/mnt/brewfs`, initial `BREWFS_CACHE_ROOT=/var/lib/brewfs/cache`, and per-tool output beneath `/artifacts/.../remote-durability/`. Both arms must use the same final helper/script SHA and flags.
- The existing strict-drain observer must complete before this gate. Its measured tool/start-return/fully-drained CPU boundaries are unchanged. Validation has a 300-second whole-process timeout and a 30-second old-process exit timeout; timeout fails the case without killing the BrewFS process or deleting staging.
- Outer runner must require every write-profile `remote-durability/<tool>/receipt.json` to have `passed=true`, no global `remote-durability.invalid` marker, and no failure summary row. Preserve the entire directory and final client/server logs. Agent447's outer server HTTP500/error gate is complementary and is not implemented here.

## Exact lifecycle and evidence

Applies to named `fio-seqwrite*`, `fio-randwrite*`, `fio-randrw*`, and `fio-bigwrite*` profiles after fio and strict post-write drain both return success. Arbitrary custom fio and metadata-only tools are not newly covered. The existing cached-write fio pattern verification remains unchanged.

The helper rejects any previous upload/put/recovery/writeback failure in the client log, snapshots every regular file's relative path, size and SHA256, and records the old mount PID/starttime/argv/binary SHA/cache environment. It runs only normal `fusermount3 -u`, then requires that exact process to exit and the FUSE mount to disappear. It never sends TERM/KILL, force-unmounts, or removes cache/staging.

It creates an exclusive UUID directory under `/var/lib/brewfs/cache-durability`, proves it initially empty, and changes only the unique plain generated `cache.root` or `cache.cache_root` line. `root` is the actual runner's accepted serde alias. All other config bytes, including data endpoint/Redis namespace and budget, are retained. Duplicate/ambiguous aliases, unowned paths, symlinks, inherited overrides and unsupported YAML shapes are rejected. It then remounts via the same mount helper with the new root in both config and environment; a different PID, identical executable SHA and argv, and the actual new process environment are required. It reads and hashes every file again, compares exact inventory/size/content, then rejects any new upload/recovery failure. Old staging is preserved. The parent shell exports the verified new root for subsequent tools instead of reusing old staging.

Per-tool receipt separately records warm hashing, normal unmount, remount, cold hashing, total validation nanoseconds, initial/final wall times, both config hashes, both mount identities, file count/bytes and hashed matching failure-line references. Config-before/config-after, expected/observed inventories and the verified new root are retained. A failure propagates nonzero and adds a failure summary row plus global invalid marker; subsequent fio profiles stop. A timeout can leave a partial false receipt, which cannot qualify.

The warm final bytes are the reference for persistence, not an independent application correctness oracle or a power-loss test. Cached fio's original known-pattern check still supplies its application oracle. This proves full reads after process/kernel-cache teardown and a fresh local cache, not S3 durability against server disk loss. Server health/error evidence remains independently required.

## Verification

`python3 -m unittest -v test_remote_durability`: 28 tests pass, including successful full inventory, alias compatibility, changed/missing/extra data, old-stage preservation, duplicate/unowned/symlink roots, inherited overrides, changed binary/argv/PID, normal-exit waiting/no-force timeout, WARN rejection, shell failure/timeout propagation and strict-drain ordering. `bash -n` and `git apply --check` pass. These are isolated protocol tests with a fake mount driver; they do not claim an actual FUSE run passed.

`python3 verify_archived_red.py`: replays the unmodified archived baseline cached-smoke trial102. Old runner status0 and fio pass coexisted with all selected final dirty/pending counters0. The new WARN scanner rejects six upload/recovery failure lines. Receipt includes full input hashes, line hashes, old summary and drain records. This is offline RED evidence, not a rerun.

Earlier local attempts are retained: attempt01 had two shell-test stub dynamic-scope failures; attempt02 passed26 tests; attempt03 was a test-edit syntax error. The final28-test run includes added argv/log-policy checks and passes. Shared original scripts and frozen Rust/source trees were not modified.
