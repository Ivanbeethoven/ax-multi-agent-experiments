import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest import mock
import verify_remote_durability as gate

class FakeMount:
    def __init__(self, dataset, log, action=None, unmount=None):
        self.dataset, self.log, self.action = dataset, log, action
        self.unmount_result, self.calls, self.started_empty = unmount, [], None
    def current(self, root):
        self.calls.append('current')
        return dict(pid=10, starttime='1', state='S', executable_sha256='same-bin', cache_root=str(root), argv=['brewfs', 'mount', '--config', 'same-config'])
    def unmount(self, old):
        self.calls.append('unmount')
        if isinstance(self.unmount_result, Exception): raise self.unmount_result
        return self.unmount_result or dict(forced=False, old_process_terminated=True)
    def start(self, root):
        self.calls.append('start')
        self.started_empty = not list(root.iterdir())
        result = dict(pid=11, starttime='2', state='S', executable_sha256='same-bin', cache_root=str(root), argv=['brewfs', 'mount', '--config', 'same-config'])
        if self.action: self.action(self, result)
        return result

class GateTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
        self.base = Path(self.tmp.name); self.owner = self.base / 'owned'; self.owner.mkdir()
        self.old = self.owner / 'cache'; self.old.mkdir()
        (self.old / 'staging-keep').write_bytes(b'unacknowledged staging must survive')
        self.dataset = self.base / 'dataset'; self.dataset.mkdir()
        (self.dataset / 'b').write_bytes(bytes(range(256)) * 9)
        (self.dataset / 'a').write_bytes(b'expected bytes')
        self.config = self.base / 'config.yaml'
        self.before = f'data:\n  backend: s3\ncache:\n  root: {self.old}\n  read_ssd_bytes: 8589934592\n  write_memory_bytes: 268435456\nlayout:\n  block_size: 4194304\n'
        self.config.write_text(self.before)
        self.log = self.base / 'brewfs.log'; self.log.write_text('healthy\n')
        self.out = self.base / 'evidence'
        patch = mock.patch.dict(os.environ, {}, clear=False); patch.start(); self.addCleanup(patch.stop)
        os.environ.pop('BREWFS_CACHE_ROOT', None)
    def run_gate(self, **kwargs):
        driver = FakeMount(self.dataset, self.log, **kwargs)
        result = gate.validate(self.dataset, self.config, self.log, self.out, driver, self.owner)
        self.assertEqual(json.loads((self.out / 'receipt.json').read_text()), result)
        return result, driver
    def test_success_full_inventory_only_root_changed(self):
        r, d = self.run_gate(); self.assertTrue(r['passed'], r); self.assertTrue(d.started_empty)
        self.assertEqual(d.calls, ['current', 'unmount', 'start'])
        self.assertEqual((r['file_count'], r['logical_bytes']), (2, 2318))
        self.assertEqual(self.config.read_text(), self.before.replace(str(self.old), r['new_cache_root']))
        self.assertEqual((self.old / 'staging-keep').read_bytes(), b'unacknowledged staging must survive')
        self.assertEqual(json.loads((self.out / 'expected.json').read_text()), json.loads((self.out / 'observed.json').read_text()))
        self.assertEqual((self.out / 'new-cache-root.txt').read_text().strip(), r['new_cache_root'])
        for n in ('warm_hash_ns', 'unmount_ns', 'remount_ns', 'cold_hash_ns', 'total_validation_ns'): self.assertGreater(r[n], 0)
        self.assertTrue(r['timing_outside_measured_tool_and_strict_drain'])
    def test_canonical_alias(self):
        self.config.write_text(self.before.replace('  root:', '  cache_root:'))
        r, _ = self.run_gate(); self.assertTrue(r['passed'])
        self.assertEqual(self.config.read_text(), self.before.replace('  root:', '  cache_root:').replace(str(self.old), r['new_cache_root']))
    def test_cold_content_mismatch(self):
        r, _ = self.run_gate(action=lambda d, r: (d.dataset / 'a').write_bytes(b'wrong bytes'))
        self.assertFalse(r['passed']); self.assertIn('SHA differs', r['reasons'][0])
    def test_cold_missing_file(self):
        r, _ = self.run_gate(action=lambda d, r: (d.dataset / 'a').unlink())
        self.assertFalse(r['passed']); self.assertIn('inventory', r['reasons'][0])
    def test_cold_extra_file(self):
        r, _ = self.run_gate(action=lambda d, r: (d.dataset / 'c').write_bytes(b'extra'))
        self.assertFalse(r['passed'])
    def test_unmount_timeout_preserves_old(self):
        r, d = self.run_gate(unmount=TimeoutError('old process alive'))
        self.assertFalse(r['passed']); self.assertEqual(d.calls, ['current', 'unmount'])
        self.assertEqual(self.config.read_text(), self.before)
        self.assertFalse((self.owner / 'cache-durability').exists())
        self.assertTrue((self.old / 'staging-keep').exists())
    def test_forced_unmount_rejected(self):
        r, d = self.run_gate(unmount=dict(forced=True, old_process_terminated=True))
        self.assertFalse(r['passed']); self.assertNotIn('start', d.calls)
    def test_unterminated_unmount_rejected(self):
        r, d = self.run_gate(unmount=dict(forced=False, old_process_terminated=False))
        self.assertFalse(r['passed']); self.assertNotIn('start', d.calls)
    def test_different_binary_rejected(self):
        r, _ = self.run_gate(action=lambda d, r: r.update(executable_sha256='different'))
        self.assertFalse(r['passed']); self.assertEqual(r['phase'], 'cold_remount')
    def test_changed_mount_arguments_rejected(self):
        r, _ = self.run_gate(action=lambda d, r: r.update(argv=['different']))
        self.assertFalse(r['passed']); self.assertIn('arguments changed', r['reasons'][0])
    def test_same_process_rejected(self):
        r, _ = self.run_gate(action=lambda d, r: r.update(pid=10))
        self.assertFalse(r['passed'])
    def test_duplicate_alias(self):
        self.config.write_text(self.before.replace('cache:\n', f'cache:\n  cache_root: {self.old}\n'))
        r, d = self.run_gate(); self.assertFalse(r['passed']); self.assertEqual(d.calls, [])
    def test_unowned_root(self):
        self.config.write_text(self.before.replace(str(self.old), str(self.base / 'elsewhere')))
        r, d = self.run_gate(); self.assertFalse(r['passed']); self.assertEqual(d.calls, [])
    def test_symlink_root(self):
        link = self.owner / 'cache-link'; link.symlink_to(self.old)
        self.config.write_text(self.before.replace(str(self.old), str(link)))
        r, d = self.run_gate(); self.assertFalse(r['passed']); self.assertEqual(d.calls, [])
    def test_env_mismatch(self):
        os.environ['BREWFS_CACHE_ROOT'] = str(self.owner / 'cache-other')
        r, d = self.run_gate(); self.assertFalse(r['passed']); self.assertEqual(d.calls, [])
    def test_empty_dataset(self):
        for p in self.dataset.iterdir(): p.unlink()
        r, d = self.run_gate(); self.assertFalse(r['passed']); self.assertEqual(d.calls, [])
    def test_symlink_dataset_file(self):
        (self.dataset / 'link').symlink_to(self.old / 'staging-keep')
        r, d = self.run_gate(); self.assertFalse(r['passed']); self.assertEqual(d.calls, [])
    def test_upload_failure_despite_dirty_zero(self):
        self.log.write_text('WARN pipeline upload failed, retrying: service error\nINFO dirty_bytes=0 pending=0\n')
        r, d = self.run_gate(); self.assertFalse(r['passed']); self.assertEqual(d.calls, [])
        self.assertEqual(r['log_failures_before'][0]['line'], 1)
        self.assertNotIn('service error', json.dumps(r))
    def test_post_remount_recovery_failure(self):
        r, _ = self.run_gate(action=lambda d, r: d.log.write_text('WARN recovery upload failed\n'))
        self.assertFalse(r['passed']); self.assertTrue(r['log_failures_after'])

class LogPolicyTests(unittest.TestCase):
    def test_only_frozen_warn_visible_filters(self):
        self.assertEqual(gate.QUALIFIED_LOG_FILTERS, frozenset(('warn', 'brewfs=info,asyncfuse::raw::logfs=debug', 'warn,asyncfuse::raw::logfs=debug')))
        self.assertNotIn('error', gate.QUALIFIED_LOG_FILTERS)
        self.assertNotIn('warn,brewfs::vfs::io::writer=error', gate.QUALIFIED_LOG_FILTERS)

class UnmountTests(unittest.TestCase):
    def test_waits_for_pid_exit_then_checks_mount_absent(self):
        d = gate.RealMount('/mnt/brewfs', '/run/brewfs/config.yaml', '/run/brewfs/perf-mount.pid', 2)
        live = dict(pid=5, starttime='10', state='S')
        with mock.patch.object(gate.subprocess, 'run') as cmd, mock.patch.object(gate, 'process_identity', side_effect=[live, None]) as proc, mock.patch.object(d, 'mounted', return_value=False), mock.patch.object(gate.time, 'sleep'):
            r = d.unmount(live)
        self.assertTrue(r['old_process_terminated']); self.assertFalse(r['forced']); self.assertEqual(proc.call_count, 2)
        cmd.assert_called_once_with(['fusermount3', '-u', '/mnt/brewfs'], check=True, timeout=2)
    def test_timeout_no_signal_or_force(self):
        d = gate.RealMount('/mnt/brewfs', '/run/brewfs/config.yaml', '/run/brewfs/perf-mount.pid', 2)
        live = dict(pid=5, starttime='10', state='S')
        with mock.patch.object(gate.subprocess, 'run') as cmd, mock.patch.object(gate, 'process_identity', return_value=live), mock.patch.object(gate.time, 'monotonic', side_effect=[0, 3]):
            with self.assertRaises(TimeoutError): d.unmount(live)
        self.assertEqual(cmd.call_count, 1)

class ShellTests(unittest.TestCase):
    def test_syntax_and_hook_after_strict_drain(self):
        p = Path(__file__).with_name('run-measured-perf-in-container.sh')
        subprocess.run(['bash', '-n', str(p)], check=True)
        t = p.read_text()
        self.assertIn('wait_for_fio_post_write_drain "$tool" || fio_status=1\n    if (( fio_status == 0 )); then\n        verify_fio_remote_durability "$tool" "$work_dir" || fio_status=1', t)
        self.assertIn('[[ ! -e "$artifact_dir/remote-durability.invalid" ]] || return 1', t)
    def call(self, status, drain='true', tool='fio-bigwrite'):
        with tempfile.TemporaryDirectory() as tmp:
            base = Path(tmp)
            t = Path(__file__).with_name('run-measured-perf-in-container.sh').read_text()
            fn = t[t.index('verify_fio_remote_durability() {'):t.index('\nrun_fio_profile() {')]
            code = r'''
set -euo pipefail
artifact_dir="$1"; stub_status="$2"; PERF_FIO_POST_WRITE_DRAIN="$3"; tool="$4"
mount_dir=/mnt/brewfs; config_path=/run/brewfs/config.yaml; log_file="$artifact_dir/brewfs.log"
truthy_env() { [[ "$1" == true ]]; }
info() { :; }; ok() { :; }; err() { :; }
timeout() {
  mkdir -p "$artifact_dir/remote-durability/$tool"
  printf '/var/lib/brewfs/cache-durability/new\n' >"$artifact_dir/remote-durability/$tool/new-cache-root.txt"
  return "$stub_status"
}
''' + fn + r'''
result=0
verify_fio_remote_durability "$tool" /mnt/brewfs/.perf-fio-bigwrite || result=$?
printf '%s\n%s\n' "$result" "${BREWFS_CACHE_ROOT:-unset}"
[[ ! -f "$artifact_dir/remote-durability.invalid" ]] || printf 'invalid\n'
'''
            p = subprocess.run(['bash', '-c', code, 'gate', str(base), str(status), drain, tool], text=True, capture_output=True, check=True)
            summary = (base / 'perf-summary.tsv').read_text() if (base / 'perf-summary.tsv').exists() else ''
            return p.stdout.splitlines(), summary
    def test_success_exports_verified_root(self):
        lines, summary = self.call(0); self.assertEqual(lines, ['0', '/var/lib/brewfs/cache-durability/new']); self.assertEqual(summary, '')
    def test_failure_marks_campaign_invalid(self):
        lines, summary = self.call(1); self.assertIn('invalid', lines); self.assertIn('fio-bigwrite-remote-durability\tfail(1)', summary)
    def test_timeout_marks_campaign_invalid(self):
        lines, summary = self.call(124); self.assertIn('invalid', lines); self.assertIn('fail(124)', summary)
    def test_requires_strict_drain(self):
        lines, _ = self.call(0, drain='false'); self.assertEqual(lines, ['1', 'unset', 'invalid'])
    def test_readonly_not_reinterpreted_as_write(self):
        lines, _ = self.call(0, tool='fio-bigread'); self.assertEqual(lines, ['0', 'unset'])

if __name__ == '__main__': unittest.main(verbosity=2)
