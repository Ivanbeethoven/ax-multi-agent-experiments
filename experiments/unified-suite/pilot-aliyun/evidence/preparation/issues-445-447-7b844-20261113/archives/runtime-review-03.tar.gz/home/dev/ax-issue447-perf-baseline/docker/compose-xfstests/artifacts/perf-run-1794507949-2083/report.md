# BrewFS Perf Report

Meta backend: redis

## Summary

| Tool | Status | Seconds | Log |
| --- | --- | ---: | --- |
| fio-seqwrite-direct0 | pass | 21 | tools/fio-seqwrite-direct0.log |
| fio-seqwrite-direct1 | pass | 20 | tools/fio-seqwrite-direct1.log |
| fio-randwrite-direct0 | pass | 27 | tools/fio-randwrite-direct0.log |
| fio-randwrite-direct0-remote-durability | fail(1) | 0 | tools/receipt.json |

## Post-Write Drain

| Tool | Drain seconds | Pending bytes | Dirty bytes | Buffer dirty bytes |
| --- | ---: | ---: | ---: | ---: |
| fio-seqwrite-direct0 | 44 | 0 | 0 | 0 |
| fio-seqwrite-direct1 | 44 | 0 | 0 | 0 |
| fio-randwrite-direct0 | 44 | 0 | 0 | 0 |

## Fio

| Tool | Workload | Direct | BS | Jobs | Read BW | Read IOPS | Write BW | Write IOPS | Read P99 | Write P99 | Raw |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |---: | ---: | ---: |
| fio-randwrite-direct0 | randwrite | 0 | 4m | 4 | 0.00 B/s | 0.00 | 151.42 MiB/s | 37.85 | 0.000 ms | 68.682 ms | results/fio-randwrite-direct0.json |
| fio-seqwrite-direct0 | write | 0 | 4m | 1 | 0.00 B/s | 0.00 | 190.01 MiB/s | 47.50 | 0.000 ms | 60.031 ms | results/fio-seqwrite-direct0.json |
| fio-seqwrite-direct1 | write | 1 | 4m | 1 | 0.00 B/s | 0.00 | 182.06 MiB/s | 45.52 | 0.000 ms | 0.005 ms | results/fio-seqwrite-direct1.json |

## Fio Runtime Accounting

Use `active_io_runtime` for close/flush tail detection; fio `job_runtime_ms` can aggregate multiple jobs under group reporting.

| Tool | Direct | Script wall | fio job_runtime | wall-job_runtime | wall/job_runtime | active_io_runtime | wall-active_io | wall/active_io | Tail marker |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| fio-randwrite-direct0 | 0 | 27 s | 104.390 s | -77.390 s | 0.26x | 26.100 s | +0.900 s | 1.03x | fio job_runtime aggregates jobs |
| fio-seqwrite-direct0 | 0 | 21 s | 20.251 s | +0.749 s | 1.04x | 20.252 s | +0.748 s | 1.04x | - |
| fio-seqwrite-direct1 | 1 | 20 s | 20.014 s | -0.014 s | 1.00x | 20.015 s | -0.015 s | 1.00x | fio job_runtime aggregates jobs |

## Fully Drained Write Throughput

Actual fio bytes divided by `active_io_runtime + post_write_drain`; unlike foreground bandwidth, this includes the time required to empty the filesystem writeback queue.

| Tool | Active I/O | Drain | Complete | Read | Write | Total | Raw |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| fio-randwrite-direct0 | 26.100 s | 44.000 s | 70.100 s | 0.00 MiB/s | 56.38 MiB/s | 56.38 MiB/s | fully-drained-throughput.tsv |
| fio-seqwrite-direct0 | 20.252 s | 44.000 s | 64.252 s | 0.00 MiB/s | 59.89 MiB/s | 59.89 MiB/s | fully-drained-throughput.tsv |
| fio-seqwrite-direct1 | 20.015 s | 44.000 s | 64.015 s | 0.00 MiB/s | 56.92 MiB/s | 56.92 MiB/s | fully-drained-throughput.tsv |

## Latency Percentiles

### Read

| Workload | p1 | p5 | p25 | p50 | p75 | p90 | p95 | p99 | p99.9 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |

### Write

| Workload | p1 | p5 | p25 | p50 | p75 | p90 | p95 | p99 | p99.9 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| fio-randwrite-direct0 | 0.000 ms | 0.000 ms | 0.000 ms | 15.401 ms | 0.000 ms | 0.000 ms | 43.254 ms | 68.682 ms | 17112.760 ms |
| fio-seqwrite-direct0 | 0.000 ms | 0.000 ms | 0.000 ms | 5.210 ms | 0.000 ms | 0.000 ms | 28.967 ms | 60.031 ms | 4462.739 ms |
| fio-seqwrite-direct1 | 0.000 ms | 0.000 ms | 0.000 ms | 0.002 ms | 0.000 ms | 0.000 ms | 0.004 ms | 0.005 ms | 0.059 ms |

## Redis Diagnostics

| Tool | Top commandstats | Details |
| --- | --- | --- |
| fio-randwrite-direct0 | evalsha: calls=556, usec/call=59.13<br>exec: calls=992, usec/call=3.15<br>rpush: calls=523, usec/call=4.06<br>get: calls=1527, usec/call=1.20<br>incrby: calls=523, usec/call=2.53 | diagnostics/redis-fio-randwrite-direct0-after.txt |
| fio-seqwrite-direct0 | evalsha: calls=87, usec/call=64.71<br>exec: calls=963, usec/call=3.61<br>get: calls=1029, usec/call=1.69<br>multi: calls=963, usec/call=0.77<br>hget: calls=984, usec/call=0.71 | diagnostics/redis-fio-seqwrite-direct0-after.txt |
| fio-seqwrite-direct1 | evalsha: calls=81, usec/call=66.75<br>exec: calls=912, usec/call=3.10<br>get: calls=974, usec/call=1.45<br>multi: calls=912, usec/call=0.65<br>hget: calls=932, usec/call=0.59 | diagnostics/redis-fio-seqwrite-direct1-after.txt |

## BrewFS Stats

Counters are per-tool deltas when matching before/after snapshots exist; dirty, live, and inflight values are after-tool gauges.

| Tool | Cache hit | FUSE read | FUSE write | Dirty | Live dirty | Recent pending | Recent uploaded | Read buffer | S3 ops | S3 avg latency | Details |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: | --- |
| fio-randwrite-direct0 | 100.0% (74/74) | 0.0 MiB | 3952.0 MiB | 3084.0 MiB | 0.0 MiB | 3084.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=222 | GET=288.75 ms, PUT=691.71 ms | diagnostics/stats-fio-randwrite-direct0-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=523 ops/3952.0 MiB/129246.0 ms, foreground=stage 129.25s/commit_wait 2.48s, flush_wait=4 ops/0.02s/4 slices, stage_fail=0, commit_before_stage=401, remote_inflight=3084.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=22, max_buffer_dirty=3560.0 MiB, max_live_dirty=1044.0 MiB, max_live_slices=145, max_recent_pending=3560.0 MiB, max_recent_uploaded=0.0 MiB, max_stage_inflight=612.0 MiB, max_remote_inflight=3560.0 MiB, last_buffer_dirty=3144.0 MiB, slices=create 523/reuse 3429/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=523 avg=7.6 MiB blocks=1.89/batch partial_tail=0.00 (size 0/max 0/flush 0/auto 2/age 0), partial_origin=normal 2/cached 0/mixed 0/unknown 0, auto_detail=age 1/idle 1/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 2/cached 0/mixed 0/unknown 0, freeze=size 63/flush 4/auto 321/max 135/age 0 |
| fio-randwrite-direct0-post-write-drained | 0.0% (0/0) | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=766 | GET=288.75 ms, PUT=296.12 ms | diagnostics/stats-fio-randwrite-direct0-post-write-drained-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=0 ops/0.0 MiB/0.0 ms, foreground=stage 0.00s/commit_wait 0.00s, flush_wait=0 ops/0.00s/0 slices, stage_fail=0, commit_before_stage=0, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 523/reuse 3429/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=0 avg=n/a blocks=0.00/batch partial_tail=0.00 (size 0/max 0/flush 0/auto 0/age 0), partial_origin=normal 0/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 0/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 0/cached 0/mixed 0/unknown 0, freeze=size 63/flush 4/auto 321/max 135/age 0 |
| fio-randwrite-direct0-post-write-runner-drained | 84.9% (1070/1261) | 512.0 MiB | 3952.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=176, PUT=1037 | GET=288.75 ms, PUT=368.23 ms | diagnostics/stats-fio-randwrite-direct0-post-write-runner-drained-after.txt; range=0, full=176, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=523 ops/3952.0 MiB/129246.0 ms, foreground=stage 129.25s/commit_wait 2.48s, flush_wait=4 ops/0.02s/4 slices, stage_fail=0, commit_before_stage=401, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 523/reuse 3429/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=523 avg=7.6 MiB blocks=1.89/batch partial_tail=0.00 (size 0/max 0/flush 0/auto 2/age 0), partial_origin=normal 2/cached 0/mixed 0/unknown 0, auto_detail=age 1/idle 1/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 2/cached 0/mixed 0/unknown 0, freeze=size 63/flush 4/auto 321/max 135/age 0 |
| fio-seqwrite-direct0 | 0.0% (0/0) | 0.0 MiB | 3848.0 MiB | 3016.0 MiB | 0.0 MiB | 3016.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=212 | GET=0.00 ms, PUT=569.76 ms | diagnostics/stats-fio-seqwrite-direct0-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=64 ops/3848.0 MiB/10665.5 ms, foreground=stage 10.67s/commit_wait 0.74s, flush_wait=2 ops/0.01s/2 slices, stage_fail=0, commit_before_stage=64, remote_inflight=3016.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=17, max_buffer_dirty=3074.0 MiB, max_live_dirty=67.0 MiB, max_live_slices=2, max_recent_pending=3074.0 MiB, max_recent_uploaded=0.0 MiB, max_stage_inflight=192.0 MiB, max_remote_inflight=3074.0 MiB, last_buffer_dirty=3051.0 MiB, slices=create 64/reuse 3785/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=64 avg=60.1 MiB blocks=15.08/batch partial_tail=0.08 (size 2/max 0/flush 1/auto 2/age 0), partial_origin=normal 5/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 2/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 2/cached 0/mixed 0/unknown 0, freeze=size 60/flush 2/auto 2/max 0/age 0 |
| fio-seqwrite-direct0-post-write-drained | 0.0% (0/0) | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=753 | GET=0.00 ms, PUT=313.06 ms | diagnostics/stats-fio-seqwrite-direct0-post-write-drained-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=0 ops/0.0 MiB/0.0 ms, foreground=stage 0.00s/commit_wait 0.00s, flush_wait=0 ops/0.00s/0 slices, stage_fail=0, commit_before_stage=0, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 64/reuse 3785/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=0 avg=n/a blocks=0.00/batch partial_tail=0.00 (size 0/max 0/flush 0/auto 0/age 0), partial_origin=normal 0/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 0/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 0/cached 0/mixed 0/unknown 0, freeze=size 60/flush 2/auto 2/max 0/age 0 |
| fio-seqwrite-direct0-post-write-runner-drained | 0.0% (0/0) | 0.0 MiB | 3848.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=965 | GET=0.00 ms, PUT=369.46 ms | diagnostics/stats-fio-seqwrite-direct0-post-write-runner-drained-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=64 ops/3848.0 MiB/10665.5 ms, foreground=stage 10.67s/commit_wait 0.74s, flush_wait=2 ops/0.01s/2 slices, stage_fail=0, commit_before_stage=64, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 64/reuse 3785/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=64 avg=60.1 MiB blocks=15.08/batch partial_tail=0.08 (size 2/max 0/flush 1/auto 2/age 0), partial_origin=normal 5/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 2/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 2/cached 0/mixed 0/unknown 0, freeze=size 60/flush 2/auto 2/max 0/age 0 |
| fio-seqwrite-direct1 | 0.0% (0/0) | 0.0 MiB | 3644.0 MiB | 3068.0 MiB | 0.0 MiB | 3068.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=153 | GET=328.93 ms, PUT=780.17 ms | diagnostics/stats-fio-seqwrite-direct1-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=58 ops/3584.0 MiB/23057.5 ms, foreground=stage 23.06s/commit_wait 0.46s, flush_wait=1 ops/0.02s/1 slices, stage_fail=0, commit_before_stage=59, remote_inflight=3068.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=17, max_buffer_dirty=3088.0 MiB, max_live_dirty=100.0 MiB, max_live_slices=2, max_recent_pending=3088.0 MiB, max_recent_uploaded=0.0 MiB, max_stage_inflight=576.0 MiB, max_remote_inflight=3088.0 MiB, last_buffer_dirty=3068.0 MiB, slices=create 59/reuse 3585/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=59 avg=61.8 MiB blocks=15.46/batch partial_tail=0.03 (size 1/max 0/flush 0/auto 1/age 0), partial_origin=normal 2/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 1/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 1/cached 0/mixed 0/unknown 0, freeze=size 56/flush 1/auto 2/max 0/age 0 |
| fio-seqwrite-direct1-post-write-drained | 0.0% (0/0) | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=0, PUT=757 | GET=328.93 ms, PUT=305.66 ms | diagnostics/stats-fio-seqwrite-direct1-post-write-drained-after.txt; range=0, full=0, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=0 ops/0.0 MiB/0.0 ms, foreground=stage 0.00s/commit_wait 0.00s, flush_wait=0 ops/0.00s/0 slices, stage_fail=0, commit_before_stage=0, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 59/reuse 3585/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=0 avg=n/a blocks=0.00/batch partial_tail=0.00 (size 0/max 0/flush 0/auto 0/age 0), partial_origin=normal 0/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 0/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 0/cached 0/mixed 0/unknown 0, freeze=size 56/flush 1/auto 2/max 0/age 0 |
| fio-seqwrite-direct1-post-write-runner-drained | 86.4% (1052/1217) | 512.0 MiB | 3644.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | 0.0 MiB | GET=162, PUT=944 | GET=328.93 ms, PUT=372.98 ms | diagnostics/stats-fio-seqwrite-direct1-post-write-runner-drained-after.txt; range=0, full=162, bg_prefetch=0, persistent_slice=0 ops/0.0 MiB, stage=59 ops/3644.0 MiB/23146.5 ms, foreground=stage 23.15s/commit_wait 0.46s, flush_wait=1 ops/0.02s/1 slices, stage_fail=0, commit_before_stage=59, remote_inflight=0.0 MiB, buffer_sleep=soft 0/0.0ms moderate 0/0.0ms hard 0/0.0ms, samples=n/a, slices=create 59/reuse 3585/reject_unique 0/reject_prefix 0, live_slices=0 avg=n/a, origin=normal 0/cached 0/mixed 0/unknown 0, upload_batch=59 avg=61.8 MiB blocks=15.46/batch partial_tail=0.03 (size 1/max 0/flush 0/auto 1/age 0), partial_origin=normal 2/cached 0/mixed 0/unknown 0, auto_detail=age 0/idle 1/pressure 0/too_many 0/buffer_high 0/flush_duration 0/unknown 0, auto_origin=normal 1/cached 0/mixed 0/unknown 0, freeze=size 56/flush 1/auto 2/max 0/age 0 |
