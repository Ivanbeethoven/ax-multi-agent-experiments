import json
from pathlib import Path
import verify_remote_durability as gate
base = Path('/home/dev/ax-perf-issues-validation/runtime-review-01')
trial = base / 'home/dev/ax-perf-issues-validation/compose/trials/ax447-baseline-cached-smoke-102/receipt.json'
t = json.loads(trial.read_text())
art = base / t['artifact_directories'][0].lstrip('/')
log = art / 'brewfs.log'
failures = gate.scan_failures(log)
summary = (art / 'perf-summary.tsv').read_text()
post = (art / 'post-write-drain.tsv').read_text()
stats = art / 'diagnostics/stats-fio-bigwrite-post-write-drained-after.txt'
selected = {}
for line in stats.read_text().splitlines():
    if not line.startswith('#') and ('dirty_bytes' in line or 'pending_bytes' in line):
        parts = line.split()
        if len(parts) == 2: selected[parts[0]] = parts[1]
assert t['status'] == 0
assert '\tfio-bigwrite' not in summary # tool is at start of line
assert 'fio-bigwrite\tpass\t' in summary
assert failures
assert selected and all(float(v) == 0 for v in selected.values())
result = {'passed': True, 'scope': 'offline replay of new WARN rejection against archived previously accepted failure; no new FUSE experiment', 'trial': 102, 'arm': 'baseline', 'old_runner_status': t['status'], 'old_tool_summary': summary.splitlines(), 'old_post_write_drain': post.splitlines(), 'old_final_dirty_pending_counters': selected, 'new_gate_rejects': True, 'failure_count': len(failures), 'failure_lines': failures, 'source_artifacts': [{'path': str(p), 'bytes': p.stat().st_size, 'sha256': gate.file_sha(p)} for p in (trial, log, art/'perf-summary.tsv', art/'post-write-drain.tsv', stats)]}
out = Path(__file__).with_name('archived-102-red-receipt.json')
gate.write_json(out, result)
print(json.dumps({'passed': True, 'old_runner_status': 0, 'new_gate_rejects': True, 'failure_count': len(failures), 'receipt': str(out)}))
