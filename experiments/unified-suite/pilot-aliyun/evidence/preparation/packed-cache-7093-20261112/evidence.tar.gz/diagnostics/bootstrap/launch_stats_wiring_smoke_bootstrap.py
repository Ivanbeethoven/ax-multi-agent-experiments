#!/usr/bin/env python3
"""Run the frozen 128-file qualification as debug wiring evidence only."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--directory', type=Path, required=True)
p.add_argument('--binary', type=Path, required=True)
p.add_argument('--producer', type=Path, required=True)
a = p.parse_args()
root = a.directory.resolve()
assert root.is_relative_to('/srv/packed') and root != Path('/srv/packed')
root.mkdir(exist_ok=False)
repo = Path('/srv/packed/ax-packed-brewfs')
env = dict(os.environ, GIT_OPTIONAL_LOCKS='0', NO_COLOR='1')
scripts = Path('/srv/packed/ax-packed-exp/experiments/unified-suite/pilot-aliyun/scripts')
harness = scripts / 'qualify-packed-cache.py'
assert hashlib.sha256(harness.read_bytes()).hexdigest() == '9ef4bc8d176355ab3fc14f8825c4daaedac2a93e504d9403d90b3eb1457462ba'
helper = scripts / 'packed_native_probe.py'
assert hashlib.sha256(helper.read_bytes()).hexdigest() == '6dcdff62148fc5e210641e8e92bde8482c1b666d7193115e27f33453b14e2177'
assert not any(s.strip().startswith(('cargo', 'rustc')) for s in
               subprocess.check_output(['ps', '-eo', 'comm='], text=True).splitlines())

def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

record = dict(scope='debug correctness and stats wiring only; timings are excluded from performance qualification',
              started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              binary_sha256=sha(a.binary), producer_sha256=sha(a.producer),
              binary_version=subprocess.check_output([str(a.binary), '--version'], text=True, env=env),
              source_commit=subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True, env=env).strip(),
              source_status=subprocess.check_output(['git', '-C', str(repo), 'status', '--porcelain'], text=True, env=env),
              harness_base_commit='5f675be4c0861b54e94edbbe395c2ed85727cec7',
              harness_status='bootstrap follow-up pending AX commit; exact source hashes frozen below',
              harness_sha256=sha(harness), helper_sha256=sha(helper))
(root / 'invocation.json').write_text(json.dumps(record, indent=2) + '\n')
result_path = root / 'debug-wiring.json'
cmd = [sys.executable, str(harness), str(result_path), '--binary', str(a.binary),
       '--producer', str(a.producer), '--files', '128', '--order', 'off-on']
with (root / 'run.log').open('x') as log:
    completed = subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT, env=env, timeout=660)
result = json.loads(result_path.read_text()) if result_path.exists() else {}
reasons = []
if completed.returncode != 0 or not result.get('passed'):
    reasons.append('frozen native/proxy qualification failed')
rows = {}
for path in sorted(root.glob('debug-wiring-raw/native-*.stats')):
    fields = {}
    for name in ('hits_total', 'misses_total', 'hit_ratio'):
        matches = re.findall(r'^brewfs_workspace_row_cache_' + name + r' ([0-9]+(?:\.[0-9]+)?)$',
                             path.read_text(), flags=re.M)
        if len(matches) != 1:
            reasons.append('missing/duplicate row metric in ' + path.name + ': ' + name)
        else:
            fields[name] = float(matches[0])
    rows[path.name] = fields
if len(rows) != 20:
    reasons.append('expected 20 raw snapshots including four explicit bootstraps')
arms = result.get('readbacks', {})
for side in ('off-0', 'on-1', 'off-2', 'on-3'):
    if not arms.get(side, {}).get('native', {}).get('passed'):
        reasons.append('native gate missing or failed for ' + side)
receipt = dict(scope=record['scope'], passed=not reasons, reasons=reasons,
               raw_result='debug-wiring.json', row_snapshots=rows,
               frozen_native_gate_passed=result.get('passed', False), cleanup=result.get('cleanup'))
(root / 'wiring-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(dict(passed=receipt['passed'], reasons=reasons, directory=str(root))))
raise SystemExit(0 if receipt['passed'] else 1)
