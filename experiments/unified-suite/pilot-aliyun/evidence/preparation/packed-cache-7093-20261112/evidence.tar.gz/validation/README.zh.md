最终源码 `7093f141d8081e6b96cd0a80814876aed5a3b577`，分支 `codex/packed-prefetch`，树 `6a14aabea9a36693edea67dad39722db468123e6`。最终提交树与完整 CI 的测试树完全相同；release 从 clean 源码构建，版本输出校验 commit/branch/dirty=false，两个产物 SHA 保存在 `release/binaries.sha256`。

这次修复真实 Shared workspace 挂载中第二次统计注册被 OnceLock 拒绝的问题：一次安装包含行缓存与 Packed 两组统计，保留既有 OnceLock 契约、完整 Packed observer 生命周期和两者渲染预算之和。启动 Output 最低预算补齐 runtime 与 row 各 256 字节；实际 CLI 安装路径的边界测试验证 exact minimum、少一个字节拒绝，以及同时持有普通读和两个回复 owner 的预算占用。

真实 FUSE 接线 RED 使用 65bc 原始挂载证据。debug02 四组开关臂全部通过，20 份原始快照同时具有两类统计，原生计数与代理流量逐阶段严格一致，清理全部成功。第一次 `.stats` 的元数据初始化由显式 bootstrap 记录，开销纳入 mount/E2E；随后 baseline 必须稳定。该协议使第一次文件遍历之前已有采样元数据预热，不能与旧 6912 无 prelude 的冷态直接等同。debug 运行仅用于正确性，不作为性能改善证据。

完整 CI 使用 `RUST_TEST_THREADS=4`。实际 feature 的所有测试 binary 合计 2847 passed / 483 ignored / 0 failed；默认 workspace 合计 1356 passed / 265 ignored / 0 failed。此外包括全部目标类型检查、格式、compose 脚本回归、默认 check/build、两种 FUSE runtime 检查、Clippy 与 all-targets warnings-as-errors。逐条命令和时间在 `attempt-03/ci/gates.log`，逐 binary 计数和总计同时保存在 `validation-summary.json`。

失败记录原样保留：attempt01 暴露旧最大枚举夹具遗漏新增 512 字节，随后仅修正两处预算公式；attempt02 出现未修改的 entity writeback 200ms 本地 staging 超时。同一冻结测试二进制单例连续十次通过，完整测试以四线程重跑通过；未改动该断言或超时。记录位于相应 attempt 的日志及 `attempt-02/ci/timing-repro.log`。

此归档证明源码与构建检查、真实统计接线和预算契约；最终 release 的开关性能资格由独立 campaign 给出。CI/构建期间允许资源隔离的并行 issue 构建，正式性能测量必须在全部构建和传输结束后开始。
