#!/bin/bash
set -euo pipefail
exec 9>/srv/packed/retry-evidence/heavy.lock
flock -n 9
if pgrep -x cargo || pgrep -x rustc; then exit 9; fi
cd /srv/packed/ax-packed-brewfs
export PATH=/root/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin:$PATH
export RUSTUP_TOOLCHAIN=stable-x86_64-unknown-linux-gnu CARGO_HOME=/root/.cargo CARGO_TARGET_DIR=/srv/packed/target
export CARGO_BUILD_JOBS=3 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0
exec > /srv/packed/retry-evidence/red.log 2>&1
date -u +%FT%TZ
git rev-parse HEAD
set +e
timeout -k 15 1800 cargo test --locked --lib --features workspace,observability,rustfs-ec-block-size-hint failed_download_retries_without_releasing_a_pinned_disk_reservation -- --nocapture
status=$?
set -e
printf '
exit_code=%s
' "$status"
date -u +%FT%TZ
if [[ $status -ne 101 ]] || ! grep -Fq 'a failed fill must not permanently poison later requests: injected tail failure' /srv/packed/retry-evidence/red.log; then
  exit 1
fi
printf 'EXPECTED_RED_CONFIRMED
'
