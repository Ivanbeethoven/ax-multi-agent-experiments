#!/bin/bash
set -euo pipefail
exec 9>/srv/packed/retry-evidence/heavy.lock
flock -n 9
cd /srv/packed/ax-packed-brewfs
export PATH=/root/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin:$PATH
export RUSTUP_TOOLCHAIN=stable-x86_64-unknown-linux-gnu CARGO_HOME=/root/.cargo CARGO_TARGET_DIR=/srv/packed/target
export CARGO_BUILD_JOBS=3 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 GIT_OPTIONAL_LOCKS=0
EVIDENCE=/srv/packed/stats-wiring-validation/attempt-02/ci
mkdir -p "$EVIDENCE"
python3 - <<'PY'
import json
from pathlib import Path
p = Path('/srv/packed/stats-wiring-debug-02/wiring-receipt.json')
d = json.loads(p.read_text())
assert d['passed'] is True and d['frozen_native_gate_passed'] is True, d
assert not d['reasons'], d
assert len(d['row_snapshots']) == 20, d
def all_true(v):
    return all(all_true(x) for x in v.values()) if isinstance(v, dict) else v is True
assert all_true(d['cleanup']), d
print('DEBUG_FUSE_SMOKE_PASSED', p)
PY
exec > "$EVIDENCE/gates.log" 2>&1
run_gate() {
    local name="$1"; shift
    printf '\nSTART %s ' "$name"; date -u +%FT%TZ
    printf 'COMMAND'; printf ' %q' "$@"; printf '\n'
    if "$@" > "$EVIDENCE/$name.log" 2>&1; then
        printf 'PASS %s ' "$name"; date -u +%FT%TZ
    else
        status=$?
        printf 'FAIL %s exit=%s ' "$name" "$status"; date -u +%FT%TZ
        tail -n 60 "$EVIDENCE/$name.log"
        exit "$status"
    fi
}
git rev-parse HEAD
# The independent issue target may compile concurrently under root's resource limits.
git diff --binary > "$EVIDENCE/tested-source.patch"
sha256sum "$EVIDENCE/tested-source.patch"
printf '%s  %s\n' 2ffef62dca5f831bc2190845ca32eed3a6e47b776ed51589ee27e7431fbe6b5a "$EVIDENCE/tested-source.patch" | sha256sum --check
systemctl show ax-packed-stats-wiring-full-ci-02 --property=CPUQuotaPerSecUSec,MemoryMax > "$EVIDENCE/actual-feature-resource-limits.txt"
run_gate actual-features-typecheck cargo check --locked --workspace --all-targets --features workspace,observability,rustfs-ec-block-size-hint
run_gate actual-feature-tests timeout -k 15 1800 cargo test --locked --workspace --lib --bins --features workspace,observability,rustfs-ec-block-size-hint
systemctl set-property --runtime ax-packed-stats-wiring-full-ci-02 MemoryMax=34G CPUQuota=450%
systemctl show ax-packed-stats-wiring-full-ci-02 --property=CPUQuotaPerSecUSec,MemoryMax > "$EVIDENCE/remaining-resource-limits.txt"
printf 'READY_FOR_ISSUE_BUILD '; date -u +%FT%TZ
run_gate fmt cargo fmt --all --check
run_gate scripts bash -c 'for f in run_perf_in_container.sh run_redis_perf.sh run_juicefs_perf_in_container.sh run_juicefs_perf.sh; do bash -n docker/compose-xfstests/$f || exit; done; for f in test_perf_report_delta.sh test_juicefs_direct_matrix.sh test_juicefs_perf_report.sh; do bash docker/compose-xfstests/$f || exit; done'
run_gate workspace-check cargo check --locked --workspace
run_gate workspace-build cargo build --locked --workspace
metadata="$(cargo metadata --no-deps --format-version 1)"
if python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); m=set(d["workspace_members"]); sys.exit(not any(p["name"]=="rfuse3" and p["id"] in m for p in d["packages"]))' <<< "$metadata"; then
    run_gate rfuse-tokio cargo check --locked -p rfuse3 --no-default-features --features tokio-runtime
    run_gate rfuse-uring cargo check --locked -p rfuse3 --no-default-features --features io-uring-runtime
    run_gate rfuse-asyncio cargo check --locked -p rfuse3 --no-default-features --features async-io-runtime
fi
run_gate fuse-tokio cargo check --locked -p brewfs --no-default-features --features fuse-tokio-runtime
run_gate fuse-uring cargo check --locked -p brewfs --no-default-features --features fuse-io-uring-runtime
run_gate workspace-tests timeout -k 15 1800 cargo test --locked --workspace --lib --bins
run_gate clippy cargo clippy --locked --workspace
run_gate ci-clippy-all-targets cargo clippy --locked --workspace --all-targets -- -D warnings
run_gate diff-check git diff --check
printf 'ALL_GATES_PASSED '; date -u +%FT%TZ
