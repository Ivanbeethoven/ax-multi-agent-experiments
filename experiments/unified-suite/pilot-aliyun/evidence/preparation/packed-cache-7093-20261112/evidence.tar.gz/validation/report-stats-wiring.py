from pathlib import Path
import json
import re

p = Path('/srv/packed/stats-wiring-validation')
identity = json.loads((p / 'source-identity.json').read_text())
gates = (p / 'attempt-03/ci/gates.log').read_text()
assert 'ALL_GATES_PASSED ' in gates
assert 'RELEASE_CLEAN_IDENTITY_VERIFIED ' in (p / 'release/release.log').read_text()
debug = json.loads(Path('/srv/packed/stats-wiring-debug-02/wiring-receipt.json').read_text())
assert debug['passed'] and debug['frozen_native_gate_passed'] and len(debug['row_snapshots']) == 20
tests = {}
for name in ('actual-feature-tests', 'workspace-tests'):
    log = (p / ('attempt-03/ci/' + name + '.log')).read_text()
    tests[name] = [dict(passed=int(a), failed=int(b), ignored=int(c)) for a, b, c in
                   re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', log)]
    assert tests[name] and all(t['failed'] == 0 for t in tests[name])
totals = {name: {key: sum(row[key] for row in rows) for key in ('passed', 'failed', 'ignored')}
          for name, rows in tests.items()}
summary = {
    'scope': 'Packed shared-workspace stats registration and output admission correctness; no performance qualification',
    'source_identity': identity,
    'passed_ci_gates': re.findall(r'^PASS (\S+) (\S+)$', gates, re.M),
    'tests': tests,
    'test_totals_across_all_binaries': totals,
    'rust_test_threads': 4,
    'debug_wiring_receipt': debug,
    'binary_sha256_receipt': (p / 'release/binaries.sha256').read_text(),
    'retained_failed_attempts': [
        {'attempt': 'attempt-01', 'reason': 'Existing maximum-enum test fixture omitted both newly shared 256-byte allowances; both formulas were updated, with all assertions retained.'},
        {'attempt': 'attempt-02', 'reason': 'Unmodified entity writeback test exceeded its 200ms local-staging deadline during the full suite. Same frozen executable passed ten isolated runs. Full suite then passed with four test threads; no assertion or timeout changed.'},
    ],
}
(p / 'validation-summary.json').write_text(json.dumps(summary, indent=2) + '\n')
text = f'''最终源码 `{identity['commit']}`，分支 `codex/packed-prefetch`，树 `{identity['tree']}`。最终提交树与完整 CI 的测试树完全相同；release 从 clean 源码构建，版本输出校验 commit/branch/dirty=false，两个产物 SHA 保存在 `release/binaries.sha256`。

这次修复真实 Shared workspace 挂载中第二次统计注册被 OnceLock 拒绝的问题：一次安装包含行缓存与 Packed 两组统计，保留既有 OnceLock 契约、完整 Packed observer 生命周期和两者渲染预算之和。启动 Output 最低预算补齐 runtime 与 row 各 256 字节；实际 CLI 安装路径的边界测试验证 exact minimum、少一个字节拒绝，以及同时持有普通读和两个回复 owner 的预算占用。

真实 FUSE 接线 RED 使用 65bc 原始挂载证据。debug02 四组开关臂全部通过，20 份原始快照同时具有两类统计，原生计数与代理流量逐阶段严格一致，清理全部成功。第一次 `.stats` 的元数据初始化由显式 bootstrap 记录，开销纳入 mount/E2E；随后 baseline 必须稳定。该协议使第一次文件遍历之前已有采样元数据预热，不能与旧 6912 无 prelude 的冷态直接等同。debug 运行仅用于正确性，不作为性能改善证据。

完整 CI 使用 `RUST_TEST_THREADS=4`。实际 feature 的所有测试 binary 合计 {totals['actual-feature-tests']['passed']} passed / {totals['actual-feature-tests']['ignored']} ignored / 0 failed；默认 workspace 合计 {totals['workspace-tests']['passed']} passed / {totals['workspace-tests']['ignored']} ignored / 0 failed。此外包括全部目标类型检查、格式、compose 脚本回归、默认 check/build、两种 FUSE runtime 检查、Clippy 与 all-targets warnings-as-errors。逐条命令和时间在 `attempt-03/ci/gates.log`，逐 binary 计数和总计同时保存在 `validation-summary.json`。

失败记录原样保留：attempt01 暴露旧最大枚举夹具遗漏新增 512 字节，随后仅修正两处预算公式；attempt02 出现未修改的 entity writeback 200ms 本地 staging 超时。同一冻结测试二进制单例连续十次通过，完整测试以四线程重跑通过；未改动该断言或超时。记录位于相应 attempt 的日志及 `attempt-02/ci/timing-repro.log`。

此归档证明源码与构建检查、真实统计接线和预算契约；最终 release 的开关性能资格由独立 campaign 给出。CI/构建期间允许资源隔离的并行 issue 构建，正式性能测量必须在全部构建和传输结束后开始。
'''
(p / 'README.zh.md').write_text(text)
print(json.dumps({'commit': identity['commit'], 'test_totals': totals, 'all_ci_gates_passed': True}, indent=2))
