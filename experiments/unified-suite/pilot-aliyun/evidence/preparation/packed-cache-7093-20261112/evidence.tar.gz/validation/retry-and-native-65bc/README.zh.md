# Packed 重试与原生 I/O 计数验证

源码提交：`65bc08e2d3dc447dcda4f73ce1c3ab096722f11d`。最终分支为
`codex/packed-prefetch`，提交树为 `d9a84c5f188dde49f08fa985792703a1af0faa77`。

## 已修复行为

失败的整包下载曾永久保留在注册表中，之后同一对象的读请求反复收到旧错误。
现在旧 reader 仍保留原错误；新读在旧 reader/worker 尚持有该条目时走 Range
fallback，保留 partial 文件的全部磁盘预算计费。最后一个 pin 释放后，下次读先
删除 partial 文件并返还预留，再发起新 fill。修复没有改变 HEAD 锁或缓存策略。

默认开启整包缓存时，三条本地缓存读入口曾绕过原生远端 I/O 计数。
现在 ReadonlyBackend 与 PackCache 共享独立的 `Arc<BackendIoCounters>`，没有
Metrics/Cache 的引用环。Full GET、HEAD、Range GET 在 transport factory 实际
执行时计次；已消费的 response body bytes 在本地写入或完整性校验之前计数。
opening error、首个 body error、完整长度错误按一次失败记录；本地命中、admission
拒绝、本地文件错误不增加远端请求或失败数。SDK 内部重试不在这个计数层统计。

新增原生指标：

- `brewfs_packed_runtime_backend_full_gets_total`
- `brewfs_packed_runtime_backend_heads_total`

既有 Range GET、requested/received bytes 和 failures 指标名称及 Range 语义保留。
操作说明也明确了 AX 的严格冷/热读门：冷读必须发生 Full/Range GET 并收到字节，
热读的 Full/HEAD/Range/received 增量都为零，且所有指标必须存在。

## 先失败、后通过的证据

- `red.log`：只加入失败恢复测试，旧生产代码在可恢复后仍返回
  `injected tail failure`，预期失败确认；`red-test-binary.sha256` 绑定旧测试二进制。
- `gates.log`：最小重试修复通过定向测试、实际 feature 全套和仓库完整 CI。
- `metrics-red.log`：只加入原生字节测试，旧计数得到 `0`，期望 `128`，预期失败确认；
  `metrics-red-test-binary.sha256` 绑定对应二进制。
- `metrics/readonly-green.log`：最终 20 项 readonly 测试全过，覆盖三条入口、local
  hit、HEAD/full/range 的 opening/body 错误、错误长度、预算拒绝零远端尝试，以及
  failed stream pin 下的磁盘预算和恢复。

## 最终完整 CI

`metrics/gates.log` 在 `2026-11-12T13:27:22Z` 记录 `ALL_GATES_PASSED`。

- 实际 features `workspace,observability,rustfs-ec-block-size-hint`：先通过
  `cargo check --locked --workspace --all-targets --features ...`，再完成
  `cargo test --locked --workspace --lib --bins --features ...`：2827 lib、2 main、
  15 fixture 测试通过，483 ignored。
- 默认 workspace 测试：1354 lib、2 main 通过，265 ignored。
- fmt、四个 shell 语法检查、三个脚本回归、workspace check/build、两套 no-default
  fuse runtime 检查、workspace Clippy、全目标 `-D warnings` Clippy、diff 检查通过。
- `rfuse3` 不属于当前 workspace，按 AGENTS.md 的条件规则跳过其独立矩阵。

测试树为 `462eb02a3af3c1911e56342cb17605f6854d94af`。测试后只补充
`doc/operations/packed-cache.md` 两段说明。`source-identity.json` 逐项证明最终
所有非 doc 根项与测试树相同，包括 src、Cargo.toml、Cargo.lock、build.rs、vendor；
`final-doc-only.patch` 和 `commit-and-freeze.log` 保留这一收尾过程。

## 构建和性能边界

最终 release 在上述提交、clean 工作树、`codex/packed-prefetch` 分支上构建，使用
default features 加 `workspace,observability,rustfs-ec-block-size-hint`，同时产生
`brewfs` 和 `packed_snapshot_fixture`。产物 SHA 与 `--version` 以最终
`binaries.sha256`、`binary-version.txt` 和 `release.log` 为准。

这份记录证明正确性回归和 CI，不宣称性能收益。原 6912 候选的四轮原始性能证据
保留；最终提交需要独立使用新二进制、同数据、同预算完成 128 正反顺序对照，
确认收益后再跑 1 万文件正反对照，并核对 native counters 与外部 S3 meter。
单机 RustFS 小样本不等于分布式 C3/C4 资格。
