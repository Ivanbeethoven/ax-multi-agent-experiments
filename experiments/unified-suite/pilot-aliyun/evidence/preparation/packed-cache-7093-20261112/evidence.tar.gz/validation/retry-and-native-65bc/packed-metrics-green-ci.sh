#!/bin/bash
set -euo pipefail
exec 9>/srv/packed/retry-evidence/heavy.lock
flock -n 9
if pgrep -x cargo || pgrep -x rustc; then exit 9; fi
cd /srv/packed/ax-packed-brewfs
export PATH=/root/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin:$PATH
export RUSTUP_TOOLCHAIN=stable-x86_64-unknown-linux-gnu CARGO_HOME=/root/.cargo CARGO_TARGET_DIR=/srv/packed/target
export CARGO_BUILD_JOBS=3 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 GIT_OPTIONAL_LOCKS=0
EVIDENCE=/srv/packed/retry-evidence/metrics
exec > "$EVIDENCE/gates.log" 2>&1
run_gate() {
    local name="$1"; shift
    printf '\nSTART %s ' "$name"; date -u +%FT%TZ
    printf 'COMMAND'; printf ' %q' "$@"; printf '\n'
    if "$@" > "$EVIDENCE/$name.log" 2>&1; then
        printf 'PASS %s ' "$name"; date -u +%FT%TZ
    else
        status=$?
        printf 'FAIL %s exit=%s ' "$name" "$status"; date -u +%FT%TZ
        tail -n 60 "$EVIDENCE/$name.log"
        exit "$status"
    fi
}
git rev-parse HEAD
git diff --binary > "$EVIDENCE/tested-source.patch"
sha256sum "$EVIDENCE/tested-source.patch"
run_gate actual-features-typecheck cargo check --locked --workspace --all-targets --features workspace,observability,rustfs-ec-block-size-hint
run_gate readonly-green timeout -k 15 1800 cargo test --locked --workspace --lib --bins --features workspace,observability,rustfs-ec-block-size-hint workspace::packed::readonly -- --nocapture
run_gate actual-feature-tests timeout -k 15 1800 cargo test --locked --workspace --lib --bins --features workspace,observability,rustfs-ec-block-size-hint
run_gate fmt cargo fmt --all --check
run_gate scripts bash -c 'for f in run_perf_in_container.sh run_redis_perf.sh run_juicefs_perf_in_container.sh run_juicefs_perf.sh; do bash -n docker/compose-xfstests/$f || exit; done; for f in test_perf_report_delta.sh test_juicefs_direct_matrix.sh test_juicefs_perf_report.sh; do bash docker/compose-xfstests/$f || exit; done'
run_gate workspace-check cargo check --locked --workspace
run_gate workspace-build cargo build --locked --workspace
metadata="$(cargo metadata --no-deps --format-version 1)"
if python3 -c 'import json,sys; d=json.loads(sys.stdin.read()); m=set(d["workspace_members"]); sys.exit(not any(p["name"]=="rfuse3" and p["id"] in m for p in d["packages"]))' <<< "$metadata"; then
    run_gate rfuse-tokio cargo check --locked -p rfuse3 --no-default-features --features tokio-runtime
    run_gate rfuse-uring cargo check --locked -p rfuse3 --no-default-features --features io-uring-runtime
    run_gate rfuse-asyncio cargo check --locked -p rfuse3 --no-default-features --features async-io-runtime
fi
run_gate fuse-tokio cargo check --locked -p brewfs --no-default-features --features fuse-tokio-runtime
run_gate fuse-uring cargo check --locked -p brewfs --no-default-features --features fuse-io-uring-runtime
run_gate workspace-tests timeout -k 15 1800 cargo test --locked --workspace --lib --bins
run_gate clippy cargo clippy --locked --workspace
run_gate ci-clippy-all-targets cargo clippy --locked --workspace --all-targets -- -D warnings
run_gate diff-check git diff --check
printf 'ALL_GATES_PASSED '; date -u +%FT%TZ
