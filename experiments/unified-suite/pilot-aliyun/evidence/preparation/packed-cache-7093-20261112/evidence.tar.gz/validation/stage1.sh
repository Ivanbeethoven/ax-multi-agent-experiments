#!/bin/bash
set -euo pipefail
exec 9>/srv/packed/retry-evidence/heavy.lock
flock -n 9
if pgrep -x cargo || pgrep -x rustc; then exit 9; fi
cd /srv/packed/ax-packed-brewfs
export PATH=/root/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin:$PATH
export RUSTUP_TOOLCHAIN=stable-x86_64-unknown-linux-gnu CARGO_HOME=/root/.cargo CARGO_TARGET_DIR=/srv/packed/target
export CARGO_BUILD_JOBS=3 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 GIT_OPTIONAL_LOCKS=0
EVIDENCE=/srv/packed/stats-wiring-validation/attempt-01
exec > "$EVIDENCE/stage1.log" 2>&1
run_gate() {
    local name="$1"; shift
    printf '\nSTART %s ' "$name"; date -u +%FT%TZ
    printf 'COMMAND'; printf ' %q' "$@"; printf '\n'
    if "$@" > "$EVIDENCE/$name.log" 2>&1; then
        printf 'PASS %s ' "$name"; date -u +%FT%TZ
    else
        status=$?
        printf 'FAIL %s exit=%s ' "$name" "$status"; date -u +%FT%TZ
        tail -n 70 "$EVIDENCE/$name.log"
        exit "$status"
    fi
}
sha256sum "$EVIDENCE/tested-source.patch"
run_gate actual-features-typecheck cargo check --locked --workspace --all-targets --features workspace,observability,rustfs-ec-block-size-hint
run_gate shared-workspace-stats-green timeout -k 15 1800 cargo test --locked --workspace --lib --bins --features workspace,observability,rustfs-ec-block-size-hint shared_workspace_stats -- --nocapture
run_gate actual-debug-binaries timeout -k 15 1800 cargo build --locked --features workspace,observability,rustfs-ec-block-size-hint --bin brewfs --bin packed_snapshot_fixture
sha256sum /srv/packed/target/debug/brewfs /srv/packed/target/debug/packed_snapshot_fixture > "$EVIDENCE/debug-binaries.sha256"
/srv/packed/target/debug/brewfs --version > "$EVIDENCE/debug-version.txt"
run_gate debug-fuse-native-smoke python3 /srv/packed/launch_stats_wiring_smoke.py --directory /srv/packed/stats-wiring-debug-01 --binary /srv/packed/target/debug/brewfs --producer /srv/packed/target/debug/packed_snapshot_fixture
printf 'DEBUG_FUSE_SMOKE_PASSED '; date -u +%FT%TZ
