#!/bin/bash
set -euo pipefail
exec 9>/srv/packed/retry-evidence/heavy.lock
flock -n 9
if pgrep -x cargo || pgrep -x rustc; then exit 9; fi
cd /srv/packed/ax-packed-brewfs
export PATH=/root/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin:$PATH
export RUSTUP_TOOLCHAIN=stable-x86_64-unknown-linux-gnu CARGO_HOME=/root/.cargo CARGO_TARGET_DIR=/srv/packed/target
export CARGO_BUILD_JOBS=3 CARGO_INCREMENTAL=0 CARGO_PROFILE_RELEASE_DEBUG=0 GIT_OPTIONAL_LOCKS=0
exec > /srv/packed/retry-evidence/release.log 2>&1
date -u +%FT%TZ
test -z "$(git status --porcelain)"
source_commit="$(git rev-parse HEAD)"
test "$(git branch --show-current)" = codex/packed-prefetch
systemctl show ax-packed-retry-release --property=CPUQuotaPerSecUSec,MemoryMax > /srv/packed/retry-evidence/release-resource-limits.txt
printf 'SOURCE_COMMIT=%s\n' "$source_commit"
timeout -k 15 3600 cargo build --locked --release --features workspace,observability,rustfs-ec-block-size-hint --bin brewfs --bin packed_snapshot_fixture
test -z "$(git status --porcelain)"
test "$(git rev-parse HEAD)" = "$source_commit"
sha256sum /srv/packed/target/release/brewfs /srv/packed/target/release/packed_snapshot_fixture > /srv/packed/retry-evidence/binaries.sha256
/srv/packed/target/release/brewfs --version > /srv/packed/retry-evidence/binary-version.txt
grep -Fxq "commit: $source_commit" /srv/packed/retry-evidence/binary-version.txt
grep -Fxq 'branch: codex/packed-prefetch' /srv/packed/retry-evidence/binary-version.txt
grep -Fxq 'dirty: false' /srv/packed/retry-evidence/binary-version.txt
cat /srv/packed/retry-evidence/binaries.sha256
printf 'RELEASE_CLEAN_IDENTITY_VERIFIED '
date -u +%FT%TZ
