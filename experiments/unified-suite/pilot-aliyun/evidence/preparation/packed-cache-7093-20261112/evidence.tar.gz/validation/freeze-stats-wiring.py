import hashlib
import json
import os
from pathlib import Path
import subprocess

root = Path('/srv/packed/ax-packed-brewfs')
evidence = Path('/srv/packed/stats-wiring-validation')
expected_base = '65bc08e2d3dc447dcda4f73ce1c3ab096722f11d'
expected_patch = '2ffef62dca5f831bc2190845ca32eed3a6e47b776ed51589ee27e7431fbe6b5a'
expected_tree = '6a14aabea9a36693edea67dad39722db468123e6'
env = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
log = (evidence / 'commit-and-freeze.log').open('x')

def git(*args):
    log.write('$ git ' + ' '.join(args) + '\n')
    log.flush()
    p = subprocess.run(['git', *args], cwd=root, env=env, text=True,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log.write(p.stdout + '\n')
    log.flush()
    p.check_returncode()
    return p.stdout.strip()

assert 'ALL_GATES_PASSED ' in (evidence / 'attempt-03/ci/gates.log').read_text()
assert git('rev-parse', 'HEAD') == expected_base
assert git('branch', '--show-current') == 'codex/packed-prefetch'
assert not git('diff', '--cached', '--name-only')
patch = subprocess.check_output(['git', 'diff', '--binary'], cwd=root, env=env)
assert hashlib.sha256(patch).hexdigest() == expected_patch
paths = sorted(git('diff', '--name-only').splitlines())
assert paths == sorted([
    'src/cadapter/read_observer/tests.rs',
    'src/cli.rs',
    'src/vfs/stats.rs',
    'src/workspace/meta_layer/mod.rs',
    'src/workspace/meta_layer/packed_lower.rs',
    'src/workspace/meta_layer/row_cache.rs',
    'src/workspace/meta_layer/tests/packed_lower_tests.rs',
    'src/workspace/packed/readonly.rs',
    'src/workspace/packed/snapshot/budget.rs',
])
git('add', '--', *paths)
assert git('write-tree') == expected_tree
git('diff', '--cached', '--check')
git('-c', 'user.name=Codex', '-c', 'user.email=codex@openai.com',
    'commit', '-m', 'Expose shared workspace Packed stats within the output budget')
commit = git('rev-parse', 'HEAD')
assert git('rev-parse', 'HEAD^{tree}') == expected_tree
assert not git('status', '--porcelain')
bundle = evidence / 'packed-stats-wiring.bundle'
git('bundle', 'create', str(bundle), 'codex/packed-prefetch', '^' + expected_base)
identity = {
    'commit': commit,
    'branch': 'codex/packed-prefetch',
    'dirty': False,
    'tree': expected_tree,
    'ci_tested_tree': expected_tree,
    'ci_source_patch_sha256': expected_patch,
    'ci_attempt': 'attempt-03',
    'rust_test_threads': 4,
    'parent': expected_base,
    'changed_paths': paths,
    'bundle_sha256': hashlib.sha256(bundle.read_bytes()).hexdigest(),
    'debug_wiring_source_patch_sha256': 'ae8a4639f37a04c9628cbde1becef26cbb5dbbd3ebf7c2d899b85f133400d96e',
    'debug_wiring_receipt': '/srv/packed/stats-wiring-debug-02/wiring-receipt.json',
    'budget_delta_sha256': '2204227d3c66989e8443159dd344aedab09b8015cfe4bca3a9dcd3d7425fc47a',
    'existing_test_fixture_delta_sha256': '474ff2cf5f0a8f032f0f0922e5ab2e4812b023f600c858194839a3b9418d63f5',
}
(evidence / 'source-identity.json').write_text(json.dumps(identity, indent=2) + '\n')
print(json.dumps(identity, indent=2))
