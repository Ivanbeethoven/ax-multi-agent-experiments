from pathlib import Path
import datetime
import hashlib
import json
import re

ROOT=Path('/home/dev/ax-packed-build/evidence-final-7093f141')
OUT=ROOT/'review'
checks=[]
failed=[]
def check(value,label):
    checks.append(label)
    if not value: failed.append(label)
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def all_true(value):
    return all(all_true(v) for v in value.values()) if isinstance(value,dict) else value is True
def load(path): return json.loads(path.read_text())

receipt=load(ROOT/'archive-receipts/head-transfer.json')
manifest=load(ROOT/'archive-receipts'/receipt['manifest'])
check(receipt['passed'] and receipt['cloud_to_rbm_sha256_matched'] and receipt['actual_remote_host']=='10.20.2.188','archived worker transfer')
check(len(manifest)==receipt['files'] and sum(v['bytes'] for v in manifest.values())==receipt['bytes'],'archive file counts and bytes')
for name,item in manifest.items():
    path=ROOT/name
    check(path.stat().st_size==item['bytes'] and sha(path)==item['sha256'],'archive '+name)
formal=load(OUT/'review.json')
old=load(ROOT/'head-01.json');d=load(ROOT/'head-02.json')
check(old['passed'] is False and old['failed_phase']=='large-object-inventory' and old['readbacks']=={},'01 fails inventory before measured reads')
check(all_true(old['cleanup']),'01 cleanup')
check(d['measured_source_commit']==formal['source_commit'] and d['binary_sha256']==formal['binary_sha256'],'02 same frozen source and binaries')
check(d['budgets']==formal['budgets'],'02 explicit budget identity')
check(d['passed'] and d['parent_binding'] and all_true(d['cleanup']),'02 correctness and cleanup')
check(not d['formal_sample'] and 'Not the formal paired warm gate' in d['native_protocol']['scope'],'02 separate diagnostic scope')
for name,expected in d['diagnostic_tools'].items():
    check(sha(ROOT/'head-02-tools'/name)==expected,'02 tool '+name)
setup=load(ROOT/'head-02-setup.json')
for name,item in setup['tools'].items():
    check(item['before']==sha(ROOT/'head-01-tools'/name) and item['after']==sha(ROOT/'head-02-tools'/name),'tool correction preserved '+name)
check(sorted(d['large_objects'].values())==[4198496]*4+[16781408]*4,'four 16MiB plus four 4MiB external objects')
a=d['readbacks']['on-head'];b=a['b_ready'];control=a['b_control']
check(b['actual_bytes']==b['object_bytes']==d['large_objects'][b['key']]==16781408,'B complete recorded persisted size')
check(b['object_sha256']==b['key'].split('/')[-1],'B content-address digest')
check(b['persisted_file'].endswith(hashlib.sha256(b['key'].encode()).hexdigest()+'.pack'),'B persisted key binding')
body=hashlib.shake_256(b'packed-head:B.bin').digest((12<<20)+4096)
for offset,item in b['unique_source_fragments'].items():
    offset=int(offset)
    check(item['bytes']==4096 and item['sha256']==hashlib.sha256(body[offset:offset+4096]).hexdigest(),'B deterministic fragment '+str(offset))
    check(0<=item['stored_offset']<=b['object_bytes']-4096,'B recorded fragment bounds '+str(offset))
raw_dir=ROOT/d['raw_logs_directory']
def parse(snap):
    fields={}
    for line in (raw_dir/snap['raw_file']).read_text().splitlines():
        if not line or line.startswith('#'):continue
        match=re.fullmatch(r'([^ ]+)\s+([0-9]+)',line)
        if match: fields[match[1]]=int(match[2])
    runtime={k:fields[k] for k in snap['runtime']}
    decode=sum(v for k,v in fields.items() if k.startswith('brewfs_object_read_work_nanoseconds_count{') and 'engine="packed"' in k and 'phase="runtime"' in k and 'kind="external_payload"' in k and 'origin="demand"' in k and 'work="decode_wall"' in k)
    check(runtime==snap['runtime'] and decode==snap['external_decode_count'],'raw native '+snap['raw_file'])
    return runtime,decode
def sample_delta(before,after):
    left,ld=parse(before);right,rd=parse(after)
    return {k:right[k]-left[k] for k in left},rd-ld
logical='brewfs_packed_logical_bytes_total'
prefix='brewfs_packed_runtime_backend_'
cd,decode=sample_delta(control['before'],control['after'])
check(cd[logical]==4096 and decode==1 and all(v==0 for k,v in cd.items() if k!=logical),'control one local decode and zero native IO')
check(control['events']==[] and control['passed'] and control['offset']==2<<20,'control proxy quiet and target')
check(control['sha256']==b['unique_source_fragments'][str(2<<20)]['sha256'],'control content')
all_events=d['probe_events'];tot=d['probe_totals']
check(all(e.get('status') in (200,206) and 'error' not in e for e in all_events),'all proxy events successful')
check(tot['gets']==sum(e['method']=='GET' for e in all_events) and tot['heads']==sum(e['method']=='HEAD' for e in all_events)
      and tot['ranges']==sum(e['method']=='GET' and e['status']==206 for e in all_events)
      and tot['bytes']==sum(e['bytes'] for e in all_events) and tot['errors']==0 and tot['active']==0,'independent proxy totals')
summary=[];head_keys=set()
for t in a['trials']:
    n=t['index'];h=t['head'];br=t['b_read'];ar=t['a_read'];events=t['events']
    check(t['b_offset']==(4+4*n)<<20 and t['a']==f'A{n}.bin','trial distinct targets '+str(n))
    check(h['key']!=b['key'] and h['key'] not in head_keys and h['key'] in d['large_objects'],'distinct A LargeData HEAD '+str(n));head_keys.add(h['key'])
    check(h['method']=='HEAD' and h['gated'] and h['released_by_signal'] and h['range'] is None,'gated HEAD identity '+str(n))
    check(not t['b_finished_while_head_blocked'] and h['start_ns']<=br['start_ns']<t['release_requested_ns']<=h['release_ns']<br['end_ns'],'B blocks through signal '+str(n))
    check(.24e9<h['release_ns']-h['start_ns']<.4e9,'bounded injected hold '+str(n))
    check(all(e in all_events for e in events) and h in events and not any(e['key']==b['key'] for e in events) and not t['b_network_events'],'B has no network events '+str(n))
    nd,dd=sample_delta(t['before'],t['after'])
    check(nd[logical]==8192 and dd==2 and nd[prefix+'failures_total']==0,'two reads/decode and no failure '+str(n))
    check(nd[prefix+'full_gets_total']==sum(e['method']=='GET' and e['range'] is None for e in events)
          and nd[prefix+'range_gets_total']==sum(e['method']=='GET' and e['range'] is not None for e in events)
          and nd[prefix+'heads_total']==sum(e['method']=='HEAD' for e in events)
          and nd[prefix+'received_bytes_total']==sum(e['bytes'] for e in events),'trial raw native/proxy reconciliation '+str(n))
    expected_b=b['unique_source_fragments'][str(t['b_offset'])]['sha256']
    expected_a=hashlib.sha256(hashlib.shake_256(('packed-head:'+t['a']).encode()).digest(4096)).hexdigest()
    check(ar['valid'] and br['valid'] and ar['sha256']==expected_a and br['sha256']==expected_b,'independent read content '+str(n))
    summary.append(dict(trial=n,a=t['a'],b_offset=t['b_offset'],head_hold_ms=(h['release_ns']-h['start_ns'])/1e6,
        b_read_ms=(br['end_ns']-br['start_ns'])/1e6,b_after_release_ms=(br['end_ns']-h['release_ns'])/1e6,
        b_network_requests=0,logical_delta=8192,external_decode_delta=2))
check(len(summary)==3 and a['passed'] and a['reproduced'],'three reproduced trials')
check(all(v['exit_code']==0 and v['unmount_exit_code']==0 and v['mount_absent'] for v in d['mount_exits'].values()),'clean mount exit')
cache_source=Path('/home/dev/ax-packed-retry/src/workspace/packed/readonly/pack_cache.rs')
source=cache_source.read_text()
check(source.index('let mut registry = self.registry.lock().await')<source.index('let head = self'),'source registry acquired before awaited HEAD')
lock_line=next(i for i,line in enumerate(source.splitlines(),1) if 'let mut registry = self.registry.lock().await' in line)
report=dict(schema='independent-packed-head-review-v1',reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    source_commit=d['measured_source_commit'],binary_sha256=d['binary_sha256'],checks=len(checks),integrity_failures=failed,
    diagnostic_reproduced=not failed,control_read_ms=(control['end_ns']-control['start_ns'])/1e6,trials=summary,
    prior_attempt=dict(passed=False,phase=old['failed_phase'],meaning='Inventory assertion expected 4 objects; producer actually emits eight (16MiB+4MiB per file). No measured read occurred; error and corrected tools retained.'),
    supported_claim='With a different cold object HEAD deliberately delayed by 250ms, an independently opened read of an unread frame from an already complete local object also waits until the HEAD is released, in all three bounded trials. The source holds the shared registry mutex across HEAD.',
    limits=['This is a controlled stall reproduction, not ordinary latency, throughput, a fix comparison, or attribution of the formal cold-readdir regression.',
            'The stored B object was removed by cleanup. Independent review verifies recorded size/digest/fragment assertions and deterministic content hashes; it cannot re-read that deleted physical file.',
            'Separate preopened never-read FDs, unique offsets, decode/logical deltas, and zero B network events substantiate the intended local read path.',
            'All budgets remain explicit as in the formal experiment; this is not a default-budget pressure test.',
            'This supplemental diagnosis does not revise the user-authorized overall-E2E acceptance decision.'],
    sources=dict(archive_receipt_sha256=sha(ROOT/'archive-receipts/head-transfer.json'),head02_sha256=sha(ROOT/'head-02.json'),
                 pack_cache_sha256=sha(cache_source),pack_cache_lock_line=lock_line,awaited_head_lines=[209,224],analyzer_sha256=sha(Path(__file__))))
(OUT/'head-review.json').write_text(json.dumps(report,indent=2)+'\n')
lines=['# 独立复核：HEAD 阻塞诊断','',f"{len(checks)} 项检查，完整性失败 {len(failed)} 项。独立重算支持三次受控阻塞复现。",'',
    f"无阻塞控制读耗时 {report['control_read_ms']:.3f} ms，external decode +1、逻辑字节 +4096、原生与 proxy 均零网络。",'',
    '| B 未读偏移 | A HEAD 注入等待 | B 读取耗时 | HEAD 释放后 B 返回 | B 网络请求 |',
    '|---:|---:|---:|---:|---:|']
for t in summary:lines.append(f"| {t['b_offset']//(1<<20)} MiB | {t['head_hold_ms']:.3f} ms | {t['b_read_ms']:.3f} ms | {t['b_after_release_ms']:.3f} ms | 0 |")
lines+=['','B 的首个 16,781,408 B 对象已完整持久化，控制和三个目标片段均有确定内容摘要与唯一位置断言；每个目标使用独立预打开、从未读取的 FD。每次 trial 的原始统计均为 decode +2、逻辑字节 +8192，网络事件全部属于 A 的元数据或外部对象。', '',
    f'7093 的共享 registry 锁覆盖 HEAD await（pack_cache.rs:{lock_line}、209–224），与受控现象相符。该诊断证明此阻塞路径可复现，不能把约 250 ms 当作普通网络延迟、修复后的收益或四轮 readdir 回退的原因。', '',
    'head-01 在库存前置检查失败：每个 20 MiB 文件实际拆为 16 MiB + 4 MiB，因此共 8 个对象。旧结果和工具保留，head-02 修改库存断言并增加片段绑定后完成；未将失败轮计作测量。', '',
    '原 B 缓存文件随清理删除；本复核检查归档的大小、摘要、片段断言和可独立重算的内容摘要，不声称重新读取已删除的文件。此独立诊断不改变用户授权的整体 E2E 验收结论。']
(OUT/'head-review.md').write_text('\n'.join(lines)+'\n')
(OUT/'head-review-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
(OUT/'analyze-head.py').write_bytes(Path(__file__).read_bytes())
(OUT/'head-review-sha256.json').write_text(json.dumps({n:sha(OUT/n) for n in ['head-review.json','head-review.md','head-review-checks.json','analyze-head.py']},indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['checks','integrity_failures','diagnostic_reproduced','control_read_ms','trials']},indent=2))
