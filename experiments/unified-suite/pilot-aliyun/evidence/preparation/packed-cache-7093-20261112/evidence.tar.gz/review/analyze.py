from pathlib import Path
import hashlib
import json
import re
import statistics
import datetime

ROOT = Path('/home/dev/ax-packed-build/evidence-final-7093f141')
OUT = ROOT / 'review'
OUT.mkdir(exist_ok=True)
SOURCE = '7093f141d8081e6b96cd0a80814876aed5a3b577'
AX = '3d756ff5b99a3b36fe28eec43cf35f122c756322'
BINS = dict(brewfs='05613fe60088e47fe7b12ddbfddc4f60afdf83f2a57ad86dd414abce11cfd7e6',
            packed_snapshot_fixture='491733d3dbbadce52832ca2e75780e8052556aa28f900b709a05d492721d54ba')
METRICS = dict(full_requests='brewfs_packed_runtime_backend_full_gets_total',
               range_requests='brewfs_packed_runtime_backend_range_gets_total',
               head_requests='brewfs_packed_runtime_backend_heads_total',
               received_bytes='brewfs_packed_runtime_backend_received_bytes_total',
               failures='brewfs_packed_runtime_backend_failures_total',
               logical_bytes='brewfs_packed_logical_bytes_total')
BUDGETS = dict(packed_disk_bytes=256<<20, metadata_bytes=256<<20,
               payload_memory_bytes=512<<20, payload_ssd_bytes=0,
               output_bytes=128<<20, control_bytes=8<<20,
               process_memory_bytes=8<<30, cpu_cores=2)
POOL_CAPS = dict(roots=16<<20, metadata_owned=256<<20, plans=32<<20,
                 control=8<<20, stored=32<<20, raw=32<<20,
                 decode_workspace=8<<20, output=128<<20)
pool_peaks = {mode: {key: 0 for key in POOL_CAPS} for mode in ('on','off')}
checks = []
failures = []

def check(value, label):
    checks.append(label)
    if not value:
        failures.append(label)

def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def all_true(value):
    return all(all_true(v) for v in value.values()) if isinstance(value, dict) else value is True

def delta(a, b):
    return {k: b[k]-a[k] for k in a}

def proxy(row):
    return dict(full_requests=row['gets']-row['ranges'], range_requests=row['ranges'],
                head_requests=row['heads'], received_bytes=row['bytes'])

def traffic(row, denominator):
    return dict(full_gets=row['gets']-row['ranges'], range_gets=row['ranges'], heads=row['heads'],
                requests=row['gets']+row['heads'], response_body_bytes=row['bytes'],
                logical_bytes_denominator=denominator,
                response_body_read_amplification=row['bytes']/denominator)

def raw_metrics(path):
    found = {k: [] for k in METRICS}
    row_fields = set()
    all_fields = {}
    for line in path.read_text().splitlines():
        fields = line.split()
        if len(fields) != 2:
            continue
        all_fields[fields[0]] = fields[1]
        for key, name in METRICS.items():
            if fields[0] == name:
                found[key].append(int(fields[1]))
        if fields[0].startswith('brewfs_workspace_row_cache_'):
            row_fields.add(fields[0])
    check(all(len(v) == 1 for v in found.values()), str(path)+': six unique native fields')
    check({'brewfs_workspace_row_cache_hits_total', 'brewfs_workspace_row_cache_misses_total',
           'brewfs_workspace_row_cache_hit_ratio'} <= row_fields, str(path)+': row fields coexist')
    mode = path.name.split('-')[1]
    for pool, cap in POOL_CAPS.items():
        prefix = 'brewfs_packed_budget_'+pool
        actual_cap = int(all_fields[prefix+'_capacity_bytes'])
        owned = int(all_fields[prefix+'_owned_bytes'])
        peak = int(all_fields[prefix+'_peak_owned_bytes'])
        check(actual_cap == cap and 0 <= owned <= peak <= cap, str(path)+': actual '+pool+' capacity and ownership bounds')
        pool_peaks[mode][pool] = max(pool_peaks[mode][pool], peak)
    check(all_fields['brewfs_packed_budget_rejections_total'] == '0' and all_fields['brewfs_packed_budget_closed'] == '0',
          str(path)+': no metadata budget rejection/close')
    return {k: v[0] for k, v in found.items()}

def input_digest(n):
    expected = {}
    for i in range(n):
        body = hashlib.shake_256(i.to_bytes(8, 'little')).digest(4096)
        expected[f'{i//32:04d}/{i:06d}.bin'] = {'bytes': 4096, 'sha256': hashlib.sha256(body).hexdigest()}
    return hashlib.sha256(json.dumps(expected, sort_keys=True).encode()).hexdigest()

runs = []
pairs = []
invocation_scripts = None
for receipt_file in sorted((ROOT/'archive-receipts').glob('pair-*.json')):
    archive = json.loads(receipt_file.read_text())
    name = archive['run']
    if not re.fullmatch(r'pair-(128|10000)-0[12]', name):
        continue
    check(archive['cloud_to_rbm_sha256_matched'] is True, name+': archive receipt')
    check(archive['actual_remote_host'] == '10.20.2.188', name+': new worker host')
    for relative, item in archive['raw_files'].items():
        path = ROOT/relative
        check(path.stat().st_size == item['bytes'] and sha(path) == item['sha256'], name+': archive '+relative)
    d = json.loads((ROOT/(name+'.json')).read_text())
    inv = json.loads((ROOT/(name+'-invocation.json')).read_text())
    n = d['files']; logical = n*4096
    check(inv['source_commit'] == SOURCE and inv['harness_commit'] == AX, name+': source identities')
    check(inv['source_clean'] and inv['no_compile_processes_at_start'], name+': clean/nonbuilding invocation')
    check(inv['launcher_sha256'] == '842459dc5f2532a4606c91ceb982247475736990f24cb41422fefb197be0f8b5', name+': launcher')
    check(d['binary_sha256'] == BINS, name+': exact same executable hashes')
    check('commit: '+SOURCE in inv['binary_version'].splitlines() and 'dirty: false' in inv['binary_version'].splitlines(), name+': actual version')
    check(d['budgets'] == BUDGETS, name+': exact common configured caps')
    check(d['input_sha256'] == input_digest(n), name+': independent deterministic content manifest hash')
    check(d['image_sha256']['rustfs'].removeprefix('sha256:') == '9750c5eaaac37e2d6ebaa8aaf39a4aa98a35fca5fba8de5ade26585123058806', name+': RustFS image')
    check(d['passed'] and d['parent_binding'] and d['private_write_isolation'] and all_true(d['cleanup']), name+': correctness and cleanup')
    check(set(d['mount_exits']) == set(d['readbacks']) and all(
        exit_row.get('exit_code') == 0 and exit_row.get('unmount_exit_code') == 0
        and exit_row.get('mount_absent') is True for exit_row in d['mount_exits'].values()),
        name+': all mounts and unmounts exit zero and mounts disappear')
    if invocation_scripts is None:
        invocation_scripts = inv['scripts']
    check(inv['scripts'] == invocation_scripts, name+': same frozen harness sources')
    row = dict(run=name, files=n, order=d['order'], result_sha256=sha(ROOT/(name+'.json')),
               input_sha256=d['input_sha256'], snapshot_manifest=d['manifest_key'],
               object_inventory_bytes=sum(x['bytes'] for x in d['object_sizes']),
               object_inventory_count=len(d['object_sizes']), formal_sample=d['formal_sample'], arms={}, correctness_visits={})
    for arm_name, arm in d['readbacks'].items():
        check(arm['passed'], name+'/'+arm_name+': passed')
        check(arm['mount_preparation_ns'] == arm['mount_ready_ns']+arm['stats_initialization_ns'], name+'/'+arm_name+': prep accounting')
        check(arm['cgroup_memory_peak_bytes'] <= BUDGETS['process_memory_bytes'], name+'/'+arm_name+': observed cgroup peak below cap')
        raw_log = (ROOT/d['raw_logs_directory']/(arm_name+'.log')).read_text()
        drain_lines = [line for line in raw_log.splitlines() if 'packed whole object cache drained,' in line]
        if arm_name.startswith('on'):
            check(len(drain_lines) == 1, name+'/'+arm_name+': one raw cache drain report')
            parsed_cache = {k:int(v) for k,v in re.findall(r'\b(hits|misses|ready_hits|inflight_hits|local_bytes|downloaded): (\d+)',drain_lines[0])}
            check(parsed_cache == arm['cache'], name+'/'+arm_name+': independently parsed cache counters')
        else:
            check(not drain_lines and not arm['cache'], name+'/'+arm_name+': no enabled-cache report')
        if not re.fullmatch(r'(on|off)-[0-3]', arm_name):
            check(not arm['native']['required'], name+'/'+arm_name+': correctness-only scope')
            if arm_name.endswith('-remount'):
                check(arm['cache']['downloaded'] == 0 and arm['cache']['misses'] == 0, name+'/'+arm_name+': retained local cache')
                check(all(arm['phases'][p]['s3'][k] == 0 for p in ('cold','warm') for k in ('gets','heads','bytes','errors')), name+'/'+arm_name+': retained runtime traffic zero')
            row['correctness_visits'][arm_name] = dict(passed=arm['passed'], cache=arm['cache'],
                end_to_end_s3=arm['end_to_end_s3'], native_gate_required=False,
                excluded_from_performance=True,
                proxy_bypassed=arm_name in ('on-private','on-private-cold'))
            continue
        mode = arm_name.split('-')[0]
        native = arm['native']
        check(native['required'] and native['passed'] and not native['reasons'], name+'/'+arm_name+': native result')
        snapshots = native['snapshots']
        check(set(snapshots) == {'bootstrap','before','cold-end','cold-drained','warm-end'}, name+'/'+arm_name+': five snapshots')
        parsed = {}
        for label, snap in snapshots.items():
            parsed[label] = raw_metrics(ROOT/d['raw_logs_directory']/snap['raw_file'])
            check(parsed[label] == snap['fields'], name+'/'+arm_name+'/'+label+': raw equals embedded fields')
            if label in ('before','cold-drained','warm-end'):
                check(snap['proxy_before'] == snap['proxy_after'] and snap['proxy_after']['active'] == 0, name+'/'+arm_name+'/'+label+': strict quiet boundary')
        check(parsed['before']['failures'] == 0, name+'/'+arm_name+': no initialization failures')
        for left, right in [('before','cold-drained'),('cold-drained','warm-end')]:
            native_diff = delta(parsed[left], parsed[right])
            proxy_diff = proxy(delta(snapshots[left]['proxy_after'], snapshots[right]['proxy_after']))
            check(all(v >= 0 for v in native_diff.values()), name+'/'+arm_name+'/'+right+': monotone native')
            check({k:native_diff[k] for k in proxy_diff} == proxy_diff, name+'/'+arm_name+'/'+right+': independent raw/proxy reconciliation')
            check(native_diff['logical_bytes'] == logical and native_diff['failures'] == 0, name+'/'+arm_name+'/'+right+': exact logical bytes/no failures')
            if right == 'cold-drained':
                check(native_diff['received_bytes'] > 0 and native_diff['full_requests']+native_diff['range_requests'] > 0, name+'/'+arm_name+': first pass reads backend')
            elif mode == 'on':
                check(all(native_diff[k] == 0 for k in proxy_diff), name+'/'+arm_name+': on second pass no remote IO')
            else:
                check(native_diff['received_bytes'] > 0 and native_diff['full_requests']+native_diff['range_requests'] > 0, name+'/'+arm_name+': off second pass remains remote')
        total_native = delta(parsed['before'], parsed['warm-end'])
        total_proxy = proxy(delta(arm['mount_s3'], arm['end_to_end_s3']))
        check({k:total_native[k] for k in total_proxy} == total_proxy, name+'/'+arm_name+': raw total vs E2E minus actual preparation')
        check(all(arm['unmount_s3'][k] == 0 for k in ('gets','ranges','heads','bytes','errors')), name+'/'+arm_name+': unmount quiet')
        check(arm['end_to_end_s3']['errors'] == 0, name+'/'+arm_name+': proxy no error/retry indication')
        bootstrap_proxy = proxy(delta(snapshots['bootstrap']['proxy_before'], snapshots['before']['proxy_after']))
        check(bootstrap_proxy == proxy(arm['stats_initialization_s3']), name+'/'+arm_name+': bootstrap traffic charged')
        check(all(v == 0 for v in delta(parsed['bootstrap'], parsed['before']).values()), name+'/'+arm_name+': stable post-bootstrap baseline')
        check(native['sampling_ns'] == sum(s['sampling_ns'] for s in snapshots.values()), name+'/'+arm_name+': sampling sum')
        accounted = arm['mount_ready_ns'] + sum(p['wall_ns'] for p in arm['phases'].values()) + arm['background_drain_ns'] + arm['unmount_ns'] + native['sampling_ns']
        residual = arm['end_to_end_ns']-accounted
        check(residual >= 0, name+'/'+arm_name+': no sampling double count in E2E')
        phases = {}
        for phase, values in arm['phases'].items():
            samples = values['samples_ns']
            check(len(samples) == n and all(len(x)==2 and min(x)>=0 for x in samples), name+'/'+arm_name+'/'+phase+': sample count')
            read_sum = sum(x[1] for x in samples); open_sum = sum(x[0] for x in samples)
            check(values['wall_ns'] >= read_sum+open_sum+values['readdir_ns'], name+'/'+arm_name+'/'+phase+': phase timers conserved')
            check(statistics.median(x[1] for x in samples) == values['median_pread_ns'], name+'/'+arm_name+'/'+phase+': median raw samples')
            phases[phase] = dict(wall_s=values['wall_ns']/1e9, readdir_s=values['readdir_ns']/1e9,
                pread_sum_s=read_sum/1e9, open_sum_s=open_sum/1e9,
                pread_median_us=values['median_pread_ns']/1e3,
                cpu_s=values['cpu_seconds'], traffic=traffic(values['s3'], logical))
        cache = arm['cache']
        if mode == 'on':
            check(cache['hits'] == cache['ready_hits']+cache['inflight_hits'], name+'/'+arm_name+': hit classes sum')
            check(cache['downloaded'] == arm['end_to_end_s3']['bytes']-arm['mount_ready_s3']['bytes'], name+'/'+arm_name+': downloaded body vs proxy')
        row['arms'][arm_name] = dict(mode=mode, phases=phases, e2e_s=arm['end_to_end_ns']/1e9,
            mount_ready_s=arm['mount_ready_ns']/1e9, bootstrap_s=arm['stats_initialization_ns']/1e9,
            sampling_total_s=native['sampling_ns']/1e9, background_quiet_wait_s=arm['background_drain_ns']/1e9,
            unmount_s=arm['unmount_ns']/1e9, e2e_unattributed_overhead_s=residual/1e9,
            e2e_traffic=traffic(arm['end_to_end_s3'],2*logical), bootstrap_traffic=arm['stats_initialization_s3'],
            vm_hwm_kib=arm['vm_hwm_kib'], cgroup_memory_peak_bytes=arm['cgroup_memory_peak_bytes'], cache=cache,
            cache_boundary_hit_ratio=cache['hits']/(cache['hits']+cache['misses']) if cache else None,
            local_returned_bytes_per_logical_two_pass_bytes=cache['local_bytes']/(2*logical) if cache else None)
    ordered = list(row['arms'])
    check(ordered == [m+'-'+str(i) for i,m in enumerate(d['order'].split('-')*2)], name+': specified chronological ordering')
    for i in (0,2):
        names = ordered[i:i+2]
        off = next(k for k in names if k.startswith('off'))
        on = next(k for k in names if k.startswith('on'))
        a,b = row['arms'][off],row['arms'][on]
        compare = {}
        values = dict(e2e_s=(a['e2e_s'],b['e2e_s']))
        for phase in ('cold','warm'):
            for field in ('wall_s','readdir_s','pread_sum_s','open_sum_s'):
                values[phase+'_'+field] = (a['phases'][phase][field],b['phases'][phase][field])
        for field,(left,right) in values.items():
            compare[field] = dict(off=left,on=right,on_over_off=right/left,change_percent=100*(right/left-1))
        pairs.append(dict(run=name,files=n,off=off,on=on,metrics=compare))
    runs.append(row)

aggregates = {}
for n in sorted({r['files'] for r in runs}):
    these = [r for r in runs if r['files']==n]
    comparisons = [p for p in pairs if p['files']==n]
    summary = {}
    for key in comparisons[0]['metrics']:
        a = statistics.mean(p['metrics'][key]['off'] for p in comparisons)
        b = statistics.mean(p['metrics'][key]['on'] for p in comparisons)
        summary[key] = dict(off_mean=a,on_mean=b,change_percent=100*(b/a-1),
                            paired_change_percent=[p['metrics'][key]['change_percent'] for p in comparisons])
    modes = {}
    for mode in ('off','on'):
        arms = [a for r in these for a in r['arms'].values() if a['mode']==mode]
        modes[mode] = dict(e2e_traffic_unique=[json.loads(x) for x in sorted({json.dumps(a['e2e_traffic'],sort_keys=True) for a in arms})],
            cold_traffic_unique=[json.loads(x) for x in sorted({json.dumps(a['phases']['cold']['traffic'],sort_keys=True) for a in arms})],
            warm_traffic_unique=[json.loads(x) for x in sorted({json.dumps(a['phases']['warm']['traffic'],sort_keys=True) for a in arms})],
            vm_hwm_kib_range=[min(a['vm_hwm_kib'] for a in arms),max(a['vm_hwm_kib'] for a in arms)],
            cgroup_peak_bytes_range=[min(a['cgroup_memory_peak_bytes'] for a in arms),max(a['cgroup_memory_peak_bytes'] for a in arms)],
            quiescence_wait_seconds_range=[min(a['background_quiet_wait_s'] for a in arms),max(a['background_quiet_wait_s'] for a in arms)])
        if mode == 'on':
            totals = {k:sum(a['cache'][k] for a in arms) for k in ('hits','misses','ready_hits','inflight_hits','local_bytes','downloaded')}
            modes[mode]['cache_totals'] = totals
            modes[mode]['pooled_cache_boundary_hit_ratio'] = totals['hits']/(totals['hits']+totals['misses'])
            modes[mode]['local_returned_bytes_per_logical_two_pass_bytes'] = totals['local_bytes']/(len(arms)*2*n*4096)
    aggregates[str(n)] = dict(runs=len(these),paired_comparisons=len(comparisons),timings=summary,traffic_and_resources=modes,
        all_pairs_e2e_improve=all(p['metrics']['e2e_s']['change_percent']<0 for p in comparisons),
        all_pairs_cold_readdir_regress=all(p['metrics']['cold_readdir_s']['change_percent']>0 for p in comparisons))
complete = {r['run'] for r in runs} == {'pair-128-01','pair-128-02','pair-10000-01','pair-10000-02'}
regressed = any(a['all_pairs_cold_readdir_regress'] for a in aggregates.values())
e2e_improves = all(a['all_pairs_e2e_improve'] for a in aggregates.values())
host = json.loads((ROOT/'execution-host.json').read_text())
check(host['source_commit'] == SOURCE and host['harness_commit'] == AX, 'host: exact source identities')
check(host['resource']['private_ip'] == '10.20.2.188' and host['resource']['memory_gib'] == 32
      and host['resource']['instance_type'] == 'ecs.g7.2xlarge', 'host: actual new 32GiB worker')
check(not host['active_compile_or_perf_processes'] and not host['running_containers_before_campaign'], 'host: idle campaign precondition')
retention = json.loads((ROOT/'payload-retention-contract.json').read_text())
pipeline = Path('/home/dev/ax-packed-retry')/retention['path']
check(retention['source_commit'] == SOURCE and sha(pipeline) == retention['file_sha256'], 'payload retention: exact source file')
source_lines = pipeline.read_text().splitlines()
check(all(source_lines[e['line']-1] == e['text'] for e in retention['source_excerpt']), 'payload retention: excerpt matches source')
check(retention['declared_payload_cache_bytes'] == 0, 'payload retention: declared zero scoped cache')
ax_root = Path('/home/dev/ax-packed-naming-final')
pilot = ax_root/'experiments/unified-suite/pilot-aliyun'
for filename, expected_sha in invocation_scripts.items():
    source_path = ax_root/filename if filename.startswith('bench/') else pilot/'scripts'/filename
    check(sha(source_path) == expected_sha, 'harness source: '+filename)
fixture = pilot/'evidence/preparation/c4-workspace-v1-packed-fork-01/smoke.py'
check(sha(fixture) == '5e0cb515cb07851e2f8713ce78395fbf2b47796ad7a7c534eaea828ecd066e2d', 'harness source: frozen fixture')
agents = Path('/home/dev/ax-packed-retry/AGENTS.md')
check('A faster data\n  path that regresses open/stat/readdir/rename is not acceptable.' in agents.read_text(), 'AGENTS metadata performance gate')
brewfs_root = Path('/home/dev/ax-packed-retry')
budget_source = brewfs_root/'src/workspace/packed/snapshot/budget.rs'
defaults_block = re.search(r'impl Default for SnapshotBudgetLimits.*?bytes:\s*\[(.*?)\]', budget_source.read_text(), re.S)[1]
default_values = []
for value in defaults_block.split(','):
    if not value.strip():
        continue
    shift = re.fullmatch(r'\s*(\d+)\s*<<\s*(\d+)\s*', value)
    default_values.append(int(shift[1]) << int(shift[2]))
default_pools = dict(zip(POOL_CAPS,default_values,strict=True))
check(default_pools['control'] == 1<<20 and default_pools['output'] == 32<<20, '7093 source: actual default Control/Output budgets')
config_source = brewfs_root/'src/vfs/cache/config.rs'
config_text = config_source.read_text()
check('read_memory_bytes: 8 * 1024 * 1024 * 1024' in config_text and 'read_ssd_bytes: 64 * 1024 * 1024 * 1024' in config_text
      and 'packed_cache_enabled: true' in config_text and 'packed_cache_bytes: 256 << 20' in config_text,
      '7093 source: VFS and stored-object cache defaults')
source_followups = dict(
    status='read-only source review candidates; no additional workload or measured performance claim',
    default_budget_scope=dict(native_pool_caps=default_pools,
        vfs_read_memory_bytes=8<<30,vfs_read_ssd_bytes=64<<30,packed_disk_bytes=256<<20,
        measured_control_peak_bytes=pool_peaks['on']['control'],
        default_budget_performance_qualified=False,
        observation='Measured Control peak exceeds the actual 1MiB default; the matched A/B used explicit Control8MiB/Output128MiB and VFS512MiB/SSD0.'),
    candidates=[dict(id='head-before-pack-admission',
        paths={'head':'src/workspace/packed/readonly/pack_cache.rs:209-224',
               'pack_admission':'src/workspace/packed/readonly/pack_cache.rs:250-264',
               'transport_admission':'src/workspace/packed/readonly/transport.rs:89-119',
               'mount_budget':'src/cli.rs:1807'},
        finding='A cache miss performs HEAD before pack download slot, 1MiB Stored buffer and entry Control admission. Rejected pack admission returns None and the caller tries Range fallback; no failed-admission memo avoids the next same-key HEAD.',
        preexisting_guards='HEAD itself is preceded by transport state/driver/generation and Plans admission (Stored=0). These guards can prevent a HEAD; they do not preflight the subsequent slot/Stored/Control pack admission.',
        qualification='Potential extra HEAD+Range under pack admission pressure is source-supported. The formal explicit-budget campaign has no native budget rejection and does not measure this pressure case or establish that it causes the readdir regression.')],
    source_sha256={str(p.relative_to(brewfs_root)):sha(p) for p in [budget_source,config_source,
        brewfs_root/'src/cli.rs',brewfs_root/'src/workspace/packed/readonly/pack_cache.rs',
        brewfs_root/'src/workspace/packed/readonly/transport.rs']})
report = dict(schema='independent-packed-7093-review-v1',reviewed_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    source_commit=SOURCE,harness_commit=AX,host='10.20.2.188 / g7 / 8 vCPU / 32 GiB',
    final_four_runs_archived=complete,scope='Read-only analysis of archived 7093 evidence; no worker visits, no workloads, no debug/6912 values',
    binary_sha256=BINS,budgets=BUDGETS,harness_scripts=invocation_scripts,checks_performed=len(checks),integrity_failures=failures,
    actual_native_pool_caps=POOL_CAPS,max_native_pool_peaks_by_mode=pool_peaks,
    source_review_followups=source_followups,
    source_evidence=dict(analyzer_sha256=sha(Path(__file__)),execution_host_sha256=sha(ROOT/'execution-host.json'),
                         payload_contract_sha256=sha(ROOT/'payload-retention-contract.json'),
                         pipeline_sha256=retention['file_sha256'],fixture_sha256=sha(fixture),
                         agents_sha256=sha(agents)),
    verdict=dict(approve_packed_pr=bool(complete and not failures and e2e_improves),
        applicable_acceptance='passed' if complete and not failures and e2e_improves else 'pending',
        strict_metadata_nonregression=not regressed,
        metadata_policy='Disclosed tradeoff accepted by the user; no longer a veto for this matched E2E experiment.',
        policy_authority='User: 没事 首次读取降低没关系 只要总体性能提高也行',
        reason='All eight matched pairs improve E2E and correctness/counter/budget checks pass. Accept under the user-authorized overall-E2E criterion; retain the cold-readdir regression and explicit-budget scope.' if complete and not failures and e2e_improves else 'Review incomplete or an applicable check failed',
        formal_C3_C4_qualification=False),
    denominator_notes=dict(response_body_amplification='Cold bytes/(files*4096), E2E bytes/(2*files*4096); includes metadata responses, excludes HTTP headers, HEAD body and transport overhead.',
        requests='GET total already contains Range GET; total requests=GET+HEAD; Full GET=GET-Range GET.',
        cache_hit_ratio='hits/(hits+misses) over the whole mounted visit, including metadata and both passes; not file-level or metadata-specific hit rate.',
        local_bytes='Cache-returned range/body bytes, not physical disk IO; OS page cache may serve them.',
        payload_retention='512MiB is ordinary VFS read-memory cap; zero retained decoded payload applies only to completed Snapshot demand-pipeline payloads, not stored-object disk/page cache or transient buffers.'),
    methodology_notes=[
        'Cold label means first traversal/read after explicit .stats bootstrap, which warms root permission metadata. Bootstrap time/traffic are charged to mount preparation and direct E2E.',
        'Sampling total already includes bootstrap; do not add both mount_preparation and all sampling again. E2E is directly timed and includes mount, initialization, two phases, samples, fixed quiescence wait, and unmount.',
        'The roughly 0.5s background drain is a mandatory quiet observation window even in the off arm, not 0.5s of measured outstanding work.',
        'Only four ordinal arms per run enter performance aggregates. Retained remount has zero runtime GET/HEAD/body but still fetches the mount manifest; it is a correctness visit without native hot gate.',
        'Private/private-cold bypass the proxy and native probe: zero meter traffic is not zero IO. They validate length-preserving private mutation, separate Redis DB/namespace, cold-cache reread and unchanged parent, not formal distributed C4 fork qualification.',
        'Limits are matched explicit configured caps, not default-budget qualification or equal realized memory occupancy. Control8MiB/Output128MiB differ from actual7093 defaults1MiB/32MiB; measured on Control peak exceeds1MiB. VFS read-memory512MiB/SSD0 also differ from defaults8GiB/64GiB. VmHWM and cgroup charged peak are different measures; no RSS improvement is claimed.',
        'All measured arms are on one new 32GiB worker with loopback RustFS, fresh client mounts, direct FUSE IO, serial sorted 4KiB file reads and shared backend cache. Reversed order reduces sequence bias but does not establish production/distributed generality. Snapshot object inventory fits inside the 256MiB stored-object cache; no oversized-working-set or sparse-read generalization is supported.',
        'Paired changes are descriptive repetitions, not a confidence interval. No separate S3 counter boundary surrounds readdir, so the evidence establishes its regression but does not isolate the causal cost of HEAD versus Full GET versus cache administration.',
        'top-level base_commit=ca07159 is frozen-fixture lineage; actual measured source is pinned by invocation/source_clean and actual binary version to 7093.',
    ],runs=runs,pairs=pairs,aggregates=aggregates)
(OUT/'review.json').write_text(json.dumps(report,indent=2)+'\n')
lines = ['# 独立复核：Packed 7093', '',
    f"已完成归档轮次：{', '.join(r['run'] for r in runs)}。独立检查 {len(checks)} 项，完整性失败 {len(failures)} 项。", '',
    '**结论：本轮可按整体 E2E 收益接受 Packed PR。** 用户已明确接受首次读取/遍历的性能取舍。八组同数据、同二进制、同显式预算对照的 E2E 均改善，正确性、计数与预算检查通过；首次 readdir 八组均回退的事实保留，`strict_metadata_nonregression=false`。' if complete and not failures and e2e_improves else '结论尚待完整证据。', '',
    '本报告只使用最终 `7093`、AX `3d756ff`、同一 g7 / 32 GiB worker 的正式原始记录，不混入 debug、6912 或原 r7 / 64 GiB 的绝对耗时。', '',
    '| 文件数 | 指标 | 关闭均值(s) | 开启均值(s) | 开启变化 | 每对变化(%) |',
    '|---:|---|---:|---:|---:|---|']
for n,a in aggregates.items():
    for key,title in [('e2e_s','E2E'),('cold_wall_s','首次完整遍历+读取'),('cold_pread_sum_s','首次 pread 调用合计'),('cold_readdir_s','首次 readdir'),('warm_readdir_s','第二次 readdir')]:
        m=a['timings'][key]
        lines.append(f"| {n} | {title} | {m['off_mean']:.6f} | {m['on_mean']:.6f} | {m['change_percent']:+.2f}% | "+', '.join(f'{x:+.2f}' for x in m['paired_change_percent'])+' |')
lines += ['', '变化为 `(on/off-1)*100%`，正数表示变慢。pread 合计来自每个文件的原始 syscall 计时；完整遍历 wall 还包含 readdir、open、close 和哈希校验。', '']
for n,a in aggregates.items():
    off=a['traffic_and_resources']['off'];on=a['traffic_and_resources']['on']
    lines.append(f"## {n} 文件的流量与缓存分母")
    lines.append('')
    lines += ['| 范围 | 开关 | Full GET | Range GET | HEAD | 总请求 | 响应体字节 | 响应体放大 |',
              '|---|---|---:|---:|---:|---:|---:|---:|']
    for label,key in [('首次读取','cold_traffic_unique'),('第二次读取','warm_traffic_unique'),('E2E 两次读取','e2e_traffic_unique')]:
        for mode,values in [('off',off[key]),('on',on[key])]:
            for t in values:
                lines.append(f"| {label} | {mode} | {t['full_gets']} | {t['range_gets']} | {t['heads']} | {t['requests']} | {t['response_body_bytes']} | {t['response_body_read_amplification']:.4f}× |")
    c=on['cache_totals']
    lines += ['',f"缓存边界 pooled 命中率为 {c['hits']}/({c['hits']}+{c['misses']}) = {on['pooled_cache_boundary_hit_ratio']:.4%}；inflight hits={c['inflight_hits']}。它不是文件或元数据专属命中率。",
        f"本地缓存返回字节/两次逻辑读取字节仍为 {on['local_returned_bytes_per_logical_two_pass_bytes']:.3f}×；S3 字节减少不能表述为所有层读放大消失。该计数不是物理盘读取量。", '']
lines += ['## 口径与验收边界', '',
    '- 每臂 SHA、输入清单摘要、配置上限相同；独立从每份 raw `.stats` 重算六个 native 字段、逻辑字节、quiet 边界、两阶段和 E2E-minus-preparation，与 proxy 一致性逐项核验。八个元数据池的实际 capacity 与 peak/owned 边界及拒绝计数也逐份检查；缓存命中统计从原始卸载日志重解析。',
    '- 首次 `.stats` bootstrap 会预热权限元数据；其流量与时间计入准备和 E2E。首次 traversal 不再是完全未经采样的冷态。约 0.5 秒 drain 是两臂都承担的静默观察窗；E2E 直接计时，不能重复叠加 bootstrap。',
    '- retained remount 验证本地持久缓存复用：无新下载、runtime 无 GET/HEAD/body，但 mount manifest 仍需远端读取。private 两臂绕过 proxy/native，只能证明新私有卷、冷缓存重挂和父卷内容隔离，不能把其零 meter 当作零下载或正式 C4 资格。',
    '- 响应体放大分母：首次为 `files*4096`，E2E 为 `2*files*4096`；GET 包含 Range，不能把两者相加。请求总数使用 GET+HEAD。',
    '- 当前对象清单大小低于256MiB整对象缓存容量；没有验证超预算工作集或稀疏少量读取。网络是本机RustFS的S3兼容API，不是真实远端S3链路。',
    '- 所有正式 arm 的 correctness、native warm gate、无错误和清理通过，八对 E2E 均改善。用户最新验收取舍以整体性能为准，因此本轮接受；首次 readdir 一致回退仍完整披露，原严格元数据非回退指标为 false。当前没有正式 C3/C4 distributed 结论。', '',
    '完整逐臂数据、归档 hashes、timing 账目和限制见 `review.json`。'+('四轮已齐。' if complete else '10k 或反向轮次尚未齐，后续仅追加已完成 SHA 归档的轮次。')]
lines += ['', '## 显式预算与默认值', '',
    '| 项目 | 7093 实际默认值 | 本次两臂配置 |', '|---|---:|---:|',
    '| Control | 1 MiB | 8 MiB |', '| Output | 32 MiB | 128 MiB |',
    '| VFS read memory | 8 GiB | 512 MiB |', '| VFS read SSD | 64 GiB | 0 |',
    '| 整对象磁盘缓存 | 256 MiB | 256 MiB |', '',
    f"开启臂原生 Control peak 为 {pool_peaks['on']['control']:,} B，已超过默认 1 MiB。当前结论只适用于匹配的显式预算，不能称作默认预算收益或默认预算下的热态资格。默认值来自 7093 的 `snapshot/budget.rs:51`、`vfs/cache/config.rs:119`；实际 Shared workspace CLI 在 `cli.rs:1807` 调用 `from_env()`。", '',
    '## 第二轮源码审查候选', '',
    '`pack_cache.rs:209–224` 在下载 slot、1 MiB Stored 缓冲与 entry Control 准入（250–264）之前发 HEAD。后者不足会返回 None，转入 Range fallback；没有失败准入记忆来免除下一次同 key HEAD。HEAD 之前已有 transport 状态、driver 数、generation 和 Plans 准入，不能说它完全绕过准入。', '',
    '这支持“预算压力下可能额外 HEAD+Range”的源码候选；当前正式配置未出现预算拒绝，没有测量该压力场景，也没有证据把 readdir 回退归因于它。此复核未改 Rust、未运行新负载。']
if failures:
    lines += ['', '## 完整性检查失败', '']+[f'- {x}' for x in failures]
(OUT/'review.md').write_text('\n'.join(lines)+'\n')
(OUT/'analyze.py').write_bytes(Path(__file__).read_bytes())
(OUT/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
(OUT/'source-followups.json').write_text(json.dumps(source_followups,indent=2)+'\n')
(OUT/'review-artifact-sha256.json').write_text(json.dumps({name:sha(OUT/name) for name in ('review.json','review.md','analyze.py','checks.json','source-followups.json')},indent=2)+'\n')
print(json.dumps({'runs':[r['run'] for r in runs],'checks':len(checks),'integrity_failures':failures,
                  'complete':complete,'verdict':report['verdict'],'aggregates':{n:{k:v for k,v in a.items() if k in ['paired_comparisons','all_pairs_e2e_improve','all_pairs_cold_readdir_regress']} for n,a in aggregates.items()}},indent=2))
