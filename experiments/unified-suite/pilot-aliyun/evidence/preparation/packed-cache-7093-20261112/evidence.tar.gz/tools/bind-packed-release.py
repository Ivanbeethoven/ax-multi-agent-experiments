#!/usr/bin/env python3
"""Copy one frozen cloud release and mechanically bind its backend receipt."""
import argparse
import fcntl
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--source', required=True)
p.add_argument('--sha256', required=True)
p.add_argument('--attempt', type=int, default=1)
p.add_argument('--reuse-transfer', action='store_true')
a = p.parse_args()
assert re.fullmatch('[0-9a-f]{40}', a.source)
assert re.fullmatch('[0-9a-f]{64}', a.sha256)
assert a.attempt > 0
root = Path('/home/dev/ax-packed-build')
evidence = root / ('evidence-final-' + a.source[:8])
evidence.mkdir(exist_ok=True)
binary = root / ('brewfs-' + a.source[:8])
compressed = binary.with_suffix('.gz')
receipt = evidence / f'backend-version-{a.attempt:02}.json'
transfer = evidence / f'binary-transfer-{a.attempt:02}.json'
assert not receipt.exists() and not transfer.exists()
env = dict(os.environ, GIT_OPTIONAL_LOCKS='0', NO_COLOR='1')
# resolve_backend.py performs Docker reads as this user; use its existing
# task-owned sudo wrapper without changing the verifier source or Git user.
wrapper = root / 'readonly-docker-bin' / 'docker'
assert wrapper.read_text() == '#!/bin/sh\nexec sudo -n /usr/bin/docker "$@"\n'
env['PATH'] = str(wrapper.parent) + ':' + env['PATH']
with Path('/home/dev/.ax-rbm-heavy.lock').open('a') as lock:
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    active = subprocess.run(['pgrep', '-ax', 'cargo|rustc|fio|smallfiles'],
                            capture_output=True, text=True)
    assert active.returncode == 1, active.stdout
    started = time.monotonic()
    if not a.reuse_transfer:
        assert not binary.exists() and not compressed.exists()
        with compressed.open('xb') as out:
            subprocess.run([str(root / 'cloud'),
                            'gzip -1c /srv/packed/target/release/brewfs'],
                           stdout=out, check=True, timeout=180)
        with gzip.open(compressed, 'rb') as src, binary.open('xb') as out:
            shutil.copyfileobj(src, out)
        binary.chmod(0o755)
    with binary.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    assert digest == a.sha256, (digest, a.sha256)
    version = subprocess.check_output([str(binary), '--version'], text=True, env=env)
    assert re.search(r'^commit: ' + a.source + '$', version, re.M), version
    assert re.search(r'^dirty: false$', version, re.M), version
    (evidence / f'actual-binary-version-{a.attempt:02}.txt').write_text(version)
    record = dict(source_commit=a.source, binary_sha256=digest,
                  binary_bytes=binary.stat().st_size, compressed_bytes=compressed.stat().st_size,
                  transfer_and_verification_seconds=time.monotonic() - started,
                  reused_transfer=a.reuse_transfer, held_shared_heavy_lock=True,
                  binary_version=version, backend_receipt=receipt.name)
    transfer.write_text(json.dumps(record, indent=2) + '\n')
    subprocess.run(['python3', '/home/dev/ax-packed-naming-final/infra/rustfs/resolve_backend.py',
                    'image', '--rustfs-source', '/home/dev/ax-packed-rustfs',
                    '--brewfs-source', '/home/dev/ax-packed-brewfs',
                    '--brewfs-binary', str(binary),
                    '--image', 'sha256:9750c5eaaac37e2d6ebaa8aaf39a4aa98a35fca5fba8de5ade26585123058806',
                    '--output', str(receipt)], check=True, env=env, timeout=120)
    print(json.dumps(dict(passed=True, directory=str(evidence), receipt=receipt.name,
                          binary_sha256=digest, elapsed_seconds=time.monotonic() - started)))
