#!/usr/bin/env python3
"""Copy completed, immutable run artifacts from cloud and verify every raw byte."""
import argparse, datetime, hashlib, json, pathlib, re, shlex, subprocess, tarfile
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--source', required=True)
p.add_argument('--run', required=True)
p.add_argument('--remote-helper', default='/home/dev/ax-packed-build/cloud')
p.add_argument('--remote-host', default='8.136.137.130')
a=p.parse_args()
assert re.fullmatch(r'[0-9a-f]{40}',a.source)
assert re.fullmatch(r'pair-(?:128|10000)-[0-9]{2}',a.run)
cloud=a.remote_helper
assert pathlib.Path(cloud).resolve().is_relative_to('/home/dev/ax-packed-build')
remote='/srv/packed/evidence-final-'+a.source[:8]
root=pathlib.Path('/home/dev/ax-packed-build/evidence-final-'+a.source[:8])
root.mkdir(exist_ok=True)
receipts=root/'archive-receipts'
receipts.mkdir(exist_ok=True)
receipt=receipts/(a.run+'.json')
assert not receipt.exists(), 'Do not overwrite an archive receipt'
names=[a.run+'.json',a.run+'-invocation.json',a.run+'-run.log',a.run+'-raw']
code="""import hashlib,json,pathlib,sys
root=pathlib.Path(sys.argv[1]); result={}
for name in sys.argv[2:]:
 p=root/name
 assert p.exists(),str(p)
 for f in sorted(p.rglob('*')) if p.is_dir() else [p]:
  if f.is_dir(): continue
  assert f.is_file() and not f.is_symlink(),str(f)
  data=f.read_bytes(); result[str(f.relative_to(root))]={'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)}
print(json.dumps(result,sort_keys=True))
"""
query='python3 -c '+shlex.quote(code)+' '+shlex.join([remote,*names])
manifest=json.loads(subprocess.check_output([cloud,query],text=True,timeout=30))
archive=receipts/(a.run+'.transport.tar')
assert not archive.exists()
command='tar -C '+shlex.quote(remote)+' -cf - '+shlex.join(names)
with archive.open('xb') as stream:
 subprocess.run([cloud,command],stdout=stream,check=True,timeout=180)
with tarfile.open(archive,'r:') as bundle:
 members={m.name.rstrip('/'):m for m in bundle.getmembers()}
 assert set(manifest)=={n for n,m in members.items() if m.isfile()}
 for name,info in manifest.items():
  m=members[name]
  assert m.isfile() and not m.issym() and not m.islnk()
  dest=root/name
  assert dest.resolve().is_relative_to(root.resolve())
  data=bundle.extractfile(m).read()
  assert len(data)==info['bytes'] and hashlib.sha256(data).hexdigest()==info['sha256'],name
  if dest.exists(): assert dest.read_bytes()==data,name
  else:
   dest.parent.mkdir(parents=True,exist_ok=True)
   dest.write_bytes(data)
 for name,info in manifest.items():
  data=(root/name).read_bytes()
  assert hashlib.sha256(data).hexdigest()==info['sha256'],name
record={'source_commit':a.source,'run':a.run,'cloud_directory':remote,'actual_remote_host':a.remote_host,'remote_helper':cloud,
 'archived_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'cloud_to_rbm_sha256_matched':True,'raw_files':manifest,
 'transport_tar_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
 'transport_tar_bytes':archive.stat().st_size}
receipt.write_text(json.dumps(record,indent=2)+'\n')
archive.unlink()
print(json.dumps({'passed':True,'receipt':str(receipt),'raw_files':len(manifest),'raw_bytes':sum(x['bytes'] for x in manifest.values())}))
