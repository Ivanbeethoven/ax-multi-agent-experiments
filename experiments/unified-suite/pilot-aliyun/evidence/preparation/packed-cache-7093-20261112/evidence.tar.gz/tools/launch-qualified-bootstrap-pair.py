#!/usr/bin/env python3
"""Launch one isolated qualification run after checking frozen source and artifacts."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--campaign', type=Path, required=True)
p.add_argument('--name', required=True)
p.add_argument('--files', type=int, choices=(128, 10000), required=True)
p.add_argument('--order', choices=('off-on', 'on-off'), required=True)
p.add_argument('--source', required=True)
p.add_argument('--harness-commit', required=True)
p.add_argument('--brewfs-sha256', required=True)
p.add_argument('--producer-sha256', required=True)
a = p.parse_args()
assert re.fullmatch(r'[a-z0-9][a-z0-9-]+', a.name)
assert re.fullmatch(r'[0-9a-f]{40}', a.source)
assert re.fullmatch(r'[0-9a-f]{40}', a.harness_commit)
assert a.harness_commit == '3d756ff5b99a3b36fe28eec43cf35f122c756322'
assert all(re.fullmatch(r'[0-9a-f]{64}', x) for x in (a.brewfs_sha256, a.producer_sha256))
root = a.campaign.resolve()
assert root.is_relative_to('/srv/packed') and root != Path('/srv/packed')
root.mkdir(parents=True, exist_ok=True)
result = root / (a.name + '.json')
invocation = root / (a.name + '-invocation.json')
log = root / (a.name + '-run.log')
assert not any(x.exists() for x in (result, invocation, log)), 'Never overwrite an attempt'
processes = subprocess.check_output(['ps', '-eo', 'comm='], text=True).splitlines()
assert not any(x.strip().startswith(('rustc', 'cargo')) for x in processes), 'Compilation overlaps measurement'
repo = Path('/srv/packed/ax-packed-brewfs')
git_env = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
commit = subprocess.check_output(['git', '-C', str(repo), 'rev-parse', 'HEAD'], text=True, env=git_env).strip()
assert commit == a.source, (commit, a.source)
assert not subprocess.check_output(['git', '-C', str(repo), 'status', '--porcelain'], text=True, env=git_env).strip(), 'Dirty source'
binary = Path('/srv/packed/target/release/brewfs')
producer = binary.with_name('packed_snapshot_fixture')
version = subprocess.check_output([str(binary), '--version'], text=True, env=dict(os.environ, NO_COLOR='1'))
assert re.search(r'^commit: ' + re.escape(a.source) + r'$', version, re.M), version
assert re.search(r'^dirty: false$', version, re.M), version

def sha(path):
    with path.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

hashes = {str(binary): sha(binary), str(producer): sha(producer)}
assert hashes[str(binary)] == a.brewfs_sha256
assert hashes[str(producer)] == a.producer_sha256
scripts = Path('/srv/packed/ax-packed-exp/experiments/unified-suite/pilot-aliyun/scripts')
harness = scripts / 'qualify-packed-cache.py'
meter = scripts / 'whole_pack_meter.py'
helper = scripts / 'packed_native_probe.py'
assessor = Path('/srv/packed/ax-packed-exp/bench/warm_lower.py')
script_hashes = {harness.name: sha(harness), meter.name: sha(meter), helper.name: sha(helper), 'bench/warm_lower.py': sha(assessor)}
assert script_hashes == {
    'qualify-packed-cache.py': '9ef4bc8d176355ab3fc14f8825c4daaedac2a93e504d9403d90b3eb1457462ba',
    'whole_pack_meter.py': '4646ca21451e1c92f62b7e917f78de158334632303eab4391ffb6a94b6c1e9d5',
    'packed_native_probe.py': '6dcdff62148fc5e210641e8e92bde8482c1b666d7193115e27f33453b14e2177',
    'bench/warm_lower.py': '0ab0d72443f74d6db5701bc635b2e4d02c4860cc0d90b240f4f9c77feb4738f2',
}, 'Native qualification harness differs from its frozen hashes'
args = [str(harness), str(result), '--binary', str(binary), '--producer', str(producer),
        '--files', str(a.files), '--order', a.order]
dry = 'import runpy,sys; sys.argv=sys.argv[1:]; runpy.run_path(sys.argv[0],init_globals={"exec":lambda *a:None})'
subprocess.run([sys.executable, '-c', dry, *args], check=True)
record = dict(source_commit=commit, harness_commit=a.harness_commit, scripts=script_hashes, assessor_commit='9e25471f658e076d36c4cbe9daa62f00ae0794cf',
              measurement_prelude='Explicit stats bootstrap then strictly quiet baseline; setup cost remains in E2E and first traversal follows this metadata initialization',
              started_at=datetime.datetime.now(datetime.timezone.utc).isoformat(), args=args,
              binary_hashes=''.join(digest + '  ' + path + '\n' for path, digest in hashes.items()),
              binary_version=version, source_clean=True, no_compile_processes_at_start=True,
              launcher_sha256=sha(Path(__file__)))
with invocation.open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
unit = 'packed-requal-' + a.source[:8] + '-' + a.name
subprocess.run(['systemd-run', '--unit=' + unit, '--property=MemoryMax=12G',
                '--property=RuntimeMaxSec=' + str(660 if a.files == 128 else 1560),
                '--property=StandardOutput=append:' + str(log),
                '--property=StandardError=append:' + str(log),
                sys.executable, *args], check=True)
print(json.dumps(dict(unit=unit, result=str(result), source=commit)))
