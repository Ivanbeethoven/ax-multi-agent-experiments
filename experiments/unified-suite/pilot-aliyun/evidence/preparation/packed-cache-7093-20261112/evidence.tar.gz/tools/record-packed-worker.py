import datetime,json,pathlib,platform,socket,subprocess
root=pathlib.Path('/srv/packed/evidence-final-7093f141')
root.mkdir(parents=True,exist_ok=True)
p=root/'execution-host.json'
assert not p.exists()
comm=subprocess.check_output(['ps','-eo','comm='],text=True).splitlines()
blocked=[x.strip() for x in comm if x.strip().startswith(('cargo','rustc','fio','smallfiles'))]
assert not blocked,blocked
containers=subprocess.check_output(['docker','ps','--format','{{.ID}} {{.Image}} {{.Names}}'],text=True).strip()
assert not containers,containers
actual_ip_addresses=subprocess.check_output(['hostname','-I'],text=True).split()
assert '10.20.2.188' in actual_ip_addresses,actual_ip_addresses
r=dict(actual_ip_addresses=actual_ip_addresses,schema='packed-execution-host-20261112',captured_at=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 source_commit='7093f141d8081e6b96cd0a80814876aed5a3b577',harness_commit='3d756ff5b99a3b36fe28eec43cf35f122c756322',
 resource=dict(instance_id='i-bp18896j0lpor86ysx2z',instance_type='ecs.g7.2xlarge',vcpus=8,memory_gib=32,zone='cn-hangzhou-j',private_ip='10.20.2.188',public_ip=None,
 disk_id='d-bp18896j0lpor86w402k',disk_gib=120,disk_type='ESSD PL1',auto_release_utc='2026-11-12T18:27:00Z',
 control_plane_receipt='rbm:/home/dev/ax-perf-issues-validation/cloud-runtime/'),
 hostname=socket.gethostname(),uname=platform.uname()._asdict(),os_release=pathlib.Path('/etc/os-release').read_text(),
 cpu=json.loads(subprocess.check_output(['lscpu','--json'],text=True)),meminfo=pathlib.Path('/proc/meminfo').read_text(),
 disk=subprocess.check_output(['df','-B1','/srv/packed'],text=True),active_compile_or_perf_processes=blocked,running_containers_before_campaign=containers,
 measurement_limits=dict(client_cpu=2,client_memory_gib=8,rustfs_cpu=2,rustfs_memory_gib=2),
 scope='All final 7093 timed arms on this exclusive worker. Static release/backend provenance bound on rbm; actual container identity checked on this worker by every run. No pooling of prior r7/64GiB absolute timings.')
p.write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps(dict(record=str(p),hostname=r['hostname'],private_ip=r['resource']['private_ip'],cpu=r['resource']['vcpus'],memory_gib=32,passed=True)))
