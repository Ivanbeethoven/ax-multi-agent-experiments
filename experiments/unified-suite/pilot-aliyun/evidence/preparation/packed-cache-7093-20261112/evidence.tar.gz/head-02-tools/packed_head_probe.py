"""Bounded, exact-object HEAD gate for an independent Packed diagnostic."""
from contextlib import contextmanager
from http.client import HTTPConnection
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from threading import Event, Lock, Thread
from urllib.parse import unquote, urlsplit
import hashlib
import os
from pathlib import Path
import re
import socket
import time

class Probe:
    def __init__(self, bucket, large):
        self.bucket=bucket; self.large=large; self.lock=Lock(); self.events=[]
        self.entered=Event(); self.release=Event(); self.armed=False; self.exclude=set()
        self.gated=None; self.counts=dict(gets=0,ranges=0,heads=0,bytes=0,errors=0,active=0,duplicate_gets=0)
        self.seen=set()
    def __call__(self):
        with self.lock: return dict(self.counts)
    def reset_duplicates(self):
        with self.lock: self.seen.clear()
    def records(self):
        with self.lock: return [dict(x) for x in self.events]
    def arm(self, exclude):
        with self.lock:
            assert not self.armed
            self.exclude=set(exclude); self.gated=None; self.entered.clear(); self.release.clear(); self.armed=True
    def disarm(self):
        self.release.set()
        with self.lock: self.armed=False

@contextmanager
def gated_proxy(port,bucket,large):
    probe=Probe(bucket,large)
    class Handler(BaseHTTPRequestHandler):
        protocol_version='HTTP/1.1'
        def setup(self):
            super().setup(); self.connection.setsockopt(socket.IPPROTO_TCP,socket.TCP_NODELAY,1)
        def log_message(self,*_): pass
        def forward(self):
            path=unquote(urlsplit(self.path).path)
            prefix='/'+bucket+'/'
            key=path[len(prefix):] if path.startswith(prefix) else None
            row=dict(method=self.command,key=key,range=self.headers.get('Range'),start_ns=time.monotonic_ns(),gated=False,status=None,bytes=0)
            with probe.lock:
                probe.events.append(row); probe.counts['active']+=1
                gate=probe.armed and self.command=='HEAD' and key in large and key not in probe.exclude and probe.gated is None
                if gate:
                    row['gated']=True; probe.gated=row; probe.entered.set()
            conn=HTTPConnection('127.0.0.1',port,timeout=10)
            try:
                if gate:
                    row['released_by_signal']=probe.release.wait(2.0)
                    row['release_ns']=time.monotonic_ns()
                conn.request(self.command,self.path,headers=dict(self.headers.items()))
                resp=conn.getresponse();row['status']=resp.status
                with probe.lock:
                    probe.counts['heads']+=self.command=='HEAD';probe.counts['gets']+=self.command=='GET'
                    probe.counts['ranges']+=self.command=='GET' and resp.status==206
                    probe.counts['errors']+=resp.status>=400
                assert resp.getheader('Content-Length') is not None
                self.send_response_only(resp.status)
                for k,v in resp.getheaders():
                    if k.lower() not in ('connection','transfer-encoding'): self.send_header(k,v)
                self.end_headers()
                if self.command=='GET':
                    while chunk:=resp.read(64<<10):
                        self.wfile.write(chunk);row['bytes']+=len(chunk)
                        with probe.lock: probe.counts['bytes']+=len(chunk)
            except Exception as error:
                row['error']=type(error).__name__;self.close_connection=True
                with probe.lock: probe.counts['errors']+=1
            finally:
                conn.close();row['end_ns']=time.monotonic_ns()
                with probe.lock:probe.counts['active']-=1
        do_GET=do_HEAD=forward
    with ThreadingHTTPServer(('127.0.0.1',0),Handler) as server:
        server.daemon_threads=True
        thread=Thread(target=server.serve_forever,daemon=True);thread.start()
        try:yield f'http://127.0.0.1:{server.server_port}',probe
        finally:probe.disarm();server.shutdown();thread.join()

def inventory(s3,bucket,objects):
    large={}
    for obj in objects:
        response=s3.get_object(Bucket=bucket,Key=obj['key'],Range='bytes=0-7')
        try:magic=response['Body'].read()
        finally:response['Body'].close()
        if magic==b'BRFLD005':large[obj['key']]=obj['bytes']
    assert len(large)==8,('expected observed 16MiB plus 4MiB split for four source files',large)
    assert sorted(large.values())==[4198496]*4+[16781408]*4,large
    return large

def sample(point,work,label):
    raw=(point/'.stats').read_text()
    (work/('head-'+label+'.stats')).write_text(raw)
    rows={}
    for line in raw.splitlines():
        if not line or line.startswith('#'):continue
        match=re.fullmatch(r'([^ ]+)\s+([0-9]+)',line)
        if match:rows[match[1]]=int(match[2])
    required=['brewfs_packed_logical_bytes_total']+['brewfs_packed_runtime_backend_'+x+'_total' for x in ('full_gets','heads','range_gets','received_bytes','failures')]
    assert all(x in rows for x in required), 'Missing actual Packed metrics'
    counts=[value for key,value in rows.items() if key.startswith('brewfs_object_read_work_nanoseconds_count{') and 'kind="external_payload"' in key and 'work="decode_wall"' in key]
    return dict(raw_file='head-'+label+'.stats',runtime={k:rows[k] for k in required},external_decode_count=sum(counts),external_decode_series_present=bool(counts))

def diagnose(point,work,probe,payload,wait_for,result=None):
    result={} if result is None else result
    result.update(passed=False,scope='Independent bounded HEAD registry diagnostic; not a throughput pair',trials=[])
    fds={}
    try:
        sample(point,work,'bootstrap')
        for name in sorted(payload):fds[name]=os.open(point/name,os.O_RDONLY)
        for key in ('B-control','B-trial-0','B-trial-1','B-trial-2'):fds[key]=os.open(point/'B.bin',os.O_RDONLY)
        wait_for(lambda:probe()['active']==0,'preopened descriptor metadata drain')
        assert not any(e['key'] in probe.large for e in probe.records()),'Opening files unexpectedly fetched external payload'
        b='B.bin';start=len(probe.records())
        assert os.pread(fds[b],4096,0)==payload[b][:4096]
        wait_for(lambda:probe()['active']==0,'B whole download',30)
        seen=[e for e in probe.records()[start:] if e['key'] in probe.large and e['method']=='GET']
        assert len(seen)==1 and seen[0]['status']==200,seen
        bkey=seen[0]['key']; digest=hashlib.sha256(bkey.encode()).hexdigest()
        def persisted():
            files=list((work/'cache-on-head').rglob(digest+'.pack'))
            return files[0] if len(files)==1 and files[0].stat().st_size==probe.large[bkey] else None
        ready=wait_for(persisted,'B complete persisted object',30)
        result['b_ready']=dict(key=bkey,object_bytes=probe.large[bkey],persisted_file=str(ready.relative_to(work)),actual_bytes=ready.stat().st_size)
        cached=ready.read_bytes()
        fragments={}
        for offset in (2<<20,4<<20,8<<20,12<<20):
            fragment=payload[b][offset:offset+4096];stored=cached.find(fragment)
            assert stored>=0 and cached.find(fragment,stored+1)==-1,('B fragment absent or ambiguous in fully persisted object',offset)
            fragments[str(offset)]=dict(stored_offset=stored,bytes=4096,sha256=hashlib.sha256(fragment).hexdigest())
        result['b_ready'].update(object_sha256=hashlib.sha256(cached).hexdigest(),unique_source_fragments=fragments)
        del cached
        control_before=sample(point,work,'control-before')
        control_events=len(probe.records());control_start=time.monotonic_ns()
        control_body=os.pread(fds['B-control'],4096,2<<20)
        control_end=time.monotonic_ns()
        assert control_body==payload[b][2<<20:(2<<20)+4096]
        control_after=sample(point,work,'control-after')
        control_decode=control_after['external_decode_count']-control_before['external_decode_count']
        control_logical=control_after['runtime']['brewfs_packed_logical_bytes_total']-control_before['runtime']['brewfs_packed_logical_bytes_total']
        control=dict(offset=2<<20,fd_policy='preopened independent never-read descriptor',start_ns=control_start,end_ns=control_end,sha256=hashlib.sha256(control_body).hexdigest(),
            before=control_before,after=control_after,events=probe.records()[control_events:],
            external_decode_delta=control_decode,logical_delta=control_logical)
        control['passed']=control_decode==1 and control_logical==4096 and not control['events']
        result['b_control']=control
        if not control['passed']:
            result['interpretation']='inconclusive: unblocked B control did not prove one local external-frame decode'
            return result
        previous={bkey}
        # Each target uses an independently preopened, never-read descriptor.
        # Unique raw fragments prove all offsets belong to the fully ready object.
        for n,offset in enumerate((4<<20,8<<20,12<<20)):
            aname=f'A{n}.bin';before=sample(point,work,f'trial-{n}-before')
            result_before=probe();events_before=len(probe.records());probe.arm(previous)
            aresult={};bresult={};adone=Event();bdone=Event()
            def read(name,at,out,done,fd):
                out['start_ns']=time.monotonic_ns()
                try:
                    data=os.pread(fd,4096,at)
                    out['sha256']=hashlib.sha256(data).hexdigest();out['valid']=data==payload[name][at:at+4096]
                except Exception as error:out['error']=type(error).__name__+': '+str(error)
                finally:out['end_ns']=time.monotonic_ns();done.set()
            ta=Thread(target=read,args=(aname,0,aresult,adone,fds[aname]),daemon=True);ta.start()
            assert probe.entered.wait(3),'Cold A did not reach its distinct external HEAD'
            gated=probe.gated;assert gated['key']!=bkey and gated['key'] not in previous
            tb=Thread(target=read,args=(b,offset,bresult,bdone,fds[f'B-trial-{n}']),daemon=True);tb.start()
            b_finished_while_head_blocked=bdone.wait(.250)
            release_requested_ns=time.monotonic_ns();probe.disarm()
            ta.join(10);tb.join(10)
            assert adone.is_set() and bdone.is_set(),'Bounded diagnostic read failed to return'
            assert aresult.get('valid') and bresult.get('valid'),(aresult,bresult)
            wait_for(lambda:probe()['active']==0,'trial request drain',30)
            after=sample(point,work,f'trial-{n}-after')
            events=probe.records()[events_before:]
            b_network=[e for e in events if e['key']==bkey]
            decode_delta=after['external_decode_count']-before['external_decode_count']
            logical_delta=after['runtime']['brewfs_packed_logical_bytes_total']-before['runtime']['brewfs_packed_logical_bytes_total']
            proof=not b_network and logical_delta==8192 and decode_delta==2 and gated.get('released_by_signal') is True
            trial=dict(index=n,a=aname,b=b,b_offset=offset,head=gated,release_requested_ns=release_requested_ns,
                b_finished_while_head_blocked=b_finished_while_head_blocked,a_read=aresult,b_read=bresult,
                before=before,after=after,external_decode_delta=decode_delta,logical_delta=logical_delta,
                b_network_events=b_network,events=events,path_isolation_proven=proof,
                observed_cross_object_wait=proof and not b_finished_while_head_blocked and bresult['end_ns']>=gated['release_ns'])
            result['trials'].append(trial);previous.add(gated['key'])
        result['passed']=all(x['path_isolation_proven'] for x in result['trials']) and probe()['errors']==0
        result['reproduced']=result['passed'] and all(x['observed_cross_object_wait'] for x in result['trials'])
        result['interpretation']='reproduced' if result['reproduced'] else ('not reproduced' if result['passed'] else 'inconclusive path isolation')
        return result
    finally:
        probe.disarm()
        for fd in fds.values():os.close(fd)
