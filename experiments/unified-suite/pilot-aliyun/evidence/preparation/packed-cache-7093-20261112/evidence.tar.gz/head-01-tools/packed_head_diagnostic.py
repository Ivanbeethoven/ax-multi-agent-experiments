#!/usr/bin/env python3
"""Independent post-qualification HEAD stall diagnostic; does not edit the frozen harness."""
import argparse
import hashlib
import json
from pathlib import Path
import runpy
import subprocess
import sys

p=argparse.ArgumentParser(description=__doc__)
p.add_argument('result',type=Path)
p.add_argument('--harness',type=Path,required=True)
p.add_argument('--binary',type=Path,required=True)
p.add_argument('--producer',type=Path,required=True)
p.add_argument('--formal-campaign',type=Path,required=True)
p.add_argument('--dry-run',action='store_true')
a=p.parse_args()
assert hashlib.sha256(a.harness.read_bytes()).hexdigest()=='9ef4bc8d176355ab3fc14f8825c4daaedac2a93e504d9403d90b3eb1457462ba'
sys.path.insert(0,str(Path(__file__).resolve().parent))
saved=sys.argv
sys.argv=[str(a.harness),str(a.result),'--binary',str(a.binary),'--producer',str(a.producer),'--files','128','--order','off-on']
try: generated=runpy.run_path(str(a.harness),init_globals={'exec':lambda *args:None})
finally:sys.argv=saved
text=generated['text'];options=generated['args']
def replace(old,new):
 global text
 assert text.count(old)==1,old
 text=text.replace(old,new,1)
replace('from packed_native_probe import NativeProbe','from packed_native_probe import NativeProbe\nfrom packed_head_probe import gated_proxy, inventory, diagnose')
replace("schema='packed-whole-object-cache-native-pair-v1',passed=False,files=options.files", "schema='packed-independent-head-stall-diagnostic-v1',passed=False,files=4")
replace("scope='One cloud host; fresh mount per arm, shared RustFS cache; readdir then serial sorted paths; SHA-256 checked.'", "scope='Separate post-qualification HEAD gate with four dense 20MiB files; no throughput conclusion'")
replace("payload={f'{i//32:04d}/{i:06d}.bin': hashlib.shake_256(i.to_bytes(8,'little')).digest(4096)\n             for i in range(options.files)}", "payload={name: hashlib.shake_256(('packed-head:'+name).encode()).digest(20<<20)\n             for name in ('A0.bin','A1.bin','A2.bin','B.bin')}")
start=text.index('    if mutate is not None:',text.index('def visit('))
stop=text.index('\ntry:',start)
text=text[:start]+'''
    arm=result['readbacks'][side]=dict(passed=False)
    diagnose(point,work,counters,payload,wait_for,arm)
    stop_mount(True)
    messages=log_file.read_text(errors='replace')
    metrics=re.findall(r'(hits|misses|ready_hits|inflight_hits|local_bytes|downloaded)\\s*[:=]\\s*(\\d+)',messages)
    arm['cache']={key:int(value) for key,value in metrics}
    arm['cgroup_memory_peak_bytes']=int((cgroup/'memory.peak').read_text())
    return arm['passed']
''' + text[stop:]
start=text.index('    from whole_pack_meter import meter')
stop=text.index('except Exception as error:',start)
text=text[:start]+'''
    phase='large-object-inventory'
    large=inventory(s3,bucket,result['object_sizes'])
    result['large_objects']=large
    result['fixture_contract']=dict(files=4,file_bytes=20<<20,dense=True,chunk_bytes=64<<20,
        content='SHAKE256(packed-head:<filename>), varied across offsets',
        initial_b_offset=0,previously_unread_b_offsets=[8<<20,12<<20,16<<20],
        head_hold_seconds=.250,automatic_release_seconds=2)
    with gated_proxy(sp,bucket,large) as (measured_endpoint,counters):
        observed_data=dict(data,s3=dict(data['s3'],endpoint=measured_endpoint))
        phase='head-isolation'
        result['passed']=visit('on-head',parent['workspace_id'],observed_data,rurl,namespace,counters)
        result['probe_events']=counters.records()
        result['probe_totals']=counters()
    result['passed']=result['passed'] and bool(result['parent_binding'])
''' + text[stop:]
replace("except Exception as error:\n    result['failed_phase']=phase", "except Exception as error:\n    if 'counters' in globals() and hasattr(counters,'records'):\n        result['probe_events']=counters.records();result['probe_totals']=counters()\n    result['failed_phase']=phase")
replace('deadline = time.monotonic() + (600 if options.files == 128 else 1500)', """result['measured_source_commit']='7093f141d8081e6b96cd0a80814876aed5a3b577'
result['diagnostic_tools']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path(__file__),Path(__file__).with_name('packed_head_probe.py'))}
result['native_protocol']=dict(schema='head-gate-native-path-evidence',scope='Raw snapshots; external decode and logical byte deltas identify requested frames. Not the formal paired warm gate.')
result.pop('order',None)
deadline = time.monotonic() + 600""")
compiled=compile(text,str(Path(__file__))+'::generated','exec')
if a.dry_run:
 print(json.dumps(dict(parsed=True,generated_sha256=hashlib.sha256(text.encode()).hexdigest(),
   wrapper_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
   helper_sha256=hashlib.sha256(Path(__file__).with_name('packed_head_probe.py').read_bytes()).hexdigest(),
   fixture_files=4,fixture_file_bytes=20<<20,producer_interface='--source-directory (no separate large-file CLI flag)')))
else:
 assert not a.result.exists()
 for name in ('pair-128-01','pair-128-02','pair-10000-01','pair-10000-02'):
  r=json.loads((a.formal_campaign/(name+'.json')).read_text())
  i=json.loads((a.formal_campaign/(name+'-invocation.json')).read_text())
  assert r['passed'] and i['source_commit']=='7093f141d8081e6b96cd0a80814876aed5a3b577'
  for binary in (a.binary,a.producer):
   with binary.open('rb') as stream: digest=hashlib.file_digest(stream,'sha256').hexdigest()
   assert digest==r['binary_sha256'][binary.name]
 assert not any(x.strip().startswith(('cargo','rustc')) for x in subprocess.check_output(['ps','-eo','comm='],text=True).splitlines())
 (a.result.parent/(a.result.stem+'-generated.py')).write_text(text)
 exec(compiled,dict(__name__='__main__',__file__=str(Path(__file__).resolve()),options=options))
