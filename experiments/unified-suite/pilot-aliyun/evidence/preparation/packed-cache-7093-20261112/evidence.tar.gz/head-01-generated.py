import hashlib
from packed_native_probe import NativeProbe
from packed_head_probe import gated_proxy, inventory, diagnose
from bench import warm_lower as native_metrics
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import signal
import socket
import subprocess
import sys
import tempfile
import time
import uuid

import boto3
from botocore.config import Config

result_path = options.result.resolve()
assert not result_path.exists()
work = Path(tempfile.mkdtemp(prefix='ax-c4-packed-fork-'))
name = 'ax-c4-packed-fork-' + uuid.uuid4().hex[:8]
tag = 'ax.c4.packed-fork.owner'
redis, rustfs = name + '-redis', name + '-rustfs'
images = {
    redis: 'sha256:63218503f6461303e502355b8b0359a1194a190341f954e7fc7e8f92cd382a43',
    rustfs: 'sha256:9750c5eaaac37e2d6ebaa8aaf39a4aa98a35fca5fba8de5ade26585123058806',
}
binary = options.binary.resolve(strict=True)
producer = options.producer.resolve(strict=True)
pins = {}
for asset in (binary, producer):
    with asset.open('rb') as stream:
        pins[asset] = hashlib.file_digest(stream, 'sha256').hexdigest()
access, secret = secrets.token_hex(12), secrets.token_hex(24)
env = dict(os.environ, AWS_ACCESS_KEY_ID=access, AWS_SECRET_ACCESS_KEY=secret, AWS_REGION='us-east-1',
    AWS_EC2_METADATA_DISABLED='true', RUST_LOG='warn,brewfs::workspace::packed::readonly=info',
    BREWFS_FUSE_READ_DIRECT_IO='1', BREWFS_PACKED_METADATA_CACHE_BYTES=str(256 << 20),
    BREWFS_PACKED_OUTPUT_BUDGET_BYTES=str(128 << 20),
    BREWFS_PACKED_CONTROL_BUDGET_BYTES=str(8 << 20), NO_COLOR='1', NO_PROXY='127.0.0.1,localhost')
point = work/'mount'
point.mkdir()
proc = None
log = None
active_side = None
phase = 'preflight'
result = dict(schema='packed-independent-head-stall-diagnostic-v1',passed=False,files=4,
    base_commit='ca07159f3da4b670e4aeb878faef928e69bc1634',
    native_protocol=dict(schema='native-runtime-proxy-reconciliation-bootstrap',
        first_pass_description='First traversal/read after recorded stats initialization; some permission metadata is already warm',
        timing_accounting='mount_ready plus stats_initialization equals mount_preparation; sampling_ns includes this initialization and must not be added to preparation twice; E2E is directly timed',
        assessor_commit='9e25471f658e076d36c4cbe9daa62f00ae0794cf',
        assessor_sha256=hashlib.sha256(Path(native_metrics.__file__).read_bytes()).hexdigest(),
        helper_sha256=hashlib.sha256(Path(sys.modules[NativeProbe.__module__].__file__).read_bytes()).hexdigest()),
    binary_sha256={p.name:s for p,s in pins.items()},
    image_sha256={'redis':images[redis],'rustfs':images[rustfs]},
    no_model=True,no_cloud=False,no_copy_baseline=True,formal_sample=False,readbacks={},
    scope='Separate post-qualification HEAD gate with four dense 20MiB files; no throughput conclusion', order=options.order, budgets=dict(packed_disk_bytes=256<<20, metadata_bytes=256<<20, payload_memory_bytes=512<<20, payload_ssd_bytes=0, output_bytes=128<<20, control_bytes=8<<20, process_memory_bytes=8<<30, cpu_cores=2))
result['measured_source_commit']='7093f141d8081e6b96cd0a80814876aed5a3b577'
result['diagnostic_tools']={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path(__file__),Path(__file__).with_name('packed_head_probe.py'))}
result['native_protocol']=dict(schema='head-gate-native-path-evidence',scope='Raw snapshots; external decode and logical byte deltas identify requested frames. Not the formal paired warm gate.')
result.pop('order',None)
deadline = time.monotonic() + 600

def expired(*_):
    raise TimeoutError('Smoke time limit reached')

signal.signal(signal.SIGTERM, expired)
signal.signal(signal.SIGALRM, expired)
signal.alarm(610 if options.files == 128 else 1510)

def clean_text(text):
    for token in (access,secret):
        text = text.replace(token,'[redacted]')
    return re.sub(r'\x1b\[[0-?]*[ -/]*[@-~]','',text)[-3000:]

def invoke(argv, check=True, limit=15, bounded=True):
    t=max(.1,min(limit,deadline-time.monotonic())) if bounded else limit
    p=subprocess.run(list(map(str,argv)),env=env,capture_output=True,text=True,timeout=t)
    if check and p.returncode:
        raise RuntimeError(f'{Path(str(argv[0])).name} exited {p.returncode}: '+clean_text(p.stderr+'\n'+p.stdout))
    return p

def docker(*args, **kwargs):
    return invoke(['docker',*args],**kwargs)

def wait_for(check, name, limit=18):
    end=min(deadline,time.monotonic()+limit)
    while time.monotonic()<end:
        val=check()
        if val:return val
        time.sleep(.15)
    raise TimeoutError('Readiness timed out: '+name)

def listening(port):
    try:
        with socket.create_connection(('127.0.0.1',port),timeout=.3): return True
    except OSError: return False

def port(container, spec):
    return int(docker('port',container,spec).stdout.strip().rsplit(':',1)[1])

def mounted():
    return any(row.split()[4]==str(point) for row in Path('/proc/self/mountinfo').read_text().splitlines())

def stop_mount(strict):
    global proc, log, active_side
    if proc is None:return
    unmount = None
    if mounted():
        unmount=invoke(['fusermount3','-u',point],check=False,limit=3,bounded=False).returncode
    try:code=proc.wait(timeout=5)
    except subprocess.TimeoutExpired:
        proc.terminate()
        try:code=proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            proc.kill();code=proc.wait(timeout=3)
    log.close()
    result.setdefault('mount_exits',{})[active_side]=dict(exit_code=code,mount_absent=not mounted(),unmount_exit_code=unmount)
    proc=None;log=None
    if strict and (code or mounted() or unmount not in (None,0)):
        raise RuntimeError('Nonclean '+str(active_side)+' FUSE exit')

def json_call(prefix,*args):
    raw=invoke([*prefix,*args]).stdout.strip()
    return json.loads(raw)

def binding(workspace):
    lines=invoke(['/usr/bin/redis-cli','-p',str(rp),'--scan','--pattern','*packed/current/'+workspace]).stdout.splitlines()
    if len(lines)>1: raise RuntimeError('Ambiguous Packed binding keys')
    return bool(lines)

def visit(side, workspace, data, rurl, namespace, counters, mutate=None):
    global active_side,proc,log
    active_side=side
    cfg=work/(side+'.json')
    cfg.write_text(json.dumps(dict(volume_format='workspace',volume={'format':'workspace'},
        workspace=workspace,workspace_namespace=namespace,data=data,
        meta={'backend':'redis','redis':{'url':rurl}},layout=dict(chunk_size=67108864,block_size=4194304),
        fuse=dict(workers=4,max_background=128,cache_ttl_ms=0,keep_cache=False),
        cache=dict(cache_root=str(work/('cache-'+side.removesuffix('-remount'))),writeback_mode='upload_before_commit',
            read_memory_bytes=536870912,read_ssd_bytes=0,compression='none'))))
    log_file=work/(side+'.log')
    log=log_file.open('wb')
    mount_env = dict(env, BREWFS_PACKED_CACHE='on' if side.startswith('on') else 'off',
        BREWFS_PACKED_CACHE_BYTES=str(256 << 20))
    counters.reset_duplicates()
    before_mount = counters()
    begin_mount = time.monotonic_ns()
    cgroup = Path('/sys/fs/cgroup')/(name+'-'+side)
    cgroup.mkdir()
    (cgroup/'memory.max').write_text(str(8 << 30))
    (cgroup/'cpu.max').write_text('200000 100000')
    def join_cgroup():
        (cgroup/'cgroup.procs').write_text(str(os.getpid()))
    proc=subprocess.Popen([binary,'mount','--config',cfg,point],stdout=log,stderr=subprocess.STDOUT,env=mount_env,preexec_fn=join_cgroup)
    def ready():
        if proc.poll() is not None:
            raise RuntimeError(f'{side} mount exited {proc.returncode}: '+clean_text(log_file.read_text(errors='replace')))
        return mounted()
    wait_for(ready,side+' FUSE mount',20)


    arm=result['readbacks'][side]=dict(passed=False)
    diagnose(point,work,counters,payload,wait_for,arm)
    stop_mount(True)
    messages=log_file.read_text(errors='replace')
    metrics=re.findall(r'(hits|misses|ready_hits|inflight_hits|local_bytes|downloaded)\s*[:=]\s*(\d+)',messages)
    arm['cache']={key:int(value) for key,value in metrics}
    arm['cgroup_memory_peak_bytes']=int((cgroup/'memory.peak').read_text())
    return arm['passed']

try:
    for p,s in pins.items():
        with p.open('rb') as stream: actual=hashlib.file_digest(stream,'sha256').hexdigest()
        if actual!=s: raise ValueError('Binary pin changed: '+p.name)
    for image in (images[rustfs],):
        if docker('image','inspect','--format','{{.Id}}',image).stdout.strip()!=image:
            raise ValueError('Image pin changed')
    result['rustfs_revision'] = docker('image','inspect','--format',
        '{{ index .Config.Labels "org.opencontainers.image.revision" }}',images[rustfs]).stdout.strip()
    if result['rustfs_revision'] != 'f4ed202508f2153afb7956bae6f7799b60eccd00':
        raise ValueError('RustFS revision differs')
    phase='start-private-services'
    common=['run','--pull','never','-d','--label',tag+'='+name]
    with socket.socket() as probe:
        probe.bind(('127.0.0.1', 0))
        rp = probe.getsockname()[1]
    redis_process = subprocess.Popen(['/usr/bin/redis-server','--bind','127.0.0.1',
        '--port',str(rp),'--dir',str(work),'--appendonly','no','--save','',
        '--maxmemory','256mb'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    result['redis_version'] = invoke(['/usr/bin/redis-server','--version']).stdout.strip()
    del result['image_sha256']['redis']
    rustenv=work/'rustfs.env'
    rustenv.write_text(f'RUSTFS_ACCESS_KEY={access}\nRUSTFS_SECRET_KEY={secret}\n')
    rustenv.chmod(0o600)
    args=[*common,'--name',rustfs,'-p','127.0.0.1::9000','--memory','2g','--cpus','2',
          '--env-file',rustenv]
    knobs=dict(RUSTFS_ADDRESS='0.0.0.0:9000',RUSTFS_CONSOLE_ENABLE='false',
        RUSTFS_VOLUMES='/data/rustfs{0...3}',RUSTFS_UNSAFE_BYPASS_DISK_CHECK='true',
        RUSTFS_OBS_LOGGER_LEVEL='warn',RUSTFS_OBS_LOG_DIRECTORY='/var/log/rustfs',
        RUSTFS_OBS_METRICS_EXPORT_ENABLED='false',RUSTFS_OBS_TRACES_EXPORT_ENABLED='false',
        RUSTFS_OBS_LOGS_EXPORT_ENABLED='false',RUSTFS_OBS_PROFILING_EXPORT_ENABLED='false',
        RUSTFS_EC_BLOCK_SIZE_HINT_ENABLE='true',RUSTFS_EC_BLOCK_SIZE_HINT_FLEET_CONFIRMED='true',
        RUSTFS_EC_READ_QUANTUM_ENABLE='true',RUSTFS_EC_READ_QUANTUM_FLEET_CONFIRMED='true')
    for k,v in knobs.items():args += ['-e',k+'='+v]
    for leaf,target in [(str(i),'/data/rustfs'+str(i)) for i in range(4)]+[('rustlogs','/var/log/rustfs')]:
        d=work/leaf;d.mkdir();os.chown(d,10001,10001);args+=['-v',str(d)+':'+target]
    docker(*args,images[rustfs])
    sp=port(rustfs,'9000/tcp')
    def redis_ready():
        if redis_process.poll() is not None:
            raise RuntimeError('Private Redis exited')
        return invoke(['/usr/bin/redis-cli','-p',str(rp),'ping'],check=False,limit=3).stdout.strip()=='PONG'
    wait_for(redis_ready,'Redis')
    wait_for(lambda:listening(sp),'RustFS')
    rurl=f'redis://127.0.0.1:{rp}/0'
    endpoint=f'http://127.0.0.1:{sp}'
    s3=boto3.client('s3',endpoint_url=endpoint,region_name='us-east-1',
        aws_access_key_id=access,aws_secret_access_key=secret,
        config=Config(signature_version='s3v4',connect_timeout=2,read_timeout=5,
                      retries={'total_max_attempts':1},s3={'addressing_style':'path'}))
    bucket='axcf-'+uuid.uuid4().hex[:10]
    phase='create-base-bucket'
    from botocore.exceptions import ClientError, EndpointConnectionError, ConnectionClosedError, ReadTimeoutError
    def s3_ready():
        try:
            s3.list_buckets()
            return True
        except ClientError as error:
            if error.response.get('ResponseMetadata',{}).get('HTTPStatusCode') not in (500,502,503,504):
                raise
            return False
        except (EndpointConnectionError, ConnectionClosedError, ReadTimeoutError):
            return False
    wait_for(s3_ready,'authenticated RustFS S3 readiness',30)
    s3.create_bucket(Bucket=bucket)
    src=work/'src';src.mkdir()
    payload={name: hashlib.shake_256(('packed-head:'+name).encode()).digest(20<<20)
             for name in ('A0.bin','A1.bin','A2.bin','B.bin')}
    for relative in payload:
        (src/relative).parent.mkdir(exist_ok=True)
    for f,data_bytes in payload.items():(src/f).write_bytes(data_bytes)
    expected={f:dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest()) for f,b in payload.items()}
    result['input_sha256']=hashlib.sha256(json.dumps(expected,sort_keys=True).encode()).hexdigest()
    phase='publish-fixture'
    manifest=work/'manifest-key'
    invoke([producer,'--source-directory',src,'--source-consistency','best-effort-detected',
        '--source-hardlink-policy','visible-links','--output-dir',work/'objects','--manifest-output',manifest,
        '--bucket',bucket,'--endpoint',endpoint,'--region','us-east-1','--force-path-style','true',
        '--prefix','base','--metadata-codec','raw','--data-codec','raw','--inline-data','off',
        '--chunk-size','67108864','--block-size','4194304','--s3-rustfs-ec-block-size-hint','auto'],limit=120)
    key=manifest.read_text().strip()
    result['manifest_key']=key
    result['object_sizes'] = [dict(key=row['Key'],bytes=row['Size'])
        for page in s3.get_paginator('list_objects_v2').paginate(Bucket=bucket)
        for row in page.get('Contents',[])]
    data=dict(backend='s3',s3=dict(bucket=bucket,endpoint=endpoint,region='us-east-1',
                force_path_style=True,rustfs_ec_block_size_hint='auto'))
    config=work/'data.json';config.write_text(json.dumps({'data':data}))
    namespace='packed-fork-'+uuid.uuid4().hex[:10]
    prefix=[binary,'workspace','--meta-backend','redis','--meta-url',rurl,'--workspace-namespace',namespace]
    phase='initialize-packed-parent'
    parent=json_call(prefix,'init-packed-volume','--manifest-key',key,'--data-config',config)
    rev=parent['fork_base']
    revision=f"{rev['layer_id']}:{rev['sealed_version']}:{bytes(rev['root_hash']).hex()}"
    result.update(parent_workspace_id=parent['workspace_id'],exact_revision=revision,parent_binding=binding(parent['workspace_id']))

    phase='large-object-inventory'
    large=inventory(s3,bucket,result['object_sizes'])
    result['large_objects']=large
    result['fixture_contract']=dict(files=4,file_bytes=20<<20,dense=True,chunk_bytes=64<<20,
        content='SHAKE256(packed-head:<filename>), varied across offsets',
        initial_b_offset=0,previously_unread_b_offsets=[8<<20,12<<20,16<<20],
        head_hold_seconds=.250,automatic_release_seconds=2)
    with gated_proxy(sp,bucket,large) as (measured_endpoint,counters):
        observed_data=dict(data,s3=dict(data['s3'],endpoint=measured_endpoint))
        phase='head-isolation'
        result['passed']=visit('on-head',parent['workspace_id'],observed_data,rurl,namespace,counters)
        result['probe_events']=counters.records()
        result['probe_totals']=counters()
    result['passed']=result['passed'] and bool(result['parent_binding'])
except Exception as error:
    if 'counters' in globals() and hasattr(counters,'records'):
        result['probe_events']=counters.records();result['probe_totals']=counters()
    result['failed_phase']=phase
    result['error']=type(error).__name__+': '+clean_text(str(error))
finally:
    signal.alarm(0)
    raw_output = result_path.parent/(result_path.stem+'-raw')
    raw_output.mkdir(exist_ok=False)
    for artifact in sorted([*work.glob('*.log'),*work.glob('*.stats')]):
        body = artifact.read_text(errors='replace').replace(access,'[redacted]').replace(secret,'[redacted]')
        (raw_output/artifact.name).write_text(body)
    result['raw_logs_directory'] = raw_output.name
    cleanup={}
    try:stop_mount(False)
    except Exception as error:cleanup['mount_error']=type(error).__name__+': '+clean_text(str(error))
    cleanup['mount_absent']=not mounted()
    cleanup['owned_containers_absent']={}
    private_redis = globals().get('redis_process')
    if private_redis is not None and private_redis.poll() is None:
        private_redis.terminate()
        try: private_redis.wait(timeout=5)
        except subprocess.TimeoutExpired:
            private_redis.kill()
            private_redis.wait(timeout=5)
    cleanup['owned_containers_absent']['redis'] = private_redis is None or private_redis.poll() is not None
    for container in (rustfs,):
        try:
            status=docker('inspect','--format','{{index .Config.Labels "'+tag+'"}}',container,check=False,limit=4,bounded=False)
            if status.returncode==0 and status.stdout.strip()==name:
                if 'failed_phase' in result and result['failed_phase'] in ('start-private-services','create-base-bucket'):
                    result.setdefault('service_log_tails',{})[container.removeprefix(name+'-')]=clean_text(docker('logs','--tail','12',container,check=False,limit=3,bounded=False).stdout)
                docker('rm','-f','-v',container,check=False,limit=5,bounded=False)
            after=docker('inspect',container,check=False,limit=4,bounded=False)
            cleanup['owned_containers_absent'][container.removeprefix(name+'-')]=after.returncode!=0
        except Exception as error:
            cleanup['container_error']=type(error).__name__+': '+clean_text(str(error))
    if cleanup['mount_absent'] and len(cleanup['owned_containers_absent'])==2 and all(cleanup['owned_containers_absent'].values()):
        shutil.rmtree(work)
    cleanup['scratch_removed']=not work.exists()
    cleanup['cgroups_absent'] = True
    for group in Path('/sys/fs/cgroup').glob(name+'-*'):
        try: group.rmdir()
        except OSError: cleanup['cgroups_absent'] = False
    result['cleanup']=cleanup
    result['passed']=result['passed'] and cleanup['scratch_removed']
    with result_path.open('x') as stream:json.dump(result,stream,indent=2);stream.write('\n')
    print(json.dumps(result,indent=2))
raise SystemExit(0 if result['passed'] else 1)
