#!/usr/bin/env bash
set -euo pipefail
root=/srv/ax-overlay-tax-20261113/total
cd "$root"
export GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=http.proxy GIT_CONFIG_VALUE_0=http://127.0.0.1:17901
exec >validation-02.log 2>&1
trap 'echo $? > /srv/ax-overlay-tax-20261113/total/validation-02.exit' EXIT
python3 -m unittest test_meter test_cold_counters test_total -v >harness-tests.log 2>&1
test -f scope-check.json
git -C build-source apply --reverse --check ../retention-parity.patch
cp retention-parity.patch artifacts/source.patch
python3 run_local.py --binary "$root/artifacts/brewfs" --producer "$root/artifacts/packed_snapshot_fixture" \
  --source-commit 03c8cc55d61473533c00a8afe13b4ef1fcd9b725 --source-patch "$root/artifacts/source.patch" \
  --workspace-format workspace --build-profile optimized-release --comparison overlay-total --object-meter proxy \
  --cache-state on --metadata-sync remote --pairs 3 --passes 1 --out "$root/validation-02"
python3 summarize.py "$root/validation-02" >validation-summary-02.json
