set -euo pipefail
bash /srv/ax-overlay-tax-20261113/total/run-validation-02.sh
bash /srv/ax-overlay-tax-20261113/total/run-measurement-02.sh
