"""Record CI truth before the user-authorized Redis-only measurements."""
from pathlib import Path
import hashlib
import json
import re
import tarfile

root = Path(__file__).resolve().parent
known = 'workspace::meta_layer::tests::writable_acl_independent_sqlite_instances_keep_mode_acl_during_atime_writes'
assert (root / 'release.exit').read_text().strip() == '0'
assert (root / 'checks.exit').exists()
log = (root / 'checks.log').read_text()
failures = re.findall(r'^test (\S+) \.\.\. FAILED$', log, re.M)
assert failures in ([], [known]), failures
assert 'Finished `dev` profile' in log and '-- -D warnings' in log
assert 'packed_readonly_payload_retention_is_opt_in_and_matches_workspace_limits ... ok' in log
assert 'test result:' in log
assert (root / 'harness-tests.log').read_text().rstrip().endswith('OK')
if failures:
    assert (root / 'checks.exit').read_text().strip() == '101'
    assert 'ResourceBusy' in log
else:
    assert (root / 'checks.exit').read_text().strip() == '0'
for line in (root / 'artifacts/SHA256SUMS').read_text().splitlines():
    expected, name = line.split('  ', 1)
    with (root / 'artifacts' / name).open('rb') as stream:
        assert hashlib.file_digest(stream, 'sha256').hexdigest() == expected
changes = []
with tarfile.open(root.parent / 'base-source.tar.gz') as archive:
    for entry in archive:
        if not entry.isfile():
            continue
        content = archive.extractfile(entry).read().replace(b'\r\n', b'\n')
        path = root / 'build-source' / entry.name
        assert path.resolve().is_relative_to((root / 'build-source').resolve())
        if path.read_bytes().replace(b'\r\n', b'\n') != content:
            changes.append(entry.name)
assert changes == ['src/cli.rs'], changes
receipt = dict(full_ci_passed=False, test_workspace_step_passed=not failures,
               ci_scope='fmt, strict all-target Clippy and workspace lib/bin tests for the measured feature set; not the full CI matrix',
               known_sqlite_failures=failures,
               tests=re.findall(r'test result: .*', log), changed_source_files=changes,
               backend='Redis', user_instruction='SQLite failure does not block Redis measurements; no SQLite tests removed',
               harness_sha256=hashlib.sha256((root / 'run_local.py').read_bytes()).hexdigest(),
               patch_sha256=hashlib.sha256((root / 'retention-parity.patch').read_bytes()).hexdigest())
with (root / 'scope-check.json').open('x') as out:
    json.dump(receipt, out, indent=2)
print(json.dumps(receipt))
