from pathlib import Path
import subprocess,time,json,hashlib
r=Path('/srv/ax-overlay-tax-20261113/total')
deadline=time.monotonic()+3600
while not (r/'build.exit').exists():
    if time.monotonic()>deadline: raise TimeoutError('build deadline')
    time.sleep(5)
# check-scope.py admits only the previously reproduced SQLite failure.
assert not (r/'validation.exit').exists() and not (r/'measurement.exit').exists()
assert not (r/'validation-01').exists() and not (r/'measurement-01').exists()
(r/'host-before.txt').write_text(subprocess.check_output(['bash','-c','hostname; uptime; free -b; df -B1 /srv; ps -eo pid,comm,pcpu,pmem,args --sort=-pcpu | head -n 20; cat /proc/self/mountinfo'],text=True))
print('starting validation',flush=True)
subprocess.run(['bash',str(r/'run-validation.sh')],cwd=r,check=True)
print('starting direct measurements',flush=True)
subprocess.run(['bash',str(r/'run-measurement.sh')],cwd=r,check=True)
print('all measurements complete',flush=True)
