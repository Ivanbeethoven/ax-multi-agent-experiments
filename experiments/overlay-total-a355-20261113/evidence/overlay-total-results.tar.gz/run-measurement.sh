#!/usr/bin/env bash
set -euo pipefail
root=/srv/ax-overlay-tax-20261113/total
cd "$root"
exec >measurement.log 2>&1
trap 'echo $? > /srv/ax-overlay-tax-20261113/total/measurement.exit' EXIT
test "$(cat validation.exit)" = 0
python3 run_local.py --binary "$root/artifacts/brewfs" --producer "$root/artifacts/packed_snapshot_fixture" \
  --source-commit 03c8cc55d61473533c00a8afe13b4ef1fcd9b725 --source-patch "$root/artifacts/source.patch" \
  --workspace-format workspace --build-profile optimized-release --comparison overlay-total --object-meter client \
  --cache-state on --metadata-sync remote --pairs 6 --passes 256 --out "$root/measurement-01"
python3 summarize.py "$root/measurement-01" >measurement-summary-01.json
