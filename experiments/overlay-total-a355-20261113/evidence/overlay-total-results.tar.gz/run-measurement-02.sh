#!/usr/bin/env bash
set -euo pipefail
root=/srv/ax-overlay-tax-20261113/total
cd "$root"
export GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=http.proxy GIT_CONFIG_VALUE_0=http://127.0.0.1:17901
exec >measurement.log 2>&1
trap 'echo $? > /srv/ax-overlay-tax-20261113/total/measurement.exit' EXIT
test "$(cat validation-02.exit)" = 0
python3 run_local.py --binary "$root/artifacts/brewfs" --producer "$root/artifacts/packed_snapshot_fixture" \
  --source-commit 03c8cc55d61473533c00a8afe13b4ef1fcd9b725 --source-patch "$root/artifacts/source.patch" \
  --workspace-format workspace --build-profile optimized-release --comparison overlay-total --object-meter client \
  --cache-state on --metadata-sync remote --pairs 6 --passes 256 --out "$root/measurement-01"
python3 summarize.py "$root/measurement-01" >measurement-summary-01.json
