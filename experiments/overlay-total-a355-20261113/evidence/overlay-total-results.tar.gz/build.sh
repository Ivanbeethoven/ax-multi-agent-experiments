#!/usr/bin/env bash
set -euo pipefail
parent=/srv/ax-overlay-tax-20261113
root="$parent/total"
cd "$root/build-source"
exec >"$root/build.log" 2>&1
trap 'echo $? > /srv/ax-overlay-tax-20261113/total/build.exit' EXIT
export PATH="$parent/toolchain/bin:$PATH" CARGO_HOME="$parent/cargo"
export CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_RELEASE_DEBUG=0
export CARGO_BUILD_JOBS=16 RUST_TEST_THREADS=2
features=fuse-io-uring-runtime,workspace,native-packed-base,frozen-base-metadata,rustfs-ec-block-size-hint,observability
cargo fmt --all
cargo fmt --all --check
sha256sum src/cli.rs > "$root/formatted-cli.sha256"
(
  export CARGO_TARGET_DIR="$parent/target"
  set -x
  cargo clippy --offline --locked --workspace --all-targets --no-default-features --features "$features" -- -D warnings
  cargo test --offline --locked --workspace --lib --bins --no-default-features --features "$features"
) >"$root/checks.log" 2>&1 &
checks_pid=$!
(
  export CARGO_TARGET_DIR="$parent/release-target"
  set -x
  cargo --config profile.release.package.brewfs.opt-level=3 build --offline --locked --release --no-default-features --features "$features" --bin brewfs --bin packed_snapshot_fixture
  mkdir "$root/artifacts"
  cp "$parent/release-target/release/brewfs" "$parent/release-target/release/packed_snapshot_fixture" "$root/artifacts/"
  cd "$root/artifacts"
  sha256sum brewfs packed_snapshot_fixture >SHA256SUMS
) >"$root/release.log" 2>&1 &
release_pid=$!
printf '%s %s\n' "$checks_pid" "$release_pid" >"$root/build-children.txt"
set +e
wait "$checks_pid"
checks_status=$?
wait "$release_pid"
release_status=$?
set -e
printf '%s\n' "$checks_status" >"$root/checks.exit"
printf '%s\n' "$release_status" >"$root/release.exit"
test "$release_status" = 0
test "$checks_status" = 0
