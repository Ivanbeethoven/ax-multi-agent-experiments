#!/usr/bin/env bash
set -euo pipefail
root=/srv/ax-overlay-tax-20261113/total
cd "$root"
exec >validation.log 2>&1
trap 'echo $? > /srv/ax-overlay-tax-20261113/total/validation.exit' EXIT
python3 -m unittest test_meter test_cold_counters test_total -v >harness-tests.log 2>&1
python3 check-scope.py
git -C build-source apply --reverse --check ../retention-parity.patch
cp retention-parity.patch artifacts/source.patch
python3 run_local.py --binary "$root/artifacts/brewfs" --producer "$root/artifacts/packed_snapshot_fixture" \
  --source-commit 03c8cc55d61473533c00a8afe13b4ef1fcd9b725 --source-patch "$root/artifacts/source.patch" \
  --workspace-format workspace --build-profile optimized-release --comparison overlay-total --object-meter proxy \
  --cache-state on --metadata-sync remote --pairs 3 --passes 1 --out "$root/validation-01"
python3 summarize.py "$root/validation-01" >validation-summary-01.json
