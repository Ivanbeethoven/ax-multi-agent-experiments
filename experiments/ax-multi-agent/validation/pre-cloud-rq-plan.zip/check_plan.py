"""Validate planning consistency. Does not certify a deployed system."""
from pathlib import Path
import csv
import hashlib
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[1]


def main():
    errors = []
    documents = ["README.md", "plan.zh.md", "integration-and-migration.md", "metrics.md"]
    required = documents + ["matrix.csv", "workloads.json", "run-manifest.example.json", "events.schema.json", "sources.json", "report/main.tex", "scripts/build_plan.ps1"]
    for name in required:
        if not (ROOT / name).is_file():
            errors.append(f"Missing {name}")
    if errors:
        print(json.dumps({"passed": False, "errors": errors})); return 1
    matrix = list(csv.DictReader((ROOT / "matrix.csv").open(encoding="utf-8", newline="")))
    ids = {f"AX{i:02d}" for i in range(8)}
    if len(matrix) != 8 or {r["experiment_id"] for r in matrix} != ids:
        errors.append("Expected exactly AX00-AX07")
    for row in matrix:
        if row.get("status") != "planned" or any(not value for value in row.values()):
            errors.append(f"Incomplete or executed matrix row: {row.get('experiment_id')}")
        if not set(row["legacy_ids"].split("|")).issubset({f"E{i:02d}" for i in range(17)}):
            errors.append(f"Unknown legacy mapping: {row['experiment_id']}")
    workloads = json.loads((ROOT / "workloads.json").read_text(encoding="utf-8"))
    if workloads["status"] != "planned" or workloads["execution_enabled"] is not False:
        errors.append("Planning config must not enable execution")
    workload_ids = {w["id"] for w in workloads["workloads"]}
    for row in matrix:
        if row["workloads"] not in workload_ids:
            errors.append(f"Missing workload: {row['workloads']}")
    for workload in workloads["workloads"]:
        if not set(workload["experiments"]).issubset(ids):
            errors.append(f"Unknown experiment in {workload['id']}")
        if not workload["oracle"] or not workload["negative"]:
            errors.append(f"Missing oracle/negative: {workload['id']}")
    pilot = workloads["pilots"]["deterministic"]
    factor = pilot["fixtures"] * pilot["systems"] * len(pilot["cache_states"]) * pilot["repetitions"]
    if factor * len(pilot["concurrencies"]) != pilot["planned_batches"] or factor * sum(pilot["concurrencies"]) != pilot["planned_worker_executions"]:
        errors.append("Deterministic pilot arithmetic mismatch")
    live = workloads["pilots"]["live"]
    batches = live["tasks"] * live["systems"] * live["batch_repetitions"]
    if batches != live["planned_batches"] or batches * live["candidates_per_batch"] != live["planned_agent_executions"]:
        errors.append("Live pilot arithmetic mismatch")
    manifest = json.loads((ROOT / "run-manifest.example.json").read_text(encoding="utf-8"))
    if manifest["status"] != "planned" or manifest["measurements"] is not None or manifest["commands_executed"] is not None:
        errors.append("Manifest must remain unexecuted")
    for key in ["executed_sources", "outcome"]:
        if any(value is not None for value in manifest[key].values()):
            errors.append(f"Observed {key} must remain null")
    if manifest["agent"]["model_requested"] != "deepseek-v4-flash":
        errors.append("Incorrect model identifier")
    schema = json.loads((ROOT / "events.schema.json").read_text(encoding="utf-8"))
    import jsonschema
    jsonschema.Draft202012Validator.check_schema(schema)
    sources = json.loads((ROOT / "sources.json").read_text(encoding="utf-8"))
    for source in sources["sources"]:
        repo = sources["repositories"][source["repository"]]
        path = ROOT / repo["path_relative_to_plan"] / source["path"]
        if hashlib.sha256(path.read_bytes()).hexdigest() != source["sha256"]:
            errors.append(f"Source changed: {source['source_id']}")
    observation = sources["prior_observation"]
    if hashlib.sha256((ROOT / observation["path_relative_to_plan"]).read_bytes()).hexdigest() != observation["sha256"]:
        errors.append("Prior summary changed")
    for name in documents:
        text = (ROOT / name).read_text(encoding="utf-8")
        for match in re.finditer(r"\]\(([^)]+)\)", text):
            link = match.group(1)
            if "://" not in link and not link.startswith("#") and not (ROOT / link.split("#")[0]).exists():
                errors.append(f"Broken link in {name}: {link}")
    report = {"passed": not errors, "scope": "local planning consistency only; no cluster/model/performance experiments", "experiment_count": len(matrix), "workload_count": len(workload_ids), "deterministic_pilot_batches": pilot["planned_batches"], "deterministic_pilot_workers": pilot["planned_worker_executions"], "live_pilot_batches": batches, "live_pilot_agent_executions": live["planned_agent_executions"], "source_files_verified": len(sources["sources"]), "event_schema": "Draft 2020-12 checked", "errors": errors}
    (ROOT / "validation").mkdir(exist_ok=True)
    (ROOT / "validation/local-checks.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return int(bool(errors))


if __name__ == "__main__":
    sys.exit(main())
