# BrewFS × AX：多 Agent、共享数据与迁移实验

状态：**实验规划与本地准备，尚未执行**。编写日期：2026-10-23。所有收益均为待检验假设；此目录不更改论文的已有结果或架构图。

核心问题：**在何种任务共享程度、修改范围和恢复条件下，共享不可变基线、私有增量、Packed Metadata 与对象粒度控制能改善多 Agent 的任务执行？这些收益的代价和失效边界是什么？**

每组实验沿同一证据链设计：任务行为 → 触发的机制 → 对照干预 → 分层开销 → 任务结果 → 否证条件。先用确定性工具工作流固定工作量，再用真实 Agent 验证外部有效性。

## 先看这张表

| 任务情境 | 要检验的 BrewFS 特性 | 直接观测 | 对任务的影响与反例 |
|---|---|---|---|
| 同一仓库启动 1/4/16 个修复候选 | 共享不可变基线 S、每个 Agent 独立 Δ | 准备时间、总物理字节、私有元数据、首个有效工具操作 | 能否更快开始任务、同资源完成更多候选；低复用、大规模改写可能抵消收益 |
| 多 Agent 搜索源码、探测依赖和属性 | Packed Metadata 的名称范围、热属性与数据定位 | lower 索引 GET、读取字节、Redis/control 请求、正负探测延迟 | 能否缩短搜索/测试启动阶段；暖缓存或离散访问可能无收益 |
| 独立小补丁、重试分支与回滚 | 私有 upper、显式映射、whiteout、版本隔离 | 修改逻辑字节与持久化物理字节、PUT 数、隔离错误 | 能否减少候选保存/切换成本；碎片化、重写和 GC 可能使其更贵 |
| 一个 Agent 发布索引，多个 Agent 消费 | 不可变版本发布与共享读取 | 发布确认、版本摘要、消费者可用时间、总传输量 | 能否减少重复构建和分发；一次性消费可能无法摊销构建成本 |
| 在工具边界暂停并换节点恢复 | 可定位的共享 S、持久化 Δ、lease/generation fencing | checkpoint、所有权移交、目标挂载、懒加载、会话恢复 | 能否降低停顿并保持结果；冷缓存、大 Δ 或 fencing 等待可能占主导 |
| 多 Agent 读取索引/语料的一小部分 | 客户端请求形状与后端 B/q 配置 | FUSE→客户端 Range→持久化布局→磁盘读取 | 更小物理读取是否缩短工具时间；upper 整对象校验、默认相同布局是负对照 |

## 阅读入口

- [完整实验协议](plan.zh.md)：AX00–AX07、对照、重复和论文证据安排。
- [AX 接入与迁移协议](integration-and-migration.md)：当前代码边界、准入条件、迁移状态机及故障点。
- [实验矩阵](matrix.csv)：每行一个可否证实验，映射现有 E00–E16。
- [工作负载规格](workloads.json)：确定性与真实 Agent 的任务族和结果 oracle。
- [计量定义](metrics.md)、[事件格式](events.schema.json)、[运行清单](run-manifest.example.json)：运行前填写、运行后核验。
- [源码依据](sources.json)：本轮实际审阅版本、文件哈希和定位。
- [可读 PDF](report/main.pdf)：6 页讨论版，源文件为 [main.tex](report/main.tex)。

## 建议先执行的最小闭环

1. AX00：验证真实 mount/data path、退出状态、会话 checkpoint 和一个 Agent 的正确性。当前 Entity/CSI 接入、fork controller、独立重挂载均需要补齐资格证据。
2. AX01：先做**无模型的 12 个确定性批次**：1 个固定仓库工作流 × 2 种合格配置 × N={1,4} × 3 次重复，源/目标冷缓存。共 30 个 worker 执行；先不扩到 N=16。
3. AX02/AX03：分别隔离 Packed Metadata 与 Δ 的效果，确认 AX01 的变化来自什么。
4. AX04：Producer 发布、4 个 Consumer 验证同一版本；随后 AX05 的 M0，再进入满足 gate 的 M1。
5. AX07：拟定 2 个任务 × 2 系统 × 3 重复 × 4 并行候选 = **48 次真实 Agent 执行、12 个批次**。这只是预算草案，尚未调用模型；不等于正式论文样本量。

正式并发扩展、故障恢复与 B/q 参数扫描按需展开，不做所有维度的笛卡尔积。先测变异与瓶颈，再冻结任务集、主要指标和正式重复数。

## 术语与证据边界

`W_i = Resolve(S, Δ_i)` 是论文的逻辑模型。S 为不可变基线；Δ 是私有变更状态，**不表示字节差分压缩**。B 是纠删码 coding block；q 是物理读取/校验单元；文件大小、FUSE 请求大小、S3 对象长度、B、q 分别记录。

一个 writable workspace 对应一个 lease-owning mount。独立 Agent 使用不同 workspace UUID / StorageClass，可共享 S；这不承诺多节点同时写同一个 upper。AX suspend/resume 在本计划中指停进程、保存应用状态并重新启动，不能称为进程内存热迁移。

旧 WSL 观测只有请求结构证据：8 个任务、1,138,884 个 FUSE 事件，使用 DSH 和 `deepseek-v4-flash`。它没有证明跨任务读集重叠或 BrewFS 加速。新 AX 实验使用的执行器、会话恢复能力和模型实际标识必须重新登记。

## 本地检查与编译

```powershell
python -m pip install -r scripts/requirements.txt
python scripts/check_plan.py
powershell -ExecutionPolicy Bypass -File scripts/build_plan.ps1
```

以上命令仅检查规划文件并用 Windows XeLaTeX 编译 PDF；不启动 AX、Kubernetes 或真实 Agent。详细验证记录见 `validation/local-checks.json`。
