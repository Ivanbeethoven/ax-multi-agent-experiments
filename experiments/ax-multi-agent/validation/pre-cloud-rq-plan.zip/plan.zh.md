# 实验协议：从设计机制到多 Agent 任务收益

版本：2026-10-23，全部实验 planned。本文是现有 `experiments/matrix.csv` 的 AX 专项展开，不替换 E00–E16，也不把历史 smoke 当作本轮结果。

## 1. 要回答的问题

核心假设是有条件的：如果多个任务确实复用不可变内容、各自修改的范围有限，且元数据/对象路径处于工具关键路径，那么 BrewFS 的共享基线和私有增量可能减少准备、分发和恢复成本；Packed Metadata 与对象粒度控制是否能进一步缩短任务时间，需要独立验证。若模型等待、暖本地缓存或大规模修改占主导，端到端收益可能很小甚至为负。

研究问题按任务组织：

- RQ-A：哪些任务共享性质决定并发运行的准备成本、资源占用和完成率？
- RQ-B：Packed Metadata、私有增量各自改变了哪些工具阶段的关键路径？
- RQ-C：共享数据的发布与迁移是否保持版本正确、隔离和持久化语义？减少了哪些成本，又引入哪些成本？
- RQ-D：客户端请求形状与后端对象布局何时能影响真实任务，而不只是存储微基准？

## 2. 从现有观测选择实验，不从观测推断收益

现有 WSL PassthroughFs 数据包含 5 个 Core、3 个 Exploratory 任务，共 1,138,884 个 FUSE 事件。六方法元数据集合为 lookup、getattr、readdirplus、opendir、releasedir、getxattr。全部状态下占比为 61.5% / 56.4%，ok-only 为 52.0% / 44.2%。open、flush、release 不在该集合内。失败探测改变请求构成，因此 AX02 同时保留 positive/negative lookup、受支持与不受支持的属性请求。

Core / Exploratory 的 read 次数为 22,142 / 98,292，write 为 1,112 / 23,600；write 中位数为 4,084 / 4,117 bytes。混合请求大小支持 AX03/AX06 研究请求转换，**不支持直接选择“最优块大小”**。逐任务强度和时间突发支持保留到达过程、任务分层及工具阶段。

旧数据为每任务单次运行，提示词/预算不同，Astropy 捕获有约 30 秒结束后尾部。handler latency 是请求处理观测；elapsed capture 包含请求间隔，可能含模型等待。error/incomplete 是 FUSE 状态或解析配对状态，退出码 0 也不等于 SWE-bench 成功。

新实验必须补采路径或稳定路径 ID、内容/版本 ID、offset/length、payload 哈希及受控保存、句柄依赖、同步关系、tool span 和模型等待区间。旧事件不足以直接重放文件语义。跨任务共享率、修改覆盖率、局部性仍是待测变量。

## 3. 系统配置与公平性

### 3.1 两条比较路线

**本地运行路线**：local full copy、经过验证的 reflink/COW 或 OverlayFS、BrewFS 各自读取同内容初始快照，拥有独立可写目录。比较任务准备、工具运行与本地资源。local/reflink 是强简单基线，但其远端持久化与跨节点能力不自动与 BrewFS 相同。

**远端持久化/恢复路线**：BrewFS 与具备相同确认点的 full-copy/增量同步 checkpoint，以及经过资格验证的共享远端文件系统（候选 JuiceFS）比较。相同后端位置、持久化完成规则、压缩、复制/EC 策略和资源预算。仅本地 fsync 与已远端持久化不能放在同一个“更快”排名里。基线若具备可复用远端基础数据，允许复用并计费，不能强迫每次完整上传。

**内部因果对照**：相同 Entity resolver/API/cache/一致性语义下，切换共享或复制的同内容基线、Packed 或 materialized/sorted-KV lower、固定或候选对象布局。后两种对照仍可能需要实现，未通过资格验证前只报告系统比较，不声称单因素消融。ordinary volume、workspace-v1、workspace-entity-v1、Native Base 不是可互换的开关。

### 3.2 固定项与计费

固定仓库内容摘要、任务镜像及依赖、CPU/内存限制、工具、真实模型名、prompt、token/turn/时间预算、重试策略、网络与服务端负载。既记录每 Agent 缓存，也记录节点与全实验总缓存；同时报告等总预算与等客户端预算，两者不混为一条曲线。

分别规定 source/target page cache、BrewFS 数据与元数据缓存、共享节点缓存、后端缓存的冷暖状态。不能在共享生产机器上执行不受控清缓存；实验节点隔离，清缓存/重启步骤入日志。固定到达负载与闭环任务吞吐分开；闭环运行变慢时请求减少，不能据此宣称后端开销下降。

总成本包括 S 构建、索引、上传、镜像拉取、依赖准备、Δ 持久化、发布、checkpoint、GC 与保留窗口。将一次构建成本按实际消费批次数摊销，另报首次执行成本；禁止只报告 amortized 数字。

## 4. AX00：先证明任务走到正确的数据路径

**问题与干预**：在 reviewed commit 上构建镜像，以单 Agent 完成 mount→读基线→写私有文件→同步→读回→结束。记录 AX task/actor、节点、PVC、PV、StorageClass、workspace UUID、S digest 与 lease generation 的映射。随后新增第二个独立 workspace 验证隔离。

**对照与 oracle**：相同脚本在本地 POSIX 目录生成 manifest 和校验值；BrewFS 从 handler、对象 GET/PUT 和最终哈希闭合证据链。不能仅通过 `AX_PREMOUNTED_WORKSPACE` 或 `/workspace` 路径认定已经挂载。

**准入结果**：runtime 类型、FS/mountinfo、canary payload 摘要、退出码、tool completion、独立 grader、同步完成点均留档；directory/owner 限制、失败探测语义、恢复接口、计数器覆盖必须明确。对 hook 开/关各做固定工作量运行，量化采集开销。此组是资格验证，无性能排名。

**当前缺口**：Entity/CSI dispatch、AX fork controller、Entity reopen、会话 checkpoint、退出码 wrapper、分层观测。见接入协议 G0–G7。缺口关闭需要代码、接口和端到端证据，不接受仅把状态改为 passed。

## 5. AX01：共享基线是否改善并发任务启动与总成本

**任务**：从同一 pinned 仓库快照启动 N 个独立 worker，各执行确定性“源码搜索→读依赖→应用固定补丁→测试”。先令所有 worker 复用同一输入，再用不相交子树或不同仓库做低复用负例。真实 Agent 的同任务多候选放在 AX07。

**干预**：共享 S + 独立 Δ；同内容的每 workspace 完整复制；本地 reflink/OverlayFS 强对照另列。内部共享 on/off 必须保持 resolver/API 相同并在独立前缀中构造物理独立对象，避免底层去重偷偷共享。

**因素**：N=1,4,16；同节点/跨节点；cold/warm；共享比例由内容 ID 和 byte range 计算。N=64/128 需重新验证 owner census、内存与调度容量，不作为默认可支持规模。

**主要指标**：批次从申请到全部 worker 首个有效工具操作的时间、全部指定工作完成的 makespan、成功任务/秒；次要为 workspace-ready、物理存储、控制记录、总网络与 CPU、准备成本摊销交点。模型推理时间单独展示。

**否证**：完整准备成本纳入后没有优势，或低共享、暖 reflink、N 增大时共享后端竞争使尾部更差。共享 S 本身不保证客户端缓存跨节点共享。

**映射**：E02、E03、E07、E13。计划图为 N 对准备/完成时间与全批次字节的两面板图；按任务/缓存分面，不只报组均值。

## 6. AX02：Packed Metadata 对搜索与路径探测的影响

**任务**：按固定文件列表执行 lookup/stat、受控缺失路径探测、名称范围扫描、递归列目录与小文件读取。正负探测分别计数；getxattr 不支持与不存在路径分开。保留旧观测的 burst 分布作为负载形状参考，执行语义由新 manifest 定义。

**干预**：在同一个 Entity lower API 下比较 Packed 与 materialized/sorted-KV lower，固定 upper、数据对象、缓存预算及 durability。若等价 lower 尚未实现，该比较为 G2 阻塞，不能拿 ordinary VFS 替代并归因于 Packed。

**因素**：名称连续/离散，正负比例、目录宽度、cold/warm，N=1/4/16。Entity 目录上限为 4096 entries，先用 32/256/2048；超限形状是显式 unsupported/边界实验，不悄悄剔除。Packed 独立分页能力与 Entity 全目录枚举分别解释。

**指标**：每个已完成工具阶段的 lower index GET、元数据读取 bytes、upper/control Redis 命令与 RTT、CPU/内存，以及阶段 wall time。GET 变少但读取更多字节、CPU 解码更慢时必须完整报告。

**否证**：只在不公平缓存下更快；warm sorted-KV、随机名称、负探测导致过读时无收益；最终工具时间不变。允许结论只成立于冷名称范围访问。

**映射**：E01、E05、E06、E12。计划图为工具时间与后端元数据请求/字节，不用总 Redis 命令替代 lower 指标。

## 7. AX03：私有增量对候选分支、重试和修改成本的影响

**任务**：给每个 worker 相同初始 S，做小文件修改、相同 byte 数但分散于多个文件的修改、删除/重命名、truncate/extend、hole 与受支持的 hard-link 操作；运行测试并生成最终 namespace/content manifest。候选之间刻意使用同名但不同内容的输出以检查隔离。

**干预**：私有 Δ 对同语义完整 materialization；本地 COW 作为强对照。从已有父任务中间状态 fork 是额外子实验，必须通过 AX fork G3；共享初始 S 不能冒充 fork 已含父任务未发布修改。

**因素**：修改覆盖率拟定 0.1%/1%/10%/50%，连续与碎片修改；删除、rename、重复重试和分支保留窗口。覆盖率以最终内容范围计，不以 write bytes 直接代替；写入多次的流量另计。

**指标**：任务结果一致性、父/兄弟污染数、增量持久化时间、PUT 数、上传/物理存储字节、mapping/whiteout/control 元数据、close/drain 尾部、保留分支与 GC 后空间。数据和 namespace 隔离不等于访问权限隔离。

**否证**：高修改覆盖、碎片对象或 GC 使总成本超过 COW/复制；同步尾部吃掉活跃阶段收益；任何隔离或持久化错误先判 correctness failure，不计算性能收益。

**映射**：E04、E10、E14、E16。图为修改覆盖率对实际成本，标出交点；不以 Δ 命名推断“稀疏修改已被观测”。

## 8. AX04：Producer→Consumer 的不可变数据共享

**任务**：producer 从固定代码/文档生成可确定复现的检索索引或测试资料，关闭写句柄并达成持久化完成点，发布带 digest 的 S'；N 个 consumer 校验版本后执行不同查询/检查。consumer 的私有输出仍写 Δ_i。

**干预**：一次构建并发布共享不可变产物；一次构建后向每 consumer 复制相同产物；每 consumer 独立重建作为次要应用对照。前两者隔离分发机制，第三者同时改变计算复用，不当作存储单因素效果。

**指标**：构建、发布、消费者 first-use 分项；全体结果摘要；总上传/下载/物理字节；旧 consumer 固定旧版本，新 consumer 显式绑定新版本。重复发布、producer 崩溃、未完成上传不能暴露半版本；统计 orphan/GC 成本。

**否证**：单 consumer、一次性消费或频繁重建不能摊销索引构建；共享读取形成热点；发布接口不支持完整导出当前 Δ 时停在 qualification。不是共享 live upper，也不声称自动 merge 多 Agent 补丁。

**映射**：E07、E11、E14–E16。计划图按消费次数显示含构建成本的累计时间与字节。

## 9. AX05：执行移动与跨节点恢复

三个模式分开：M0 保持同一节点和现有 mount，只重启任务进程；M1 工具边界 quiesce 后跨节点恢复；M2 进程/节点故障后 takeover。M0 是控制基线，不称跨节点迁移。M1/M2 只有各自 gate 通过才执行，不能把模式混成一条曲线。

**任务**：在“搜索后、补丁后且同步完成、测试后”三种 checkpoint 停止新工具操作；恢复同一任务、会话、prompt 预算余量、工具结果与 S/Δ 版本。非幂等外部副作用需操作账本，不能盲目重放。进程内存、活跃 socket、未落盘状态不在本计划恢复保证中。

**对照**：不迁移、同节点进程重启、经过相同远端确认的 full-copy 和增量同步恢复；具备相同恢复语义的远端挂载作为补充。源/目标 cache、会话持久化和数据落点匹配。

**指标**：从暂停请求到目标首个有效工具操作的停顿；quiesce、checkpoint、fencing、target mount、session restore、cold first-use 分项；新传输 bytes、已存在远端状态 bytes、最终任务完成、失败/重试；目标 node UID 必须不同。共享远端对象无需重新传输不等于迁移“零成本”。

**故障**：源在 durable checkpoint 前后被杀；ownership 转移前后中断；旧 writer 恢复；目标 mount/首次读失败；网络分区。验证最多一个有效 writer、旧 generation 提交拒绝、已确认状态不丢失、不会读取未提交状态；同时报告可用性等待。

**否证**：target 冷加载、租约等待或会话恢复比完整复制更贵；FS 内容恢复但 Agent 丢失进度；不满足 fencing。不能借论文中的恢复协议替代当前 fresh-only 实现。

**映射**：E03、E13–E16。时间图必须区分 pause interval 和持久化前置工作；持续 checkpoint 开销计入全任务成本。

## 10. AX06：对象粒度能否作用到任务关键路径

按三步执行：固定 S3 请求流的后端实验 → Packed lower 的客户端读路径 → 确定性/真实任务。第一步固定客户端请求和对象内容，第二步解释读取范围、合并及完整性策略，第三步确认变化是否传导到工具时间。不能直接从 FUSE read 大小推导磁盘 I/O 单元。

**干预**：新建对象，固定 d/p、压缩、缓存与 durability，分别改变 B 和 q；记录 accepted/persisted 的实际 (B,q,d,p)。候选取值必须来自所选 RustFS commit 的支持集合，未经资格验证不预设任意 q。auto 若与默认 B 相同，是“无干预”负对照。

**任务**：大索引/资料的局部读、跨对象边界读、顺序扫描和小 upper 修改。分别记录实际对象长度与 Range。Entity upper 整对象 GET 后校验，因此其短逻辑读可能没有 q 收益；当前 ≤1 MiB upper 对象也可能不触发 auto hint，是负对照。

**指标**：FUSE requested/returned bytes、S3 Range/response bytes、HEAD/GET/PUT、后端 physical read/write bytes、校验/EC CPU、repair bytes、工具时间和总任务时间。客户端缓存、Range coalescing、整对象读取策略作为独立因子，不为制造收益关闭完整性校验。

**否证**：hint 未传递/持久化；后端减少读取但客户端仍全对象 GET；CPU/修复/写入放大抵消收益；模型时间掩盖端到端效果。可以只报告 backend 或特定 lower 场景结果。

**映射**：E08–E11。计划图用请求到对象再到物理读的分层量，禁止画尚未测得的速度柱状图。

## 11. AX07：真实 Agent 的外部有效性与任务质量

固定 AX 执行器版本（候选为当前集成的 Codex CLI）、实际模型 `deepseek-v4-flash`、resolved model 标识、任务镜像、prompt、工具、token/turn/timeout、provider 并发配额及重试。旧 DSH 观测与新 AX 执行器不同，按 harness 分层报告。

先从旧 Core/Exploratory 各选一个可重建且测试环境合格的任务。每个任务启动 4 个独立候选，S 的 base commit 完全相同，候选 seed/提示在系统间配对。不同 SWE-bench task 的 base commit 常不相同，不能为了共享率把它们强制改到同一个基线；异任务并发需核对兼容性或分 snapshot 组。

拟定 pilot 为 2 tasks × 2 systems × 3 batches × 4 candidates = 48 agent executions。若 provider 不能固定随机种子，记录不支持，仍配对 task/prompt/预算及请求时间区块，不能宣称完全可复现推理。候选间存在相关性，48 次不等于 48 个独立任务。

**任务结果**：主要报告所有 assigned task/candidate 的官方 grader 成功率、deadline 内有效完成数和资源成本，另报 batch 至少一个正确候选的比率。best-of-N selection 规则在看结果前冻结，不能只为某系统挑最佳样本。退出码、模型 API 完成、产出 patch、测试通过、官方成功分开；成功样本耗时只作为条件性次要结果。

**因果边界**：真实 Agent 会因 I/O 反馈和模型随机性产生不同工具路径。AX07 回答 practical benefit；AX01–AX06 固定工作量后才回答机制因果。若只见真实 Agent 变快而分层指标未变，不归因于存储设计。

**映射**：E01、E12、E13。结果按任务分层，报告模型等待、工具 wall time 与全程 elapsed，保留 task-level 失败原因。

## 12. 重复、分析与执行顺序

独立单位为新建环境下的运行/并发批次，任务作为上层聚类；一个批次内数百万 I/O 不能充当重复次数。确定性 pilot 至少 3 个全新批次；后续敏感性初拟 5 次，正式数量由 pilot 方差与目标置信区间宽度冻结。2 个 live task 的 pilot 仅用于验证流程和估计预算，不作总体 Agent 人群推断。

各系统在 task、cache、concurrency 区块内随机交错，保存 seed 和顺序。主指标使用配对差值/比值及按 task、batch 层次重采样的 95% 区间；任务太少时给逐任务值和范围，不包装成精确总体区间。p95/p99 的样本单位与窗口必须标明。模型故障、timeout、系统故障全部计入 assigned 分母并单列原因。计量缺失导致无效的 run 保留原记录、理由和 replacement 关联，不能静默重跑。

推进顺序：AX00 → AX01 小闭环 → AX02/AX03 → AX04 → AX05 M0→M1→M2 → AX06 → AX07。AX06 的后端资格可独立准备；不要求完成昂贵全矩阵后才能发现主张不成立。拟定硬件为两台隔离 client worker 加独立 metadata 和多节点 RustFS 资源；核数、内存、网速、磁盘、EC拓扑、模型额度均待部署前盘点，不能写成已用环境。

## 13. 论文中的预期证据位置

主文优先保留 AX01 的并发任务效果、AX02/AX03 的关键机制解释、AX05 的恢复正确性与停顿、AX07 的任务质量。AX04 若成为主要应用证据再入主文；AX06 只有完整接通并影响任务才支持联合系统收益，否则在后端实验中限定结论。

详细参数扫描、故障逐例、成本清单和源数据放配套材料；改变结论的反例不能隐藏。既有 WSL 观测继续承担动机，不能替代上述实验。当前只有规划，论文摘要不新增加速比、共享率、最优块大小或任务成功率结论。
