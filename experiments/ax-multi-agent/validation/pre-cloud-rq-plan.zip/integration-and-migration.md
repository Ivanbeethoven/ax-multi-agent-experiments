# AX 接入、资格条件与迁移协议

这是待实现/待执行的协议，不是已验证能力清单。审阅基线为 BrewFS `f80e7148c82e9f1ef235ab19318b89cb41a093a2` 和 AX `4ef115f88f3e0eedd2c2d9653fe04a25c1e158c6`（`Ivanbeethoven/ax` 的 `brewfs-workspace` 分支）。实际实验必须冻结兼容的新 commit、研究补丁和镜像 digest；不能用 reviewed SHA 冒充 executed SHA。

## 当前可确认的边界

| 代码/记录 | 审阅事实 | 对实验的约束 |
|---|---|---|
| AX `internal/substrate/client.go` | `externalStorageClassName` 非空时生成 externalVolumeTemplate；否则 durableDir；SnapshotFidelity 为 VOLUMES | external CSI 卷的 checkpoint 语义需独立验证，不能沿用 durableDir 的假设；1Gi 是声明，不是已验证容量限额 |
| AX `runner/runner.go` | premounted 仅检查目录并跳过初次 setup；任务进程结束后 runner 仍可存活；暂停时 SIGTERM 后超时 SIGKILL | Ready/Running 不等于任务成功；仓库、declared files、skills、goal 预装需一致且计费；不保留进程内存 |
| AX `internal/server/fork.go` | CLI 为 `ax workspace fork <parent> <name>`；创建 BrewFSWorkspaceFork 并等待 Ready + workspaceId + storageClassName | 当前 BrewFS checkout 全仓搜索未找到该 CRD/controller；这是跨版本接入缺口，不等于 BrewFS 没有其他内部 fork 机制 |
| AX fork 的命名映射 | forker 使用配置 namespace 与 parentName；不直接使用 atespace 参数 | 先验证 AX workspace 名到 BrewFSWorkspace 名的映射、跨 atespace 重名和 409 Conflict 对象的来源/规格；Ready 不能单独证明 child fork 正确 |
| CSI README / main.rs | CreateVolume 返回既有 UUID 的确定性 identity，不创建数据；NodeStage 启动挂载，NodePublish bind；snapshot RPC 未实现 | 每独立 writer 必须有不同 UUID 与 StorageClass；CSI 不是 snapshot/fork 引擎 |
| CSI 单写者 | 只宣告 SINGLE_NODE_WRITER / SINGLE_NODE_READER_ONLY | 不把同一 workspace 挂到两个节点作为多 Agent 共享实验；共享的是 immutable S |
| 历史 CSI smoke | 2026-10-22、AX a0a660a、workspace-v1；23 bytes canary 与 RustFS payload 一致；independent remount 未验证 | 只作为历史路径证据；不证明当前 Entity、多节点或恢复；csi-sanity 为 30 pass/3 fail/1 pending/58 skipped |
| Entity mount | fresh-only，create_fresh_from_manifest；租约失效后停止 admission 并卸载/drain | M1/M2 需实现并证明 reopen/ownership handoff；底层 reopen 方法存在不等于 CLI 已接通 |
| Entity 数据/目录 | direct_io，metadata TTL=0，无 kernel writeback，FUSE write≤1MiB；目录≤4096 entries；owner census 有界 | 与 buffered VFS 不是单因素对照；大目录与大 fan-out 先 qualification，保留 unsupported 记录 |
| Entity upper | 对象 HEAD 后完整 GET、SHA-256 校验再切片；upper 对象受 write/chunk 切片限制 | 不把短 FUSE read 当短后端 Range；不能取消完整性校验来制造 q 收益 |
| 观测入口 | 当前 Entity diagnostics 已删除，旧 SIGUSR1/ENV 脚本过时；通用 ReadObserver 和普通 VFS .stats 未接入 | 分层计数器需要新插桩或外部采集，并记录覆盖与扰动 |
| agent image `run-agent.sh` | codex exec 后 `|| true`，随后写 AGENT_DONE；日志写入 /workspace；CODEX_HOME 位于 /opt/codex-home | 研究 wrapper 必须保留真实退出码，日志移出被测目录；会话状态需显式 checkpoint |

AX 的旧 `docs/brewfs-integration.md` 与新增 CSI/fork 代码存在时间差；本方案以已审阅代码为事实来源，并把运行行为留给 AX00 验证。

## 拓扑与身份映射

主拓扑：一个 pinned S → N 个独立 workspace（Δ_1…Δ_N）→ N 个 AX task/actor。每个 Δ 一个有效 lease-owning mount。节点可有多个独立 workspace；同一节点共享 mount 只适用于同一 workspace 下明确协作的容器，是另一类一致性场景。

每个任务必须保存映射：`run_id → AX task/actor → node UID → external volume identity → workspace UUID → StorageClass → S digest → upper state/version → lease generation`。若 Substrate 路径没有 Kubernetes PVC/PV，记录 null 和 external volume identity，不能伪造 PVC。

S 的“共享”要用 manifest/content ID 核对，不用仓库名判断。各 Δ 对象与 metadata prefix 分离，权限与命名隔离单独核验。跨任务发现同名输出不代表可共享的相同内容。

## 资格条件与交付物

| Gate | 当前状态 | 进入下一步前必须产生的证据 |
|---|---|---|
| G0 路径与观测 | 待验证 | 兼容 pins、镜像、实际 mount argv/runtime、mountinfo、canary、分层计数与测量扰动；CPU/内存/cache/后端拓扑清单 |
| G1 任务与会话 | 需研究 wrapper | 真 exit、API/tool completion、独立 grader、timeout/provider error；可恢复的 session ID/状态、预算余量与 tool ledger；日志外置 |
| G2 可比基线/消融 | 待实现或资格验证 | 同内容/语义/持久化/缓存；materialized lower 与 shared-off 对照补丁；正确性 manifest；若缺失只做系统比较 |
| G3 父状态 fork | 跨 repo 缺口 | CRD/schema/controller、命名映射、幂等冲突检查、parent quiesce/commit、child 独立 UUID/SC、父子版本与 sibling isolation；失败回收 |
| G4 独立 reopen 与迁移 | Entity 入口缺口 | clean close→另一进程重开→另一节点恢复；内容/namespace 校验；租约/epoch 转移和 stale writer 拒绝；session restore 另证 |
| G5 不可变发布 | 待资格验证 | 当前 S+Δ 导出/发布路径、durable ack、manifest digest、版本固定、半发布不可见、回收保护 |
| G6 对象布局 | 未闭合链路 | producer/strict PUT 的 hint 传递；新对象 persisted B/q/d/p；实际 Range 与 backend physical I/O；相同配置负对照 |
| G7 规模与寿命 | 待测 | 每目录 entry/byte 限制、owner census 实际上限与保留 tombstone 压力、N=16 通过后才升 N；空间/GC 在保留窗口后收敛 |

一项 gate 失败只阻塞依赖它的实验，不阻塞独立的后端检查或协议准备。源码能力、接通接口与实测通过分别记录。

## 迁移合同：三个模式

| 模式 | 含义 | 准入条件 | 可声称的结果 |
|---|---|---|---|
| M0 | 保留原节点与 mount，停止并重启 Agent 进程 | G0/G1；证明 AX 操作不会触发 NodeUnstage 或丢失 mount | 执行恢复控制组；不能称跨节点或冷恢复 |
| M1 | 工具边界 quiesce，持久化后将所有权移交到另一节点 | G0/G1/G4；target node UID 不同 | 跨节点应用 checkpoint 恢复 |
| M2 | 注入进程/节点故障，从最后已确认 checkpoint takeover | M1 + 故障条件下 fencing、durability、session oracle | 有界故障下的恢复正确性与可用性成本 |

### checkpoint 最小内容

不可变 S digest/manifest；已确认 Δ 版本及引用对象；workspace UUID 与 generation/epoch；namespace 和内容 oracle；Agent 会话可导出的状态/恢复标识；task/prompt/tool-policy/image 摘要；已完成 tool result、外部副作用账本、未完成操作标记；token/turn/time 预算已用量；随机种子与 provider 不支持项。

不得默认仅保存 `/workspace` 就保存了 Agent 状态。当前 `CODEX_HOME=/opt/codex-home` 在外部；要验证选择的执行器能够 resume。凭据在目标端通过受控配置注入，checkpoint 不打包 API key。无法恢复的进程内存、未完成网络流和外部事务显式标为限制。

### M1 状态机（协议要求，非当前已实现功能）

1. **RUNNING → QUIESCING**：协调器发暂停请求，阻止新工具 dispatch；等待或按合同取消现有操作，记录所有子进程状态。
2. **QUIESCING → DURABLE**：关闭/同步文件及目录操作；等待定义的远端 durable ack；保存 Agent session 和工具账本；发布不可变 checkpoint manifest。fsync 返回不能未经验证就视为远端提交。
3. **DURABLE → FENCED**：停止源写 admission；正常关闭旧 mount 或等待经过验证的租约失效机制；记录旧 generation 已不可提交。source/target 不得重叠有效写权限。
4. **FENCED → RESTORING**：目标节点经控制面获得新有效 generation，打开既有 S/Δ；验证 manifest、必要内容和 session；保持 workspace identity 的逻辑连续性，记录新 mount identity。
5. **RESTORING → RUNNING**：恢复任务，执行有内容校验的第一个有效工具操作，再释放新工具队列。仅 Pod Ready、touch 或读取预热 canary 不计 first useful operation。
6. 任一步失败进入 **RECOVERY_REQUIRED**。保留 checkpoint 与日志；不得自动让源、目标同时重试写。由当前所有权决定在哪一端恢复，记录回滚和人工介入时间。

上述阶段必须有 coordinator monotonic 时间，跨主机事件用 trace ID 关联。禁止直接相减两台机器未同步的 monotonic 时钟。持续 checkpoint 的前置成本计入总任务时间。

### 故障注入与 oracle

| 故障点 | 预期不变量 | 观测 |
|---|---|---|
| checkpoint ack 前杀源 | 只允许回到上一个已确认 checkpoint | acknowledged 操作集与恢复 manifest 对比 |
| ack 后、fence 前杀源 | 已确认数据保留，目标等待合法接管 | durable readback、租约等待、重试计数 |
| 源隔离但仍存活，目标试图接管 | 任一时刻至多一个可提交 writer | 带 generation 的重复写，旧写被拒绝；不要只看进程存活 |
| 目标 mount / first-read 失败 | 不暴露部分恢复状态 | source/target generation、清理和重试路径 |
| S' 上传中 producer 失败 | 未提交版本对 consumer 不可见 | manifest visibility、orphan bytes、GC 后保留版本可读 |

故障清理仅操作专用实验 namespace/bucket prefix 和标记资源。所有注入点先在正确性场景执行，再测耗时；若恢复错误，性能图标记失败而非删掉样本。

## 执行准备顺序

1. 冻结源码、补丁、镜像与工具链；记录实际硬件和参数，不重用历史 smoke 的环境字段。
2. 实现 G1 wrapper 和 G0 telemetry，退出码、任务结果、日志外置与 checkpoint state 可验。
3. 接通 Entity/CSI 并通过 AX00；先单挂载，再两个独立 workspace，同 S 不同 Δ。
4. 实现或资格验证 G2 强对照；执行 README 的 12 个无模型批次，定位成本。
5. 补齐 G3/G5 再做父分叉与 producer/consumer。若只支持初始快照，从实验命名中排除“父状态 fork”。
6. 独立重挂载成功后做 M0/M1，最后 M2。每次变更重新记录补丁 SHA 和需要重跑的 gate。

本目录不提供假定现已可用的集群启动脚本。`ax workspace fork` 是已确认的客户端语法，其服务端依赖尚未齐备；真实运行指令需在具体兼容版本和部署 namespace 冻结后写入每次运行清单。
