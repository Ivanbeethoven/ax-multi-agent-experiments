# 计量口径与结果解释

所有性能字段在计划清单中为 null。事件契约见 `events.schema.json`；这是拟定的新采集格式，不宣称当前 AX/BrewFS 已直接输出这些字段。原始 FUSE、S3、后端与 Agent 日志应分别保存，normalizer 记录版本和源 offset，保留原始状态。

## 时间与任务结果

| 字段/指标 | 定义与单位 |
|---|---|
| workspace_ready_ms | 协调器申请到内容与挂载校验通过；分别列调度、镜像、预装、mount，不能只看 Ready bit |
| first_useful_tool_ms | 协调器申请到预先定义的第一个真实工具结果完成；任务相关内容校验通过 |
| batch_makespan_ms | 固定批次首次申请到最后一个指定候选终止；同时报告 deadline 内成功数，失败快不能作为胜出 |
| task_elapsed_ms | task 开始到终止，包括模型等待、工具间隔、重试与持久化尾部；setup/teardown 单列且计总成本 |
| tool_wall_ms | 工具进程/调用边界时间；并发工具的 span 用区间并集或 DAG 关键路径，不能直接求和代替 elapsed |
| model_wait_ms | provider 请求到响应/流结束区间；与工具重叠时标记 overlap，不能强行让分项简单加和 |
| handler_latency_us | 单一 FUSE handler 接收/返回之差；不等于系统调用端到端、模型等待或 capture elapsed |
| migration_pause_ms | 协调器暂停请求到目标首个有效工具完成；拆 quiesce/checkpoint/fence/restore/cold-read |
| task_success | 固定版本 grader 的结果；没有 grader 就是 null/ungraded，不能用 exit 0 补填 |
| success_throughput | deadline 内 grader 成功候选数 / 固定观测窗口秒数；分母包含失败、排队和 timeout |

保存 wrapper exit、模型请求完成、tool completion、patch produced、测试结果、官方 grader 各层状态。FUSE ENOENT、属性不支持、incomplete pairing 与 Agent 失败分开。AX Running/PID1 存活不是任务存活。日志/指标写到独立 telemetry volume 或流，记录采样率与丢事件数，测量 overhead 用开/关配对运行评估。

## 共享与修改：使用内容版本和范围

1. 同一 S 下，把每个 Agent 实际读取范围映射到 `(content_id, byte_interval)` 并求集合 R_i。`read_reuse = 1 - |union R_i| / sum |R_i|`；各 R_i 内先去重，长度按 bytes 计算。分母 0 时记 null。另报 pairwise Jaccard、独立内容数与热度分布，不把重复本地读误算成跨 Agent 复用。
2. 跨不同 S 仅在相同内容 ID 与范围具有对应关系时计算 byte reuse；只用 path 相同会把不同版本混合。路径重叠、内容重叠、实际缓存命中分别报告。
3. `modified_coverage` 为相对 S 最终发生内容改变的原有文件范围 bytes / S 原有逻辑 bytes。新增 bytes、删除 bytes、namespace-only 修改、重复覆盖写流量另列；不能用 sum(write length) 代替最终覆盖率。记录计算算法对重命名、hole、truncate 的规则。
4. 正负元数据请求按 method × status × tool phase 分层；明确六方法集合，保留 open/flush/release 的独立计数。unsupported 操作既保留次数，也标记是否破坏任务 oracle。

## 字节与请求：分层不混加

| 层 | 必采字段 | 可回答的问题 |
|---|---|---|
| FUSE | method、status/errno、requested/returned bytes、offset、handle/object ID | Agent 向文件系统发出什么逻辑请求 |
| Entity/lower | lower/upper/control 分类、索引页、mapping/whiteout 操作、缓存命中 | Packed 和 Δ 实际改变了什么工作 |
| 客户端 S3 | HEAD/GET/PUT、Range、request/response bytes、object ID/length、重试 | FUSE 请求如何形成对象请求 |
| RustFS | accepted/persisted B/q/d/p、physical read/write、EC/checksum CPU、repair | 布局是否生效，物理代价如何改变 |
| 资源 | 每节点 CPU/RSS/cache、Redis bytes/commands、网络、对象与 metadata 存储 | 是否把成本移动到其他层或共享节点 |

`S3_read_amplification = S3 response bytes / successful FUSE returned read bytes`，标记缓存状态、预取和重复范围。`backend_read_amplification = backend physical read bytes / S3 response bytes`；后台修复独立计数。分母为 0 时 null，不能输出无穷再取平均。先按批次求总分子/分母，另报任务分布，不平均不等权比例。

`upload_amplification = uploaded payload bytes / acknowledged logical write bytes` 只描述上传流量，不是 EC 冗余率。物理写入放大另用 backend physical write bytes / logical write bytes，并说明 metadata、padding、校验和副本/EC 是否计入。完整 durability/drain 窗口后封账。

快照存储分三栏：单份共享 S、所有 Δ 的并集物理对象、索引/control/retained history。同对象不能按每 workspace 重复加总；反之不能遗漏上层引用之外的 orphan/retention/GC。迁移分“此次新传输字节”“已存在远端状态字节”“目标首次使用读取字节”，远端常驻成本计入长期资源。

## 统计与图表约定

单位为 bytes、KiB=1024 bytes、MiB=1024² bytes、ms/us，图注标单位、样本范围、独立批次数、cache、runtime 和分母。工作量固定时比较开销；arrival-driven 另报排队、到达与完成数。每个实验预先确定一个主要任务指标和一个机制指标，降低事后挑指标空间。

任务/批次配对、随机顺序、相同 seed；重复 I/O 不算独立样本。正式数据集冻结后给逐任务效应与聚类区间。采样/丢日志引起无效测量要保存原 run，标明替换关联。所有失败和 unsupported 的任务保留在任务资格与结果表；只有“是否纳入性能统计”的规则预先确定。

计划图只规定坐标与分组，不填入假数据：AX01 并发/缓存→时间与字节；AX02 正负探测→工具时间与 lower 开销；AX03 修改比例→持久化/GC 成本；AX04 消费次数→含构建成本；AX05 迁移阶段→停顿与正确性；AX06 对象范围→各层放大；AX07 逐任务质量、时间及失败。
