#!/usr/bin/env bash
set -euo pipefail
cd /srv/ax-overlay-tax-20261113
exec > remount-regression.log 2>&1
trap 'echo $? > remount-regression.exit' EXIT
export GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=http.proxy GIT_CONFIG_VALUE_0=http://127.0.0.1:17898
python3 -m unittest test_meter test_cold_counters -v
python3 run_local-remount-fix.py --binary /srv/ax-overlay-tax-20261113/artifacts/brewfs --producer /srv/ax-overlay-tax-20261113/artifacts/packed_snapshot_fixture --source-commit 03c8cc55d61473533c00a8afe13b4ef1fcd9b725 --source-patch /srv/ax-overlay-tax-20261113/artifacts/source.patch --workspace-format workspace --build-profile optimized-release --comparison empty-cache --cache-state on --metadata-sync local-buffered --metadata-edits 2 --pairs 3 --passes 1 --out /srv/ax-overlay-tax-20261113/remount-regression-01
