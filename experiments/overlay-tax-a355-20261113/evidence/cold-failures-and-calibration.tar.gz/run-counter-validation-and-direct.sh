#!/usr/bin/env bash
set -euo pipefail
cd /srv/ax-overlay-tax-20261113
bash run-cold-native-03.sh
bash run-cold-native-04.sh
