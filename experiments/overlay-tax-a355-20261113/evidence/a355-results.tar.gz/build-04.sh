#!/usr/bin/env bash
set -euo pipefail
root=/srv/ax-overlay-tax-20261113
cd "$root/build-source"
exec >"$root/build-04.log" 2>&1
trap 'printf "%s\n" "$?" >"/srv/ax-overlay-tax-20261113/build-04.exit"' EXIT
test "$(cat "$root/build-03.exit")" = 101
old_test="$root/target/debug/deps/brewfs-ec90c7b2862fd863"
sha256sum "$old_test" >"$root/sqlite-isolated-test.sha256"
RUST_TEST_THREADS=1 "$old_test" --exact workspace::meta_layer::tests::writable_acl_independent_sqlite_instances_keep_mode_acl_during_atime_writes --nocapture >"$root/sqlite-isolated-test.log" 2>&1
git apply --reverse --check ../ablation-v2.patch
git apply --reverse ../ablation-v2.patch
git apply ../ablation-v3.patch
export PATH="$root/toolchain/bin:$PATH" CARGO_HOME="$root/cargo"
export CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_RELEASE_DEBUG=0
export CARGO_BUILD_JOBS=16 RUST_TEST_THREADS=2
features=fuse-io-uring-runtime,workspace,native-packed-base,frozen-base-metadata,rustfs-ec-block-size-hint,observability
(
  export CARGO_TARGET_DIR="$root/target"
  set -x
  cargo fmt --all --check
  cargo clippy --offline --locked --workspace --all-targets --no-default-features --features "$features" -- -D warnings
  cargo test --offline --locked --workspace --lib --bins --no-default-features --features "$features"
) >"$root/checks-04.log" 2>&1 &
checks_pid=$!
(
  export CARGO_TARGET_DIR="$root/release-target"
  set -x
  cargo --config profile.release.package.brewfs.opt-level=3 build --offline --locked --release --no-default-features --features "$features" --bin brewfs --bin packed_snapshot_fixture
  cp "$root/release-target/release/brewfs" "$root/release-target/release/packed_snapshot_fixture" "$root/artifacts/"
  cd "$root/artifacts"
  sha256sum brewfs packed_snapshot_fixture >SHA256SUMS
  printf '%s\n' 03c8cc55d61473533c00a8afe13b4ef1fcd9b725 >source-commit.txt
  cp "$root/ablation-v3.patch" source.patch
  printf '%s\n' 'Normal opt-level=3 release; same binary for production, overlay-read, lower-read.' >BUILD-SCOPE.txt
) >"$root/release-04.log" 2>&1 &
release_pid=$!
printf '%s %s\n' "$checks_pid" "$release_pid" >"$root/build-04-children.txt"
set +e
wait "$checks_pid"
checks_status=$?
wait "$release_pid"
release_status=$?
set -e
printf '%s\n' "$checks_status" >"$root/checks-04.exit"
printf '%s\n' "$release_status" >"$root/release-04.exit"
test "$checks_status" = 0
test "$release_status" = 0
