"""Record actual CI status before the Redis-only diagnostic; never mark CI green."""
import argparse
import hashlib
import json
import re
from pathlib import Path

root = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--out', type=Path, default=root / 'measurement-check-scope.json')
args = parser.parse_args()
log = (root / 'checks-05.log').read_text()
known = 'workspace::meta_layer::tests::writable_acl_independent_sqlite_instances_keep_mode_acl_during_atime_writes'
failed = re.findall(r'^test (\S+) \.\.\. FAILED$', log, re.M)
assert failed == [known], failed
assert 'test result: FAILED. 2851 passed; 1 failed; 489 ignored;' in log
assert 'Finished `dev` profile' in log and '-- -D warnings' in log
for name in ['read_ablation_preserves_contents_and_rejects_writes',
             'read_ablation_refuses_nonempty_upper',
             'read_ablation_refuses_revoked_lease_and_replaced_view']:
    assert re.search(r'^test .*::' + name + r' \.\.\. ok$', log, re.M)
baseline = json.loads((root / 'main-sqlite-summary.json').read_text())
assert len(baseline['results']) == 5 and all(r['exit'] == 101 for r in baseline['results'])
for i in range(1, 6):
    original = (root / f'main-sqlite-{i}.log').read_text()
    assert known in original and 'ResourceBusy' in original
for line in (root / 'artifacts/SHA256SUMS').read_text().splitlines():
    digest, name = line.split('  ', 1)
    with (root / 'artifacts' / name).open('rb') as f:
        assert hashlib.file_digest(f, 'sha256').hexdigest() == digest
with (root / 'artifacts/source.patch').open('rb') as f:
    assert hashlib.file_digest(f, 'sha256').hexdigest() == '7cda6c9524b2440bc61a3ad9057814100088e2b735ce4d733b7616201cbdb466'
with args.out.open('x') as f:
    json.dump(dict(full_ci_passed=False, tests_passed=2851, tests_failed=[known],
                   tests_ignored=489, backend='Redis', diagnostic_only=True,
                   user_instruction='SQLite failure does not block this measurement; remove SQLite tests later',
                   unmodified_baseline=baseline), f, indent=2)
