from pathlib import Path
import gzip
import hashlib
import json
import shutil
import subprocess

root=Path('/srv/ax-overlay-tax-20261113')
archive=root/'main-test.gz'
with archive.open('rb') as f:
    assert hashlib.file_digest(f,'sha256').hexdigest() == '97f0b482723436f2d5b3f3d74797d74396277a943c48119f8b219287b9c15a17'
binary=root/'main-test'
with gzip.open(archive,'rb') as src, binary.open('xb') as dst:
    shutil.copyfileobj(src,dst)
binary.chmod(0o700)
with binary.open('rb') as f:
    digest=hashlib.file_digest(f,'sha256').hexdigest()
assert digest=='fe223e64b7445cc85b0a6d701c76778d401e89f668ee9cd808259653dc6b5c12'
name='workspace::meta_layer::tests::writable_acl_independent_sqlite_instances_keep_mode_acl_during_atime_writes'
rows=[]
for i in range(1,6):
    done=subprocess.run([str(binary),'--exact',name,'--nocapture'],capture_output=True,text=True,timeout=60)
    (root/f'main-sqlite-{i}.log').write_text(done.stdout+done.stderr)
    rows.append(dict(repetition=i,exit=done.returncode))
receipt=dict(source_commit='10813952eaa35c7f4fe29ac447f823bc203558fe',
    related_sqlite_source_unchanged_in_current_base=True,
    note='Prior merged-main test binary; next commit only renamed a CLI configuration key. No diagnostic ablation patch.',
    binary_sha256=digest,results=rows)
with (root/'main-sqlite-summary.json').open('x') as f:
    json.dump(receipt,f,indent=2)
print(json.dumps(receipt))
