#!/usr/bin/env bash
set -euo pipefail
root=/srv/ax-overlay-tax-20261113
cd "$root/build-source"
exec >"$root/build-03.log" 2>&1
trap 'printf "%s\n" "$?" >"/srv/ax-overlay-tax-20261113/build-03.exit"' EXIT
test "$(cat "$root/build-02.exit")" = 101
git apply --reverse --check ../ablation.patch
git apply --reverse ../ablation.patch
git apply ../ablation-v2.patch
export PATH="$root/toolchain/bin:$PATH" CARGO_HOME="$root/cargo" CARGO_TARGET_DIR="$root/target"
export CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_PROFILE_RELEASE_DEBUG=0
export CARGO_BUILD_JOBS=16 RUST_TEST_THREADS=16
features=fuse-io-uring-runtime,workspace,native-packed-base,frozen-base-metadata,rustfs-ec-block-size-hint,observability
set -x
cargo fmt --all --check
cargo test --offline --locked --workspace --lib --bins --no-default-features --features "$features" read_ablation -- --nocapture
cargo clippy --offline --locked --workspace --all-targets --no-default-features --features "$features" -- -D warnings
cargo test --offline --locked --workspace --lib --bins --no-default-features --features "$features"
cargo --config profile.release.package.brewfs.opt-level=3 build --offline --locked --release --no-default-features --features "$features" --bin brewfs --bin packed_snapshot_fixture
cp "$root/target/release/brewfs" "$root/target/release/packed_snapshot_fixture" "$root/artifacts/"
cd "$root/artifacts"
sha256sum brewfs packed_snapshot_fixture >SHA256SUMS
printf '%s\n' 03c8cc55d61473533c00a8afe13b4ef1fcd9b725 >source-commit.txt
cp "$root/ablation-v2.patch" source.patch
printf '%s\n' 'Normal opt-level=3 release; same binary for production, overlay-read, lower-read.' >BUILD-SCOPE.txt
