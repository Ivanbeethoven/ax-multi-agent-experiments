#!/usr/bin/env bash
set -euo pipefail
root=/srv/ax-overlay-tax-20261113
cd "$root"
exec >run-01.log 2>&1
trap 'printf "%s\n" "$?" >"/srv/ax-overlay-tax-20261113/run-01.exit"' EXIT
test "$(hostname)" = A355
test "$(cat release-05.exit)" = 0
python3 check-measurement-scope.py
test ! -e run-01
test -z "$(pgrep -x rustc || true)"
mkdir -p tmp
export TMPDIR="$root/tmp" TOKIO_WORKER_THREADS=4 GIT_OPTIONAL_LOCKS=0
unset BREWFS_METADATA_PROFILE BREWFS_METADATA_MAX_BYTES BREWFS_METADATA_MAX_OPERATIONS BREWFS_METADATA_FLUSH_MS
python3 - <<'PY'
import json, os, platform, time
from pathlib import Path
def counters():
    values=list(map(int,Path('/proc/stat').read_text().splitlines()[0].split()[1:9]))
    return sum(values), values[3]+values[4]
a=counters()
time.sleep(2)
b=counters()
idle=100*(b[1]-a[1])/(b[0]-a[0])
assert idle > 95, f'host busy: idle={idle}'
with Path('measurement-host.json').open('x') as f:
    json.dump(dict(host=platform.node(), kernel=platform.release(), cpu_count=os.cpu_count(),
                   cpu_idle_percent=idle, loadavg=os.getloadavg(), meminfo=Path('/proc/meminfo').read_text(),
                   cpuinfo=Path('/proc/cpuinfo').read_text(), swaps=Path('/proc/swaps').read_text()),f,indent=2)
PY
set -x
python3 run_local.py --binary "$root/artifacts/brewfs" --producer "$root/artifacts/packed_snapshot_fixture" \
  --source-commit "$(cat artifacts/source-commit.txt)" --source-patch "$root/artifacts/source.patch" \
  --workspace-format workspace --build-profile optimized-release --comparison overlay-tax \
  --cache-state on --metadata-sync remote --pairs 6 --passes 1024 --out "$root/run-01"
python3 summarize.py "$root/run-01" >summary-01.json
