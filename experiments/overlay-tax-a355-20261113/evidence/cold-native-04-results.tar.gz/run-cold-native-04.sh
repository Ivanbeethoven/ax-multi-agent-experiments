#!/usr/bin/env bash
set -euo pipefail
root=/srv/ax-overlay-tax-20261113
cd "$root"
exec >cold-native-04.log 2>&1
trap 'printf "%s\n" "$?" >"/srv/ax-overlay-tax-20261113/cold-native-04.exit"' EXIT
test "$(cat cold-native-03.exit)" = 0
test ! -e cold-native-04
test -z "$(pgrep -x rustc || true)"
python3 check-measurement-scope-02.py --out cold-check-04.json
export TMPDIR="$root/tmp" TOKIO_WORKER_THREADS=4 GIT_OPTIONAL_LOCKS=0
export GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=http.proxy GIT_CONFIG_VALUE_0=http://127.0.0.1:17898
unset BREWFS_METADATA_PROFILE BREWFS_METADATA_MAX_BYTES BREWFS_METADATA_MAX_OPERATIONS BREWFS_METADATA_FLUSH_MS
set -x
python3 run_local.py --binary "$root/artifacts/brewfs" --producer "$root/artifacts/packed_snapshot_fixture" \
  --source-commit "$(cat artifacts/source-commit.txt)" --source-patch "$root/artifacts/source.patch" \
  --workspace-format workspace --build-profile optimized-release --comparison cold-native --object-meter client \
  --cache-state on --metadata-sync remote --pairs 6 --passes 64 --out "$root/cold-native-04"
python3 summarize_cold.py "$root/cold-native-04" >summary-cold-native-04.json
tar -czf cold-native-04-results.tar.gz cold-native-04 summary-cold-native-04.json run_local.py summarize_cold.py run-cold-native-04.sh cold-check-04.json artifacts/SHA256SUMS artifacts/source-commit.txt artifacts/source.patch
sha256sum cold-native-04-results.tar.gz >cold-native-04-results.sha256
