#!/usr/bin/env bash
set -euo pipefail
r=/srv/ax-overlay-scale-20261114
cd "$r"
exec >run-a355-02.log 2>&1
trap 'echo $? > /srv/ax-overlay-scale-20261114/run-a355-02.exit' EXIT
while pgrep -f '^bash /srv/ax-overlay-scale-20261114/check-build.sh$' >/dev/null; do sleep 5; done
test "$(cat checks-01.exit)" = 0
test "$(cat release.exit)" = 0
test "$(cat tdd.exit)" = 101
test "$(cat check-monitor.exit)" = 0
test "$(cat checks-01/status.txt)" = passed
(cd source-audit-lf && git apply --reverse --check ../phase2-formatted.patch)
cp phase2-formatted.patch artifacts/source.patch
(cd artifacts && sha256sum brewfs packed_snapshot_fixture source.patch >SHA256SUMS)
python3 - <<'PY'
import json,re,time
from pathlib import Path
r=Path('.')
logs={}
for p in (r/'checks-01').glob('*.log'):
 results=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',p.read_text())
 if results:
  assert all(int(x[0])>0 and x[1]=='0' for x in results)
  logs[p.name]=results
assert len(logs)==7,logs
(r/'check-receipt.json').write_text(json.dumps(dict(passed=True,sqlite_tests_executed=False,tests=logs),indent=2)+'\n')
while True:
 busy=[]
 for p in Path('/proc').glob('[0-9]*/cmdline'):
  try: cmd=p.read_bytes().replace(b'\0',b' ').decode(errors='replace')
  except (OSError,ProcessLookupError): continue
  if 'scripts/lazy_clone_read_bench.py' in cmd or ('/srv/juicefs-' in cmd and ' mount ' in cmd): busy.append(cmd)
 if not busy: break
 print('waiting for foreign workload',flush=True);time.sleep(10)
PY
export GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=http.proxy GIT_CONFIG_VALUE_0=http://127.0.0.1:17901
{ date -Is; uptime; free -b; df -B1 /srv; docker ps --format '{{.Names}} {{.Status}}'; } >host-before.txt
python3 harness/experiments/overlay-scale-a355-20261114/run_mutations.py \
 --binary "$r/artifacts/brewfs" --producer /srv/ax-overlay-tax-20261113/total/artifacts/packed_snapshot_fixture \
 --source-commit 03c8cc55d61473533c00a8afe13b4ef1fcd9b725 --source-patch "$r/artifacts/source.patch" \
 --workspace-format workspace --build-profile optimized-release --comparison empty-cache --object-meter proxy \
 --cache-state on --metadata-sync remote --metadata-edits 8 --pairs 3 --passes 32 \
 --out "$r/mutations-01" >mutations-01.log 2>&1
echo 0 >mutations-01.exit
bash harness/experiments/overlay-scale-a355-20261114/run.sh \
 /srv/ax-overlay-tax-20261113/total/artifacts "$r/artifacts" "$r/measure-01"
echo 0 >measure-01.exit
