import importlib.util,json,socket,subprocess,sys,time,uuid
from pathlib import Path
r=Path('/srv/ax-overlay-scale-20261114')
sys.path.insert(0,str(r/'harness/experiments/overlay-scale-a355-20261114'))
from redis_audit import audit
spec=importlib.util.spec_from_file_location('runner',r/'harness/experiments/hot-lower-20261112/run_local.py');runner=importlib.util.module_from_spec(spec);spec.loader.exec_module(runner)
owner='ax-overlay-audit-'+uuid.uuid4().hex[:10]
subprocess.run(['docker','run','-d','--rm','--name',owner,'--label','ax.audit.owner='+owner,'-p','127.0.0.1::6379',runner.REDIS],check=True,capture_output=True)
try:
 port=int(subprocess.check_output(['docker','port',owner,'6379/tcp'],text=True).strip().rsplit(':',1)[1])
 time.sleep(1)
 def command(*words):
  words=[w.encode() for w in words]
  data=b'*'+str(len(words)).encode()+b'\r\n'+b''.join(b'$'+str(len(w)).encode()+b'\r\n'+w+b'\r\n' for w in words)
  with socket.create_connection(('127.0.0.1',port),timeout=5) as c:
   c.sendall(data); return c.recv(4096)
 def operation():
  command('GET','audit-key');command('EVAL',"return redis.call('GET','audit-key')",'0')
 out=r/'monitor-integration.json';audit(port,operation,out);result=json.loads(out.read_text())
 assert result['counts']=={'client':{'GET':1,'EVAL':1},'lua':{'GET':1}},result
 print(json.dumps(result))
finally:
 actual=subprocess.check_output(['docker','inspect','--format','{{index .Config.Labels "ax.audit.owner"}}',owner],text=True).strip()
 assert actual==owner
 subprocess.run(['docker','rm','-f',owner],check=True,capture_output=True)
