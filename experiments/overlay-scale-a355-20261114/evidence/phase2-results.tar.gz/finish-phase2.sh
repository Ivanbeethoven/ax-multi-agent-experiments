#!/usr/bin/env bash
set -euo pipefail
r=/srv/ax-overlay-scale-20261114
cd "$r"
exec >finish-phase2.log 2>&1
trap 'echo $? > /srv/ax-overlay-scale-20261114/finish-phase2.exit' EXIT
test "$(cat run-a355-04.exit)" = 0
test "$(cat measure-02.exit)" = 0
python3 - <<'PY'
import hashlib,json
from pathlib import Path
r=Path('.')
expected=json.loads((r/'phase2-expected-source.json').read_text())
missing=[];different=[]
for name,want in expected['files'].items():
 p=r/'source'/name
 if not p.is_file(): missing.append(name);continue
 got=hashlib.sha256(p.read_bytes().replace(b'\r\n',b'\n')).hexdigest()
 if got!=want:different.append(dict(path=name,expected=want,actual=got))
receipt=dict(passed=not missing and not different,files=len(expected['files']),normalization='CRLF to LF',missing=missing,different=different,manifest_sha256=hashlib.sha256((r/'phase2-expected-source.json').read_bytes()).hexdigest())
(r/'full-source-audit.json').write_text(json.dumps(receipt,indent=2)+'\n')
assert receipt['passed'],receipt
PY
python3 -m unittest discover -s harness/experiments/overlay-open-a355-20261113 -p 'test_*.py' >final-detail-tests.log 2>&1
python3 -m unittest discover -s harness/experiments/overlay-scale-a355-20261114 -p 'test_*.py' >final-scale-tests.log 2>&1
for script in harness/experiments/overlay-{open-a355-20261113,scale-a355-20261114}/*.sh; do bash -n "$script"; done
export PATH=/srv/ax-overlay-tax-20261113/toolchain/bin:$PATH
export CARGO_HOME=/srv/ax-overlay-tax-20261113/cargo
export CARGO_TARGET_DIR=/srv/ax-overlay-tax-20261113/target
export CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 RUST_TEST_THREADS=2 CARGO_BUILD_JOBS=16
cd source
cargo test --offline --locked --lib --no-default-features --features fuse-io-uring-runtime,workspace,native-packed-base,frozen-base-metadata,rustfs-ec-block-size-hint,observability packed_readonly_payload_retention_is_opt_in -- --nocapture >../final-cli-test.log 2>&1
cd "$r"
export GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=http.proxy GIT_CONFIG_VALUE_0=http://127.0.0.1:17901
bash harness/experiments/overlay-open-a355-20261113/run-regression.sh /srv/ax-overlay-tax-20261113/total/artifacts "$r/artifacts" "$r/fio-prepared-01"
