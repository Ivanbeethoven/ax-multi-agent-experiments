#!/bin/bash
set -euo pipefail
r=/srv/ax-overlay-scale-20261114
cd "$r"
trap 'echo $? > fio-debug-candidate-01.exit' EXIT
export GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=http.proxy GIT_CONFIG_VALUE_0=http://127.0.0.1:17901
{ date -Is; uptime; free -b; df -B1 /srv; docker ps --format '{{.Names}} {{.Status}}'; } >host-before.txt
python3 harness/experiments/overlay-scale-a355-20261114/../overlay-open-a355-20261113/run_fio_guard.py --prepared-file --rust-log warn,brewfs::vfs::fs=debug \
 --binary /srv/ax-overlay-scale-20261114/artifacts/brewfs --producer /srv/ax-overlay-tax-20261113/total/artifacts/packed_snapshot_fixture \
 --source-commit 03c8cc55d61473533c00a8afe13b4ef1fcd9b725 --source-patch /srv/ax-overlay-scale-20261114/artifacts/source.patch \
 --workspace-format workspace --build-profile optimized-release --comparison empty-cache --object-meter proxy \
 --cache-state on --metadata-sync remote --metadata-edits 8 --pairs 3 --passes 32 \
 --out "$r/fio-debug-candidate-01" >fio-debug-candidate-01.log 2>&1
echo 0 >fio-debug-candidate-01.exit
