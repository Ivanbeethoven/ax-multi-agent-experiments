#!/usr/bin/env bash
set -uo pipefail
r=/srv/ax-overlay-scale-20261114
cd "$r/source"
export PATH=/srv/ax-overlay-tax-20261113/toolchain/bin:$PATH CARGO_HOME=/srv/ax-overlay-tax-20261113/cargo CARGO_TARGET_DIR=/srv/ax-overlay-tax-20261113/target CARGO_BUILD_JOBS=16 CARGO_INCREMENTAL=0 CARGO_PROFILE_RELEASE_DEBUG=0
cargo fmt --all || exit 1
(bash tools/perf/check_overlay_hot.sh "$r/checks-01" >"$r/checks-01.log" 2>&1; echo $? >"$r/checks-01.exit") &
a=$!
(export CARGO_TARGET_DIR=/srv/ax-overlay-tax-20261113/release-target
 cargo --config profile.release.package.brewfs.opt-level=3 build --offline --locked --release --no-default-features --features fuse-io-uring-runtime,workspace,native-packed-base,frozen-base-metadata,rustfs-ec-block-size-hint,observability --bin brewfs --bin packed_snapshot_fixture >"$r/release.log" 2>&1
 rc=$?; echo "$rc" >"$r/release.exit"
 if test "$rc" = 0; then mkdir "$r/artifacts"; cp "$CARGO_TARGET_DIR/release/brewfs" "$CARGO_TARGET_DIR/release/packed_snapshot_fixture" "$r/artifacts/"; fi
) &
b=$!
wait "$a"; wait "$b"
