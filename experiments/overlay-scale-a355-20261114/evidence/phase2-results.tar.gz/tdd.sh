#!/usr/bin/env bash
set -uo pipefail
cd /srv/ax-overlay-scale-20261114/source
export PATH=/srv/ax-overlay-tax-20261113/toolchain/bin:$PATH CARGO_HOME=/srv/ax-overlay-tax-20261113/cargo CARGO_TARGET_DIR=/srv/ax-overlay-tax-20261113/target CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_BUILD_JOBS=16
cargo test --offline --locked --lib --no-default-features --features fuse-io-uring-runtime,workspace,native-packed-base,frozen-base-metadata,rustfs-ec-block-size-hint,observability fenced_layer_capture -- --nocapture >/srv/ax-overlay-scale-20261114/tdd.log 2>&1
echo $? >/srv/ax-overlay-scale-20261114/tdd.exit
