#!/usr/bin/env bash
set -euo pipefail
r=/srv/ax-overlay-scale-20261114
cd "$r"
exec >archive-phase2.log 2>&1
trap 'echo $? > /srv/ax-overlay-scale-20261114/archive-phase2.exit' EXIT
test "$(cat run-a355-04.exit)" = 0
python3 -m unittest discover -s harness/experiments/overlay-scale-a355-20261114 -p 'test_*.py' >final-analysis-tests.log 2>&1
for group in small large16 large64; do
  python3 harness/experiments/overlay-scale-a355-20261114/summarize.py "measure-02/$group" >"measure-02/$group-summary-final.json"
done
python3 - <<'PY'
import hashlib,json,subprocess
from pathlib import Path
root=Path('.')
def subset(old,new):
 if isinstance(old,dict):return all(k in new and subset(v,new[k]) for k,v in old.items())
 if isinstance(old,list):return len(old)==len(new) and all(subset(a,b) for a,b in zip(old,new))
 return old==new
for group in ('small','large16','large64'):
 a=json.loads((root/'measure-02'/f'{group}-summary.json').read_text())
 b=json.loads((root/'measure-02'/f'{group}-summary-final.json').read_text())
 assert subset(a,b),group
names=('measure-01','measure-02','mutations-01','mutations-baseline-01','mutations-chmod-01','fio-prepared-01','fio-prepared-candidate-01','fio-debug-baseline-01','fio-debug-candidate-01')
receipts=[]
for name in names:
 for p in (root/name).rglob('run.json'):
  s=json.loads(p.read_text()); assert s['cleanup']['mount_absent'],str(p)
  for container in s['containers']:
   assert s['cleanup'][container],str(p)
   probe=subprocess.run(['docker','inspect',container],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
   assert probe.returncode!=0,container
  receipts.append(dict(path=str(p),passed=s['passed'],cells=len(s['cells']),cleanup_complete=True,error=s.get('error')))
(root/'final-validation.json').write_text(json.dumps(dict(
 read_measurements_passed=54,all_original_summary_values_unchanged=True,
 full_source_files_verified=2015,sqlite_tests_executed=False,
 complete_acceptance=False,
 blockers=['Concurrent replace/open returned ENOENT on baseline and candidate',
           'Prepared-file fio randrw returned EIO on baseline and candidate; debug logs show workspace is busy'],
 runs=receipts),indent=2)+'\n')
inputs=[p for p in root.iterdir() if p.is_file() and p.name not in ('archive-phase2.log','archive-phase2.exit') and not p.name.startswith('phase2-results')]
inputs += [root/name for name in names]
inputs += [root/'checks-01',root/'harness',root/'artifacts/SHA256SUMS',root/'artifacts/source.patch']
# Freeze the baseline release build command as well as this iteration's build.
baseline=Path('/srv/ax-overlay-tax-20261113/total/build.log')
(root/'baseline-build.log').write_bytes(baseline.read_bytes());inputs.append(root/'baseline-build.log')
files=sorted({p for entry in inputs for p in ([entry] if entry.is_file() else entry.rglob('*')) if p.is_file() and '__pycache__' not in p.parts})
(root/'archive-files.txt').write_text(''.join(str(p)+'\n' for p in files))
PY
tar -czf phase2-results.tar.gz -T archive-files.txt
sha256sum phase2-results.tar.gz >phase2-results.sha256
stat -c '%s' phase2-results.tar.gz >phase2-results.bytes
