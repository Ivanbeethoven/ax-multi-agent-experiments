#!/usr/bin/env bash
set -euo pipefail
r=/srv/ax-overlay-open-retry-20261114
old=/srv/ax-overlay-open-profile-20261114
trap 'echo $? > "$r/finish-results.exit"' EXIT
deadline=$((SECONDS + 3600))
while test ! -f "$r/measure-tail30.exit"; do
  test "$SECONDS" -lt "$deadline" || exit 124
  sleep 10
done
for phase in build check3 measure3 measure-tail30; do test "$(cat "$r/$phase.exit")" = 0; done
exec 9>/run/lock/ax-overlay-open-diagnostic.lock
flock -n 9
mkdir "$r/results/analysis"
h="$r/harness/experiments/overlay-open-profile-a355-20261114"
python3 "$h/summarize_checks.py" "$r/results" > "$r/results/check-summary.json"
python3 "$h/diagnose.py" --results "$r/results" --baseline-profile "$old/profile-existing" > "$r/results/diagnostics-summary.json"
for arm in baseline candidate; do
  profile="$old/profile-existing"
  if test "$arm" = candidate; then profile="$r/results/profile-existing"; fi
  for mode in path openat; do
    perf report -i "$profile/small-files-32-pair1-production-warm/cpu-$mode.data" \
      --stdio --no-children --call-graph none --sort symbol --percent-limit 0.1 \
      > "$r/results/analysis/cpu-$arm-$mode-flat.txt"
  done
done
python3 "$r/harness/experiments/overlay-fixes-a355-20261114/audit_source.py" verify \
  "$r/candidate" "$r/artifacts/retry-manifest-v3.json" > "$r/artifacts/final-source-audit.json"
