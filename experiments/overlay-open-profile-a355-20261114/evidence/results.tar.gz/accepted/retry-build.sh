#!/usr/bin/env bash
set -euo pipefail
r=/srv/ax-overlay-open-retry-20261114
cd "$r/candidate"
export PATH=/srv/ax-overlay-tax-20261113/toolchain/bin:$PATH
export CARGO_HOME=/srv/ax-overlay-tax-20261113/cargo
export CARGO_TARGET_DIR=/srv/ax-overlay-tax-20261113/release-target
export CARGO_INCREMENTAL=0 CARGO_PROFILE_RELEASE_DEBUG=0 CARGO_BUILD_JOBS=12
features=fuse-io-uring-runtime,workspace,native-packed-base,frozen-base-metadata,rustfs-ec-block-size-hint,observability
trap 'echo $? > "$r/build.exit"' EXIT
mkdir "$r/artifacts"
date -Is >"$r/artifacts/build-start.txt"
rustc -Vv >"$r/artifacts/rustc.txt"
cargo --config profile.release.package.brewfs.opt-level=3 build --offline --locked --release --no-default-features --features "$features" --bin brewfs >"$r/build.log" 2>&1
cp "$CARGO_TARGET_DIR/release/brewfs" "$r/artifacts/brewfs"
cp /srv/ax-overlay-fixes-20261114/artifacts/packed_snapshot_fixture "$r/artifacts/packed_snapshot_fixture"
sha256sum "$r/artifacts/brewfs" "$r/artifacts/packed_snapshot_fixture" >"$r/artifacts/binary-sha256.txt"
date -Is >"$r/artifacts/build-end.txt"
