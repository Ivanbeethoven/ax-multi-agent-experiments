#!/usr/bin/env python3
"""Local writable Packed Overlay: optimized binary, cache off/on, paired runs.

Uses only pinned local Docker images and loopback ports. No cloud credentials,
cloud API, model, privileged host cache flush, or historical result modification.
"""
import argparse
from contextlib import contextmanager
import hashlib
from http.client import HTTPConnection, HTTPException
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import os
import platform
from pathlib import Path
import re
import secrets
import shutil
import socket
import subprocess
import tempfile
from threading import Lock, Thread
import time
import uuid

import boto3
from botocore.config import Config

REDIS = 'sha256:63218503f6461303e502355b8b0359a1194a190341f954e7fc7e8f92cd382a43'
RUSTFS = 'sha256:942893356344d292d9fcccadfceb039467c589ba10b4045cb148c0a65d2d3fec'
RUSTFS_REPO = 'https://github.com/Ivanbeethoven/rustfs.git'
RUSTFS_BRANCH = 'feat/dynamic-block-size-rebased'


def verify_backend(invoke):
    """Freeze the installed image only when its OCI revision is branch HEAD."""
    source = invoke(['git', 'ls-remote', RUSTFS_REPO, 'refs/heads/' + RUSTFS_BRANCH], timeout=30).stdout.strip().split()
    assert len(source) == 2 and re.fullmatch('[0-9a-f]{40}', source[0]), 'cannot resolve RustFS branch'
    labels = json.loads(invoke(['docker', 'image', 'inspect', '--format', '{{json .Config.Labels}}', RUSTFS]).stdout)
    assert labels.get('org.opencontainers.image.source') == RUSTFS_REPO
    assert labels.get('org.opencontainers.image.revision') == source[0], 'local RustFS image is not branch HEAD; rebuild before freezing a new run'
    return dict(repository=RUSTFS_REPO, branch=RUSTFS_BRANCH, revision_policy='branch-latest',
                source_commit=source[0], built_from_commit=labels['org.opencontainers.image.revision'],
                image_digest=RUSTFS, resolved_at_unix_ns=time.time_ns(),
                resolved_by='git ls-remote + Docker OCI revision/source labels')


def save(path, value):
    with path.open('x', encoding='utf-8') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')


def sha(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


@contextmanager
def meter(port):
    counts = dict(requests=0, gets=0, heads=0, puts=0, deletes=0, received_bytes=0, sent_bytes=0, errors=0, inflight=0)
    lock = Lock()

    class Handler(BaseHTTPRequestHandler):
        protocol_version = 'HTTP/1.1'
        disable_nagle_algorithm = True

        def log_message(self, *_):
            pass

        def forward(self):
            upstream = HTTPConnection('127.0.0.1', port, timeout=15)
            active = True
            with lock:
                counts['requests'] += 1
                counts['inflight'] += 1
                for verb, key in [('GET', 'gets'), ('HEAD', 'heads'), ('PUT', 'puts'), ('DELETE', 'deletes')]:
                    counts[key] += self.command == verb
            try:
                headers = dict(self.headers.items())
                length = int(self.headers.get('Content-Length', '0'))
                if length > 16 * 1024**2 or self.headers.get('Transfer-Encoding'):
                    raise ValueError('unsupported proxy request body')
                body = self.rfile.read(length) if length else None
                upstream.request(self.command, self.path, body=body, headers=headers)
                with lock:
                    counts['sent_bytes'] += length
                response = upstream.getresponse()
                data = response.read(16 * 1024**2 + 1)
                if len(data) > 16 * 1024**2:
                    raise ValueError('oversize local response')
                with lock:
                    counts['errors'] += response.status >= 400
                    counts['received_bytes'] += len(data)
                    counts['inflight'] -= 1
                    active = False
                self.send_response_only(response.status)
                for name, value in response.getheaders():
                    if name.lower() not in ('connection', 'transfer-encoding', 'content-length'):
                        self.send_header(name, value)
                self.send_header('Content-Length', response.getheader('Content-Length', '0') if self.command == 'HEAD' else str(len(data)))
                self.end_headers()
                self.wfile.write(data)
            except Exception:
                with lock:
                    counts['errors'] += 1
                self.close_connection = True
            finally:
                upstream.close()
                if active:
                    with lock:
                        counts['inflight'] -= 1

        do_GET = do_HEAD = do_PUT = do_DELETE = do_POST = forward

    def snapshot():
        with lock:
            return counts.copy()

    with ThreadingHTTPServer(('127.0.0.1', 0), Handler) as server:
        server.daemon_threads = True
        thread = Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            yield f'http://127.0.0.1:{server.server_port}', snapshot
        finally:
            server.shutdown()
            thread.join(5)


def commandstats(port):
    with socket.create_connection(('127.0.0.1', port), timeout=5) as connection:
        connection.sendall(b'*2\r\n$4\r\nINFO\r\n$12\r\ncommandstats\r\n')
        with connection.makefile('rb') as stream:
            header = stream.readline()
            if not header.startswith(b'$'):
                raise ValueError('Redis INFO did not return a bulk string')
            raw = stream.read(int(header[1:]))
    result = {}
    for line in raw.decode().splitlines():
        if line.startswith('cmdstat_'):
            name, fields = line.split(':', 1)
            result[name[8:]] = {key: float(value) for key, value in (field.split('=') for field in fields.split(','))}
    return result


def delta(after, before):
    return {key: value - before.get(key, 0) for key, value in after.items()}


def redis_delta(after, before):
    return {command: delta({key: value for key, value in values.items() if key != 'usec_per_call'},
                           before.get(command, {})) for command, values in after.items()}


def metrics(raw):
    return {match[1]: float(match[2]) for line in raw.splitlines()
            if (match := re.fullmatch(r'([a-zA-Z_][a-zA-Z0-9_]*) ([0-9.eE+-]+)', line))}


def client_objects(raw, arm):
    plain = metrics(raw)
    if arm == 'native-overlay':
        return dict(read_requests=plain['brewfs_s3_get_ops_total'],
                    body_bytes=plain['brewfs_s3_get_bytes_total'])
    assert plain['brewfs_object_read_http_body_bytes_observed'] == 1
    names = {'brewfs_object_read_started_total': 'read_requests',
             'brewfs_object_read_received_body_bytes_total': 'body_bytes'}
    result = dict(read_requests=0, body_bytes=0)
    seen = set()
    for line in raw.splitlines():
        match = re.fullmatch(r'([a-zA-Z_][a-zA-Z0-9_]*)\{([^}]+)\} ([0-9.eE+-]+)', line)
        if match and match[1] in names and 'layer="http_attempt"' in match[2] and 'engine="packed"' in match[2]:
            result[names[match[1]]] += float(match[3])
            seen.add(match[1])
    assert seen == set(names), 'HTTP attempt counters missing'
    return result


def measured_round(root, expected):
    round_start = start = time.monotonic_ns()
    directory = os.open(root / 'sub', os.O_RDONLY | os.O_DIRECTORY)
    try:
        observed = sorted(os.listdir(directory))
        listed = time.monotonic_ns() - start
        start = time.monotonic_ns()
        st = os.stat('b.txt', dir_fd=directory, follow_symlinks=False)
        stated = time.monotonic_ns() - start
    finally:
        os.close(directory)
    assert observed == sorted(Path(p).name for p in expected if p.startswith('sub/'))
    assert st.st_size == len(expected['sub/b.txt'])
    reads = []
    for name, content in expected.items():
        fd = os.open(root / name, os.O_RDONLY | os.O_NOFOLLOW)
        try:
            assert os.fstat(fd).st_size == len(content)
            start = time.monotonic_ns()
            got = os.pread(fd, len(content), 0)
            elapsed = time.monotonic_ns() - start
            assert got == content, name
            reads.append(dict(path=name, elapsed_ns=elapsed, bytes=len(got)))
        finally:
            os.close(fd)
    return dict(open_and_list_ns=listed, lookup_and_stat_ns=stated, pread=reads,
                round_elapsed_ns=time.monotonic_ns() - round_start)


def total_overlay_config(config, arm, manifest_key):
    """Pair the shared Packed caches; the standalone arm has no workspace."""
    assert arm in ('production', 'candidate', 'packed-direct')
    config = dict(config, cache=dict(config['cache']))
    config['cache'].update(read_memory_bytes=0, read_ssd_bytes=0, packed_cache='off',
                           packed_cache_bytes=0, prefetch_enabled=False, range_background_prefetch=False)
    if arm == 'packed-direct':
        config.update(volume_format='packed-snapshot', volume={'format': 'packed-snapshot'},
                      packed_manifest_key=manifest_key)
        config.pop('workspace', None)
        config.pop('workspace_namespace', None)
    return config


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary', type=Path, required=True)
    parser.add_argument('--candidate-binary', type=Path,
                        help='Optional optimized Overlay binary; overlay-total adds a third, interleaved arm')
    parser.add_argument('--candidate-source-patch', type=Path)
    parser.add_argument('--producer', type=Path, required=True)
    parser.add_argument('--source-commit', required=True)
    parser.add_argument('--source-patch', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--pairs', type=int, default=3)
    parser.add_argument('--passes', type=int, default=128)
    parser.add_argument('--build-profile', choices=('optimized-release', 'debug'), default='optimized-release',
                        help='Record the actual binary profile; debug runs validate correctness only')
    parser.add_argument('--comparison', choices=('empty-cache', 'overlay-tax', 'cold-native', 'overlay-total'), default='empty-cache',
                        help='overlay-tax requires the archived read-only ablation patch; includes unmodified production mode')
    parser.add_argument('--object-meter', choices=('proxy', 'client'), default='proxy',
                        help='client: direct S3 with BrewFS phase counters for cold-native or overlay-total')
    parser.add_argument('--workspace-format', choices=('workspace-v1', 'workspace'), default='workspace-v1',
                        help='Historical builds use workspace-v1; current main requires workspace')
    parser.add_argument('--cache-state', choices=('both', 'on', 'off'), default='both',
                        help='Use on for version comparisons with the same enabled read cache')
    parser.add_argument('--metadata-sync', choices=('remote', 'local-journal', 'local-buffered'), default='remote',
                        help='Metadata acknowledgement mode; each cell gets an independent local journal')
    parser.add_argument('--metadata-edits', type=int, default=0,
                        help='After hot reads, time repeated chmod/stat plus final fsync/close separately')
    parser.add_argument('--rust-log', default='warn',
                        help='Rust tracing filter; verbose diagnosis must use a separate output from performance runs')
    parser.add_argument('--total-fixture', choices=('standard', 'many10000'), default='standard')
    parser.add_argument('--total-temperatures', choices=('both', 'warm'), default='both')
    parser.add_argument('--total-row-cache-bytes', type=int, default=64 << 20)
    parser.add_argument('--total-payload-cache-bytes', type=int, default=8 << 20)
    parser.add_argument('--total-lower-build', choices=('baseline', 'candidate'), default='baseline',
                        help='Choose the binary for standalone lower; legacy runs used baseline')
    args = parser.parse_args()
    if args.total_lower_build == 'candidate':
        assert args.comparison == 'overlay-total' and args.candidate_binary
    assert os.geteuid() == 0, 'run under sudo for private RustFS volume ownership'
    assert args.pairs >= 3 and 1 <= args.passes <= 4096
    assert 0 <= args.metadata_edits <= 4096
    assert args.total_row_cache_bytes >= 0 and args.total_payload_cache_bytes >= 0
    if args.comparison != 'overlay-total':
        assert (args.total_fixture, args.total_temperatures, args.total_row_cache_bytes,
                args.total_payload_cache_bytes) == ('standard', 'both', 64 << 20, 8 << 20)
    phased = args.comparison in ('cold-native', 'overlay-total')
    assert args.object_meter == 'proxy' or phased
    if args.comparison in ('overlay-tax', 'cold-native', 'overlay-total'):
        assert args.metadata_sync == 'remote' and args.metadata_edits == 0
        assert args.workspace_format == 'workspace' and args.cache_state == 'on'
        assert args.build_profile == 'optimized-release'
    assert re.fullmatch('[0-9a-f]{40}', args.source_commit)
    for path in [args.binary, args.producer, args.source_patch]:
        assert path.is_absolute() and path.is_file()
    if args.candidate_binary:
        assert args.comparison == 'overlay-total' and args.candidate_source_patch
        for path in (args.candidate_binary, args.candidate_source_patch):
            assert path.is_absolute() and path.is_file()
    else:
        assert args.candidate_source_patch is None
    active_binary = args.binary
    args.out.mkdir(parents=True, exist_ok=False)
    work = Path(tempfile.mkdtemp(prefix='brewfs-hot-local-'))
    owner = 'brewfs-hot-' + uuid.uuid4().hex[:10]
    containers = [owner + '-redis', owner + '-rustfs']
    access, secret = secrets.token_hex(12), secrets.token_hex(24)
    env = dict(os.environ, AWS_ACCESS_KEY_ID=access, AWS_SECRET_ACCESS_KEY=secret,
               BREWFS_METADATA_SYNC=args.metadata_sync,
               AWS_REGION='us-east-1', AWS_EC2_METADATA_DISABLED='true',
               RUST_LOG=args.rust_log, NO_PROXY='127.0.0.1,localhost',
               BREWFS_PACKED_VERIFY_MEMO='0',
               BREWFS_FUSE_READ_DIRECT_IO='1', BREWFS_WORKSPACE_ROW_CACHE_TTL_MS='600000')
    payload_cache_setting = ('BREWFS_PACKED_RETAINED_PAYLOAD_BYTES' if args.workspace_format == 'workspace'
                             else 'BREWFS_PACKED_V3_RETAINED_PAYLOAD_BYTES')
    for key in ('BREWFS_PACKED_RETAINED_PAYLOAD_BYTES', 'BREWFS_PACKED_V3_RETAINED_PAYLOAD_BYTES'):
        env.pop(key, None)
    env[payload_cache_setting] = str(8 << 20)
    for name in ('BREWFS_PACKED_WORKSPACE_READ_CONTROL', 'BREWFS_PACKED_WORKSPACE_EXTENT_CONTROL'):
        env.pop(name, None)
    if args.comparison in ('overlay-tax', 'cold-native', 'overlay-total'):
        env['BREWFS_WORKSPACE_ROW_CACHE_TTL_MS'] = '60000'
        env['BREWFS_WORKSPACE_ROW_CACHE_BYTES'] = str(64 << 20)
    if args.comparison == 'overlay-total':
        env['BREWFS_PACKED_METADATA_CACHE_BYTES'] = str(256 << 20)
        env['BREWFS_WORKSPACE_ROW_CACHE_BYTES'] = str(args.total_row_cache_bytes)
        env[payload_cache_setting] = str(args.total_payload_cache_bytes)
        env.pop('BREWFS_PACKED_METADATA_ARM', None)
    result = dict(schema='hot-overlay-local-v1', passed=False, source_commit=args.source_commit,
                  owner=owner, temporary_directory=str(work), containers=containers,
                  started_unix_ns=time.time_ns(), host=dict(kernel=platform.release(), machine=platform.machine(),
                                                          cpu_count=os.cpu_count(), python=platform.python_version(),
                                                          swaps=Path('/proc/swaps').read_text(), loadavg=os.getloadavg()),
                  source_patch_sha256=sha(args.source_patch), binary_sha256=sha(args.binary),
                  harness_sha256=sha(Path(__file__).resolve()),
                  producer_sha256=sha(args.producer), images=dict(redis=REDIS, rustfs=RUSTFS),
                  argv=list(map(str, __import__('sys').argv)), cells=[], commands=[],
                  runtime_env={key: value for key, value in env.items() if key.startswith('BREWFS_') or key in ('RUST_LOG', 'AWS_EC2_METADATA_DISABLED')},
                  metadata_sync=args.metadata_sync, cache_state=args.cache_state, workspace_format=args.workspace_format,
                  build_profile=args.build_profile,
                  comparison=(f'same {args.build_profile} binary; new empty-query cache disabled/enabled; writable Overlay in both arms'
                              if args.cache_state == 'both' else
                              f'{args.build_profile} binary; empty-query cache fixed {args.cache_state}; writable Overlay'))
    save(args.out / 'ownership.json', dict(owner=owner, temporary_directory=str(work), containers=containers))
    if args.comparison == 'overlay-tax':
        result.update(schema='hot-overlay-tax-v1',
                      comparison='same optimized binary; production vs overlay-read vs lower-read; empty upper; same fences and permission path')
    if args.comparison == 'cold-native':
        result.update(schema='overlay-cold-native-v1',
                      object_meter=args.object_meter,
                      comparison='fresh remount and cache directory; first round vs subsequent reads; native-overlay is workspace without Packed lower, files in writable layer',
                      cold_scope='client process and client cache only; backend Redis/RustFS and host caches are not flushed')
    if args.comparison == 'overlay-total':
        result.update(schema='overlay-total-v1', object_meter=args.object_meter,
                      total_settings=dict(fixture=args.total_fixture, temperatures=args.total_temperatures,
                                          upper_row_cache_bytes=args.total_row_cache_bytes,
                                          retained_payload_bytes=args.total_payload_cache_bytes,
                                          packed_metadata_bytes=256 << 20),
                      comparison='writable WorkspaceMetaLayer vs standalone PackedReadonlyMeta; same immutable manifest, binary and shared cache budgets; no upper-bypass ablation',
                      cold_scope='client process and client cache only; backend Redis/RustFS and host caches are not flushed')
        if args.candidate_binary:
            result.update(schema='overlay-version-total-v1',
                          candidate_binary_sha256=sha(args.candidate_binary),
                          candidate_source_patch_sha256=sha(args.candidate_source_patch),
                          comparison='baseline Overlay, candidate Overlay and standalone Packed; one immutable manifest and identical cache budgets')
        result['total_settings']['lower_build'] = args.total_lower_build
    process, logfile, point = None, None, None

    def invoke(argv, *, check=True, timeout=60):
        argv = list(map(str, argv))
        # Never record the ephemeral access/secret used by local services.
        result['commands'].append([part.replace(access, '[local-access]').replace(secret, '[local-secret]') for part in argv])
        done = subprocess.run(argv, env=env, capture_output=True, text=True, timeout=timeout)
        if check and done.returncode:
            raise RuntimeError(f'{argv[0]} exited {done.returncode}: {done.stderr[-2000:]}')
        return done

    def docker(*argv, **kwargs):
        return invoke(['docker', *argv], **kwargs)

    def mounted():
        return point is not None and any(row.split()[4] == str(point) for row in Path('/proc/self/mountinfo').read_text().splitlines())

    def stop():
        nonlocal process, logfile
        if process is None:
            return
        if mounted():
            invoke(['fusermount3', '-u', point], timeout=15)
        try:
            code = process.wait(timeout=20)
        except subprocess.TimeoutExpired:
            process.terminate()
            try:
                code = process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                code = process.wait(timeout=5)
        logfile.close()
        process = logfile = None
        assert code == 0 and not mounted(), 'mount did not exit cleanly'

    def wait_for(predicate, label, interval=.1):
        until = time.monotonic() + 30
        while time.monotonic() < until:
            if predicate():
                return
            time.sleep(interval)
        raise TimeoutError(label)

    def start_mount(config_path, log_path, mount_env=None):
        nonlocal process, logfile
        assert process is None
        logfile = log_path.open('xb')
        mount_command = [str(active_binary), 'mount', '--config', str(config_path), str(point)]
        result['commands'].append(mount_command)
        process = subprocess.Popen(mount_command, env=env if mount_env is None else mount_env,
                                   stdout=logfile, stderr=subprocess.STDOUT)

        def ready():
            if process.poll() is not None:
                raise RuntimeError(f'mount failed: {log_path}')
            return mounted()
        wait_for(ready, 'FUSE mount', interval=.001 if args.comparison == 'overlay-total' else .1)

    try:
        for image in (REDIS, RUSTFS):
            assert docker('image', 'inspect', '--format', '{{.Id}}', image).stdout.strip() == image
        result['backend_version'] = verify_backend(invoke)
        common = ['run', '--pull', 'never', '-d', '--label', 'brewfs.hot.owner=' + owner]
        docker(*common, '--name', containers[0], '-p', '127.0.0.1::6379', '--memory', '256m', '--cpus', '1',
               REDIS, 'redis-server', '--appendonly', 'no', '--save', '')
        rustenv = work / 'rustfs.env'
        rustenv.write_text(f'RUSTFS_ACCESS_KEY={access}\nRUSTFS_SECRET_KEY={secret}\n')
        rustenv.chmod(0o600)
        command = [*common, '--name', containers[1], '-p', '127.0.0.1::9000', '--memory', '2g', '--cpus', '2', '--env-file', rustenv]
        settings = dict(RUSTFS_ADDRESS='0.0.0.0:9000', RUSTFS_CONSOLE_ENABLE='false', RUSTFS_VOLUMES='/data/rustfs{0...3}',
                        RUSTFS_UNSAFE_BYPASS_DISK_CHECK='true', RUSTFS_OBS_LOGGER_LEVEL='warn', RUSTFS_OBS_LOG_DIRECTORY='/var/log/rustfs',
                        RUSTFS_OBS_METRICS_EXPORT_ENABLED='false', RUSTFS_OBS_TRACES_EXPORT_ENABLED='false', RUSTFS_OBS_LOGS_EXPORT_ENABLED='false',
                        RUSTFS_OBS_PROFILING_EXPORT_ENABLED='false', RUSTFS_EC_BLOCK_SIZE_HINT_ENABLE='true',
                        RUSTFS_EC_BLOCK_SIZE_HINT_FLEET_CONFIRMED='true', RUSTFS_EC_READ_QUANTUM_ENABLE='true', RUSTFS_EC_READ_QUANTUM_FLEET_CONFIRMED='true')
        for key, value in settings.items():
            command += ['-e', key + '=' + value]
        for leaf, target in [(str(i), '/data/rustfs' + str(i)) for i in range(4)] + [('rustlogs', '/var/log/rustfs')]:
            path = work / leaf
            path.mkdir()
            os.chown(path, 10001, 10001)
            command += ['-v', str(path) + ':' + target]
        docker(*command, RUSTFS)
        redis_port = int(docker('port', containers[0], '6379/tcp').stdout.strip().rsplit(':', 1)[1])
        rustfs_port = int(docker('port', containers[1], '9000/tcp').stdout.strip().rsplit(':', 1)[1])
        wait_for(lambda: docker('exec', containers[0], 'redis-cli', 'ping', check=False).stdout.strip() == 'PONG', 'Redis')
        endpoint = f'http://127.0.0.1:{rustfs_port}'
        def rustfs_ready():
            connection = HTTPConnection('127.0.0.1', rustfs_port, timeout=2)
            try:
                connection.request('GET', '/health')
                response = connection.getresponse()
                response.read()
                return response.status == 200
            except (OSError, HTTPException):
                return False
            finally:
                connection.close()
        wait_for(rustfs_ready, 'RustFS health')
        s3 = boto3.client('s3', endpoint_url=endpoint, region_name='us-east-1', aws_access_key_id=access, aws_secret_access_key=secret,
                          config=Config(signature_version='s3v4', connect_timeout=2, read_timeout=10, retries={'total_max_attempts': 3}, s3={'addressing_style': 'path'}))
        with meter(rustfs_port) as (metered_endpoint, s3_counts):
            scenarios = ('two-files', 'small-files-32') if args.comparison in ('overlay-tax', 'cold-native', 'overlay-total') else ('two-files', 'modified-upper')
            if args.comparison == 'overlay-total' and args.total_fixture == 'many10000':
                scenarios = ('many-files-10000',)
            for scenario in scenarios:
                payload = {'a.txt': b'packed smoke\n', 'sub/b.txt': bytes(range(64))}
                if scenario == 'many-files-10000':
                    payload = {'a.txt': bytes(range(256)) * 16, 'sub/b.txt': bytes(reversed(range(256))) * 16}
                    payload.update({f'sub/item-{i:05}.bin': bytes((i + j) % 256 for j in range(4096))
                                    for i in range(9998)})
                    assert len(payload) == 10000 and sum(map(len, payload.values())) == 40960000
                if scenario == 'small-files-32':
                    payload.update({f'sub/item-{i:02}.bin': bytes((i + j) % 256 for j in range(4096)) for i in range(30)})
                if scenario == 'modified-upper':
                    payload.update({'sub/edit.bin': bytes(range(256)) * 16, 'sub/delete.txt': b'delete me', 'stable.bin': bytes(range(256)) * 16})
                src = work / ('src-' + scenario)
                (src / 'sub').mkdir(parents=True)
                for name, content in payload.items():
                    (src / name).write_bytes(content)
                # Workspace initialization appends a 36-character UUID.
                bucket = 'hot-' + owner.rsplit('-', 1)[1] + ('-a' if scenario == 'two-files' else '-b')
                s3.create_bucket(Bucket=bucket)
                manifest = work / ('manifest-' + scenario)
                invoke([args.producer, '--source-directory', src, '--source-consistency', 'best-effort-detected', '--source-hardlink-policy', 'visible-links',
                        '--output-dir', work / ('objects-' + scenario), '--manifest-output', manifest, '--bucket', bucket, '--endpoint', endpoint,
                        '--region', 'us-east-1', '--force-path-style', 'true', '--prefix', 'base', '--metadata-codec', 'raw', '--data-codec', 'raw',
                        '--inline-data', 'off', '--chunk-size', '67108864', '--block-size', '4194304', '--s3-rustfs-ec-block-size-hint', 'auto'], timeout=120)
                data = dict(backend='s3', s3=dict(bucket=bucket, endpoint=endpoint if args.object_meter == 'client' else metered_endpoint, region='us-east-1', force_path_style=True, rustfs_ec_block_size_hint='auto'))
                data_config = work / ('data-' + scenario + '.json')
                data_config.write_text(json.dumps({'data': data}))
                for pair in range(args.pairs):
                    cache_order = [False, True] if pair % 2 == 0 else [True, False]
                    if args.cache_state != 'both':
                        cache_order = [args.cache_state == 'on']
                    arms = [(enabled, 'production', 'warm') for enabled in cache_order]
                    if args.comparison == 'overlay-tax':
                        from itertools import permutations
                        order = list(permutations(('production', 'overlay-read', 'lower-read')))[pair % 6]
                        arms = [(True, arm, 'warm') for arm in order]
                    if args.comparison == 'cold-native':
                        import random
                        conditions = [(arm, state) for arm in ('production', 'overlay-read', 'lower-read', 'native-overlay')
                                      for state in ('cold', 'warm')]
                        random.Random(20261113 + pair).shuffle(conditions)
                        arms = [(True, arm, state) for arm, state in conditions]
                    if args.comparison == 'overlay-total':
                        order = ('production', 'packed-direct') if pair % 2 == 0 else ('packed-direct', 'production')
                        if args.candidate_binary:
                            from itertools import permutations
                            order = list(permutations(('production', 'candidate', 'packed-direct')))[pair % 6]
                        temperatures = ('cold', 'warm') if pair % 2 == 0 else ('warm', 'cold')
                        if args.total_temperatures == 'warm':
                            temperatures = ('warm',)
                        arms = [(True, arm, state) for state in temperatures for arm in order]
                    for enabled, arm, cache_temperature in arms:
                        suffix = arm if args.comparison == 'overlay-tax' else ('on' if enabled else 'off')
                        if phased:
                            suffix = arm + '-' + cache_temperature
                        label = f'{scenario}-pair{pair+1}-' + suffix
                        assert sha(args.binary) == result['binary_sha256'], 'binary changed during pairing'
                        use_candidate = arm == 'candidate' or (
                            arm == 'packed-direct' and args.total_lower_build == 'candidate')
                        active_binary = args.candidate_binary if use_candidate else args.binary
                        if args.candidate_binary:
                            assert sha(args.candidate_binary) == result['candidate_binary_sha256'], 'candidate changed during pairing'
                        out = args.out / label
                        out.mkdir()
                        namespace = label + '-' + uuid.uuid4().hex[:8]
                        rurl = f'redis://127.0.0.1:{redis_port}/0'
                        init = ['init-volume'] if arm == 'native-overlay' else ['init-packed-volume', '--manifest-key', manifest.read_text().strip()]
                        parent = {'workspace_id': None}
                        if arm != 'packed-direct':
                            parent = json.loads(invoke([active_binary, 'workspace', '--meta-backend', 'redis', '--meta-url', rurl,
                                                       '--workspace-namespace', namespace, *init, '--data-config', data_config]).stdout)
                        point = work / label
                        point.mkdir()
                        config = dict(volume_format=args.workspace_format, volume={'format': args.workspace_format}, workspace=parent['workspace_id'], workspace_namespace=namespace,
                                      data=data, meta={'backend': 'redis', 'redis': {'url': rurl}}, layout=dict(chunk_size=67108864, block_size=4194304),
                                      fuse=dict(workers=4, max_background=128, cache_ttl_ms=0, keep_cache=False),
                                      cache=dict(cache_root=str(work / ('cache-' + label)), writeback_mode='upload_before_commit', read_memory_bytes=536870912, read_ssd_bytes=0, compression='none'))
                        if args.comparison == 'overlay-total':
                            config = total_overlay_config(config, arm, manifest.read_text().strip())
                        config_path = out / 'config.json'
                        save(config_path, config)
                        env['BREWFS_WORKSPACE_EMPTY_QUERY_CACHE'] = str(int(enabled))
                        env.pop('BREWFS_PACKED_WORKSPACE_READ_CONTROL', None)
                        if arm in ('overlay-read', 'lower-read'):
                            env['BREWFS_PACKED_WORKSPACE_READ_CONTROL'] = arm
                        if args.metadata_sync != 'remote':
                            env['BREWFS_METADATA_JOURNAL_DIR'] = str(work / ('journal-' + label))
                        else:
                            env.pop('BREWFS_METADATA_JOURNAL_DIR', None)
                        if phased:
                            # Prepare and verify once, then really unmount. Never delete a live cache.
                            preparation_config = dict(config, cache=dict(config['cache'], cache_root=str(work / ('prepare-cache-' + label))))
                            preparation_path = out / 'prepare-config.json'
                            save(preparation_path, preparation_config)
                            start_mount(preparation_path, out / 'prepare-mount.log')
                            if arm == 'native-overlay':
                                (point / 'sub').mkdir()
                                for name, content in payload.items():
                                    with (point / name).open('wb') as f:
                                        f.write(content)
                                        f.flush()
                                        os.fsync(f.fileno())
                            measured_round(point, payload)
                            stop()
                            assert not Path(config['cache']['cache_root']).exists()
                            save(out / 'remount-proof.json', dict(clean_unmount=True, same_workspace=parent['workspace_id'],
                                 preparation_cache=preparation_config['cache']['cache_root'], measured_cache=config['cache']['cache_root'],
                                 manifest_key=manifest.read_text().strip(), mount_format=config['volume_format'],
                                 measured_cache_absent_before_mount=True, native_data_in_writable_layer=arm == 'native-overlay'))
                        mount_s3_before = s3_counts()
                        if args.comparison == 'overlay-total':
                            mount_redis_before = commandstats(redis_port)
                        mount_started = time.monotonic_ns()
                        start_mount(config_path, out / 'mount.log')
                        mount_elapsed_ns = time.monotonic_ns() - mount_started
                        mount_s3 = delta(s3_counts(), mount_s3_before)
                        if args.comparison == 'overlay-total':
                            time.sleep(.3)
                            (out / 'mount.stats').write_text((point / '.stats').read_text())
                            mount_redis_after = commandstats(redis_port)
                        mount_row = next(row for row in Path('/proc/self/mountinfo').read_text().splitlines() if row.split()[4] == str(point))
                        assert 'rw' in mount_row.split()[5].split(','), 'the comparison requires writable Overlay'
                        (out / 'mountinfo.txt').write_text(mount_row + '\n')
                        save(out / 'runtime-env.json', {key: value for key, value in env.items()
                             if key.startswith('BREWFS_') or key == 'TOKIO_WORKER_THREADS'})
                        expected = payload.copy()
                        warmup_started = time.monotonic_ns()
                        warmup_s3_before = s3_counts()
                        # Warm old empty results before mutating: correctness
                        # checks must catch stale negatives in the same mount.
                        if not phased or cache_temperature == 'warm':
                            measured_round(point, expected)
                            measured_round(point, expected)
                        if scenario == 'modified-upper':
                            path = point / 'sub/edit.bin'
                            fd = os.open(path, os.O_RDWR)
                            try:
                                os.pwrite(fd, b'upper-overwrite', 32)
                                os.fsync(fd)
                                os.ftruncate(fd, 128)
                                os.ftruncate(fd, 4096)
                                os.fsync(fd)
                            finally:
                                os.close(fd)
                            changed = bytearray(payload['sub/edit.bin'])
                            changed[32:47] = b'upper-overwrite'
                            changed[128:] = bytes(4096 - 128)
                            expected['sub/edit.bin'] = bytes(changed)
                            os.unlink(point / 'sub/delete.txt')
                            del expected['sub/delete.txt']
                            (point / 'sub/new.txt').write_bytes(b'new upper file')
                            fd = os.open(point / 'sub/new.txt', os.O_RDONLY)
                            os.fsync(fd)
                            os.close(fd)
                            expected['sub/new.txt'] = b'new upper file'
                            os.rename(point / 'sub/new.txt', point / 'sub/renamed.txt')
                            expected['sub/renamed.txt'] = expected.pop('sub/new.txt')
                        warm = []
                        for index in range(0 if phased and cache_temperature == 'cold' else 3):
                            before = s3_counts()
                            measured_round(point, expected)
                            warm.append(delta(s3_counts(), before))
                        save(out / 'warm.json', dict(rounds=warm, after=s3_counts()))
                        warmup_elapsed_ns = time.monotonic_ns() - warmup_started
                        warmup_s3 = delta(s3_counts(), warmup_s3_before)
                        if warm:
                            assert all(value == 0 for value in warm[-1].values()), f'lower/upper not hot: {warm}'
                        if phased:
                            # Native object counters are mirrored by VFS every 100 ms.
                            # Wait outside timed phases so the preceding phase is fully reflected.
                            time.sleep(.3)
                        (out / 'before.stats').write_text((point / '.stats').read_text())
                        before_stats = metrics((out / 'before.stats').read_text())
                        if args.comparison == 'overlay-total':
                            assert before_stats['brewfs_packed_v3_payload_retention_capacity_bytes'] == args.total_payload_cache_bytes
                            assert before_stats['brewfs_packed_index_cache_configured_bytes'] == 256 << 20
                            if arm != 'packed-direct':
                                assert before_stats['brewfs_workspace_row_cache_capacity_bytes'] == args.total_row_cache_bytes
                                assert before_stats['brewfs_workspace_row_cache_retained_bytes'] <= args.total_row_cache_bytes
                        before_redis = commandstats(redis_port)
                        before_s3 = s3_counts()
                        assert before_s3['inflight'] == 0, 'object request still active before measurement'
                        if phased:
                            first = measured_round(point, expected)
                            first_s3 = delta(s3_counts(), before_s3)
                            first_redis = commandstats(redis_port)
                            time.sleep(.3)
                            (out / 'first.stats').write_text((point / '.stats').read_text())
                            first_stats = metrics((out / 'first.stats').read_text())
                            steady_s3_before = s3_counts()
                            steady_redis_before = commandstats(redis_port)
                            started = time.monotonic_ns()
                            steady_samples = [measured_round(point, expected) for _ in range(args.passes)]
                            steady_elapsed = time.monotonic_ns() - started
                            samples = [first, *steady_samples]
                            elapsed = first['round_elapsed_ns'] + steady_elapsed
                        else:
                            started = time.monotonic_ns()
                            samples = [measured_round(point, expected) for _ in range(args.passes)]
                            elapsed = time.monotonic_ns() - started
                        after_s3 = s3_counts()
                        after_redis = commandstats(redis_port)
                        if phased:
                            time.sleep(.3)
                        (out / 'after.stats').write_text((point / '.stats').read_text())
                        stats_delta = delta(metrics((out / 'after.stats').read_text()), before_stats)
                        remote_delta = delta(after_s3, before_s3)
                        cell = dict(label=label, cache_enabled=enabled, scenario=scenario, pair=pair+1, arm=arm, elapsed_ns=elapsed,
                                    binary_sha256=sha(active_binary),
                                    rustfs_before=before_s3, rustfs_after=after_s3,
                                    warm_s3=warm, rustfs_delta=remote_delta, stats_delta=stats_delta,
                                    redis_before=before_redis, redis_after=after_redis,
                                    redis_delta={key: delta({field: number for field, number in value.items() if field != 'usec_per_call'}, before_redis.get(key, {})) for key, value in after_redis.items()},
                                    expected_sha256={name: hashlib.sha256(content).hexdigest() for name, content in expected.items()}, samples=samples)
                        save(out / 'hot-read.json', cell)
                        assert after_s3['inflight'] == 0, 'object request still active after measurement'
                        if phased:
                            steady_s3 = delta(after_s3, steady_s3_before)
                            objects_before = client_objects((out / 'before.stats').read_text(), arm)
                            objects_first = client_objects((out / 'first.stats').read_text(), arm)
                            objects_after = client_objects((out / 'after.stats').read_text(), arm)
                            first_objects = delta(objects_first, objects_before)
                            steady_objects = delta(objects_after, objects_first)
                            assert all(value >= 0 for value in first_objects.values()), 'object counters reset'
                            assert not any(steady_objects.values()), 'subsequent full reads are not hot'
                            if cache_temperature == 'warm':
                                assert not any(first_objects.values()), 'warm first read caused object I/O'
                            else:
                                assert first_objects['read_requests'] > 0 and first_objects['body_bytes'] > 0, 'fresh remount did not demonstrate a cold object read'
                            if args.object_meter == 'proxy':
                                assert not any(steady_s3.values())
                                assert first_objects['body_bytes'] == first_s3['received_bytes'], 'client/meter byte counts disagree'
                                assert first_objects['read_requests'] == first_s3['gets' if arm == 'native-overlay' else 'requests'], 'client/meter request counts disagree'
                            assert stats_delta['brewfs_fuse_read_ops_total'] == (args.passes + 1) * len(expected)
                            cell.update(cache_temperature=cache_temperature, first_round=first,
                                object_meter=args.object_meter, first_objects=first_objects, steady_objects=steady_objects,
                                object_counter_scope='native-overlay: S3 GETs; Packed: HTTP attempts including HEAD; bytes: response bodies',
                                stats_settle_seconds=.3,
                                first_s3=first_s3, first_redis_delta=redis_delta(first_redis, before_redis),
                                first_stats_delta=delta(first_stats, before_stats), steady_elapsed_ns=steady_elapsed,
                                steady_rounds=args.passes, steady_s3=steady_s3,
                                steady_redis_delta=redis_delta(after_redis, steady_redis_before),
                                steady_stats_delta=delta(metrics((out / 'after.stats').read_text()), first_stats),
                                mount_elapsed_ns=mount_elapsed_ns, mount_s3=mount_s3,
                                warmup_elapsed_ns=warmup_elapsed_ns, warmup_s3=warmup_s3,
                                timing_scope='elapsed_ns sums first-round and steady-loop active wall time; inter-phase counter collection excluded')
                        else:
                            assert all(value == 0 for value in remote_delta.values()), 'remote traffic in measured phase'
                            assert stats_delta['brewfs_fuse_read_ops_total'] == args.passes * len(expected)
                        if args.comparison == 'overlay-total':
                            cell['manifest_key'] = manifest.read_text().strip()
                            cell['mount_format'] = config['volume_format']
                            cell['cache_config'] = {k: v for k, v in config['cache'].items() if k != 'cache_root'}
                            cell['mount_objects'] = client_objects((out / 'mount.stats').read_text(), arm)
                            cell['warmup_objects'] = delta(objects_before, cell['mount_objects'])
                            cell['mount_redis_delta'] = redis_delta(mount_redis_after, mount_redis_before)
                            cell['warmup_redis_delta'] = redis_delta(before_redis, mount_redis_after)
                            if cache_temperature == 'cold':
                                assert not any(cell['warmup_objects'].values()), 'object reads after mount before cold phase'
                            if arm == 'packed-direct':
                                for stage in ('mount_redis_delta', 'warmup_redis_delta', 'redis_delta'):
                                    assert all(v.get('calls', 0) == 0 for k, v in cell[stage].items() if k != 'info'), 'standalone snapshot accessed Redis'
                                assert all(value == 0 for key, value in stats_delta.items() if key.startswith('brewfs_workspace_') and key.endswith('_total')), 'standalone snapshot used Workspace operations'
                        if phased and arm in ('overlay-read', 'lower-read', 'packed-direct'):
                            import errno
                            try:
                                forbidden = os.open(point / 'a.txt', os.O_WRONLY)
                            except OSError as error:
                                assert error.errno == errno.EROFS
                                cell['write_open_rejected'] = True
                            else:
                                os.close(forbidden)
                                raise AssertionError('read-only control accepted a write open')
                        if args.comparison == 'overlay-tax':
                            if arm == 'lower-read':
                                assert stats_delta['brewfs_workspace_read_extent_control_bypasses_total'] == args.passes * len(expected)
                                assert stats_delta['brewfs_workspace_upper_extent_queries_total'] == 0
                                assert stats_delta['brewfs_workspace_upper_extent_empty_cache_hits_total'] == 0
                                assert stats_delta['brewfs_workspace_read_namespace_control_lookup_bypasses_total'] > 0
                                assert stats_delta['brewfs_workspace_read_namespace_control_getattr_bypasses_total'] > 0
                            elif arm == 'overlay-read':
                                assert stats_delta['brewfs_workspace_read_extent_control_queries_total'] == args.passes * len(expected)
                                assert stats_delta['brewfs_workspace_read_extent_control_bypasses_total'] == 0
                            # Controlled modes must reject a write open without changing the tree.
                            if arm != 'production':
                                import errno
                                try:
                                    forbidden = os.open(point / 'a.txt', os.O_WRONLY)
                                except OSError as error:
                                    assert error.errno == errno.EROFS, error
                                    cell['write_open_rejected'] = True
                                else:
                                    os.close(forbidden)
                                    raise AssertionError('read-only control accepted a write open')
                            measured_round(point, expected)
                        if args.metadata_edits:
                            name = sorted(expected)[0]
                            target = point / name
                            fd = os.open(target, os.O_RDONLY)
                            metadata_before = commandstats(redis_port)
                            metadata_s3_before = s3_counts()
                            samples = []
                            chmod_samples, stat_samples = [], []
                            started = time.monotonic_ns()
                            try:
                                for index in range(args.metadata_edits):
                                    permissions = 0o600 if index % 2 == 0 else 0o640
                                    operation_start = time.monotonic_ns()
                                    os.chmod(target, permissions)
                                    chmod_end = time.monotonic_ns()
                                    assert os.stat(target).st_mode & 0o777 == permissions
                                    operation_end = time.monotonic_ns()
                                    samples.append(operation_end - operation_start)
                                    chmod_samples.append(chmod_end - operation_start)
                                    stat_samples.append(operation_end - chmod_end)
                                active_ns = time.monotonic_ns() - started
                                os.fsync(fd)
                            finally:
                                os.close(fd)
                            total_ns = time.monotonic_ns() - started
                            metadata_after = commandstats(redis_port)
                            metadata_s3_after = s3_counts()
                            cell['metadata_edits'] = dict(path=name, count=args.metadata_edits,
                                latency_schema='chmod-stat-v2', chmod_ns=chmod_samples, stat_ns=stat_samples,
                                final_mode=permissions, operation_ns=samples, active_ns=active_ns,
                                total_with_drain_ns=total_ns, redis_before=metadata_before,
                                redis_after=metadata_after,
                                rustfs_before=metadata_s3_before, rustfs_after=metadata_s3_after,
                                rustfs_delta=delta(metadata_s3_after, metadata_s3_before),
                                redis_delta={key: delta({field: number for field, number in value.items() if field != 'usec_per_call'}, metadata_before.get(key, {})) for key, value in metadata_after.items()})
                            save(out / 'metadata-phase.json', cell)
                        stop()
                        if args.metadata_sync != 'remote':
                            journal = work / ('journal-' + label) / 'state.bin'
                            shutil.copyfile(journal, out / 'metadata-journal.bin')
                            cell['metadata_journal_sha256'] = sha(journal)
                            cell['metadata_journal_bytes'] = journal.stat().st_size
                        if args.metadata_sync != 'remote' or args.metadata_edits:
                            # A fresh process in remote mode must see the final
                            # tree without reading our local journal. This is
                            # outside the timed hot-read interval.
                            remount_env = dict(env, BREWFS_METADATA_SYNC='remote')
                            remount_env.pop('BREWFS_METADATA_JOURNAL_DIR', None)
                            start_mount(config_path, out / 'remount-remote.log', remount_env)
                            cell['remote_remount_samples'] = measured_round(point, expected)
                            if args.metadata_edits:
                                assert os.stat(point / cell['metadata_edits']['path']).st_mode & 0o777 == cell['metadata_edits']['final_mode']
                            stop()
                            cell['remote_remount_verified'] = True
                        save(out / 'result.json', cell)
                        result['cells'].append({key: cell[key] for key in ('label', 'scenario', 'pair', 'arm', 'cache_enabled', 'elapsed_ns')})
                        if phased:
                            result['cells'][-1]['cache_temperature'] = cache_temperature
                        print(label, round(elapsed / 1e6, 3), 'ms', flush=True)
            result['passed'] = True
    except Exception as error:
        result['error'] = (type(error).__name__ + ': ' + str(error)).replace(access, '[local-access]').replace(secret, '[local-secret]')
        raise
    finally:
        cleanup = {}
        try:
            stop()
        except Exception as error:
            cleanup['mount_error'] = str(error)
        for name in containers:
            try:
                found = docker('inspect', '--format', '{{index .Config.Labels "brewfs.hot.owner"}}', name, check=False)
                if found.returncode == 0 and found.stdout.strip() == owner:
                    docker('rm', '-f', '-v', name)
                cleanup[name] = docker('inspect', name, check=False).returncode != 0
            except Exception as error:
                cleanup[name] = False
                cleanup[name + '_error'] = str(error)
        cleanup['mount_absent'] = not mounted()
        result['cleanup'] = cleanup
        if cleanup['mount_absent'] and all(cleanup.get(name) for name in containers):
            shutil.rmtree(work)
        else:
            result['passed'] = False
        if 'mount_error' in cleanup:
            result['passed'] = False
        result['finished_unix_ns'] = time.time_ns()
        save(args.out / 'run.json', result)
        (args.out / 'SHA256SUMS').write_text(''.join(f'{sha(path)}  {path.relative_to(args.out).as_posix()}\n' for path in sorted(args.out.rglob('*')) if path.is_file()))


if __name__ == '__main__':
    main()
