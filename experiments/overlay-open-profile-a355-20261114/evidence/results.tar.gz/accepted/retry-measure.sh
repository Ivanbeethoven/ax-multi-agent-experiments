#!/usr/bin/env bash
set -euo pipefail
r=/srv/ax-overlay-open-retry-20261114
trap 'echo $? > "$r/measure.exit"' EXIT
for phase in build check; do
  deadline=$((SECONDS + 7200))
  while test ! -f "$r/$phase.exit"; do
    test "$SECONDS" -lt "$deadline" || exit 124
    sleep 10
  done
  test "$(cat "$r/$phase.exit")" = 0
done
test "$(cat "$r/checks/status.txt")" = passed
export GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=http.proxy GIT_CONFIG_VALUE_0=http://127.0.0.1:17901
bash "$r/harness/experiments/overlay-open-profile-a355-20261114/run.sh" \
  /srv/ax-overlay-fixes-20261114/artifacts "$r/artifacts" "$r/results"
