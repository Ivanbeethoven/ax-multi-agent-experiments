#!/usr/bin/env bash
set -euo pipefail
r=/srv/ax-overlay-open-retry-20261114
trap 'echo $? > "$r/measure-tail30.exit"' EXIT
deadline=$((SECONDS + 3600))
while test ! -f "$r/measure3.exit"; do
  test "$SECONDS" -lt "$deadline" || exit 124
  sleep 10
done
test "$(cat "$r/measure3.exit")" = 0
export GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=http.proxy GIT_CONFIG_VALUE_0=http://127.0.0.1:17901
bash "$r/harness/experiments/overlay-open-profile-a355-20261114/run_tail30.sh" \
  /srv/ax-overlay-fixes-20261114/artifacts "$r/artifacts" "$r/results/fio-tail30"
