#!/usr/bin/env bash
set -euo pipefail
r=/srv/ax-overlay-open-profile-20261114
cd "$r/candidate"
export PATH=/srv/ax-overlay-tax-20261113/toolchain/bin:$PATH
export CARGO_HOME=/srv/ax-overlay-tax-20261113/cargo
export CARGO_TARGET_DIR=/srv/ax-overlay-tax-20261113/target
export CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 CARGO_BUILD_JOBS=12
features=fuse-io-uring-runtime,workspace,native-packed-base,frozen-base-metadata,rustfs-ec-block-size-hint,observability
trap 'echo $? > "$r/check.exit"' EXIT
# Shell scripts in the Windows archive use CRLF; normalize this disposable
# source copy before running the shell CI gate.
find docker/compose-xfstests -type f -name '*.sh' -exec sed -i 's/\r$//' {} +
sed -i 's/\r$//' tools/perf/check_overlay_hot.sh
cargo test --offline --locked --lib --no-default-features --features "$features" hot_handle_futures -- --nocapture >"$r/size-after.log" 2>&1
cargo test --offline --locked --lib --no-default-features --features "$features" hot_path_profile -- --nocapture >"$r/profile-test.log" 2>&1
bash tools/perf/check_overlay_hot.sh "$r/checks"
