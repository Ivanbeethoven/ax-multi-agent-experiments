#!/usr/bin/env bash
set -euo pipefail
r=/srv/ax-overlay-open-profile-20261114
trap 'echo $? > "$r/fio-diagnostic.exit"' EXIT
exec 9>/run/lock/ax-overlay-open-diagnostic.lock
flock -n 9
export GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=http.proxy GIT_CONFIG_VALUE_0=http://127.0.0.1:17901
python3 "$r/harness/experiments/overlay-open-a355-20261113/run_fio_guard.py" --prepared-file \
  --producer "$r/artifacts/packed_snapshot_fixture" \
  --source-commit 03c8cc55d61473533c00a8afe13b4ef1fcd9b725 \
  --workspace-format workspace --build-profile optimized-release \
  --cache-state on --metadata-sync remote --pairs 3 \
  --binary /srv/ax-overlay-fixes-20261114/artifacts/brewfs --candidate-binary "$r/artifacts/brewfs" \
  --source-patch /srv/ax-overlay-fixes-20261114/artifacts/source.patch --candidate-source-patch "$r/artifacts/source.patch" \
  --comparison overlay-total --object-meter client --total-temperatures warm \
  --total-row-cache-bytes 67108864 --total-payload-cache-bytes 8388608 \
  --passes 2 --total-fixture standard --rust-log warn,brewfs::vfs::fs=debug \
  --out "$r/fio-diagnostic" >"$r/fio-diagnostic.log" 2>&1
