#!/usr/bin/env bash
set -euo pipefail
r=/srv/ax-overlay-fixes-20261114
cd "$r"
exec 9>/run/lock/ax-overlay-open-diagnostic.lock
flock -n 9
trap 'echo $? > repro-replace.exit' EXIT
export GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=http.proxy GIT_CONFIG_VALUE_0=http://127.0.0.1:17901
{ date -Is; uptime; df -B1 /srv; docker ps --format '{{.Names}} {{.Status}}'; } >repro-replace-host.txt
python3 /srv/ax-overlay-scale-20261114/harness/experiments/overlay-scale-a355-20261114/run_mutations.py \
 --concurrent-kind replace --rust-log warn,brewfs::fuse=debug,brewfs::vfs::fs=debug \
 --binary /srv/ax-overlay-scale-20261114/artifacts/brewfs \
 --producer /srv/ax-overlay-tax-20261113/total/artifacts/packed_snapshot_fixture \
 --source-commit 03c8cc55d61473533c00a8afe13b4ef1fcd9b725 \
 --source-patch /srv/ax-overlay-scale-20261114/artifacts/source.patch \
 --workspace-format workspace --build-profile optimized-release \
 --comparison empty-cache --object-meter proxy --cache-state on \
 --metadata-sync remote --metadata-edits 8 --pairs 3 --passes 32 --out "$r/repro-replace" \
 >repro-replace.log 2>&1
