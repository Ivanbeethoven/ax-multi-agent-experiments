#!/usr/bin/env bash
set -euo pipefail
r=/srv/ax-overlay-fixes-20261114
trap 'echo $? > "$r/shell-ci.exit"' EXIT
# Preserve original source and failed CRLF receipt. Normalize only the shell
# check copy; all Rust commands in checks/ already completed before bash -n.
cp -a "$r/source" "$r/shell-ci-source"
python3 - "$r/shell-ci-source" >"$r/shell-normalization.json" <<'PY'
import json, sys
from pathlib import Path
changed = []
for path in Path(sys.argv[1]).rglob('*.sh'):
    raw = path.read_bytes()
    if b'\r\n' in raw:
        path.write_bytes(raw.replace(b'\r\n', b'\n'))
        changed.append(str(path.relative_to(sys.argv[1])))
print(json.dumps(dict(changed=changed, transformation='CRLF to LF in shell-check copy only'), indent=2))
PY
cd "$r/shell-ci-source"
for script in run_perf_in_container.sh run_redis_perf.sh run_juicefs_perf_in_container.sh run_juicefs_perf.sh; do
  bash -n "docker/compose-xfstests/$script"
done
for script in test_perf_report_delta.sh test_juicefs_direct_matrix.sh test_juicefs_perf_report.sh; do
  bash "docker/compose-xfstests/$script" >"$r/checks/$script.log" 2>&1
done
printf 'passed\n' >"$r/checks/status.txt"
