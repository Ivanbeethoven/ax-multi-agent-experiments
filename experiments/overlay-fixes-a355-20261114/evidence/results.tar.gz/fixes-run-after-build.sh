#!/usr/bin/env bash
set -euo pipefail
r=/srv/ax-overlay-fixes-20261114
while test ! -f "$r/green.exit"; do sleep 15; done
test "$(cat "$r/green.exit")" = 0
for command in brewfs fio rustc; do
  if pgrep -x "$command"; then echo "Other $command process present; stop before measurements"; exit 1; fi
done
cp "$r/source.patch" "$r/artifacts/source.patch"
export GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=http.proxy GIT_CONFIG_VALUE_0=http://127.0.0.1:17901
exec bash "$r/harness/experiments/overlay-fixes-a355-20261114/run.sh" \
  /srv/ax-overlay-scale-20261114/artifacts "$r/artifacts" "$r/validation-01"
