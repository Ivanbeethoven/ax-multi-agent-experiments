#!/usr/bin/env bash
set -euo pipefail
r=/srv/ax-overlay-fixes-20261114
trap 'echo $? > "$r/debug-run.exit"' EXIT
exec 9>/run/lock/ax-overlay-open-diagnostic.lock
flock -n 9
export GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=http.proxy GIT_CONFIG_VALUE_0=http://127.0.0.1:17901
for kind in replace mixed; do
  python3 "$r/harness/experiments/overlay-fixes-a355-20261114/run_correctness.py" \
    --check "$kind" --binary "$r/debug-artifacts/brewfs" \
    --source-patch "$r/source.patch" --producer /srv/ax-overlay-tax-20261113/total/artifacts/packed_snapshot_fixture \
    --source-commit 03c8cc55d61473533c00a8afe13b4ef1fcd9b725 \
    --workspace-format workspace --build-profile debug --comparison empty-cache \
    --object-meter proxy --cache-state on --metadata-sync remote --metadata-edits 8 \
    --rust-log warn,brewfs::fuse=debug,brewfs::vfs::fs=debug \
    --pairs 3 --passes 1 --out "$r/debug-$kind-02" >"$r/debug-$kind-02.log" 2>&1
done
