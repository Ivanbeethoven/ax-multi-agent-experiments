#!/usr/bin/env bash
set -euo pipefail
r=/srv/ax-overlay-fixes-20261114
trap 'echo $? > "$r/fixed-release.exit"' EXIT
# The existing CI child continues independently; no measurements until both finish.
cd "$r/source"
export PATH=/srv/ax-overlay-tax-20261113/toolchain/bin:$PATH
export CARGO_HOME=/srv/ax-overlay-tax-20261113/cargo CARGO_TARGET_DIR=/srv/ax-overlay-tax-20261113/release-target
export CARGO_BUILD_JOBS=12 CARGO_INCREMENTAL=0 CARGO_PROFILE_RELEASE_DEBUG=0
features=fuse-io-uring-runtime,workspace,native-packed-base,frozen-base-metadata,rustfs-ec-block-size-hint,observability
{ rustc -Vv; env | grep '^CARGO_'; } >"$r/release-environment.txt"
cargo --config profile.release.package.brewfs.opt-level=3 build --offline --locked --release --bin brewfs --no-default-features --features "$features" >"$r/release.log" 2>&1
mkdir -p "$r/artifacts"
cp "$CARGO_TARGET_DIR/release/brewfs" "$r/artifacts/brewfs"
cp /srv/ax-overlay-tax-20261113/total/artifacts/packed_snapshot_fixture "$r/artifacts/packed_snapshot_fixture"
cp "$r/source.patch" "$r/artifacts/source.patch"
sha256sum "$r/artifacts/"* >"$r/binary-SHA256SUMS"
while kill -0 205544 2>/dev/null; do sleep 10; done
test "$(cat "$r/checks/status.txt")" = passed
