#!/usr/bin/env bash
set -euo pipefail
r=/srv/ax-overlay-fixes-20261114
trap 'echo $? > "$r/green.exit"' EXIT
cd "$r/source"
export PATH=/srv/ax-overlay-tax-20261113/toolchain/bin:$PATH
export CARGO_HOME=/srv/ax-overlay-tax-20261113/cargo CARGO_TARGET_DIR=/srv/ax-overlay-tax-20261113/target
export CARGO_BUILD_JOBS=12 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 RUST_TEST_THREADS=2
features=fuse-io-uring-runtime,workspace,native-packed-base,frozen-base-metadata,rustfs-ec-block-size-hint,observability
cargo fmt --all
cargo test --offline --locked --lib --no-default-features --features "$features" replaced_lookup_open_requests -- --nocapture >"$r/green-open.log" 2>&1
cargo test --offline --locked --lib --no-default-features --features "$features" packed_snapshot_tests -- --nocapture >"$r/green-snapshot.log" 2>&1
bash tools/perf/check_overlay_hot.sh "$r/checks" >"$r/checks-launch.log" 2>&1
export CARGO_TARGET_DIR=/srv/ax-overlay-tax-20261113/release-target
cargo --config profile.release.package.brewfs.opt-level=3 build --offline --locked --release --bin brewfs --no-default-features --features "$features" >"$r/release.log" 2>&1
mkdir -p "$r/artifacts"
cp "$CARGO_TARGET_DIR/release/brewfs" "$r/artifacts/brewfs"
cp /srv/ax-overlay-tax-20261113/total/artifacts/packed_snapshot_fixture "$r/artifacts/packed_snapshot_fixture"
sha256sum "$r/artifacts/"* >"$r/binary-SHA256SUMS"
