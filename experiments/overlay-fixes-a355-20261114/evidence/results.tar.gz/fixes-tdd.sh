#!/usr/bin/env bash
set -uo pipefail
r=/srv/ax-overlay-fixes-20261114
cd "$r/source"
export PATH=/srv/ax-overlay-tax-20261113/toolchain/bin:$PATH
export CARGO_HOME=/srv/ax-overlay-tax-20261113/cargo CARGO_TARGET_DIR=/srv/ax-overlay-tax-20261113/target
export CARGO_BUILD_JOBS=12 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 RUST_TEST_THREADS=2
features=fuse-io-uring-runtime,workspace,native-packed-base,frozen-base-metadata,rustfs-ec-block-size-hint,observability
cargo fmt --all
for filter in replaced_lookup_open_requests pending_publication_is_distinct publication_wait_is_bounded; do
  cargo test --offline --locked --lib --no-default-features --features "$features" "$filter" -- --nocapture >"$r/tdd-$filter.log" 2>&1
  echo $? >"$r/tdd-$filter.exit"
done
printf 'done\n' >"$r/tdd.finished"
