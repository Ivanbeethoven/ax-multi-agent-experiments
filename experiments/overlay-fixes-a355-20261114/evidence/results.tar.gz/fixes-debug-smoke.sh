#!/usr/bin/env bash
set -euo pipefail
r=/srv/ax-overlay-fixes-20261114
trap 'echo $? > "$r/debug-smoke.exit"' EXIT
cd "$r/source"
export PATH=/srv/ax-overlay-tax-20261113/toolchain/bin:$PATH
export CARGO_HOME=/srv/ax-overlay-tax-20261113/cargo CARGO_TARGET_DIR=/srv/ax-overlay-tax-20261113/target
export CARGO_BUILD_JOBS=12 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0
features=fuse-io-uring-runtime,workspace,native-packed-base,frozen-base-metadata,rustfs-ec-block-size-hint,observability
cargo build --offline --locked --bin brewfs --no-default-features --features "$features" >"$r/debug-build.log" 2>&1
mkdir "$r/debug-artifacts"
cp "$CARGO_TARGET_DIR/debug/brewfs" "$r/debug-artifacts/brewfs"
sha256sum "$r/debug-artifacts/brewfs" >"$r/debug-artifacts/SHA256SUMS"
exec 9>/run/lock/ax-overlay-open-diagnostic.lock
flock -n 9
export GIT_CONFIG_COUNT=1 GIT_CONFIG_KEY_0=http.proxy GIT_CONFIG_VALUE_0=http://127.0.0.1:17901
for kind in replace mixed; do
  python3 "$r/harness/experiments/overlay-fixes-a355-20261114/run_correctness.py" \
    --check "$kind" --binary "$r/debug-artifacts/brewfs" \
    --source-patch "$r/source.patch" --producer /srv/ax-overlay-tax-20261113/total/artifacts/packed_snapshot_fixture \
    --source-commit 03c8cc55d61473533c00a8afe13b4ef1fcd9b725 \
    --workspace-format workspace --build-profile debug --comparison empty-cache \
    --object-meter proxy --cache-state on --metadata-sync remote --metadata-edits 8 \
    --rust-log warn,brewfs::fuse=debug,brewfs::vfs::fs=debug \
    --pairs 1 --passes 1 --out "$r/debug-$kind" >"$r/debug-$kind.log" 2>&1
done
