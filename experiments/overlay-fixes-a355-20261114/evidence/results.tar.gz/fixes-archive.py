"""Archive results/scripts only, never binary, build tree, or workspace data."""
import hashlib
import json
from pathlib import Path
import tarfile

r = Path('/srv/ax-overlay-fixes-20261114')
assert (r / 'validation-01/exit-code.txt').read_text().strip() == '0'
assert (r / 'checks/status.txt').read_text().strip() == 'passed'
assert (r / 'fixed-release.exit').read_text().strip() == '0'
for group, cells in [('replace', 6), ('mixed', 6), ('fio', 6), ('small', 18), ('large64', 9)]:
    run = json.loads((r / 'validation-01' / group / 'run.json').read_text())
    assert run['passed'] and len(run['cells']) == cells
    assert run['cleanup']['mount_absent']
    assert all(run['cleanup'][name] for name in run['containers'])

paths = set()
for directory in ['checks', 'harness', 'validation-01', 'repro-replace', 'debug-replace-02', 'debug-mixed-02']:
    for path in (r / directory).rglob('*'):
        if path.is_file() and '__pycache__' not in path.parts:
            paths.add(path)
suffixes = {'.json', '.log', '.txt', '.md', '.sh', '.py', '.exit', '.finished', '.patch', '.sha256'}
paths.update(p for p in r.iterdir() if p.is_file() and p.suffix in suffixes
             and not (p.name.startswith('archive') and p.suffix == '.json'))
paths.add(r / 'binary-SHA256SUMS')
paths.add(r / 'debug-artifacts/SHA256SUMS')
archive = r.with_name(r.name + '-results-v2.tar.gz')
assert not archive.exists()
with tarfile.open(archive, 'w:gz', compresslevel=6) as target:
    for path in sorted(paths):
        assert not path.is_symlink()
        target.add(path, arcname=path.relative_to(r), recursive=False)
digest = hashlib.file_digest(archive.open('rb'), 'sha256').hexdigest()
print(json.dumps(dict(file=archive.name, files=len(paths), bytes=archive.stat().st_size, sha256=digest), indent=2))
